//
// Created by niclas on 28.05.18.
//

#pragma once

#include <cmath>
#include <geometry_msgs/PoseStamped.h>
#include <pcl_ros/point_cloud.h>
#include <nav_msgs/Path.h>
#include <opencv2/opencv.hpp>
#include <hphlib/pcl.h>


constexpr float RAD_2_DEG = static_cast<float>(180.0/M_PI);

constexpr float MAXIMUM_BOUNDARY_JUMP_SQUARED = 11.0f * 11.0f; //20 meters

constexpr float OFFSET_OBSTACLE_PATH = 1.5f;
constexpr float OFFSET_DRIVING_PATH = 1.5f;

constexpr int SMOOTHING_NUMBER = 2;
constexpr int MIN_POSES_THRESHOLD = 3;
constexpr float MAXIMUM_BOUNDARY_ANGLE_JUMP_RAD = 1.0472f; // 60°

/**
 * Initial offset in meters for boundary search from center of car
 */
constexpr float BOUNDARY_Y_OFFSET = 2.0f;
constexpr int TILES_PER_METER = 5;
constexpr int SEARCH_DIST_SIDEWAYS = 4;
constexpr int SEARCH_DIST_FORWARD = 10;



template <typename Pt>
inline Eigen::Vector3f pclToEigen(const Pt& point) {
    return Eigen::Vector3f(point.x, point.y, point.z);
}


inline Eigen::Vector3f stampedPoseToEigen(const geometry_msgs::PoseStamped& pose) {
    return Eigen::Vector3f(static_cast<const float &>(pose.pose.position.x),
                           static_cast<const float &>(pose.pose.position.y),
                           static_cast<const float &>(pose.pose.position.z));
}

inline Eigen::Vector2f stampedPoseToPoint(const geometry_msgs::PoseStamped& pose) {
    return Eigen::Vector2f(static_cast<const float &>(pose.pose.position.x),
                           static_cast<const float &>(pose.pose.position.y));
}


/**
 * returns angle between two vectors as RADIANT!
 * @param vector1
 * @param vector2
 * @return
 */
inline float angleBetweenVectors(const Eigen::Vector3f& vector1, const Eigen::Vector3f& vector2) {
    return std::acos(vector1.dot(vector2)/(vector1.norm() * vector2.norm()));
}



enum class ColorClass {
    YellowOrRedOrFinish,
    BlueOrRedOrFinish,
    RedOrFinish
};

enum class ConeColor {
    Red,
    Yellow,
    Blue,
    Finish
};


template <typename Pt>
inline float lengthSquared(const Pt& point) {
    return point.x * point.x + point.y * point.y + point.z * point.z;
}

template <typename Pt>
inline float length(const Pt& point) {
    return std::sqrt(lengthSquared(point));
}

template <typename Pt>
inline float normalizedDot(const Pt& p1, const Pt& p2) {
    float dot = p1.x * p2.x + p1.y * p2.y + p1.z * p2.z;

    float p1_l = length(p1);
    float p2_l = length(p2);

    return dot / (p1_l * p2_l);
}



inline geometry_msgs::PoseStamped poseFromEigen(const Eigen::Vector3f& vec) {
    geometry_msgs::PoseStamped pose;

    pose.pose.position.x = vec[0];
    pose.pose.position.y = vec[1];
    pose.pose.position.z = vec[2];

    return pose;
}


inline bool isMatchingCone(const pcl::PointXYZRGB& pt, ColorClass clazz) {
    ConeColor cone_color;

    if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_RED)) {
        cone_color = ConeColor::Red;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_BLUE)) {
        cone_color = ConeColor::Blue;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_YELLOW)) {
        cone_color = ConeColor::Yellow;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_FINISH)) {
        cone_color = ConeColor ::Finish;
    } else {
        return false;
    }

    if (clazz == ColorClass::BlueOrRedOrFinish) {
        return cone_color == ConeColor::Blue || cone_color == ConeColor::Red || cone_color == ConeColor::Finish;
    } else if (clazz == ColorClass::YellowOrRedOrFinish) {
        return cone_color == ConeColor::Yellow || cone_color == ConeColor::Red || cone_color == ConeColor::Finish;
    } else if (clazz == ColorClass::RedOrFinish) {
        return cone_color == ConeColor::Red || cone_color == ConeColor::Finish;
    } else {
        return false;
    }
}
