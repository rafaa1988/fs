#include <ros/ros.h>
#include <telemetry/Runner.h>
#include "BordersAndPath.h"
#include <hphlib/util.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "pathfinder");
    ros::NodeHandle n("~");

    std::string topic_path     = getRequiredRosParam<std::string>(n, "topic_path");
    BordersAndPath pathfinder(topic_path, n);
    telemetry::Runner tele("template");

    ROS_INFO("Pathfinder node launched");

    ros::spin();

    return EXIT_SUCCESS;
}