#include <ros/ros.h>
#include <pcl_ros/transforms.h>
#include <hphlib/pcl.h>
#include <hphlib/Control.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/OccupancyGrid.h>
#include "BordersAndPath.h"
#include <std_msgs/Float32.h>
#include <hphlib/util.h>
//#include "utility.h"
//#include "PathFollowing.h"



BordersAndPath::BordersAndPath(std::string& pub, ros::NodeHandle& n)
    : frame_id_path_((getRequiredRosParam<std::string>(n, "frame_id_path")))
    , topic_local_map_((getRequiredRosParam<std::string>(n, "topic_local_map")))
    , local_map_sub_(n.subscribe(topic_local_map_, 1, &BordersAndPath::pointcloudCallback, this))
    , legacy_minimum_distance_(getRequiredRosParam<float>(n, "legacy_minimum_distance"))
    , legacy_lean_in_factor_(getRequiredRosParam<float>(n, "legacy_lean_in_factor"))
{

    center_line_publisher_ = n.advertise<nav_msgs::Path>(pub, 1);
    left_bound_publisher_ = n.advertise<nav_msgs::Path>("left", 1);
    right_bound_publisher_ = n.advertise<nav_msgs::Path>("right", 1);
    grid_cell_publisher_ = n.advertise<nav_msgs::OccupancyGrid>("grid", 1);
    //control_publisher_ = n.advertise<hphlib::Control>("/control", 1);

}



size_t BordersAndPath::next(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass clazz, bool weightAngles)    {

    size_t best = std::numeric_limits<size_t>::max();
    float best_score = std::numeric_limits<float>::max();

    pcl::PointXYZRGB forward;
    forward.x = 1;

    for (size_t i = 0; i < cloud.size(); ++i) {

        const auto& point(cloud[i]);

        // Skip behind car
        if (point.x <= 0.0f) {
            continue;
        }

        // Skip wrong color
        if (!isMatchingCone(point, clazz)) {
            continue;
        }

        float squared_distance = lengthSquared(point);

        // Skip if too close
        if (squared_distance < legacy_minimum_distance_ * legacy_minimum_distance_) {
            continue;
        }

        // Normalized dot in range [0, 1] where 1 is best (straight on a line) and 0 is worst (90° turn)
        // Therefore weight subtracting from 1.1 such that a small weight always remains and normalized dot of 1
        // yields to smallest score
        float angle_weight = weightAngles
            ? 1.1f - normalizedDot(forward, point)
            : 1;

        float score = squared_distance * angle_weight;

        if (score < best_score) {
            best = i;
            best_score = score;
        }
    }

    return best;
}

nav_msgs::Path BordersAndPath::offsetPath(const nav_msgs::Path path, float offset) {
    nav_msgs::Path resultPath;
    resultPath.header.frame_id = path.header.frame_id;

    resultPath.poses.push_back(poseFromEigen(Eigen::Vector3f::Zero()));

    for (size_t i = 1; i < path.poses.size(); ++i) {
        Eigen::Vector3f first = stampedPoseToEigen(path.poses[i-1]);

        // skip if behind car
        if (first.x() < 0)
            continue;

        Eigen::Vector3f second = stampedPoseToEigen(path.poses[i]);
        Eigen::Vector3f diff = second - first;
        diff.normalize();
        Eigen::Vector3f toCenter = diff.cross(Eigen::Vector3f::UnitZ());

        auto pose = poseFromEigen(second + (offset * toCenter));
        pose.pose.orientation.z = 1.0;
        resultPath.poses.push_back(pose);
        //resultPath.poses.push_back(poseFromEigen(second + (offset * toCenter)));
        //if (!std::isnan(poseFromEigen(second + (offset * toCenter)).pose.position.x)) {
        //}
    }

    return resultPath;
}


nav_msgs::Path BordersAndPath::simpleDrivingPath(const nav_msgs::Path& leftPath, const nav_msgs::Path& rightPath) {

    //select longest boundary path
    if (leftPath.poses.size() > rightPath.poses.size()) {
        return offsetPath(leftPath, OFFSET_DRIVING_PATH);
    } else {
        return offsetPath(rightPath, -OFFSET_DRIVING_PATH);
    }
}

nav_msgs::Path BordersAndPath::boundary(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass color, float initial_y_offset) {

    nav_msgs::Path path;
    path.header.frame_id = cloud.header.frame_id;

    // Initially go left or right for first cone depending on initial y offset
    Eigen::Affine3f initial_offset_transform = Eigen::Affine3f::Identity();
    initial_offset_transform.translate(Eigen::Vector3f(0.0f, -initial_y_offset, 0.0f));

    // Check if there is a cone behind us
    pcl::PointXYZRGB min_cone;
    float min_cone_dist = 5 * 5;
    bool found_cone = false;
    for (auto &cone: cloud) {
        if (isMatchingCone(cone, color)) {
            float d = cone.x * cone.x + cone.y * cone.y;
            // check if cone is behind us, on the same side as we would expect and closer than min_cone
            if (cone.x < 0 &&  d < min_cone_dist && cone.y * initial_y_offset > 0) {
                min_cone = cone;
                min_cone_dist = d;
                found_cone = true;
            }
        }
    }
    if (found_cone) {
        path.poses.push_back(poseFromEigen(pclToEigen(min_cone)));
    }

    // Immediately apply reverse of initial offset to stacked reverse transform
    Eigen::Affine3f reverse_transform = Eigen::Affine3f::Identity();
    reverse_transform.translate(Eigen::Vector3f(0.0f, initial_y_offset, 0.0f));

    // Rewrite working copy to initial offset
    pcl::PointCloud<pcl::PointXYZRGB> copy;
    pcl::transformPointCloud(cloud, copy, initial_offset_transform);

    pcl::PointCloud<pcl::PointXYZRGB> temp;

    for (int i = 0; i < 20; ++i) {
        // Don't weight angles for first cone as not on boundary yet
        size_t cone_i = next(copy, color, i != 0);

        // Stop if no more cones found
        if (cone_i == std::numeric_limits<size_t>::max()) {
            break;
        }

        const auto& cone(copy[cone_i]);

        // Abort if too far to cone
        if (lengthSquared(cone) >= MAXIMUM_BOUNDARY_JUMP_SQUARED) {
            break;
        }

        float angle = 0.0f;

        // Don't rotate for first cone since angle is expected to be large as origin is not on boundary yet
        if (i != 0) {
            angle = std::atan2(cone.y, cone.x);

            // Angle on red or finish cones should be tighter, as they are placed in a line
            if (isMatchingCone(cone, ColorClass::RedOrFinish) && std::abs(angle) > MAXIMUM_BOUNDARY_ANGLE_JUMP_RAD / 2) {
                break;
            }
            // Break if angle absurd
            if (std::abs(angle) > MAXIMUM_BOUNDARY_ANGLE_JUMP_RAD) {
                break;
            }
        }

        // Lean in for better curves
        angle *= legacy_lean_in_factor_;

        auto pose = poseFromEigen(reverse_transform * pclToEigen(cone));
        pose.pose.orientation.z = 1;
        //path.poses.push_back(poseFromEigen(reverse_transform * pclToEigen(cone)));
        path.poses.push_back(pose);

        Eigen::Affine3f frame_transform = Eigen::Affine3f::Identity();
        frame_transform.rotate(Eigen::AngleAxisf(-angle, Eigen::Vector3f::UnitZ())).translate(Eigen::Vector3f(-cone.x, -cone.y, -cone.z));

        pcl::transformPointCloud(copy, temp, frame_transform);
        copy.swap(temp);

        // Apply inverse of all transformations in reverse order to get identity with forward transform
        reverse_transform.translate(Eigen::Vector3f(cone.x, cone.y, cone.z)).rotate(Eigen::AngleAxisf(angle, Eigen::Vector3f::UnitZ()));

        // Swap and pop used cone
        // std::swap(copy[i], copy.back());
        // copy.points.pop_back();
    }

    return path;
}


void BordersAndPath::interpolateBoundaryPath(nav_msgs::Path& boundaryPath, size_t intermediatePoints) {
    if (intermediatePoints == 0) {
        return;
    }

    std::vector<geometry_msgs::PoseStamped> newPoses;

    for (size_t i = 1; i < boundaryPath.poses.size(); ++i) {
        Eigen::Vector3f first = stampedPoseToEigen(boundaryPath.poses[i-1]);
        Eigen::Vector3f second = stampedPoseToEigen(boundaryPath.poses[i]);
        Eigen::Vector3f diff = second - first;

        newPoses.reserve((1+intermediatePoints) * boundaryPath.poses.size());

        newPoses.push_back(boundaryPath.poses[i-1]);
        for (size_t j = 0; j < intermediatePoints; ++j) {
            Eigen::Vector3f newPoint = first + (j+1) * (diff/(intermediatePoints+1));
            newPoses.push_back(poseFromEigen(newPoint));
        }

        newPoses.push_back(boundaryPath.poses[i]);
    }

    boundaryPath.poses = newPoses;
}


nav_msgs::Path BordersAndPath::calcCenterTrack(const nav_msgs::Path& leftBoundary, const nav_msgs::Path& rightBoundary) {

    nav_msgs::Path resultPath;

    std::vector<Eigen::Vector3f> leftBounds;
    std::vector<Eigen::Vector3f> rightBounds;

    // clean up boundaries to only contain points in front of us
    for(auto &pose: leftBoundary.poses) {
        if (pose.pose.position.x > 0) {
            leftBounds.push_back(stampedPoseToEigen(pose));
        }
    }

    for(auto &pose: rightBoundary.poses) {
        if (pose.pose.position.x > 0) {
            rightBounds.push_back(stampedPoseToEigen(pose));
        }
    }

    // check if there are enough boundaries to create a midline
    if (leftBounds.size() < MIN_POSES_THRESHOLD || rightBounds.size() < MIN_POSES_THRESHOLD) {
        return simpleDrivingPath(leftBoundary, rightBoundary);
    }

    // start from car origin
    resultPath.poses.push_back(poseFromEigen(Eigen::Vector3f::Zero()));

    size_t leftIndex = 0;
    size_t rightIndex = 0;

    bool calcLeft = leftBounds.size() > rightBounds.size();
    while (leftIndex < leftBounds.size() && rightIndex < rightBounds.size()) {
        Eigen::Vector3f left = leftBounds[leftIndex];
        Eigen::Vector3f right = rightBounds[rightIndex];

        Eigen::Vector3f result;
        if (calcLeft) {
            result = left + ((right - left) * 0.5f);
            leftIndex++;
        } else {
            result = right + ((left - right) * 0.5f);
            rightIndex++;
        }

        calcLeft = !calcLeft;

        resultPath.poses.push_back(poseFromEigen(result));
    }


    return resultPath;
}


void BordersAndPath::pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg) {
    nav_msgs::Path leftPath = boundary(*msg, ColorClass::BlueOrRedOrFinish, BOUNDARY_Y_OFFSET);
    nav_msgs::Path rightPath = boundary(*msg, ColorClass::YellowOrRedOrFinish, -BOUNDARY_Y_OFFSET);
    
    //nav_msgs::Path centerPath = calcCenterTrack(leftPath, rightPath);
    nav_msgs::Path centerPath = simpleDrivingPath(leftPath, rightPath);

    leftPath.header.frame_id = frame_id_path_;
    rightPath.header.frame_id = frame_id_path_;
    centerPath.header.frame_id = frame_id_path_;

    center_line_publisher_.publish(centerPath);
    left_bound_publisher_.publish(leftPath);
    right_bound_publisher_.publish(rightPath);
}
