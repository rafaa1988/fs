#pragma once

#include <pcl_ros/point_cloud.h>
//#include "search/AStar.h"
//#include "search/ObstacleGrid.h"
#include <nav_msgs/Path.h>
#include "utility.h"

class BordersAndPath {
public:

    BordersAndPath(std::string &pub, ros::NodeHandle &n);

private:
    const std::string frame_id_path_;
    const std::string topic_local_map_;
    ros::Subscriber local_map_sub_;
    ros::Publisher center_line_publisher_;
    ros::Publisher left_bound_publisher_;
    ros::Publisher right_bound_publisher_;
    ros::Publisher grid_cell_publisher_;
    //ros::Publisher control_publisher_;

    float legacy_minimum_distance_;
    float legacy_lean_in_factor_;

    size_t next(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass clazz, bool weightAngles = false);

    nav_msgs::Path boundary(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass color, float initial_y_offset);

    void pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg);

    nav_msgs::Path offsetPath(const nav_msgs::Path path, float offset);

    nav_msgs::Path calcCenterTrack(const nav_msgs::Path &leftBoundary, const nav_msgs::Path &rightBoundary);

    void interpolateBoundaryPath(nav_msgs::Path& boundaryPath, size_t intermediatePoints);

    nav_msgs::Path simpleDrivingPath(const nav_msgs::Path &leftPath, const nav_msgs::Path &rightPath);

};
