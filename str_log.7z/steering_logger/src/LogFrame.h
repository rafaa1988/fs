#pragma once

#include <hphlib/PackedEndian.h>

struct __attribute__((packed)) LogFrame {
    little_f32_t position_demand;
    little_f32_t position_actual;
    bool position_rx;
    little_f32_t velocity_demand;
    little_f32_t velocity_actual;
    bool velocity_rx;
    little_f32_t current_demand;
    little_f32_t current_actual;
    bool current_rx;
    bool steering_enabled;
    little_f32_t vehicle_velocity;
    little_f32_t lower_shaft_steering_torque;
    bool lower_shaft_steering_torque_rx;
    little_f32_t wheel_steering_angle;
    bool wheel_steering_rx;
    bool motor_rdy;
    little_f32_t target_steering_angle;
    little_f32_t system_clock;
};

static_assert(sizeof(LogFrame) == 51, "SIze mismatch");