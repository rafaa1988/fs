#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <fstream>
#include <hphlib/SteeringAngle.h>
#include <hphlib/WheelOdometry.h>
#include <hphlib/io/UdpSocket.h>
#include <hphlib/misc/PollService.h>
#include "LogFrame.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "steering_logger");

    uint16_t sink_port = 2002;

    ros::NodeHandle n("~");

    std::ofstream file_output_stream;

    hphlib::vehicle::StatusMonitor mon(n);

    telemetry::Runner tele("steer");

    auto start_handler = [&] () {
        std::stringstream file_name_stream;

        auto t = std::time(nullptr);
        auto tm = *std::localtime(&t);

        file_name_stream << "/bags/steering_log" << std::put_time(&tm, "%Y-%m-%d_%H-%M-%S") << ".csv";

        file_output_stream.open(file_name_stream.str(), std::ios_base::out);

        if (!file_output_stream) {
            ROS_ERROR_STREAM("Failed to create file output stream for " + file_name_stream.str());
        }

        // Write header
        file_output_stream << "Clock" << "; ";
        file_output_stream << "Position demand" << "; ";
        file_output_stream << "Position actual " << "; ";
        file_output_stream << "Velocity demand" << "; ";
        file_output_stream << "Velocity actual" << "; ";
        file_output_stream << "Current demand" << "; ";
        file_output_stream << "Current actual" << "; ";
        file_output_stream << "Steering enabled" << "; ";
        file_output_stream << "Vehicle velocity" << "; ";
        file_output_stream << "Lower shaft steering torque" << "; ";
        file_output_stream << "Wheel steering angle actual" << "; ";
        file_output_stream << "Wheel steering angle demand" << "; ";
        file_output_stream << "Motor ready" << "\n";
    };

    // Create new CSV when vehicle goes off
    mon.set_go_callback(start_handler);
    
    // Stop on off
    mon.set_off_callback([&] () {
        if (file_output_stream) {
            file_output_stream.close();
        }
    });

    // Periodically flush file stream to disk
    auto timer = n.createSteadyTimer(ros::WallDuration(1.0), [&] (const auto& ev) {

        (void) ev;
        
        tele.report("diag-rec", static_cast<bool>(file_output_stream));

        if (file_output_stream) {
            file_output_stream << std::flush;
        }
    });

    // Create socket where data logger is received
    hphlib::UdpSocket sock(sink_port, true);

    // Create poll service to receive UDP datagrams containing log info
    hphlib::PollService poll(sock, [&] () {

        LogFrame frame{};

        auto rx_bytes = sock.receive(reinterpret_cast<uint8_t *>(&frame), sizeof frame);

        if (rx_bytes != sizeof frame) {
            ROS_WARN_STREAM("Received log frame of incorrect size: " << rx_bytes);
        }
        
        // Stage all telemetry values even if not recording
        if (frame.lower_shaft_steering_torque_rx) {
            tele.stage("torque", frame.lower_shaft_steering_torque.native());
        }
        
        if (frame.position_rx) {
            tele.stage("enc-dmnd", frame.position_demand.native());
            tele.stage("enc-act", frame.position_actual.native());
        }
        
        if (frame.velocity_rx) {
            tele.stage("vel-dmnd", frame.velocity_demand.native());
            tele.stage("vel-act", frame.velocity_actual.native());
        }
        
        if (frame.current_rx) {
            tele.stage("cur-dmnd", frame.current_demand.native());
            tele.stage("cur-act", frame.current_actual.native());
        }
        
        if (!file_output_stream) {
            tele.report();
            return;
            // start_handler();
        }

        // Clock
        file_output_stream << frame.system_clock.native() << "; ";

        if (frame.position_rx) {
            file_output_stream << frame.position_demand.native() << "; " << frame.position_actual.native() << "; ";
        } else {
            file_output_stream << "; ; ";
        }

        if (frame.velocity_rx) {
            file_output_stream << frame.velocity_demand.native() << "; " << frame.velocity_actual.native() << "; ";
        } else {
            file_output_stream << "; ; ";
        }

        if (frame.current_rx) {
            file_output_stream << frame.current_demand.native() << "; " << frame.current_actual.native() << "; ";
        } else {
            file_output_stream << "; ; ";
        }

        file_output_stream << frame.steering_enabled << "; ";

        file_output_stream << frame.vehicle_velocity << "; ";

        if (frame.lower_shaft_steering_torque_rx) {
            file_output_stream << frame.lower_shaft_steering_torque.native() << "; ";
        } else {
            file_output_stream << "; ";
        }

        if (frame.wheel_steering_rx) {
            file_output_stream << frame.wheel_steering_angle.native() << "; ";
        } else {
            file_output_stream << "; ";
        }

        file_output_stream << frame.target_steering_angle.native() << "; ";
        file_output_stream << frame.motor_rdy << "\n";

        tele.report();
    });

    ROS_INFO_STREAM("Steering diagnostics logger listening on port " << sink_port);

    ros::spin();

    return EXIT_SUCCESS;
}
