# Software health monitor

This node monitors the health of specified system components to determine an overall software health
status of the ASCU.
