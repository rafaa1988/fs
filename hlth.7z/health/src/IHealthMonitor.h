#pragma once

#include <telemetry/Runner.h>

class IHealthMonitor {
public:
    enum class Health {
        Healthy, Ill, Dead
    };

private:
    telemetry::Runner* runner_;
    std::string telemetry_topic_;

protected:
    virtual Health getHealthInternal() = 0;

public:
    IHealthMonitor(telemetry::Runner& runner, const std::string& telemetry_topic);

    Health getHealth();

    virtual ~IHealthMonitor() = default;
};

bool operator<(IHealthMonitor::Health a, IHealthMonitor::Health b);