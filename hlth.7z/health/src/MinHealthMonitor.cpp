#include "MinHealthMonitor.h"

MinHealthMonitor::MinHealthMonitor(telemetry::Runner &runner, const std::string &tele_topic)
        : ICompositeHealthMonitor(runner, tele_topic)
{
}

IHealthMonitor::Health MinHealthMonitor::getHealthInternal() {
    IHealthMonitor::Health h = IHealthMonitor::Health::Healthy;

    for (auto& mon_ptr : monitors_) {
        IHealthMonitor::Health monitor_health = mon_ptr->getHealth();

        if (monitor_health < h) {
            h = monitor_health;
        }
    }

    return h;
}