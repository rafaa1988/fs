#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/Control.h>
#include <hphlib/Health.h>
#include <hphlib/Woof.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/CameraInfo.h>
#include <nav_msgs/Odometry.h>
#include "TopicHealthMonitor.h"
#include "PartialMaxHealthMonitor.h"
#include "MinHealthMonitor.h"
#include "MaxHealthMonitor.h"
#include "ControlWatchdog.h"

int main(int argc, char** argv) {

    ros::init(argc, argv, "health");

    ros::NodeHandle n("~");

    ros::Publisher pub(n.advertise<hphlib::Health>("/health/master", 1));

    telemetry::Runner runner("health");

    auto left_cam_health = std::make_unique<TopicHealthMonitor<sensor_msgs::CameraInfo>>(runner, "cam_l", n, "/master/camera_info", 8.0);
    auto right_cam_health = std::make_unique<TopicHealthMonitor<sensor_msgs::CameraInfo>>(runner, "cam_r", n, "/slave1/camera_info", 8.0);

    auto total_camera_health = std::make_unique<PartialMaxHealthMonitor>(runner, "cam_t");
    total_camera_health->add(std::move(left_cam_health));
    total_camera_health->add(std::move(right_cam_health));

    auto left_lidar_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "lidar_l", n, "/ibeo_lux_left/ibeo_pointcloud", 8.0);
    auto right_lidar_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "lidar_r", n, "/ibeo_lux_left/ibeo_pointcloud", 8.0);

    auto total_lidar_health = std::make_unique<PartialMaxHealthMonitor>(runner, "lidar_t");
    total_lidar_health->add(std::move(left_lidar_health));
    total_lidar_health->add(std::move(right_lidar_health));

    auto left_detection_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "detect_l", n, "/lidar/DetectL/cones", 8.0);
    auto right_detection_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "detect_r", n, "/lidar/DetectR/cones", 8.0);

    auto total_detection_health = std::make_unique<PartialMaxHealthMonitor>(runner, "detect_t");
    total_detection_health->add(std::move(left_detection_health));
    total_detection_health->add(std::move(right_detection_health));

    auto left_validation_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "valid_l", n, "/camValidL/cones", 8.0);
    auto right_validation_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "valid_r", n, "/camValidR/cones", 8.0);

    auto total_validation_health = std::make_unique<PartialMaxHealthMonitor>(runner, "valid_t");
    total_validation_health->add(std::move(left_validation_health));
    total_validation_health->add(std::move(right_validation_health));

    auto odo_health = std::make_unique<TopicHealthMonitor<nav_msgs::Odometry>>(runner, "odo", n, "/odometry/filtered", 8.0);

    auto slam_health = std::make_unique<TopicHealthMonitor<sensor_msgs::PointCloud2>>(runner, "slam", n, "/slam/cones", 8.0);

    auto control_health = std::make_unique<ControlWatchdog>(runner, "ctrl", n);

    MinHealthMonitor uber_system_health(runner, "master");
    uber_system_health.add(std::move(total_camera_health));
    uber_system_health.add(std::move(total_lidar_health));
    uber_system_health.add(std::move(total_detection_health));
    uber_system_health.add(std::move(total_validation_health));
    uber_system_health.add(std::move(odo_health));
    uber_system_health.add(std::move(slam_health));
    uber_system_health.add(std::move(control_health));

    ros::SteadyTimerCallback timer_cb = [&] (const ros::SteadyTimerEvent& ev) {
        (void) ev;

        auto health = uber_system_health.getHealth();

        int encoded_health = hphlib::Health::DEAD;

        if (health == IHealthMonitor::Health::Healthy) {
            encoded_health = hphlib::Health::HEALTHY;
        } else if (health == IHealthMonitor::Health::Ill) {
            encoded_health = hphlib::Health::ILL;
        }

        hphlib::Health health_msg;
        health_msg.header.stamp = ros::Time::now();
        health_msg.data = encoded_health;

        pub.publish(health_msg);

        runner.report();
    };

    auto timer = n.createSteadyTimer(ros::WallDuration(0.1), timer_cb);

    ros::spin();

    return EXIT_SUCCESS;
}