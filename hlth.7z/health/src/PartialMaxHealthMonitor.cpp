#include "PartialMaxHealthMonitor.h"

PartialMaxHealthMonitor::PartialMaxHealthMonitor(telemetry::Runner &runner, const std::string &topic)
        : ICompositeHealthMonitor(runner, topic)
{
}

IHealthMonitor::Health PartialMaxHealthMonitor::getHealthInternal() {

    auto best_health = IHealthMonitor::Health::Dead;
    auto worst_health = IHealthMonitor::Health::Healthy;

    for (auto& mon_ptr : monitors_) {
        auto health = mon_ptr->getHealth();

        best_health = std::max(health, best_health);
        worst_health = std::min(health, worst_health);
    }

    // If nothing is alive, we are so dead
    if (best_health == IHealthMonitor::Health::Dead) {
        return best_health;
    } else if (worst_health == IHealthMonitor::Health::Healthy) {
        // Else we could be at least ill for best, but if the worst health is healthy, that means everyone is healthy
        return worst_health;
    } else {
        // At least some nodes are ill or dead, but we are not fully dead, our state is ill
        return IHealthMonitor::Health::Ill;
    }
}
