#include "MaxHealthMonitor.h"

MaxHealthMonitor::MaxHealthMonitor(telemetry::Runner &runner, const std::string &topic)
    : ICompositeHealthMonitor(runner, topic)
{
}

IHealthMonitor::Health MaxHealthMonitor::getHealthInternal() {
    Health h = Health::Dead;

    for (auto& mon_ptr : monitors_) {
        h = std::max(h, mon_ptr->getHealth());
    }

    return h;
}
