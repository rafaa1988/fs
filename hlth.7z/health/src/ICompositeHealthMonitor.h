#pragma once

#include <memory>
#include <vector>
#include "IHealthMonitor.h"

/**
 * Base composite health monitor that encapsulates other monitors
 * @author Maximilian Schier
 */
class ICompositeHealthMonitor : public IHealthMonitor {
protected:
    std::vector<std::unique_ptr<IHealthMonitor>> monitors_;

public:
    ICompositeHealthMonitor(telemetry::Runner& runner, const std::string& tele_topic);

    void add(std::unique_ptr<IHealthMonitor> mon);

    virtual ~ICompositeHealthMonitor() = default;
};