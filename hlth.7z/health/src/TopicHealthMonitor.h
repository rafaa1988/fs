#pragma once

#include <deque>
#include <ros/node_handle.h>
#include <ros/subscriber.h>
#include "IHealthMonitor.h"

/**
 * Topic health monitor, basing health on topic publish frequency. Template parameter must be a message type containing
 * a ros::Time header stamp, so for PCL topics do not use pcl::* messages but sensor_msgs::pointcloud2.
 * @tparam T Topic type to listen for
 * @author Maximilian Schier
 */
template <class T>
class TopicHealthMonitor final : public IHealthMonitor {
private:
    ros::Subscriber sub_;

    double max_avg_delta_;
    size_t window_length_;

    IHealthMonitor::Health current_health_;

    std::unique_ptr<ros::Time> last_time_;
    std::deque<double> deltas_;

public:
    TopicHealthMonitor(telemetry::Runner& runner, const std::string& tele_topic, ros::NodeHandle& n,
                       const std::string& topic, double min_hz, size_t window_length = 10)
        : IHealthMonitor(runner, tele_topic)
        , sub_(n.subscribe<T>(topic, 1, &TopicHealthMonitor::callback, this))
        , max_avg_delta_(1.0 / min_hz)
        , window_length_(window_length)
        , current_health_(IHealthMonitor::Health::Dead)
    {}

    // Binding this, do not copy or move
    TopicHealthMonitor(const TopicHealthMonitor& that) = delete;
    TopicHealthMonitor& operator=(const TopicHealthMonitor& that) = delete;

    void callback(const typename T::ConstPtr& msg) {

        // If this is the first message seen, can't take delta, just store and exit
        if (!last_time_) {
            last_time_ = std::make_unique<ros::Time>(msg->header.stamp);
            return;
        }

        // Calculate the new difference between the current and the last message
        double new_delta = (msg->header.stamp - *last_time_).toSec();

        // Set the current message as the last message for upcoming invocations
        last_time_ = std::make_unique<ros::Time>(msg->header.stamp);

        // Add the current delta to the queue of all message deltas
        deltas_.push_back(new_delta);

        // Pop while the queue is larger than the desired window
        while (deltas_.size() > window_length_) {
            deltas_.pop_front();
        }

        // If the window is saturated, calculated the average over the window and check that it is lower than the
        // desired max delta, in which case we are healthy
        if (deltas_.size() == window_length_) {
            // Take average of deltas
            double avg = std::accumulate(deltas_.begin(), deltas_.end(), 0.0) / window_length_;

            if (avg > max_avg_delta_) {
                current_health_ = IHealthMonitor::Health::Dead;
            } else {
                current_health_ = IHealthMonitor::Health::Healthy;
            }
        }
    }

    Health getHealthInternal() override {
        // If dead, we are so dead
        if (current_health_ == IHealthMonitor::Health::Dead) {
            return current_health_;
        }

        // If alive, check that the last message was within a reasonable time frame, which we will just define
        // as triple the max_delta
        if (ros::Time::now() - *last_time_ > ros::Duration(max_avg_delta_ * 3.0)) {
            return IHealthMonitor::Health::Dead;
        } else {
            return current_health_;
        }
    }
};