#pragma once

#include "ICompositeHealthMonitor.h"

/**
 * Monitor reporting the maximum health of any of its children
 * @author Maximilian Schier
 */
class MaxHealthMonitor final : public ICompositeHealthMonitor {
public:
    MaxHealthMonitor(telemetry::Runner& runner, const std::string& topic);

    Health getHealthInternal() override;
};
