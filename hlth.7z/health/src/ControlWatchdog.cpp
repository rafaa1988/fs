#include "ControlWatchdog.h"

ControlWatchdog::ControlWatchdog(telemetry::Runner &runner, const std::string &topic, ros::NodeHandle &n)
    : IHealthMonitor(runner, topic)
    , control_actual_monitor_(runner, "ctrl_act", n, "/control", 6.0)
    , control_preflight_monitor_(runner, "ctrl_pre", n, "/control/wd", 6.0)
    , status_mon_(n)
{
    status_mon_.set_go_callback([this] () {
        this->driving_mode_start_ = ros::Time::now();
    });
}

IHealthMonitor::Health ControlWatchdog::getHealthInternal() {
    auto ctrl_act_health = control_actual_monitor_.getHealth();
    auto ctrl_pre_health = control_preflight_monitor_.getHealth();

    // Need actual control if driving or finished
    bool need_control = status_mon_.state() == hphlib::vehicle::StatusMonitor::STATE_DRIVING ||
                        status_mon_.state() == hphlib::vehicle::StatusMonitor::STATE_FINISHED;

    // In grace if just entered driving
    bool in_driving_grace = need_control && (ros::Time::now() < driving_mode_start_ + ros::Duration(5.0));
    
    // If in grace but already have good watchdog on control, immediately quit grace
    if (in_driving_grace && ctrl_act_health == Health::Healthy) {
        driving_mode_start_ = {};
    }

    if (need_control && !in_driving_grace) {
        return ctrl_act_health;
    } else {
        return std::max(ctrl_act_health, ctrl_pre_health);
    }
}
