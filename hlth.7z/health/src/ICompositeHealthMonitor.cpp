#include "ICompositeHealthMonitor.h"

ICompositeHealthMonitor::ICompositeHealthMonitor(telemetry::Runner &runner, const std::string &tele_topic)
    : IHealthMonitor(runner, tele_topic)
{
}

void ICompositeHealthMonitor::add(std::unique_ptr<IHealthMonitor> mon) {
    monitors_.push_back(std::move(mon));
}
