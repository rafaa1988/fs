#pragma once

#include "IHealthMonitor.h"
#include "TopicHealthMonitor.h"
#include <hphlib/Control.h>
#include <hphlib/Woof.h>
#include <hphlib/vehicle/StatusMonitor.h>

/**
 * If vehicle is in state AS_DRIVING or AS_FINISHED, ControlWatchdog returns health of actual control topic. Otherwise,
 * control watchdog returns health of max(actual control topic, control preflight watchdog). During transition, small
 * grace is applied where preflight remains valid to not immediately fail if controller just starts publishing on go.
 */
class ControlWatchdog final : public IHealthMonitor {
private:
    TopicHealthMonitor<hphlib::Control> control_actual_monitor_;
    TopicHealthMonitor<hphlib::Woof> control_preflight_monitor_;
    hphlib::vehicle::StatusMonitor status_mon_;
    ros::Time driving_mode_start_;

public:
    ControlWatchdog(telemetry::Runner& runner, const std::string& topic, ros::NodeHandle& n);

    // Binding this, do not copy or move
    ControlWatchdog(const ControlWatchdog& that) = delete;
    ControlWatchdog& operator=(const ControlWatchdog& that) = delete;

protected:
    Health getHealthInternal() override;
};
