#include "IHealthMonitor.h"

IHealthMonitor::IHealthMonitor(telemetry::Runner &runner, const std::string &telemetry_topic)
    : runner_(&runner)
    , telemetry_topic_(telemetry_topic)
{
}

bool operator<(IHealthMonitor::Health a, IHealthMonitor::Health b) {
    if ((a == IHealthMonitor::Health::Dead || a == IHealthMonitor::Health::Ill) && b == IHealthMonitor::Health::Healthy) {
        return true;
    } else if (a == IHealthMonitor::Health::Dead && b == IHealthMonitor::Health::Ill) {
        return true;
    } else {
        return false;
    }
}

IHealthMonitor::Health IHealthMonitor::getHealth() {
    auto health = getHealthInternal();

    const char* health_val = "d";

    if (health == Health::Healthy) {
        health_val = "h";
    } else if (health == Health::Ill) {
        health_val = "i";
    }

    runner_->stage(telemetry_topic_, health_val);

    return health;
}
