#pragma once

#include "ICompositeHealthMonitor.h"

/**
 * Monitor that is healthy if any of it composite monitors are healthy, dead if all composite monitors dead, otherwise ill
 * @author Maximilian Schier
 */
class PartialMaxHealthMonitor final : public ICompositeHealthMonitor {
public:
    PartialMaxHealthMonitor(telemetry::Runner& runner, const std::string& topic);

    Health getHealthInternal() override;
};
