#pragma once

#include "ICompositeHealthMonitor.h"

class MinHealthMonitor final : public ICompositeHealthMonitor {
public:
    MinHealthMonitor(telemetry::Runner& runner, const std::string& tele_topic);

    Health getHealthInternal() override;
};
