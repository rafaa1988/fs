#include <ros/ros.h>
#include "MissionSelector.h"

void run_main(ros::NodeHandle& n) {
    MissionSelector ms(n);

    ros::spin();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "mission_selector");

    ros::NodeHandle n("~");
    
    ROS_INFO("Starting mission selector");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }
    
    ROS_INFO("Exiting cleanly");

    return EXIT_SUCCESS;
}
