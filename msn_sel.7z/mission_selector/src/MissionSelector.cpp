#include "MissionSelector.h"
#include <hphlib/os.h>
#include <ros/node_handle.h>
#include <csignal>

MissionSelector::MissionSelector(ros::NodeHandle &n)
    : status_mon_(n)
    , child_pid_(0)
    , watchdog_timer_(n.createSteadyTimer(ros::WallDuration(0.1), &MissionSelector::timerCallback, this))
{
    status_mon_.set_ready_callback([this] () {
        auto mission = this->status_mon_.mission_on_ready();

        ROS_INFO_STREAM("Selected mission: " << hphlib::vehicle::decodeAmi(mission));

        this->launch(mission);
    });

    // Kill when vehicle enters off state again
    status_mon_.set_off_callback([this] () {
        ROS_INFO("Mission is done, vehicle off");
        this->ensureChildKilled();
    });
}

void MissionSelector::ensureChildKilled() {
    if (child_pid_ != 0) {
        hphlib::os::signal(child_pid_, SIGINT);
        hphlib::os::waitTerminated(child_pid_);
        child_pid_ = 0;
    }
}

void MissionSelector::timerCallback(const ros::SteadyTimerEvent &ev) {
    (void) ev;

    // If no child alive, nothing to check
    if (child_pid_ == 0) {
        return;
    }

    // Ensure the child is still alive
    auto optional_exit = hphlib::os::checkTerminated(child_pid_);

    if (optional_exit) {
        ROS_ERROR_STREAM("Child with PID " << child_pid_ << " has died unexpectedly with exit code " << *optional_exit);
        child_pid_ = 0;
    }
}

void MissionSelector::launch(uint8_t mission) {
    this->ensureChildKilled();

    std::stringstream launch_file_stream;
    launch_file_stream << "mission_" << hphlib::vehicle::decodeAmi(mission) << ".launch";

    std::string launch_file(launch_file_stream.str());

    char* const args[] = {
            const_cast<char *const>("roslaunch"),
            const_cast<char *const>("mission_selector"),
            const_cast<char *const>(launch_file.c_str()),
            nullptr
    };

    try {
        child_pid_ = hphlib::os::execute(args[0], args, hphlib::os::ExecuteMode::SearchExecutable);
    } catch (const std::system_error& e) {
        ROS_ERROR_STREAM("Failed to launch roslaunch: " << e.what());
    }
}

MissionSelector::~MissionSelector() {
    this->ensureChildKilled();
}
