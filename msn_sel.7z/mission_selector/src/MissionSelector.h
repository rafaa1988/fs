#pragma once

#include <hphlib/vehicle/StatusMonitor.h>
#include <ros/steady_timer.h>

class MissionSelector {
private:
    // Status monitor used to be notified on mission change
    hphlib::vehicle::StatusMonitor status_mon_;

    // PID of the child process executing the mission
    pid_t child_pid_;

    ros::SteadyTimer watchdog_timer_;

    /**
     * Make sure our child is dead. Do not call on humans.
     */
    void ensureChildKilled();

    /**
     * Launch the given mission
     * @param mission Mission
     */
    void launch(uint8_t mission);

    /**
     * Callback invoked when the watchdog timer ticks.
     * @param ev Timer event
     */
    void timerCallback(const ros::SteadyTimerEvent& ev);

public:
    explicit MissionSelector(ros::NodeHandle& n);

    // Local PID, do not copy or move
    MissionSelector(const MissionSelector& that) = delete;
    MissionSelector& operator=(const MissionSelector& that) = delete;

    ~MissionSelector();
};

