# Mission selector

This node monitors the selected mission through the vehicle status monitor and launches
appropriate launch files.