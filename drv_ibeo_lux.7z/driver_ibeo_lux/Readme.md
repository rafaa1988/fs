# ibeo LUX network driver

## General

The ibeo LUX network driver implements data exchange with the ibeo LUX Lidar sensor through network communication.

The driver publishes scan data as LaserScan and PointCloud messages, can publish object data of the built-in object
detection and tracking and implements the ibeo command interface for configuring and monitoring the sensor.

# Synchronizing the device clock with the PC clock
The internal device clock of the Lidar sensor counts the time since boot up of the sensor. It should be noted that the
device clock can have rather strong drift, in initial tests a drift of a few milliseconds from the PC clock was measured
after just a few minutes of operation. Therefore the device clock is unsatisfactory as a stable clock source.

In order to give accurate timestamps for published data, the driver first performs a series of RTT measurements
by querying parameters from the device. The following simplifications are made: Queueing delay is equal for both 
directions of the network, as is processing delay. One way time is assumed to be equal for both requesting a parameter
and the lidar sending scan data, which would only be true if the lidar flushed its TCP stream early.

The driver then simply takes the median one way time of all RTT measurements. When scan data is received,
it subtracts the one way time from the current PC clock time and further subtracts the difference between
the time the lidar sent the frame and the time the lidar started capturing scan data, since according to ROS
specification the header of a laser scan message should indicated the start of the measurement.