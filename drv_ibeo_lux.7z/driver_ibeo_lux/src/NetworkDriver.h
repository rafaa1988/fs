#pragma once

#include <array>
#include <boost/endian/conversion.hpp>
#include <ros/ros.h>
#include <hphlib/io/TcpSocket.h>
#include "interface/generic/IbeoHeader.h"
#include "interface/commands/SubCommand.h"
#include "interface/commands/Command.h"

/**
 * The network driver manages communication with the sensor through a network socket and implements the basic
 * functions for synchronization, reading and writing.
 *
 * @brief Implement network communication with ibeo sensor
 */
class NetworkDriver {
private:

    /**
     * Input stream state
     */
    enum class State {
        /**
         * The driver is not synchronized and must synchronize first
         */
        MustSynchronize,

        /**
         * The driver is synchronized and can receive a header next
         */
        CanReadHeader,

        /**
         * A header was received, the driver can receive the message next
         */
        CanReadMessage
    };

    /**
     * Receive fixed amount of bytes via our socket
     * @param buffer Buffer where received data is written to
     * @param length Length of bytes to receive
     * @throws std::runtime_error If the socket times out or is closed
     * @throws std::system_error On other socket related errors
     */
    void receive(uint8_t* buffer, size_t length);

    /**
     * Send fixed amount of bytes to remote device
     * @param buffer Start of buffer to send
     * @param length Number of bytes to send
     */
    void transmit(const uint8_t* buffer, size_t length);

    static const std::array<uint8_t, 4> MAGIC_WORD;

    /**
     * Buffer unwanted content is read into
     * TODO: This could really be nicer
     */
    static std::array<uint8_t, 200'000> trash_buffer;

    /**
     * Network socket used to talk to the sensor
     */
    hphlib::TcpSocket socket_;

    ros::Time last_sync_time_;

    /**
     * Expected size of next message
     */
    uint32_t next_message_size_;

    /**
     * State of stream, used to check right order of method execution between synchronizing, reading header and
     * reading message
     */
    State state_;

public:

    NetworkDriver();

    /**
     * Connect the driver to a new device
     * @param ipv4 IPv4 address of device
     * @param port Remote port to use for TCP communication
     */
    void connectDevice(const std::string& ipv4, uint16_t port);

    /**
     * Synchronize the input stream on the next magic word. The magic word is read from the stream and not put back
     */
    void synchronizeOnMagicWord();

    /**
     * Synchronize and read stream until a header of the given data type is reached
     * @param data_type Data type desired
     * @return First matching header, already converted to native byte order
     */
    LadarHeader synchronizeAndFilterHeader(uint16_t data_type);

    /**
     * Read the next header from the stream, must be synchronized
     * @return Header
     */
    LadarHeader readHeader();

    /**
     * Read the next message from stream, must be called after readHeader and buffer must be large enough to fit
     * message of size as indicated by last header
     * @param buffer Pointer to start of buffer
     * @param length Length of buffer
     * @return Length of bytes written to buffer
     */
    size_t readMessage(uint8_t* buffer, size_t length);

    ros::Time lastMessageUncorrectedTime() const;

    /**
     * Send a command to the ibeo
     * @param command Command to be send
     */
    template <typename SubCommand>
    void sendCommand(SubCommand& sub_command) {
        // Must send:
        // Magic word
        // Ibeo Header
        // Ibeo Command Header
        // Ibeo Subcommand

        Command<SubCommand> command;
        command.commandId = sub_command.commandId();
        command.subCommand = sub_command;

        LadarHeader header{};

        // Specifications advise setting to 0
        header.prevMessageSize = 0;

        header.messageSize = sizeof command;

        // Specifications advise setting to 0
        header.reserved = 0;

        header.dataType = LadarHeader::DATA_TYPE_COMMAND;

        // Fill ntp time of message with anything after converting byte order, REALLY IMPORTANT to set this to Hannover
        std::memcpy(&header.ntpTime, "Hannover", sizeof header.ntpTime);

        transmit(&MAGIC_WORD[0], MAGIC_WORD.size());
        transmit(reinterpret_cast<const uint8_t *>(&header), sizeof header);
        transmit(reinterpret_cast<const uint8_t *>(&command), sizeof command);
    }

    /**
     * Send a command to the sensor and await the reply, drops other messages send by the sensor until
     * the acknowledgement is received
     * @tparam SubCommand Type of sub command to send
     * @param sub_command Sub command to executed
     * @return Received reply
     */
    template <typename SubCommand>
    void awaitVoidCommand(SubCommand& sub_command) {

        // Take command id in native order
        uint16_t id = sub_command.commandId();

        sendCommand<SubCommand>(sub_command);

        LadarHeader header = synchronizeAndFilterHeader(LadarHeader::DATA_TYPE_COMMAND_REPLY);

        little_uint16_t reply_id{};
        receive(reinterpret_cast<uint8_t *>(&reply_id), sizeof reply_id);

        if (reply_id == id) {
            // Okay
            if (header.messageSize != 2) {
                std::stringstream estream;
                estream << "Expected reply of length " << 0 << ", got " << (header.messageSize - 2)
                        << " in acknowledgement of command 0x" << std::setw(4) << std::setfill('0') << std::hex << id;
                throw std::runtime_error(estream.str());
            }

            return;

        } else if (reply_id == (0x8000 | id)) {
            // Failure
            std::stringstream estream;
            estream << "Sensor will not comply to command 0x" << std::setw(4) << std::setfill('0') << std::hex << id
                    << ", payload: ";
            dumpHex(estream, reinterpret_cast<const uint8_t*>(&sub_command), sizeof sub_command);
            throw std::runtime_error(estream.str());
        } else {
            // Unexpected reply
            std::stringstream estream;
            estream << "Sensor acknowledged command 0x" << std::setw(4) << std::setfill('0') << std::hex << reply_id
                    << " while expecting reply to 0x" << std::setw(4) << std::setfill('0') << std::hex << id;
            throw std::runtime_error(estream.str());
        }
    }

    void dumpHex(std::ostream& stream, const uint8_t* buffer, size_t length) {

        stream << std::hex;

        for (size_t i = 0; i < length; i++) {
            stream << std::setw(2) << std::setfill('0') << static_cast<int>(buffer[i]) << " ";
        }
    }

    /**
     * Send a command to the sensor and await the reply, drops other messages send by the sensor until
     * the acknowledgement is received
     * @tparam CommandReply Type of reply expected
     * @tparam SubCommand Type of sub command to send
     * @param sub_command Sub command to executed
     * @return Received reply
     */
    template <typename CommandReply, typename SubCommand>
    CommandReply awaitCommand(SubCommand& sub_command) {

        // Take command id in native order
        uint16_t id = sub_command.commandId();

        sendCommand<SubCommand>(sub_command);

        LadarHeader header = synchronizeAndFilterHeader(LadarHeader::DATA_TYPE_COMMAND_REPLY);

        little_uint16_t reply_id{};
        receive(reinterpret_cast<uint8_t *>(&reply_id), sizeof reply_id);

        if (reply_id == id) {
            // Okay
            CommandReply reply;

            if (sizeof reply != header.messageSize - 2) {
                std::stringstream estream;
                estream << "Expected reply of length " << sizeof reply << ", got " << (header.messageSize - 2)
                        << " in acknowledgement of command 0x" << std::setw(4) << std::setfill('0') << std::hex << id;
                throw std::runtime_error(estream.str());
            }

            receive(reinterpret_cast<uint8_t *>(&reply), sizeof reply);

            return reply;

        } else if (reply_id == (0x8000 | id)) {
            // Failure
            std::stringstream estream;
            estream << "Sensor will not comply to command 0x" << std::setw(4) << std::setfill('0') << std::hex << id
                    << ", payload: ";
            dumpHex(estream, reinterpret_cast<const uint8_t*>(&sub_command), sizeof sub_command);
            throw std::runtime_error(estream.str());
        } else {
            // Unexpected reply
            std::stringstream estream;
            estream << "Sensor acknowledged command 0x" << std::setw(4) << std::setfill('0') << std::hex << reply_id
                    << " while expecting reply to 0x" << std::setw(4) << std::setfill('0') << std::hex << id;
            throw std::runtime_error(estream.str());
        }
    }
};