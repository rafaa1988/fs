#include <algorithm>
#include <ros/ros.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <thread>
#include "NetworkDriver.h"
#include "interface/generic/ErrorMessage.h"
#include "util.h"

decltype(NetworkDriver::MAGIC_WORD) NetworkDriver::MAGIC_WORD = {0xAF, 0xFE, 0xC0, 0xC2};
decltype(NetworkDriver::trash_buffer) NetworkDriver::trash_buffer = {};

NetworkDriver::NetworkDriver()
    : state_(State::MustSynchronize)
{
}

void NetworkDriver::connectDevice(const std::string &ipv4, uint16_t port) {

    using namespace std::chrono_literals;

    socket_ = hphlib::TcpSocket(hphlib::TcpSocket::DYNAMIC_PORT);
    socket_.setNagleEnabled(false);
    socket_.setReceiveTimeoutMs(1'000);

    hphlib::TcpSocket::Endpoint remote(ipv4.c_str(), port);
    socket_.connect(remote);
}

void NetworkDriver::receive(uint8_t* buffer, size_t length) {
    socket_.receiveExact(buffer, length);
}

void NetworkDriver::synchronizeOnMagicWord() {

    unsigned int    i;
    uint32_t        retryNumMax = 100'000;

    std::array<uint8_t, 4> magicWordBuf{};

    // synchronize to header by reading the magic word (4 bytes)
    receive(&magicWordBuf[0], magicWordBuf.size());

    for (i = 0; i < retryNumMax; i++) {
        // search for magic word
        if (magicWordBuf == MAGIC_WORD) {
            last_sync_time_ = ros::Time::now();
            break;
        }

        // Magic word was not received, but maybe misaligned, keep receiving one more byte and shift through magic word
        std::rotate(magicWordBuf.begin(), magicWordBuf.begin() + 1, magicWordBuf.end());
        receive(&magicWordBuf[3], 1);
    }

    // synchronization timeout
    if (i == retryNumMax) {
        std::stringstream estream;
        estream << "Can't synchronize to ladar header, timeout after " << i << " attempts";
        throw std::runtime_error(estream.str());
    }

    state_ = State::CanReadHeader;
}

LadarHeader NetworkDriver::readHeader() {

    if (state_ != State::CanReadHeader) {
        throw std::logic_error("Cannot read header: illegal stream state");
    }

    LadarHeader header{};

    receive(reinterpret_cast<uint8_t *>(&header), sizeof header);

    state_ = State::CanReadMessage;
    next_message_size_ = header.messageSize;
    last_sync_time_ = ntpToROSTime(header.ntpTime);

    return header;
}

size_t NetworkDriver::readMessage(uint8_t *buffer, size_t length) {
    if (state_ != State::CanReadMessage) {
        throw std::logic_error("Cannot read message: illegal stream state");
    }

    if (length < next_message_size_) {
        std::stringstream estream;
        estream << "Cannot read message to buffer: Buffer too small, need at least "
                << next_message_size_ << " bytes, got " << length;
        throw std::domain_error(estream.str());
    }

    receive(buffer, next_message_size_);

    state_ = State::MustSynchronize;

    return next_message_size_;
}

void NetworkDriver::transmit(const uint8_t *buffer, size_t length) {
    socket_.send(buffer, length);
}

LadarHeader NetworkDriver::synchronizeAndFilterHeader(uint16_t data_type) {

    constexpr int MAX_UNDESIRED = 50;

    for (int i = 0; i < MAX_UNDESIRED; ++i) {
        synchronizeOnMagicWord();

        LadarHeader header = readHeader();

        if (header.dataType == data_type) {
            return header;
        }

        readMessage(trash_buffer.data(), header.messageSize);

        // Don't just drop errors while synchronizing on command
        if (header.dataType == LadarHeader::DATA_TYPE_ERROR) {
            ErrorMessage err{};

            std::memcpy(&err, trash_buffer.data(), sizeof err);

            ROS_WARN_STREAM("Received error message: " << err.formatAsString());
        }
    }

    std::stringstream estream;
    estream << "Too many (" << MAX_UNDESIRED << ") undesired messages while filtering for data type 0x"
            << std::setw(4) << std::setfill(' ') << std::hex << data_type;
    throw std::runtime_error(estream.str());
}

ros::Time NetworkDriver::lastMessageUncorrectedTime() const {
    return last_sync_time_;
}
