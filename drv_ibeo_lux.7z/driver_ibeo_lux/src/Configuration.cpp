#include "Configuration.h"
#include "interface/commands/Parameters.h"
#include "interface/commands/ReplyGetStatus.h"
#include "interface/commands/CommandGetStatus.h"

void Configuration::dumpSensorConfiguration(NetworkDriver &driver) {
    ROS_INFO("Mounting x          : %d cm", queryParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_X));
    ROS_INFO("Mounting y          : %d cm", queryParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_Y));
    ROS_INFO("Mounting z          : %d cm", queryParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_Z));
    ROS_INFO("Front to front axle : %d cm", queryParam<uint16_t>(driver, Parameters::VEHICLE_FRONT_TO_FRONT_AXLE));
    ROS_INFO("Wheelbase           : %d cm", queryParam<uint16_t>(driver, Parameters::FRONT_AXLE_TO_REAR_AXLE));
    ROS_INFO("Rear axle to rear   : %d cm", queryParam<uint16_t>(driver, Parameters::REAR_AXLE_TO_VEHICLE_REAR));
    ROS_INFO_STREAM("Processing switch   : 0x" << std::hex << queryParam<uint16_t>(driver, Parameters::CUSTOMER_PROCESSING_SWITCH0));
    ROS_INFO_STREAM("Data output flag    : 0x" << std::hex << queryParam<uint16_t>(driver, Parameters::DATA_OUTPUT_FLAG));
    ROS_INFO_STREAM("Sync angle offset   : " << querySyncAngleOffsetDegree(driver));
    ROS_INFO_STREAM("Start angle         : " << queryStartAngleDegree(driver));
    ROS_INFO_STREAM("End angle           : " << queryStopAngleDegree(driver));

    // Device type causing error on sensor present
    // ROS_INFO_STREAM("Device type         : 0x" << std::hex << queryParam<uint16_t>(driver, Parameters::DEVICE_TYPE));
}

void Configuration::dumpSensorStatus(NetworkDriver &driver) {

    CommandGetStatus cmd;
    auto status = driver.awaitCommand<ReplyGetStatus>(cmd);

    ROS_INFO("Serial number       : %s", status.serialString().c_str());
    ROS_INFO("Sensor temperature  : %f deg C", status.temperatureCelsius());

    if (status.laserOn()) {
        ROS_INFO("Laser status        : Nominal");
    } else {
        ROS_WARN("Laser status        : DISABLED");
    }

    if (status.motorOn()) {
        ROS_INFO("Motor status        : Nominal");
    } else {
        ROS_WARN("Motor status        : DISABLED");
    }

    ROS_INFO_STREAM("External sync detected: " << (status.externalSyncDetected() ? "Yes" : "No"));

    if (status.syncOk()) {
        ROS_INFO("Sync status         : Nominal");
    } else {
        ROS_WARN("Sync status         : ERROR IN SYNC");
    }

    ROS_INFO("Sync config         : %s", status.isSyncMaster() ? "Master" : "Slave");
}

void Configuration::loadOriginConfiguration(NetworkDriver &driver) {
    setParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_X, 0);
    setParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_Y, 0);
    setParam<int16_t>(driver, Parameters::SENSOR_MOUNTING_Z, 0);
    setParam<uint16_t>(driver, Parameters::VEHICLE_FRONT_TO_FRONT_AXLE, 0);
    setParam<uint16_t>(driver, Parameters::FRONT_AXLE_TO_REAR_AXLE, 0);
    setParam<uint16_t>(driver, Parameters::FRONT_AXLE_TO_REAR_AXLE, 0);
    setParam<uint16_t>(driver, Parameters::REAR_AXLE_TO_VEHICLE_REAR, 0);

    // Set sync to auto and enable dirt and rain detection
    setParam<uint16_t>(driver, Parameters::CUSTOMER_PROCESSING_SWITCH0, 0x000d);

    // Disable data output processing
    setParam<uint16_t>(driver, Parameters::DATA_OUTPUT_FLAG, 0x0000);
}

float queryGenericAngle(NetworkDriver &driver, uint16_t index) {
    auto raw = Configuration::queryParam<uint16_t>(driver, index);

    // Actual type may be int14_t, sign extend manually to always ensure last bits set correctly
    if (raw & (1 << 13)) {
        raw |=  0xc000;
    } else {
        raw &= ~0xc000;
    }

    return static_cast<int16_t>(raw) / 32.0f;
}

void setGenericAngle(NetworkDriver &driver, uint16_t index, float angle_deg) {
    // Actual type may be int14_t but no conversion necessary in two's complement
    auto raw = static_cast<int16_t>(angle_deg * 32.0f);

    Configuration::setParam<int16_t>(driver, index, raw);
}

float Configuration::queryStartAngleDegree(NetworkDriver &driver) {
    return queryGenericAngle(driver, Parameters::START_ANGLE);
}

float Configuration::queryStopAngleDegree(NetworkDriver &driver) {
    return queryGenericAngle(driver, Parameters::END_ANGLE);
}

float Configuration::querySyncAngleOffsetDegree(NetworkDriver &driver) {
    return queryGenericAngle(driver, Parameters::SYNC_ANGLE_OFFSET);
}

void Configuration::setSyncAngleOffsetDegrees(NetworkDriver &driver, float angle_deg) {
    return setGenericAngle(driver, Parameters::SYNC_ANGLE_OFFSET, angle_deg);
}
