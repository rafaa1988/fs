#pragma once

#include <ros/ros.h>

constexpr double NTP_TO_ROSTIME_FRAC_MULTIPLYER = 1953125.0 / 8388608.0;

static inline ros::Time ntpToROSTime(uint32_t ladarNtpTime_seconds, uint32_t ladarNtpTime_secondsFrac) {
    return ros::Time(ladarNtpTime_seconds,
                     static_cast<uint32_t>(uint64_t(ladarNtpTime_secondsFrac) * NTP_TO_ROSTIME_FRAC_MULTIPLYER));
}

static inline ros::Time ntpToROSTime(uint64_t native_stamp) {
    return ros::Time(static_cast<uint32_t>(native_stamp >> 32),
                     static_cast<uint32_t>((native_stamp & 0xffffffff) * NTP_TO_ROSTIME_FRAC_MULTIPLYER));
}