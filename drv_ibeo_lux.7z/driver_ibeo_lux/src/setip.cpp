#include <boost/program_options.hpp>

#include "NetworkDriver.h"
#include "Configuration.h"
#include "interface/commands/Parameters.h"
#include "interface/commands/CommandSaveConfig.h"

int main(int argc, char** argv) {

    // Required by driver
    ros::Time::init();

    boost::program_options::options_description desc("Options");

    std::string old_ip;
    std::string new_ip;
    bool show_help = false;

    desc.add_options()
            ("help,h", boost::program_options::bool_switch(&show_help), "Show help")
            ("new,n", boost::program_options::value<std::string>(&new_ip)->required(), "New IP")
            ("old,o", boost::program_options::value<std::string>(&old_ip)->required(), "Old IP");

    boost::program_options::variables_map vm;

    try {
        boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(desc).run(), vm);

        if (show_help) {
            std::cout << "Usage: " << argv[0] << " OPTIONS BAG1 [BAG2 [..]]\n" << desc;
            return EXIT_SUCCESS;
        }

        boost::program_options::notify(vm);
    } catch (const std::exception& e) {
        std::cerr << "Error parsing arguments: " << e.what() << "\n\n"
                  << "Usage: " << argv[0] << " OPTIONS BAG1 [BAG2 [..]]\n" << desc;
        return EXIT_FAILURE;
    }

    unsigned char bytes[4];

    // TODO: Don't sscanf
    if (sscanf(new_ip.c_str(), "%hhu.%hhu.%hhu.%hhu", bytes + 3, bytes + 2, bytes + 1, bytes + 0) != 4) {
        throw std::runtime_error("Failed to parse new IP");
    }

    uint32_t ip = bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];

    NetworkDriver driver;
    driver.connectDevice(old_ip, 12002);

    Configuration::setParam(driver, Parameters::IP_ADDRESS, ip);

    CommandSaveConfig save{};

    driver.awaitVoidCommand(save);
}