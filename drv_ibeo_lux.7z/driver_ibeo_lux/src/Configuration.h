#pragma once

#include "NetworkDriver.h"
#include "interface/commands/ReplyGetParameter.h"
#include "interface/commands/CommandGetParameter.h"
#include "interface/commands/CommandSetParameter.h"

/**
 * @brief Configuration methods for the sensor
 * @author Maximilian Schier
 */
namespace Configuration {

    /**
     * Convenience method to query a parameter from the sensor
     * @tparam T Native type of parameter
     * @param driver Network driver handle
     * @param paramId Parameter id
     * @return Native value of parameter
     */
    template <typename T>
    T queryParam(NetworkDriver& driver, uint16_t paramId) {
        CommandGetParameter cmd{};
        cmd.parameterIndex = paramId;

        ReplyGetParameter reply = driver.awaitCommand<ReplyGetParameter>(cmd);
        return reply.as<T>();
    }

    /**
     * Get the sync angle offset in degrees
     * @param driver Network driver connected to device to query on
     * @return Sync angle offset in degrees
     */
    float querySyncAngleOffsetDegree(NetworkDriver &driver);

    float queryStartAngleDegree(NetworkDriver &driver);

    float queryStopAngleDegree(NetworkDriver &driver);

    /**
     * Convenience method to set a parameter on the sensor
     * @tparam T Native type of parameter
     * @param driver Network driver handle
     * @param paramId Parameter id
     * @param val Native value of parameter
     */
    template <typename T>
    void setParam(NetworkDriver& driver, uint16_t paramId, T val) {
        CommandSetParameter cmd = CommandSetParameter::createInNetworkOrder<T>(paramId, val);

        driver.awaitVoidCommand(cmd);
    }

    /**
     * Set the sync angle offset
     * @param driver Network driver connected to device to query on
     * @param angle_deg Angle in degrees
     */
    void setSyncAngleOffsetDegrees(NetworkDriver &driver, float angle_deg);

    /**
     * Load the correct origin configuration onto the sensor
     * @param driver
     */
    void loadOriginConfiguration(NetworkDriver& driver);

    /**
     * Dump the sensor configuration to ROS console
     * @param driver Network driver handle
     */
    void dumpSensorConfiguration(NetworkDriver &driver);

    /**
     * Dump the sensor status to ROS console
     * @param driver Network driver handle
     */
    void dumpSensorStatus(NetworkDriver& driver);
}