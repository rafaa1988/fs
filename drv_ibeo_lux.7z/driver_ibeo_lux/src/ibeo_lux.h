/*
 * Copyright (C) 2005-2010 University of Hannover
 *                         Institute for Systems Engineering - RTS
 *                         Professor Bernardo Wagner
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * Authors
 *      Nikolai Hansen          <nikolai.hansen@web.de>
 *      Jan Carstensen          <carstensen@rts.uni-hannover.de>
 *      Maximilian Schier       <max.schier@gmail.com> (Review for season 18)
 */

#pragma once

#include <iostream>
#include <string>

#include <boost/endian/conversion.hpp>

#include <ros/ros.h>

#include <hphlib/misc/SlidingWindow.h>
#include <telemetry/Runner.h>
#include <hphlib/vehicle/StatusMonitor.h>

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"

#include "interface/generic/IbeoHeader.h"
#include "interface/generic/ScanData.h"
#include "NetworkDriver.h"

//Horizontal angle start/end-increments
//1/32° = 1 increment =~ 0.0005454153912 rad
#define FIRST_ANGLE_INCR_LAYER_0            1630
#define FIRST_ANGLE_INCR_LAYER_1            1630
#define LAST_ANGLE_INCR_LAYER_0            -1922//-1634 zur sicherheit von den erwarteten min -50° auf -60° erhöht //N Antwort vom IBEO Support abwarten
#define LAST_ANGLE_INCR_LAYER_1            -1922//-1634
#define FIRST_ANGLE_INCR_LAYER_2            1630//1134 zur sicherheit von den erwarteten min 35° auf über 40° erhöht
#define FIRST_ANGLE_INCR_LAYER_3            1630 //1134
#define LAST_ANGLE_INCR_LAYER_2            -1938
#define LAST_ANGLE_INCR_LAYER_3            -1938

//Vertical angle for each layer [rad]
constexpr float VERTICAL_ANGLE_LAYER_0 = -0.020943951f; //-1,2°
constexpr float VERTICAL_ANGLE_LAYER_1 = -0.006981317f; //-0,4°
constexpr float VERTICAL_ANGLE_LAYER_2 =  0.006981317f; // 0,4°
constexpr float VERTICAL_ANGLE_LAYER_3 =  0.020943951f; // 1,2°

//Basic Frame-IDs for published ROS-Topics
#define FRAME_ID_LAYER0                     "_ibeo_layer_0_link"
#define FRAME_ID_LAYER1                     "_ibeo_layer_1_link"
#define FRAME_ID_LAYER2                     "_ibeo_layer_2_link"
#define FRAME_ID_LAYER3                     "_ibeo_layer_3_link"
#define FRAME_ID_POINTCLOUD                 "_ibeo_pointcloud_link"

#define CM_TO_METER                         0.01
#define HORIZONTAL_ANGLE_INCREMENT_DEGREE   1 / 32
#define HORIZONTAL_ANGLE_INCREMENT_RADIAN   (2 * M_PI * HORIZONTAL_ANGLE_INCREMENT_DEGREE) / 360

#define LADAR_IBEO_LUX_MAX_RANGE            80.0            //[meter] IBEO-Datasheet: 200m
#define LADAR_IBEO_LUX_MIN_RANGE            0.3             //[meter] IBEO-Datasheet: 0.3m
#define LASERSCANMSG_NO_ECHO_RECEIVED       0

/// time data type
struct __attribute__((packed)) LadarNtp64 {
    uint32_t                seconds;            // seconds since 1.1.1900 - 0:00:00
    uint32_t                secondsFrac;        // fractional seconds in 2^-32 s
};

/// time data type reverted
struct __attribute__((packed)) LadarNtp64Reverted {
    uint32_t                secondsFrac;        // fractional seconds in 2^-32 s
    uint32_t                seconds;            // seconds since 1.1.1900 - 0:00:00
};

class LadarIbeoLux {
private:

    /**
     * Additional time given to the sensor after the startup command where it does not have to be synchronized
     */
    static const int STARTUP_GRACE_SECONDS;

    /**
     * Sync monitor window size. Sensor status is inserted into the window to monitor whether the sensor has successfully
     * synchronized with an external trigger. Required to have window since the sensor usually briefly detects out of
     * synchronization even in normal operation.
     */
    static const int SYNC_WINDOW_SIZE_SECONDS;

    /**
     * Ratio of samples in sync monitor window to even consider trigger signal as stable.
     * If ratio between samples with external trigger to all samples below threshold, never restart
     * sensor because out of sync
     */
    static const float SYNC_EXT_TRIGGER_RATIO_THRESHOLD;

    /**
     * Ratio of samples in sync monitor window to consider sensor out of sync. If external trigger stable but ratio
     * of synchronized samples to all samples below threshold, restart sensor because out of sync
     */
    static const float SYNC_SYNC_RATIO_THRESHOLD;

    //dynamic Parameters
    std::string                 ladarIp;
    std::string                 frameIdPrefix;
    float                       ladarFrequencyMode_hz;

    int                         ibeoAngularIncrementSteps;          //50Hz->32*[1/32°] 25Hz->16*[1/32°] 12,5Hz->8*[1/32°]
    float                       scanTime;                           //[sec] Time between Scans 50Hz->0.02 25Hz->0.04 12,5->0.08

    int                         ladarPort;
    std::array<uint8_t, 99'000> message_buffer_;

    hphlib::SlidingWindow<std::pair<bool, bool>> sync_window_;
    std::chrono::steady_clock::time_point sensor_start_;

    float                       sync_angle_offset_;
    float                       sync_angle_ratio_from_full_ratio_;

    NetworkDriver               driver_;

    sensor_msgs::LaserScan      layer0LaserScan;
    sensor_msgs::LaserScan      layer1LaserScan;
    sensor_msgs::LaserScan      layer2LaserScan;
    sensor_msgs::LaserScan      layer3LaserScan;
    sensor_msgs::LaserScan      layer0LaserScan_pub;
    sensor_msgs::LaserScan      layer1LaserScan_pub;
    sensor_msgs::LaserScan      layer2LaserScan_pub;
    sensor_msgs::LaserScan      layer3LaserScan_pub;
    ros::Time                   scanStartTime;
    ros::Time                   scanEndTime;

    /**
     * One way network delay, set by measureDelay()
     */
    ros::Duration               medianOneWayTime;

    ros::Publisher              ibeoLayer0_pub;
    ros::Publisher              ibeoLayer1_pub;
    ros::Publisher              ibeoLayer2_pub;
    ros::Publisher              ibeoLayer3_pub;
    ros::Publisher              pcPublisher;

    telemetry::Runner           tele_;

    /**
     * Used to count frames between periodic queries of scanner status
     */
    ros::Time time_of_last_status_query_;

    /**
     * Last time a frame was successfully pushed by the sensor
     */
    ros::Time last_successful_frame_time_;

    /**
     * Status monitor used to determine when it is safe to restart lidar
     */
    hphlib::vehicle::StatusMonitor status_monitor_;

    void                        pubLaserScanMsgs(ScanData &scanData, ros::Time timeStamp);
    void                        pubPointCloudMsgs(ScanData &scanData, ros::Time timeStamp);
    void                        moduleSpinOnce();
    void                        measureDelay();
    void                        initLaserScanMsg();
    void                        restartSensor();

    /**
     * Stage status messages for the telemetry, supply no arguments to use the default parameters that log that all
     * functions are unavailable
     * @param status_word Actual status word of sensor or default value for all functions unavailable
     * @param points Actual number of points or default value for no points available
     */
    void stageStatusTelemetry(uint16_t status_word = 0x0, int points = 0);

public:

    /**
     * Instantiate a new driver instance by reading driver parameters from the given node handle
     * @param n ROS node containing parameters
     */
    explicit LadarIbeoLux(ros::NodeHandle& n);

    // -> non realtime context
    void initAndRun();

};
