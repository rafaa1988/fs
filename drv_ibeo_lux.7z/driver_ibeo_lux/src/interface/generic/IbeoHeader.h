#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Header sent before each message
 * @author Maximilian Schier
 */
struct __attribute__((packed)) LadarHeader {

    /**
     * Size of previous message in bytes, used to navigate in backwards in recordings, can be ignored
     */
    big_uint32_t prevMessageSize;

    /**
     * Size of messages following this header in bytes
     */
    big_uint32_t messageSize;

    /**
     * This field reserved for future use
     */
    uint8_t reserved;

    /**
     * Device ID of the sending device
     */
    uint8_t deviceId;

    /**
     * Data type of following message
     */
    big_uint16_t dataType;

    /**
     * NTP time stamp of this header
     */
    big_uint64_t ntpTime;

    /**
     * Indicates object detection data follows
     */
    static constexpr uint16_t DATA_TYPE_OBJECT_DATA   = 0x2221;

    /**
     * Indicates raw scan data follows
     */
    static constexpr uint16_t DATA_TYPE_SCAN_DATA     = 0x2202;

    /**
     * Indicates a command follows
     */
    static constexpr uint16_t DATA_TYPE_COMMAND       = 0x2010;

    /**
     * Indicates a command reply follows
     */
    static constexpr uint16_t DATA_TYPE_COMMAND_REPLY = 0x2020;

    /**
     * Indicates vehicle state data follows
     */
    static constexpr uint16_t DATA_TYPE_VEHICLE_STATE = 0x2805;

    static constexpr uint16_t DATA_TYPE_ERROR         = 0x2030;
};
