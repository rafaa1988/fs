#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Data point for each scan echo
 * @author Maximilian Schier, Nikolai Hansen, Jan Carstensen
 */
struct __attribute__((packed)) ScanDataPoint {
    uint8_t                 layerEcho;          // scan layer of this point (uint4_H)
    // echo number of this point (uint4_L)
    uint8_t                 flags;
    // 0x01:    transparent point
    // 0x02:    rain/snow/spray/fog/...
    // 0x04:    ground
    // 0x08:    dirt
    // 0xF0:    reserved
    little_int16_t                  angle;              // angle of this point in angle ticks
    little_uint16_t                 distance;           // distance of this point in cm
    little_uint16_t                 pulseWidth;         // detected with of hte echo pulse in cm
    little_uint16_t                 reserved;           // -

    static constexpr uint8_t FLAG_TRANSPARENT = 0x01;
    static constexpr uint8_t FLAG_CLUTTER     = 0x02;
    static constexpr uint8_t FLAG_GROUND      = 0x04;
    static constexpr uint8_t FLAG_DIRT        = 0x08;
};

/**
 * @brief Scan data message send after each measurement
 * @author Maximilian Schier, Nikolai Hansen, Jan Carstensen
 */
struct __attribute__((packed)) ScanData {

    static constexpr size_t SCAN_POINT_MAX = 10000;

    // NOTE: reverse order of NTP seconds and fracs not in accordance with interface specifications

    little_uint16_t                 scanNum;
    little_uint16_t                 scannerStatus;
    little_uint16_t                 syncPhaseOffset;
    little_uint32_t                 scanStartSecondFracs;
    little_uint32_t                 scanStartSeconds;
    little_uint32_t                 scanEndSecondFracs;
    little_uint32_t                 scanEndSeconds;
    little_uint16_t                 angleTicksPerRot;
    little_int16_t                  startAngle;
    little_int16_t                  endAngle;
    little_uint16_t                 scanPoints;
    little_int16_t                  posYaw;
    little_int16_t                  posPitch;
    little_int16_t                  posRoll;
    little_int16_t                  posX;
    little_int16_t                  posY;
    little_int16_t                  posZ;
    little_uint16_t                 reserved;
    ScanDataPoint                   points[SCAN_POINT_MAX];
};