#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Error message send by sensor
 * @author Maximilian Schier
 */
struct __attribute__((packed)) ErrorMessage {
    little_uint16_t errorRegister1;
    little_uint16_t errorRegister2;
    little_uint16_t warningRegister1;
    little_uint16_t warningRegister2;
    little_uint16_t reserved1;
    little_uint16_t reserved2;
    little_uint16_t reserved3;
    little_uint16_t reserved4;

    bool hasInternalError() const;

    bool hasMotorFault() const;

    /**
     * Error in computation of environmental model. Can usually be fixed by sending a stop/start command sequence.
     * @return True indicates this error is present
     */
    bool resetEnvironmentalModel() const;

    std::string formatAsString() const;
};
