#include <sstream>
#include <iomanip>
#include "ErrorMessage.h"

bool ErrorMessage::hasInternalError() const {
    return static_cast<bool>(errorRegister1 & 0x0001);
}

bool ErrorMessage::hasMotorFault() const {
    return static_cast<bool>(errorRegister1 & 0x3c02);
}

std::string ErrorMessage::formatAsString() const {
    std::stringstream stream;

    if (errorRegister1 & 0x3c03) {
        stream << "Internal error, contact support ";
    }

    if (errorRegister1 & 0x000c) {
        stream << "Scan buffer error ";
    }

    if (errorRegister1 & 0x0300) {
        stream << "APD temperature error ";
    }

    if (errorRegister2 & 0x0080) {
        stream << "Reset environment model ";
    }

    if (errorRegister2 & 0x000f) {
        stream << "Internal error, contact support ";
    }

    if (errorRegister2 & 0x0030) {
        stream << "Misconfigured ";
    }

    if (errorRegister2 & 0x0040) {
        stream << "Data processing timeout ";
    }

    if (warningRegister1 & 0x0008) {
        stream << "Warning low temperature ";
    }

    if (warningRegister1 & 0x0010) {
        stream << "Warning high temperature ";
    }

    if (warningRegister1 & 0x0080) {
        stream << "Warning synchronization ";
    }

    if (warningRegister2 & 0x0008) {
        stream << "Incorrect scan data ";
    }

    if (warningRegister2 & 0x0040) {
        stream << "Memory access failure ";
    }

    stream << "... Bit fields: " << std::hex << "0x" << std::setw(4) << std::setfill('0') << errorRegister1 << ", "
                       << "0x" << std::setw(4) << std::setfill('0') << errorRegister2 << ", "
                       << "0x" << std::setw(4) << std::setfill('0') << warningRegister1 << ", "
                       << "0x" << std::setw(4) << std::setfill('0') << warningRegister2;
    return stream.str();
}

bool ErrorMessage::resetEnvironmentalModel() const {
    return static_cast<bool>(errorRegister2 & 0x0080);
}
