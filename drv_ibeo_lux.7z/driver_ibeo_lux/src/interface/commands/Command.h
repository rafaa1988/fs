#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Template structure for any command message send to the sensor
 * @tparam SubCommand Sub command encapsulated by the command message
 * @author Maximilian Schier
 */
template <typename SubCommand>
struct __attribute__((packed)) Command {

    /**
     * ID of command to be executed
     */
    little_uint16_t commandId;

    /**
     * Sub command data
     */
    SubCommand subCommand;
};
