#pragma once

#include "SubCommand.h"

/**
 * @brief Subcommand that resets the sensor's DSP
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandReset : public SubCommand<0x0000> {};