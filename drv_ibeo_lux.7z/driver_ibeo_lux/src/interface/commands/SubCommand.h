#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Template class for all sub commands to be send to the sensor
 * @tparam CommandId Id of this command that should be written to the command message header
 * @author Maximilian Schier
 *
 * Usually this template is not used directly for communication with the device, but rather
 * one of the extending structs
 */
template <uint16_t CommandId>
struct __attribute__((packed)) SubCommand {

    /**
     * Every command has this reserved field
     */
    little_uint16_t reserved;

    uint16_t commandId() const {
        return CommandId;
    }
};