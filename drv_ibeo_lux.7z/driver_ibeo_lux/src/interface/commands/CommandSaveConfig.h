#pragma once

#include "SubCommand.h"

/**
 * @brief Sub command to permanently write configuration to ROM
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandSaveConfig : public SubCommand<0x0004> {};