#pragma once

#include <type_traits>
#include "SubCommand.h"

/**
 * @brief Subcommand that sets a parameter
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandSetParameter : public SubCommand<0x0010> {
    little_uint16_t parameterIndex;
    uint8_t bytes[4];

    /**
     * Create a new set parameter command with the given index and value
     * @tparam T Native type of value
     * @param index Parameter index to be set
     * @param value Native value
     * @return Command with bytes correctly ordered
     */
    template <typename T>
    static CommandSetParameter createInNetworkOrder(uint16_t index, T value) {
        static_assert(std::is_arithmetic<T>(), "T must be arithmetic");
        static_assert(sizeof(T) <= 4, "T must be less than 5 bytes");

        CommandSetParameter cmd{};
        cmd.parameterIndex = index;

        // Byte payload always little endian, convert from native
        hphlib::PackedEndian<T, false /* LE */> networkValue;
        networkValue = value;

        std::memcpy(cmd.bytes, &networkValue, sizeof networkValue);

        return cmd;
    }
};