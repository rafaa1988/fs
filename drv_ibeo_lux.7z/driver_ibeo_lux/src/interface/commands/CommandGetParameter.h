#pragma once

#include "SubCommand.h"

/**
 * @brief Subcommand that queries a parameter
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandGetParameter : public SubCommand<0x0011> {
    little_uint16_t parameterIndex;
};