#pragma once

#include <cstdint>

namespace Parameters {
    static constexpr uint16_t IP_ADDRESS                  = 0x1000;
    static constexpr uint16_t TCP_PORT                    = 0x1001;
    static constexpr uint16_t CUSTOMER_PROCESSING_SWITCH0 = 0x1004;
    static constexpr uint16_t DATA_OUTPUT_FLAG            = 0x1012;
    static constexpr uint16_t START_ANGLE                 = 0x1100;
    static constexpr uint16_t END_ANGLE                   = 0x1101;
    static constexpr uint16_t SYNC_ANGLE_OFFSET           = 0x1103;
    static constexpr uint16_t SENSOR_MOUNTING_X           = 0x1200;
    static constexpr uint16_t SENSOR_MOUNTING_Y           = 0x1201;
    static constexpr uint16_t SENSOR_MOUNTING_Z           = 0x1202;
    static constexpr uint16_t SENSOR_MOUNTING_YAW         = 0x1203;
    static constexpr uint16_t SENSOR_MOUNTING_PITCH       = 0x1204;
    static constexpr uint16_t SENSOR_MOUNTING_ROLL        = 0x1205;
    static constexpr uint16_t VEHICLE_FRONT_TO_FRONT_AXLE = 0x1206;
    static constexpr uint16_t FRONT_AXLE_TO_REAR_AXLE     = 0x1207;
    static constexpr uint16_t REAR_AXLE_TO_VEHICLE_REAR   = 0x1208;
    static constexpr uint16_t DEVICE_TYPE                 = 0x3301;
}