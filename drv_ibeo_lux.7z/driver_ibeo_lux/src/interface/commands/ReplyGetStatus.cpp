#include <boost/endian/conversion.hpp>
#include <sstream>
#include <iomanip>
#include "ReplyGetStatus.h"

float ReplyGetStatus::temperatureCelsius() const {
    return (-(temperature - 579.2364f)) / 3.63f;
}

bool ReplyGetStatus::laserOn() const {
    return static_cast<bool>(scannerStatus & 0x0002);
}

bool ReplyGetStatus::motorOn() const {
    return static_cast<bool>(scannerStatus & 0x0001);
}

bool ReplyGetStatus::externalSyncDetected() const {
    return static_cast<bool>(scannerStatus & 0x0010);
}

bool ReplyGetStatus::syncOk() const {
    return static_cast<bool>(scannerStatus & 0x0020);
}

bool ReplyGetStatus::isSyncMaster() const {
    return static_cast<bool>(scannerStatus & 0x0040);
}

std::string ReplyGetStatus::serialString() const {
    std::stringstream stream;
    stream << std::hex << std::setw(2) << std::setfill('0') << (serial0 >> 8) << "-"
           << std::setw(2) << std::setfill('0') << (serial0 & 0xff) << "-"
           << std::dec << serial1;
    return stream.str();
}
