#pragma once

#include "SubCommand.h"

/**
 * @brief Subcommand that queries the sensor's status
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandGetStatus : public SubCommand<0x0001> {};