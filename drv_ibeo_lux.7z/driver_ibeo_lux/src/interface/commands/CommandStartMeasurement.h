#pragma once

#include "SubCommand.h"

/**
 * @brief Subcommand that starts all measurements
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandStartMeasurement : public SubCommand<0x0020> {};