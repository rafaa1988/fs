#pragma once

#include "SubCommand.h"

/**
 * @brief Subcommand that stops all measurements
 * @author Maximilian Schier
 */
struct __attribute__((packed)) CommandStopMeasurement : public SubCommand<0x0021> {};