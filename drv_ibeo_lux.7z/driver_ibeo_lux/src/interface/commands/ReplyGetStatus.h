#pragma once

#include <hphlib/PackedEndian.h>

/**
 * @brief Reply to 'GetStatus' sub command that queries sensor's status
 * @author Maximilian Schier
 */
struct __attribute__((packed)) ReplyGetStatus {

    /**
     * Get whether this is a sync master
     * @return True if master, false if slave
     */
    bool isSyncMaster() const;

    /**
     * Whether external sync was detected
     * @return True if so
     */
    bool externalSyncDetected() const;

    /**
     * Get whether laser is on
     * @return If laser is on
     */
    bool laserOn() const;

    /**
     * Get whether motor is on
     * @return If motor is on
     */
    bool motorOn() const;

    /**
     * Return a string representation of the serial number in the format yy-cw-counter
     * @return Serial as string
     */
    std::string serialString() const;

    /**
     * Get whether sync is ok
     * @return True if sync ok
     */
    bool syncOk() const;

    /**
     * Get the temperature of the camera in °C
     * @return Temperature °C
     */
    float temperatureCelsius() const;

    little_uint16_t firmwareVersion;
    little_uint16_t fpgaVersion;
    little_uint16_t scannerStatus;
    little_uint32_t reserved;
    little_uint16_t temperature;
    little_uint16_t serial0;
    little_uint16_t serial1;
    little_uint16_t reserved2;
    little_uint16_t fpgaTimeStamp[3];
    little_uint16_t dspTimeStamp[3];
};
