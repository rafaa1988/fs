#pragma once

#include <cstring>
#include <hphlib/PackedEndian.h>

/**
 * @brief Reply send by sensor in response to parameter queries
 * @author Maximilian Schier
 */
struct __attribute__((packed)) ReplyGetParameter {

    /**
     * Return the content of this reply as the native type specified by the template parameter
     * @tparam T Native type to be interpreted as, byte order automatically converted
     * @return Value of this reply
     */
    template <typename T>
    T as() const {
        static_assert(std::is_arithmetic<T>(), "T must be arithmetic");
        static_assert(sizeof(T) <= 4, "T must be at most 4 bytes");

        hphlib::PackedEndian<T, false /* LE */> result;

        std::memcpy(&result, bytes, sizeof result);

        return result;
    }

    little_uint16_t paramIndex;
    uint8_t bytes[4];
};
