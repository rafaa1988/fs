/*
 * Copyright (C) 2005-2018 University of Hannover
 *                         Institute for Systems Engineering - RTS
 *                         Professor Bernardo Wagner
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * Authors
 *      Nikolai Hansen          <nikolai.hansen@web.de>
 *      Jan Carstensen          <carstensen@rts.uni-hannover.de>
 *      Maximilian Schier       <max.schier@gmail.com> (Review and improvements for season 18)
 */

#include <chrono>
#include <thread>
#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include <pcl_ros/point_cloud.h>
#include "ibeo_lux.h"
#include "util.h"
#include "Configuration.h"
#include "interface/commands/Parameters.h"
#include "interface/commands/CommandStopMeasurement.h"
#include "interface/commands/CommandStartMeasurement.h"
#include "interface/generic/ErrorMessage.h"
#include "interface/commands/ReplyGetStatus.h"
#include "interface/commands/CommandGetStatus.h"

const int   LadarIbeoLux::STARTUP_GRACE_SECONDS            =   10;
const int   LadarIbeoLux::SYNC_WINDOW_SIZE_SECONDS         =    5;
const float LadarIbeoLux::SYNC_EXT_TRIGGER_RATIO_THRESHOLD = 0.80f;
const float LadarIbeoLux::SYNC_SYNC_RATIO_THRESHOLD        = 0.10f;

void LadarIbeoLux::measureDelay() {

    // First stop sending measurement data to not delay stream
    CommandStopMeasurement stop_cmd;
    driver_.awaitVoidCommand(stop_cmd);

    // Now perform timings
    std::vector<ros::Duration> one_way_times;

    ROS_INFO("Beginning RTT measurements");

    for (int i = 0; i < 30; ++i) {
        CommandGetParameter cmd{};
        cmd.parameterIndex = Parameters::IP_ADDRESS;

        // Time duration of simple get parameter command to determine rtt
        ros::Time start = ros::Time::now();
        driver_.awaitCommand<ReplyGetParameter>(cmd);
        ros::Time stop = ros::Time::now();

        ros::Duration rtt = stop - start;

        // One way time is half RTT, queueing and processing delays ignored
        one_way_times.push_back(rtt * 0.5);
    }

    // Take median of one way times, mean would be dominated by outliers
    std::sort(one_way_times.begin(), one_way_times.end());
    medianOneWayTime = one_way_times[one_way_times.size() / 2];

    ROS_INFO_STREAM("Median one way time: " << medianOneWayTime.toSec());
}

void LadarIbeoLux::pubPointCloudMsgs(ScanData &scanData, ros::Time timeStamp) {
    int layer;
    float horizontalAngle, layerVertAngle, range;

    pcl::PointCloud<pcl::PointXYZRGBL> cloud;

    for (int i = 0; i < scanData.scanPoints; i++) {

        layer = (scanData.points[i].layerEcho & 0x0F);

        //set Vertical angle
        if (layer == 0) {
            layerVertAngle = VERTICAL_ANGLE_LAYER_0;
        } else if (layer == 1) {
            layerVertAngle = VERTICAL_ANGLE_LAYER_1;
        } else if (layer == 2) {
            layerVertAngle = VERTICAL_ANGLE_LAYER_2;
        } else if (layer == 3) {
            layerVertAngle = VERTICAL_ANGLE_LAYER_3;
        } else {
            ROS_WARN_STREAM("Invalid layer index: " << layer);
            continue;
        }

        //set range
        range = static_cast<float>(scanData.points[i].distance * CM_TO_METER);

        //Calculate horizontal angle in radian
        horizontalAngle = static_cast<float>(scanData.points[i].angle * HORIZONTAL_ANGLE_INCREMENT_RADIAN);

        pcl::PointXYZRGBL this_point;
        this_point.x = std::cos(layerVertAngle) * std::cos(horizontalAngle) * range;
        this_point.y = std::cos(layerVertAngle) * std::sin(horizontalAngle) * range;
        this_point.z = std::sin(layerVertAngle) * range;

        auto flags = scanData.points[i].flags;

        if (flags & ScanDataPoint::FLAG_DIRT) {
            this_point.rgba = hphlib::LIDAR_COLOR_DIRT;
        } else if (flags & ScanDataPoint::FLAG_GROUND) {
            this_point.rgba = hphlib::LIDAR_COLOR_GROUND;
        } else if (flags & ScanDataPoint::FLAG_CLUTTER) {
            this_point.rgba = hphlib::LIDAR_COLOR_CLUTTER;
        } else {
            this_point.rgba = hphlib::LIDAR_COLOR_NEUTRAL;
        }

        this_point.label = scanData.points[i].pulseWidth.native();

        cloud.push_back(this_point);
    }

    cloud.header.stamp = pcl_conversions::toPCL(timeStamp);
    cloud.header.frame_id = frameIdPrefix + FRAME_ID_POINTCLOUD;

    pcPublisher.publish(cloud);
}

void LadarIbeoLux::pubLaserScanMsgs(ScanData &scanData , ros::Time timeStamp) {
    //Init LaserScan.msg
    int layer;
    int echo;

    layer0LaserScan_pub = sensor_msgs::LaserScan(layer0LaserScan);
    layer1LaserScan_pub = sensor_msgs::LaserScan(layer1LaserScan);
    layer2LaserScan_pub = sensor_msgs::LaserScan(layer2LaserScan);
    layer3LaserScan_pub = sensor_msgs::LaserScan(layer3LaserScan);

    layer0LaserScan_pub.header.stamp = timeStamp;
    layer1LaserScan_pub.header.stamp = timeStamp;
    layer2LaserScan_pub.header.stamp = timeStamp;
    layer3LaserScan_pub.header.stamp = timeStamp;

    //store scanpoints in laserScan-Message
    for (int i = 0; i < scanData.scanPoints; i++)
    {
        layer =   (scanData.points[i].layerEcho & 0x0F);
        echo  =  ((scanData.points[i].layerEcho & 0xF0) >> 4);

        //Fill laserScan-Messages with ranges
        if (echo == 0) {
            if(layer == 0) {
                layer0LaserScan_pub.ranges[(-LAST_ANGLE_INCR_LAYER_0 + scanData.points[i].angle) / ibeoAngularIncrementSteps]= scanData.points[i].distance * CM_TO_METER;
            } else if (layer == 1) {
                layer1LaserScan_pub.ranges[(-LAST_ANGLE_INCR_LAYER_1 + scanData.points[i].angle) / ibeoAngularIncrementSteps]= scanData.points[i].distance * CM_TO_METER;
            } else if (layer == 2) {
                layer2LaserScan_pub.ranges[(-LAST_ANGLE_INCR_LAYER_2 + scanData.points[i].angle) / ibeoAngularIncrementSteps]= scanData.points[i].distance * CM_TO_METER;
            } else if (layer == 3) {
                layer3LaserScan_pub.ranges[(-LAST_ANGLE_INCR_LAYER_3 + scanData.points[i].angle) / ibeoAngularIncrementSteps]= scanData.points[i].distance * CM_TO_METER;
            }
        }
    }

    //Publish laserScan-Messages
    LadarIbeoLux::ibeoLayer0_pub.publish(layer0LaserScan_pub);
    LadarIbeoLux::ibeoLayer1_pub.publish(layer1LaserScan_pub);
    LadarIbeoLux::ibeoLayer2_pub.publish(layer2LaserScan_pub);
    LadarIbeoLux::ibeoLayer3_pub.publish(layer3LaserScan_pub);
}

void LadarIbeoLux::moduleSpinOnce() {
    ros::Time ladarSendTime;

    if ((ros::Time::now() - time_of_last_status_query_).toSec() > 10.0) {

        time_of_last_status_query_ = ros::Time::now();

        CommandGetStatus cmd;
        auto status = driver_.awaitCommand<ReplyGetStatus>(cmd);

        stageStatusTelemetry(status.scannerStatus);
        tele_.stage("temp", status.temperatureCelsius());
    }

    try {
        driver_.synchronizeOnMagicWord();
    } catch (const std::system_error& e) {
        if (hphlib::isBlockingException(e)) {
            // Timeout while reading socket, if it takes too long to recover, restart device
            if ((ros::Time::now() - last_successful_frame_time_).toSec() > 10.0) {
                restartSensor();
            } else {
                tele_.stage("points", 0);
                tele_.report("status", "timeout");
                return;
            }
        } else {
            // Else rethrow
            throw;
        }
    }

    last_successful_frame_time_ = ros::Time::now();

    LadarHeader header = driver_.readHeader();

    ros::Time header_recording_time = ros::Time::now();

    if (header.messageSize > message_buffer_.size()) {
        std::stringstream estream;
        estream << "Ladar header indicates message size of " << header.messageSize
                << ", maximum supported is " << message_buffer_.size();
        throw std::runtime_error(estream.str());
    }

    // read ladar data body
    driver_.readMessage(&message_buffer_[0], header.messageSize);

    // parse ladar data body
    if (header.dataType == LadarHeader::DATA_TYPE_SCAN_DATA) {
        ScanData ladarScanData{};

        // Copy only as much as actually received
        std::memcpy(&ladarScanData, &message_buffer_[0], header.messageSize);

        // Update sync watchdog window, required since the sensor sometimes fails to synchronize on external trigger
        // in which case it has to be restarted

        bool ext_trig = static_cast<bool>(ladarScanData.scannerStatus & 0x0010);
        bool sync_ok  = static_cast<bool>(ladarScanData.scannerStatus & 0x0020);

        sync_window_.update(std::make_pair(ext_trig, sync_ok));

        bool restart_bad_sync = false;

        // If the sensor has been running for a full window length and the additional startup grace period
        if (std::chrono::steady_clock::now() > sensor_start_ + std::chrono::seconds(STARTUP_GRACE_SECONDS + SYNC_WINDOW_SIZE_SECONDS)) {

            // Count triggered and synchronized samples in window
            size_t samples_with_trigger = 0;
            size_t samples_with_sync    = 0;

            for (const auto & p : sync_window_) {
                if (p.first) {
                    samples_with_trigger++;
                }
                if (p.second) {
                    samples_with_sync++;
                }
            }

            float trigger_ratio = static_cast<float>(samples_with_trigger) / sync_window_.size();
            float sync_ratio    = static_cast<float>(samples_with_sync)    / sync_window_.size();
            
            tele_.stage("sync", sync_ratio);

            // If ratios above threshold detect potential out of sync and restart, but only do so if it is safe
            // to restart, that is the vehicle is off
            if (trigger_ratio > SYNC_EXT_TRIGGER_RATIO_THRESHOLD && sync_ratio < SYNC_SYNC_RATIO_THRESHOLD) {
                if (status_monitor_.state() == hphlib::vehicle::StatusMonitor::STATE_OFF) {
                    restart_bad_sync = true;
                }
            }
        }

        if (ladarScanData.scanPoints == 0 || restart_bad_sync) {
            if (ladarScanData.scanPoints == 0) {
                ROS_WARN("Restarting sensor because no points received...");
            } else {
                ROS_WARN("Restarting sensor because bad sync...");
            }
            restartSensor();
            ROS_WARN("Done restarting");
            return;
        }

        // calculate ladar timestamps
        scanStartTime = ntpToROSTime(ladarScanData.scanStartSeconds, ladarScanData.scanStartSecondFracs);
        scanEndTime   = ntpToROSTime(ladarScanData.scanEndSeconds, ladarScanData.scanEndSecondFracs);
        
        //ROS_INFO_STREAM("Median OWT:    " << medianOneWayTime);
        //ROS_INFO_STREAM("Scan start:    " << scanStartTime);
        //ROS_INFO_STREAM("Scan end:      " << scanEndTime);
        //ROS_INFO_STREAM("Scan duration: " << (scanEndTime - scanStartTime));
        //ROS_INFO_STREAM("Header time:   " << driver_.lastMessageUncorrectedTime());
        //ROS_INFO_STREAM("Header to start: " << (driver_.lastMessageUncorrectedTime() - scanStartTime));

        // Corrected start time is time point of received trigger signal in local computer ROS time,
        // Timing frame is:
        // Start ..... Sync ..... End ...... Message Header ... Network Delay | Timeframes
        // Since Sync is not availble, calculate it from the ratio of sync to start and stop angles
        ros::Time correctedStartTime = header_recording_time - (medianOneWayTime + (driver_.lastMessageUncorrectedTime() - scanEndTime) + ((scanEndTime - scanStartTime) * (1 - sync_angle_ratio_from_full_ratio_)));

        tele_.stage("status", "running");
        stageStatusTelemetry(ladarScanData.scannerStatus);
        tele_.stage("points", ladarScanData.scanPoints.native());

        // Always stage the current sync angle of the sensor, useful to later debug recordings
        tele_.stage("sync-ang", sync_angle_offset_);

        // Publish ROS-Messages if subscribed, don't need to deliver more work preparing the message if nobody listens
        if(pcPublisher.getNumSubscribers() >= 1) {
            pubPointCloudMsgs(ladarScanData, correctedStartTime);
        }

        if(ibeoLayer0_pub.getNumSubscribers() >= 1 || ibeoLayer1_pub.getNumSubscribers() >= 1 || ibeoLayer2_pub.getNumSubscribers() >= 1 || ibeoLayer3_pub.getNumSubscribers() >= 1) {
            pubLaserScanMsgs(ladarScanData, correctedStartTime);
        }

    } else if (header.dataType == LadarHeader::DATA_TYPE_VEHICLE_STATE) {
        // Vehicle state is just CAN pass-through
    } else if (header.dataType == LadarHeader::DATA_TYPE_OBJECT_DATA) {
        // Object detection unsuited for small objects
    } else if (header.dataType == LadarHeader::DATA_TYPE_ERROR) {

        if (header.messageSize != sizeof(ErrorMessage)) {
            ROS_WARN("Sensor send error message of unexpected size");
            return;
        }

        ErrorMessage err{};

        std::memcpy(&err, &message_buffer_[0], sizeof err);

        ROS_WARN_STREAM("Sensor failure: " << err.formatAsString());
    } else {
        ROS_INFO("Unknown data type: 0x%x, size %d", header.dataType, header.messageSize);
    }

    tele_.report();
}

// === initialize LaserScan message ===
void LadarIbeoLux::initLaserScanMsg(void) {
    //Fill laserScan-Messages with Meta-Data
    layer0LaserScan.header.frame_id = frameIdPrefix + FRAME_ID_LAYER0;//"base_laser_front_layer_0_link";
    layer0LaserScan.angle_min = LAST_ANGLE_INCR_LAYER_0 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer0LaserScan.angle_max = FIRST_ANGLE_INCR_LAYER_0 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer0LaserScan.angle_increment = ibeoAngularIncrementSteps * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer0LaserScan.range_min = LADAR_IBEO_LUX_MIN_RANGE;//N in Meter
    layer0LaserScan.range_max = LADAR_IBEO_LUX_MAX_RANGE;
    layer0LaserScan.ranges.resize(((FIRST_ANGLE_INCR_LAYER_0 - LAST_ANGLE_INCR_LAYER_0) / ibeoAngularIncrementSteps) + 1, LASERSCANMSG_NO_ECHO_RECEIVED);
    layer0LaserScan.time_increment = (scanEndTime.toSec() - scanStartTime.toSec()) * static_cast<double> (ibeoAngularIncrementSteps) / (static_cast<double> (FIRST_ANGLE_INCR_LAYER_0 - LAST_ANGLE_INCR_LAYER_0));//N 50Hz-> 55554.0nsec Time_Inc
    layer0LaserScan.scan_time = scanTime;

    layer1LaserScan.header.frame_id = frameIdPrefix + FRAME_ID_LAYER1;//"base_laser_front_layer_1_link";
    layer1LaserScan.angle_min = LAST_ANGLE_INCR_LAYER_1 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer1LaserScan.angle_max = FIRST_ANGLE_INCR_LAYER_1 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer1LaserScan.angle_increment = ibeoAngularIncrementSteps * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer1LaserScan.range_min = LADAR_IBEO_LUX_MIN_RANGE;//N in Meter
    layer1LaserScan.range_max = LADAR_IBEO_LUX_MAX_RANGE;
    layer1LaserScan.ranges.resize(((FIRST_ANGLE_INCR_LAYER_1 - LAST_ANGLE_INCR_LAYER_1) / ibeoAngularIncrementSteps) + 1, LASERSCANMSG_NO_ECHO_RECEIVED);
    layer1LaserScan.time_increment = (scanEndTime.toSec() - scanStartTime.toSec()) * static_cast<double> (ibeoAngularIncrementSteps) / (static_cast<double> (FIRST_ANGLE_INCR_LAYER_1 - LAST_ANGLE_INCR_LAYER_1));//N 50Hz-> 55554.0nsec Time_Inc
    layer1LaserScan.scan_time = scanTime;

    layer2LaserScan.header.frame_id = frameIdPrefix + FRAME_ID_LAYER2;//"base_laser_front_layer_2_link";
    layer2LaserScan.angle_min = LAST_ANGLE_INCR_LAYER_2 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer2LaserScan.angle_max = FIRST_ANGLE_INCR_LAYER_2 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer2LaserScan.angle_increment = ibeoAngularIncrementSteps * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer2LaserScan.range_min = LADAR_IBEO_LUX_MIN_RANGE;//N in Meter
    layer2LaserScan.range_max = LADAR_IBEO_LUX_MAX_RANGE;
    layer2LaserScan.ranges.resize(((FIRST_ANGLE_INCR_LAYER_2 - LAST_ANGLE_INCR_LAYER_2) / ibeoAngularIncrementSteps) + 1, LASERSCANMSG_NO_ECHO_RECEIVED);
    layer2LaserScan.time_increment = (scanEndTime.toSec() - scanStartTime.toSec()) * static_cast<double> (ibeoAngularIncrementSteps) / (static_cast<double> (FIRST_ANGLE_INCR_LAYER_2 - LAST_ANGLE_INCR_LAYER_2));//N 50Hz-> 55554.0nsec Time_Inc
    layer2LaserScan.scan_time = scanTime;

    layer3LaserScan.header.frame_id = frameIdPrefix + FRAME_ID_LAYER3;//"base_laser_front_layer_3_link";
    layer3LaserScan.angle_min = LAST_ANGLE_INCR_LAYER_3 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer3LaserScan.angle_max = FIRST_ANGLE_INCR_LAYER_3 * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer3LaserScan.angle_increment = ibeoAngularIncrementSteps * HORIZONTAL_ANGLE_INCREMENT_RADIAN;
    layer3LaserScan.range_min = LADAR_IBEO_LUX_MIN_RANGE;//N in Meter
    layer3LaserScan.range_max = LADAR_IBEO_LUX_MAX_RANGE;
    layer3LaserScan.ranges.resize(((FIRST_ANGLE_INCR_LAYER_3 - LAST_ANGLE_INCR_LAYER_3) / ibeoAngularIncrementSteps) + 1, LASERSCANMSG_NO_ECHO_RECEIVED);
    layer3LaserScan.time_increment = (scanEndTime.toSec() - scanStartTime.toSec()) * static_cast<double> (ibeoAngularIncrementSteps) / (static_cast<double> (FIRST_ANGLE_INCR_LAYER_3 - LAST_ANGLE_INCR_LAYER_3));//N 50Hz-> 55554.0nsec Time_Inc
    layer3LaserScan.scan_time = scanTime;
}

void LadarIbeoLux::initAndRun() {

    ROS_INFO_STREAM("Beginning to connect to " << ladarIp << ":" << ladarPort);

    for (;;) {

        stageStatusTelemetry();
        tele_.report("status", "connect");

        try {
            driver_.connectDevice(ladarIp, static_cast<uint16_t>(ladarPort));
            break;
        } catch (std::exception& e) {
            ROS_WARN_STREAM("Failed to connect to ladar at " << ladarIp << ":" << ladarPort << ": " << e.what());

            std::this_thread::sleep_for(std::chrono::seconds(1));

            ros::spinOnce();

            if (!ros::ok()) {
                throw std::runtime_error("ROS went down while connecting");
            }
        }
    }

    ROS_INFO("Successfully connected");

    tele_.report("status", "init");

    measureDelay();

    Configuration::loadOriginConfiguration(driver_);

    // Set the sync angle and check it
    Configuration::setSyncAngleOffsetDegrees(driver_, sync_angle_offset_);

    float sync_angle_readback = Configuration::querySyncAngleOffsetDegree(driver_);
    
    float start_angle = Configuration::queryStartAngleDegree(driver_);
    float stop_angle  = Configuration::queryStopAngleDegree(driver_);
    
    // Calculate the ratio of start to sync from full start to stop to figure out time of sync from time of start and time of end of measurement
    // Start -------- Sync -------- End | Angles
    // <---------------->
    // <------------------------------>
    sync_angle_ratio_from_full_ratio_ = (sync_angle_readback - start_angle) / (stop_angle - start_angle);

    if (sync_angle_readback != sync_angle_offset_) {
        std::stringstream stream;
        stream << "Failed to set sensor sync angle: " << sync_angle_readback << " (read back) != "
               << sync_angle_offset_ << " (target)";

        throw std::runtime_error(stream.str());
    }

    restartSensor();

    // Set the last successful frame time to now to not immediately restart the sensor, it is still spinning up
    last_successful_frame_time_ = ros::Time::now();

    // Get status
    Configuration::dumpSensorStatus(driver_);
    Configuration::dumpSensorConfiguration(driver_);


    initLaserScanMsg();

    while (ros::ok()) {
        moduleSpinOnce();
        ros::spinOnce();
    }
}

LadarIbeoLux::LadarIbeoLux(ros::NodeHandle& n)
    : sync_window_(std::chrono::seconds(SYNC_WINDOW_SIZE_SECONDS))
    , tele_(getRequiredRosParam<std::string>(n, "tele_node"))
    , status_monitor_(n)
{
    ladarIp               = getRequiredRosParam<std::string>(n, "ladarIp");
    ladarPort             = 12002;
    ladarFrequencyMode_hz = getRequiredRosParam<float>(n, "ladarFrequencyMode_hz");
    frameIdPrefix         = getRequiredRosParam<std::string>(n, "frameIdPrefix");
    sync_angle_offset_    = getRequiredRosParam<float>(n, "syncAngle");

    if (ladarFrequencyMode_hz == 12.5) {
        ibeoAngularIncrementSteps = 8;      //50Hz->32*[1/32°] 25Hz->16*[1/32°] 12,5Hz->8*[1/32°]
        scanTime = 0.08;                    //[sec] Time between Scans 50Hz->0.02 25Hz->0.04 12,5->0.08
    } else if (ladarFrequencyMode_hz == 25) {
        ibeoAngularIncrementSteps = 16;
        scanTime = 0.04;
    } else if (ladarFrequencyMode_hz == 50) {
        ibeoAngularIncrementSteps = 32;
        scanTime = 0.02;
    } else {
        throw std::runtime_error("ladarFrequencyMode_hz must be specified as '12.5', '25' or '50'.");
    }

    // Initialize Publishers
    ibeoLayer0_pub    = n.advertise<sensor_msgs::LaserScan>("ibeo_layer_0", 10);
    ibeoLayer1_pub    = n.advertise<sensor_msgs::LaserScan>("ibeo_layer_1", 10);
    ibeoLayer2_pub    = n.advertise<sensor_msgs::LaserScan>("ibeo_layer_2", 10);
    ibeoLayer3_pub    = n.advertise<sensor_msgs::LaserScan>("ibeo_layer_3", 10);
    pcPublisher       = n.advertise<sensor_msgs::PointCloud2>("ibeo_pointcloud",10);
}

void LadarIbeoLux::restartSensor() {

    // Fake status disabled while restarting
    stageStatusTelemetry();

    tele_.report("status", "restart");

    CommandStopMeasurement stop;
    driver_.awaitVoidCommand(stop);

    CommandStartMeasurement start;
    driver_.awaitVoidCommand(start);

    // Reset the sensor start time to now
    sensor_start_ = std::chrono::steady_clock::now();
}

void LadarIbeoLux::stageStatusTelemetry(uint16_t status_word, int points) {
    tele_.stage("motor", static_cast<bool>(status_word & 0x0001));
    tele_.stage("laser", static_cast<bool>(status_word & 0x0002));
    tele_.stage("ext_trig", static_cast<bool>(status_word & 0x0010));
    tele_.stage("sync_ok",  static_cast<bool>(status_word & 0x0020));
    tele_.stage("points", points);
}

int  main(int argc, char *argv[]) {

    ros::init(argc, argv, "Driver Ibeo Lux");
    ros::NodeHandle n("~");

    try {
        LadarIbeoLux pInst(n);

        pInst.initAndRun();
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }

    return EXIT_SUCCESS;
}
