# ROS Node icp
Calculates odometry from point clouds using Iterative Closest Point (ICP)

