#pragma once

// forward declared dependencies
namespace tf {
    class TransformListener;
}

#include <utility>
#include <pcl_ros/point_cloud.h>
#include <ros/node_handle.h>
//#include "util.h"
#include <nav_msgs/Odometry.h>






//#include "pcl_extensions.h"

class ICPNode {

private:
    //rosparam
    std::string topic_subscribe;
    std::string topic_publish;
    std::string odom_frame_id;
    int min_number_of_points;
    double init_correspondence_distance;
    int icp_max_tries;
    double add_to_correspondence_distance;
    int icp_maximum_iterations;
    bool set_transformation_epsilon;
    double transformation_epsilon;
    bool set_euclidean_fitness_epsilon;
    double euclidean_fitness_epsilon;

    //variabels
    ros::Publisher publisher;
    ros::Subscriber subscriber;
    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr previous_frame;
    nav_msgs::Odometry odom;
    tf::TransformListener *tf_listener;

    //functions
    void callback(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &input_cloud);
    void publishOdom(std_msgs::Header header, Eigen::Matrix4f transform_eigen);

public:
    explicit ICPNode(ros::NodeHandle& n);
    ICPNode(const ICPNode& that) = delete;
    ICPNode(ICPNode&& that) = delete;
    ICPNode& operator=(const ICPNode& that) = delete;
    ICPNode& operator=(ICPNode && that) = delete;
};

