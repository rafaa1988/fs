#include <ros/ros.h>
//#include <telemetry/Runner.h>
#include "ICPNode.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "icp");

    ros::NodeHandle n("~");

    ICPNode icp_node(n);

    ROS_INFO("icp node launched");

    while (ros::ok()) {
        ros::spinOnce();
    }

    return EXIT_SUCCESS;
}