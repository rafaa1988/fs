

#include "ICPNode.h"
#include <pcl/registration/icp.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>
#include <boost/make_shared.hpp>
#include <geometry_msgs/Pose.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <pcl_ros/transforms.h>
#include "tf/transform_listener.h"
#include <hphlib/util.h>


ICPNode::ICPNode(ros::NodeHandle &n)
        : topic_subscribe(getRequiredRosParam<std::string>(n, "topic_subscribe"))
        , topic_publish(getRequiredRosParam<std::string>(n, "topic_publish"))
        , odom_frame_id(getRequiredRosParam<std::string>(n, "odom_frame_id"))
        , min_number_of_points(getRequiredRosParam<int>(n, "min_number_of_points"))
        , init_correspondence_distance(getRequiredRosParam<double>(n, "init_correspondence_distance"))
        , icp_max_tries(getRequiredRosParam<int>(n, "icp_max_tries"))
        , add_to_correspondence_distance(getRequiredRosParam<double>(n, "add_to_correspondence_distance"))
        , icp_maximum_iterations(getRequiredRosParam<int>(n, "icp_maximum_iterations"))
        , set_transformation_epsilon(getRequiredRosParam<bool>(n, "set_transformation_epsilon"))
        , transformation_epsilon(getRequiredRosParam<double>(n, "transformation_epsilon"))
        , set_euclidean_fitness_epsilon(getRequiredRosParam<bool>(n, "set_euclidean_fitness_epsilon"))
        , euclidean_fitness_epsilon(getRequiredRosParam<double>(n, "euclidean_fitness_epsilon"))
        , publisher(n.advertise<nav_msgs::Odometry>(topic_publish, 1))
        , subscriber(n.subscribe<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_subscribe, 1, &ICPNode::callback, this))
{
    previous_frame = boost::make_shared<pcl::PointCloud<pcl::PointXYZRGBA>>();
    previous_frame->clear();
    tf_listener = new tf::TransformListener();

    odom.pose.pose.position.x = 0.0;
    odom.pose.pose.position.y = 0.0;
    odom.pose.pose.position.z = 0.0;
    tf::quaternionTFToMsg(tf::createQuaternionFromYaw(0),odom.pose.pose.orientation);
}



void ICPNode::callback(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &input_cloud) {

    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr current_frame(new pcl::PointCloud<pcl::PointXYZRGBA>);
    *current_frame = *input_cloud;
    //transform Pointcloud to odometry-frame (ToDo evtl. could only the calculated transform be transformed to reduce the latency a little bit)

    pcl_ros::transformPointCloud(odom_frame_id, *current_frame, *current_frame, (*tf_listener));

    //Devel
    ros::Time begin_callback = ros::Time::now();
    ROS_INFO_STREAM("previous_frame->size() " << previous_frame->size() << "   current_frame->size() " << current_frame->size());


    //if enough points in current and previous frame: Do ICP
    if (current_frame->size() >= (unsigned) min_number_of_points && previous_frame->size() >= (unsigned) min_number_of_points)
    {
        pcl::IterativeClosestPoint<pcl::PointXYZRGBA, pcl::PointXYZRGBA> icp;
        // Set the input source and target
        icp.setInputSource (previous_frame);
        icp.setInputTarget (current_frame);
        // Set the maximum number of iterations (criterion 1)
        icp.setMaximumIterations (icp_maximum_iterations);
        // Set the transformation epsilon (criterion 2)
        if (set_transformation_epsilon)
            icp.setTransformationEpsilon (transformation_epsilon);
        // Set the euclidean distance difference epsilon (criterion 3)
        if (set_euclidean_fitness_epsilon)
            icp.setEuclideanFitnessEpsilon (euclidean_fitness_epsilon);

        double maxCorDistance = init_correspondence_distance;
        int tries = 0;
        while (tries < icp_max_tries && !icp.hasConverged())
        {
            // Set the max correspondence distance to 1m (e.g., correspondences with higher distances will be ignored)
            icp.setMaxCorrespondenceDistance (maxCorDistance);
            // Perform the alignment
            icp.align (*previous_frame);
            tries ++;
            ROS_INFO("Has converged: %d, fitness score: %f, try number: %d",icp.hasConverged(),icp.getFitnessScore(), tries);
            maxCorDistance += add_to_correspondence_distance;
        }

        if (icp.hasConverged()) {
            // Obtain the transformation that aligned previous_frame to current_frame
            Eigen::Matrix4f transformation = icp.getFinalTransformation ();
            std_msgs::Header header = pcl_conversions::fromPCL(current_frame->header);//fromPCL(input_cloud->header) ?
            //header.frame_id = input_cloud->header.frame_id;
            publishOdom(header, transformation);
        }
        else {
            ROS_WARN_STREAM("icp did not converge. No Odomtry published for this frame.");
        }

    }
    else
    {
        ROS_WARN_STREAM("min_number_of_points = "<< min_number_of_points << " not reached in current and / or last frame");
    }

    previous_frame = std::move(current_frame);
    //devel
    ros::Duration duration_callback = ros::Time::now() - begin_callback;
    ROS_INFO("duration_callback %f", duration_callback.toSec());
}

void ICPNode::publishOdom(std_msgs::Header header, Eigen::Matrix4f transform_eigen) {

    //calculating old yaw
    double yaw = tf::getYaw(odom.pose.pose.orientation);
    //updating position
    odom.pose.pose.position.x -= transform_eigen(0,3) * cos(yaw) - transform_eigen(1,3) * sin(yaw);
    odom.pose.pose.position.y -= transform_eigen(0,3) * sin(yaw) + transform_eigen(1,3) * cos(yaw);


    //updating yaw
    tf::Matrix3x3 R3x3(transform_eigen(0,0),transform_eigen(0,1),transform_eigen(0,2),
                       transform_eigen(1,0),transform_eigen(1,1),transform_eigen(1,2),
                       transform_eigen(2,0),transform_eigen(2,1),transform_eigen(2,2));


    double updateroll, updatepitch, updateyaw;
    R3x3.getRPY(updateroll, updatepitch, updateyaw);
    yaw = -updateyaw;

    ros::Duration ros_time_diff = header.stamp -  pcl_conversions::fromPCL(previous_frame->header.stamp);
    double time_diff = ros_time_diff.toSec();
    odom.twist.twist.linear.x = -transform_eigen(0,3) / time_diff;
    odom.twist.twist.linear.y = -transform_eigen(1,3) / time_diff;
    odom.twist.twist.linear.z = -transform_eigen(2,3) / time_diff;
    odom.twist.twist.angular.x = -updateroll / time_diff;
    odom.twist.twist.angular.y = -updatepitch / time_diff;
    odom.twist.twist.angular.z = -updateyaw / time_diff;

    /**
    //publish odom.pose for visualisation in rviz
    odom.pose.pose.position.x = odom.twist.twist.linear.x;
    odom.pose.pose.position.y = odom.twist.twist.linear.y; */
    tf::quaternionTFToMsg(tf::createQuaternionFromYaw(yaw),odom.pose.pose.orientation);


    //update header
    header.frame_id = odom_frame_id;
    odom.header = header;
    publisher.publish(odom);
}