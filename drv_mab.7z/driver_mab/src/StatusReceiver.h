#pragma once

#include <atomic>
#include <memory>
#include <thread>
#include <hphlib/io/UdpSocket.h>
#include <telemetry/Runner.h>
#include <hphlib/misc/PollService.h>

/**
 * Receive status datagrams from the RTCU via UDP/IP. Integrates with the ROS event loop and publishes telemetry and
 * ROS messages whenever status datagrams are received. Use with ros::spin().
 *
 * @author Maximilian Schier
 */
class StatusReceiver {
private:
    std::shared_ptr<hphlib::UdpSocket> sock_;
    ros::NodeHandle nh_;
    telemetry::Runner steer_tele_;
    telemetry::Runner mission_tele_;
    telemetry::Runner ebs_tele_;
    telemetry::Runner hv_tele_;
    telemetry::Runner lv_tele_;
    telemetry::Runner ts_fl_tele_;
    telemetry::Runner ts_fr_tele_;
    telemetry::Runner ts_rl_tele_;
    telemetry::Runner ts_rr_tele_;

    ros::Publisher steering_pub_;
    ros::Publisher status_pub_;
    hphlib::PollService poller_;
    ros::SteadyTimer timer_;
    uint8_t mission_overwrite_;

    /**
     * Read one status frame from the specified socket and handle it
     */
    void step();

public:
    /**
     * Register a new status receiver with the specified shared socket for the ROS event loop. Integrates with ROS'
     * poll set to asynchronously poll datagrams from the specified socket.
     * @param socket UDP socket to be used. Must be non-blocking
     */
    explicit StatusReceiver(std::shared_ptr<hphlib::UdpSocket> socket);
};
