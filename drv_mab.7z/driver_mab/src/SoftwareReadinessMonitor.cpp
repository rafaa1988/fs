#include "SoftwareReadinessMonitor.h"
#include <ros/node_handle.h>
#include <std_msgs/String.h>

SoftwareReadinessMonitor::SoftwareReadinessMonitor(ros::NodeHandle &n, const std::string &health_topic,
                                                   hphlib::vehicle::StatusMonitor &status_monitor)
    : sub_(n.subscribe<hphlib::Health>(health_topic, 1, &SoftwareReadinessMonitor::callback, this))
    , vehicle_mon_(&status_monitor)
    , last_msg_(0)
{
}

void SoftwareReadinessMonitor::callback(const hphlib::Health::ConstPtr& msg) {
    last_time_ = ros::Time::now();
    last_msg_ = msg->data;
}

bool SoftwareReadinessMonitor::readyToStartDriving() const {
    // If no message received, never ready
    if (last_msg_ == 0) {
        return false;
    }

    // If last message too old, not ready
    if (ros::Time::now() - last_time_ > ros::Duration(0.2)) {
        return false;
    }

    // If vehicle state is off or ready, only ready if really healthy
    if (vehicle_mon_->state() == hphlib::vehicle::StatusMonitor::STATE_OFF || vehicle_mon_->state() == hphlib::vehicle::StatusMonitor::STATE_READY) {
        return last_msg_ == hphlib::Health::HEALTHY;
    } else {
        // In all other states, ready if healthy or ill, don't want to kill car if we can still poorly run it
        return last_msg_ == hphlib::Health::HEALTHY || last_msg_ == hphlib::Health::ILL;
    }
}

