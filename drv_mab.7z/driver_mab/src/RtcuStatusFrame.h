#pragma once

#include <hphlib/PackedEndian.h>

struct __attribute__((packed)) RtcuStatusFrame {
    little_uint32_t magic;
    little_uint16_t ebs_info;
    little_f32_t hv_voltage;
    little_f32_t hv_current;
    little_uint16_t hv_info;
    little_f32_t lv_voltage;
    little_uint32_t inverter_info;
    little_int16_t steering_fsm_state;
    uint8_t steering_info;
    uint8_t ami_target;
    uint8_t as_fsm_state;

    bool asmsOn() const;

    bool hvPrechargeReady() const;
    bool hvBmsError() const;
    bool hvBmsCriticalVoltage() const;
    bool hvBmsCriticalTemperature() const;
    bool hvBmsTimeout() const;
    bool hvBmsTemperatureLoss() const;
    bool hvImdError() const;
    bool hvShutdownCircuitClosed() const;

    bool ebsReadyToActivate() const;
    bool ebsArmed() const;
    bool ebsServiceBrakeEngagaed() const;
    bool ebsTriggered() const;
    bool ebsDrivingStateSet() const;
    bool ebsLowPressure() const;
    bool ebsCriticalPressure() const;
    bool ebsHighPressure() const;
    bool ebsPressureSensorsWatchdogOkay() const;

    bool resRemoteAlive() const;

    bool steeringSensorFault() const;
    bool steeringControllerFault() const;
    bool steeringSensorWatchdogOkay() const;
    bool steeringOperational() const;

    bool tsFlReady() const;
    bool tsFlError() const;
    bool tsFlOn() const;
    bool tsFlHighTempMotor() const;
    bool tsFlHighTempInverter() const;
    bool tsFlHighTempIGBT() const;

    bool tsFrReady() const;
    bool tsFrError() const;
    bool tsFrOn() const;
    bool tsFrHighTempMotor() const;
    bool tsFrHighTempInverter() const;
    bool tsFrHighTempIGBT() const;

    bool tsRlReady() const;
    bool tsRlError() const;
    bool tsRlOn() const;
    bool tsRlHighTempMotor() const;
    bool tsRlHighTempInverter() const;
    bool tsRlHighTempIGBT() const;

    bool tsRrReady() const;
    bool tsRrError() const;
    bool tsRrOn() const;
    bool tsRrHighTempMotor() const;
    bool tsRrHighTempInverter() const;
    bool tsRrHighTempIGBT() const;
    
    static constexpr uint8_t AS_OFF = 0x01;
    static constexpr uint8_t AS_READY = 0x02;
    static constexpr uint8_t AS_DRIVING = 0x03;
    static constexpr uint8_t AS_EMERGENCY_STOP = 0x04;
    static constexpr uint8_t AS_FINISHED = 0x05;

    static constexpr uint8_t AMI_ACCEL = 0x01;
    static constexpr uint8_t AMI_SKIDPAD = 0x02;
    static constexpr uint8_t AMI_TRACKDRIVE = 0x03;
    static constexpr uint8_t AMI_BRAKETEST = 0x04;
    static constexpr uint8_t AMI_INSPECTION = 0x05;
};

static_assert(sizeof(RtcuStatusFrame) == 29, "Sanity check");

constexpr uint32_t MAGIC_RTCU_STATUS = 0x5342414d;
