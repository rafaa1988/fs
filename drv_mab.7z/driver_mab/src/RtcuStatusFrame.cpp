#include "RtcuStatusFrame.h"

bool RtcuStatusFrame::asmsOn() const {
    return static_cast<bool>(this->ebs_info & (1 << 8));
}

bool RtcuStatusFrame::steeringSensorFault() const {
    return static_cast<bool>(this->steering_info & (1 << 3));
}

bool RtcuStatusFrame::steeringOperational() const {
    return static_cast<bool>(this->steering_info & (1 << 1));
}

bool RtcuStatusFrame::steeringSensorWatchdogOkay() const {
    return static_cast<bool>(this->steering_info & (1 << 2));
}

bool RtcuStatusFrame::steeringControllerFault() const {
    return static_cast<bool>(this->steering_info & (1 << 0));
}

bool RtcuStatusFrame::resRemoteAlive() const {
    return static_cast<bool>(this->ebs_info & (1 << 10));
}

bool RtcuStatusFrame::ebsReadyToActivate() const {
    return static_cast<bool>(this->ebs_info & (1 << 0));
}

bool RtcuStatusFrame::ebsArmed() const {
    return static_cast<bool>(this->ebs_info & (1 << 1));
}

bool RtcuStatusFrame::ebsTriggered() const {
    return static_cast<bool>(this->ebs_info & (1 << 2));
}

bool RtcuStatusFrame::ebsDrivingStateSet() const {
    return static_cast<bool>(this->ebs_info & (1 << 3));
}

bool RtcuStatusFrame::ebsLowPressure() const {
    return static_cast<bool>(this->ebs_info & (1 << 4));
}

bool RtcuStatusFrame::ebsCriticalPressure() const {
    return static_cast<bool>(this->ebs_info & (1 << 5));
}

bool RtcuStatusFrame::ebsHighPressure() const {
    return static_cast<bool>(this->ebs_info & (1 << 6));
}

bool RtcuStatusFrame::ebsPressureSensorsWatchdogOkay() const {
    return static_cast<bool>(this->ebs_info & (1 << 7));
}

bool RtcuStatusFrame::ebsServiceBrakeEngagaed() const {
    return static_cast<bool>(this->ebs_info & (1 << 9));
}

bool RtcuStatusFrame::hvPrechargeReady() const {
    return static_cast<bool>(this->hv_info & (1 << 0));
}

bool RtcuStatusFrame::hvBmsError() const {
    return static_cast<bool>(this->hv_info & (1 << 1));
}

bool RtcuStatusFrame::hvBmsCriticalVoltage() const {
    return static_cast<bool>(this->hv_info & (1 << 2));
}

bool RtcuStatusFrame::hvBmsCriticalTemperature() const {
    return static_cast<bool>(this->hv_info & (1 << 3));
}

bool RtcuStatusFrame::hvBmsTimeout() const {
    return static_cast<bool>(this->hv_info & (1 << 4));
}

bool RtcuStatusFrame::hvBmsTemperatureLoss() const {
    return static_cast<bool>(this->hv_info & (1 << 5));
}

bool RtcuStatusFrame::hvImdError() const {
    return static_cast<bool>(this->hv_info & (1 << 6));
}

bool RtcuStatusFrame::hvShutdownCircuitClosed() const {
    return static_cast<bool>(this->hv_info & (1 << 7));
}

bool RtcuStatusFrame::tsFlReady() const {
    return static_cast<bool>(this->inverter_info & (1 << 0));
}

bool RtcuStatusFrame::tsFlError() const {
    return static_cast<bool>(this->inverter_info & (1 << 1));
}

bool RtcuStatusFrame::tsFlOn() const {
    return static_cast<bool>(this->inverter_info & (1 << 2));
}

bool RtcuStatusFrame::tsFlHighTempMotor() const {
    return static_cast<bool>(this->inverter_info & (1 << 3));
}

bool RtcuStatusFrame::tsFlHighTempInverter() const {
    return static_cast<bool>(this->inverter_info & (1 << 4));
}

bool RtcuStatusFrame::tsFlHighTempIGBT() const {
    return static_cast<bool>(this->inverter_info & (1 << 5));
}

bool RtcuStatusFrame::tsFrReady() const {
    return static_cast<bool>(this->inverter_info & (1 << 6));
}

bool RtcuStatusFrame::tsFrError() const {
    return static_cast<bool>(this->inverter_info & (1 << 7));
}

bool RtcuStatusFrame::tsFrOn() const {
    return static_cast<bool>(this->inverter_info & (1 << 8));
}

bool RtcuStatusFrame::tsFrHighTempMotor() const {
    return static_cast<bool>(this->inverter_info & (1 << 9));
}

bool RtcuStatusFrame::tsFrHighTempInverter() const {
    return static_cast<bool>(this->inverter_info & (1 << 10));
}

bool RtcuStatusFrame::tsFrHighTempIGBT() const {
    return static_cast<bool>(this->inverter_info & (1 << 11));
}

bool RtcuStatusFrame::tsRlReady() const {
    return static_cast<bool>(this->inverter_info & (1 << 12));
}

bool RtcuStatusFrame::tsRlError() const {
    return static_cast<bool>(this->inverter_info & (1 << 13));
}

bool RtcuStatusFrame::tsRlOn() const {
    return static_cast<bool>(this->inverter_info & (1 << 14));
}

bool RtcuStatusFrame::tsRlHighTempMotor() const {
    return static_cast<bool>(this->inverter_info & (1 << 15));
}

bool RtcuStatusFrame::tsRlHighTempInverter() const {
    return static_cast<bool>(this->inverter_info & (1 << 16));
}

bool RtcuStatusFrame::tsRlHighTempIGBT() const {
    return static_cast<bool>(this->inverter_info & (1 << 17));
}

bool RtcuStatusFrame::tsRrReady() const {
    return static_cast<bool>(this->inverter_info & (1 << 18));
}

bool RtcuStatusFrame::tsRrError() const {
    return static_cast<bool>(this->inverter_info & (1 << 19));
}

bool RtcuStatusFrame::tsRrOn() const {
    return static_cast<bool>(this->inverter_info & (1 << 20));
}

bool RtcuStatusFrame::tsRrHighTempMotor() const {
    return static_cast<bool>(this->inverter_info & (1 << 21));
}

bool RtcuStatusFrame::tsRrHighTempInverter() const {
    return static_cast<bool>(this->inverter_info & (1 << 22));
}

bool RtcuStatusFrame::tsRrHighTempIGBT() const {
    return static_cast<bool>(this->inverter_info & (1 << 23));
}
