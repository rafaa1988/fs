#pragma once

#include <hphlib/PackedEndian.h>

struct __attribute__((packed)) RtcuControlFrame {
    little_uint32_t magic;
    little_f32_t target_steering_angle;
    little_f32_t target_velocity;
    little_uint16_t request_flags;
    little_uint16_t cones_total;
    little_uint16_t cones_immediate;
    uint8_t lap_counter;
    uint8_t mission_read_back;

    /**
     * Flag to finish the current mission cleanly
     */
    static constexpr uint16_t FLAG_FINISH_MISSION = (1 << 0);

    /**
     * Flag to signal ASCU readiness to start driving
     */
    static constexpr uint16_t FLAG_ASCU_READY_TO_START_DRIVING = (1 << 2);
};

static_assert(sizeof(RtcuControlFrame) == 20, "Sanity check");

constexpr uint32_t MAGIC_RTCU_CONTROL = 0x4342414d;