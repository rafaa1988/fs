#pragma once

#include <hphlib/pcl.h>
#include <hphlib/Control.h>
#include <hphlib/Lap.h>
#include <hphlib/io/UdpSocket.h>
#include <memory>
#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <telemetry/Runner.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <pcl-1.7/pcl/impl/point_types.hpp>
#include <pcl-1.7/pcl/point_cloud.h>
#include "SoftwareReadinessMonitor.h"

/**
 * Receive control messages from the standard control topic and periodically send to the RTCU.
 *
 * Integrates with the ROS event loop through a steady timer, use with ros::spin().
 */
class ControlTransmitter {
private:
    std::shared_ptr<hphlib::UdpSocket> sock_;

    std::shared_ptr<telemetry::Runner> tele_;

    hphlib::UdpSocket::Endpoint remote_;

    ros::Subscriber control_sub_;
    ros::Subscriber lap_counter_sub_;
    ros::Subscriber global_map_sub_;
    ros::Subscriber left_local_sub_;
    ros::Subscriber right_local_sub_;

    hphlib::Control last_control_;
    uint8_t current_lap_;
    size_t global_cone_count_;
    size_t left_cone_count_;
    size_t right_cone_count_;

    bool finish_request_latch_;

    uint8_t mission_read_back_;

    std::chrono::steady_clock::time_point last_control_time_point_;

    ros::SteadyTimer timer_;

    hphlib::vehicle::StatusMonitor status_monitor_;

    SoftwareReadinessMonitor software_monitor_;

    void callback(const hphlib::Control::ConstPtr& msg);

    void lapCounterCallback(const hphlib::Lap::ConstPtr& msg);

    void globalMapCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map);
    void leftLocalCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map);
    void rightLocalCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map);

    void timer_callback(const ros::SteadyTimerEvent& ev);

    void sendControl();

public:
    explicit ControlTransmitter(std::shared_ptr<hphlib::UdpSocket> sock, std::shared_ptr<telemetry::Runner> tele, ros::NodeHandle& n);

    // Binding this, do not copy or move
    ControlTransmitter(const ControlTransmitter& that) = delete;
    ControlTransmitter& operator=(const ControlTransmitter& that) = delete;
};
