#include "ControlTransmitter.h"
#include "RtcuControlFrame.h"
#include <hphlib/util.h>

ControlTransmitter::ControlTransmitter(std::shared_ptr<hphlib::UdpSocket> sock, std::shared_ptr<telemetry::Runner> tele, ros::NodeHandle& n)
    : sock_(std::move(sock))
    , tele_(std::move(tele))
    , remote_(hphlib::UdpSocket::Endpoint(getRequiredRosParam<std::string>(n, "rtcu_host").c_str(), getRequiredRosParamPort(n, "rtcu_port")))
    , control_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "topic"), 1, &ControlTransmitter::callback, this))
    , lap_counter_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "lap_topic"), 1, &ControlTransmitter::lapCounterCallback, this))
    , global_map_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "global_map_topic"), 1, &ControlTransmitter::globalMapCallback, this))
    , left_local_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "left_local_topic"), 1, &ControlTransmitter::leftLocalCallback, this))
    , right_local_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "right_local_topic"), 1, &ControlTransmitter::rightLocalCallback, this))
    , current_lap_(0)
    , global_cone_count_(0)
    , left_cone_count_(0)
    , right_cone_count_(0)
    , finish_request_latch_(false)
    , mission_read_back_(0)
    , last_control_time_point_(decltype(last_control_time_point_)::min())  // Initialize watch dog timepoints to very early
    , timer_(n.createSteadyTimer(ros::WallDuration(0.1), &ControlTransmitter::timer_callback, this))
    , status_monitor_(n)
    , software_monitor_(n, "/health/master", status_monitor_)
{
    // Always reset finish request latch when vehicle changes state
    status_monitor_.set_state_change_callback([this] (auto& ignored) {
        (void) ignored;
        this->finish_request_latch_ = false;
    });

    // Always read back mission to the RTCU, so subscribe mission change listener
    status_monitor_.set_mission_change_callback([this] (uint8_t mission) {
        this->mission_read_back_ = mission;
    });

    // Clear last control message upon entering ready, this way if a controller does not immediately
    // publish upon GO, we do not publish an outdated control message of the last session
    status_monitor_.set_ready_callback([this] () {
        this->last_control_ = {};
    });
}

void ControlTransmitter::callback(const hphlib::Control::ConstPtr &msg) {
    last_control_ = *msg;
    last_control_time_point_ = std::chrono::steady_clock::now();

    // Latch finish mission request to not be overwritten by loudest talking publisher
    // Ignore finish mission request in any other state but driving or the driver might be stuck trying to
    // finish the mission which cannot happen because of wrong AS state
    if (msg->finish_mission && status_monitor_.state() == hphlib::vehicle::StatusMonitor::STATE_DRIVING) {
        finish_request_latch_ = true;
    }

    // Always send a control packet immediately, when a new software control message is received
    sendControl();
}

void ControlTransmitter::lapCounterCallback(const hphlib::Lap::ConstPtr& msg) {
    current_lap_ = msg->current_lap;
}

void ControlTransmitter::globalMapCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map) {
    global_cone_count_ = map->size();
}

void ControlTransmitter::leftLocalCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map) {
    left_cone_count_ = map->size();
}

void ControlTransmitter::rightLocalCallback(const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& map) {
    right_cone_count_ = map->size();
}

void ControlTransmitter::timer_callback(const ros::SteadyTimerEvent& ev) {
    (void) ev;

    // Periodically send a control message with low frequency to always keep RTCU updated on readiness
    sendControl();
}

void ControlTransmitter::sendControl() {
    RtcuControlFrame frame{};
    frame.magic = MAGIC_RTCU_CONTROL;
    frame.target_velocity = 0.0f;
    frame.target_steering_angle = 0.0f;
    frame.lap_counter = current_lap_;
    frame.cones_total = global_cone_count_;
    frame.cones_immediate = left_cone_count_ + right_cone_count_;
    frame.mission_read_back = mission_read_back_;

    uint16_t flags = 0;

    // Set the ASCU ready flag if the software monitor reports ASCU readiness
    if (software_monitor_.readyToStartDriving()) {
        flags |= RtcuControlFrame::FLAG_ASCU_READY_TO_START_DRIVING;
    }

    // If finish requested
    if (finish_request_latch_) {
        flags |= RtcuControlFrame::FLAG_FINISH_MISSION;

        frame.target_steering_angle = last_control_.steering_angle;
    } else {
        // Safe and sound

        frame.target_steering_angle = last_control_.steering_angle;
        frame.target_velocity       = last_control_.target_velocity;
    }

    frame.request_flags = flags;

    // Send control command to RTCU. If this blocks, warn but do not crash
    try {
        sock_->sendTo(reinterpret_cast<const uint8_t *>(&frame), sizeof frame, remote_);
    } catch (const std::system_error& e) {
        if (hphlib::isBlockingException(e)) {
            ROS_WARN("Connection to RTCU is blocked, cannot send control command");
        } else {
            throw;
        }
    }

    tele_->stage("ang_trgt", frame.target_steering_angle.native());
    tele_->stage("vel_trgt", frame.target_velocity.native());
    tele_->stage("ascu_rdy", static_cast<bool>(flags & RtcuControlFrame::FLAG_ASCU_READY_TO_START_DRIVING));
    tele_->stage("cones-total", global_cone_count_);
    tele_->stage("cones-immediate", frame.cones_immediate.native());

    tele_->report();
}
