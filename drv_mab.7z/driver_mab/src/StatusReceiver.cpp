#include <hphlib/vehicle/StatusMonitor.h>
#include <std_msgs/Float32.h>
#include "StatusReceiver.h"
#include "RtcuStatusFrame.h"

StatusReceiver::StatusReceiver(std::shared_ptr<hphlib::UdpSocket> socket)
    : sock_(std::move(socket))
    , steer_tele_("steer")
    , mission_tele_("mission")
    , ebs_tele_("ebs")
    , hv_tele_("hv")
    , lv_tele_("lv")
    , ts_fl_tele_("ts-fl")
    , ts_fr_tele_("ts-fr")
    , ts_rl_tele_("ts-rl")
    , ts_rr_tele_("ts-rr")
    , steering_pub_(nh_.advertise<std_msgs::Float32>("steering_angle", 10))
    , status_pub_(nh_.advertise<hphlib::Status>(hphlib::vehicle::StatusMonitor::STATUS_TOPIC, 1))
    , poller_(*sock_, [this] () { this->step(); })
    , mission_overwrite_(0)
{
    if (sock_->isBlocking()) {
        throw std::logic_error("Socket must be non-blocking");
    }
    
    ros::SteadyTimerCallback timer_cb = [this] (const auto& ev) {
        (void) ev;

        int mission;

        if (this->nh_.getParam("/test/mission_overwrite", mission)) {
            this->mission_overwrite_ = mission;
        }
    };
    
    // Immediately call timer callback to set mission overwrite from the start, otherwise may be interupted
    // by incoming packet before mission overwrite is set
    timer_cb({});

    // Periodically check mission overwrite until RTCU sends useful mission
    timer_ = nh_.createSteadyTimer(ros::WallDuration(0.5f), std::move(timer_cb));
}

std::string decodeFsm(uint8_t fsm) {
    switch (fsm) {
    case RtcuStatusFrame::AS_OFF:
        return hphlib::vehicle::StatusMonitor::STATE_OFF;
    case RtcuStatusFrame::AS_READY:
        return hphlib::vehicle::StatusMonitor::STATE_READY;
    case RtcuStatusFrame::AS_DRIVING:
        return hphlib::vehicle::StatusMonitor::STATE_DRIVING;
    case RtcuStatusFrame::AS_EMERGENCY_STOP:
        return hphlib::vehicle::StatusMonitor::STATE_EMERGENCY;
    case RtcuStatusFrame::AS_FINISHED:
        return hphlib::vehicle::StatusMonitor::STATE_FINISHED;
    default:
        std::stringstream stream;
        stream << "<invalid: " << static_cast<int>(fsm) << ">";
        return stream.str();
    }
}

void StatusReceiver::step() {
    RtcuStatusFrame frame{};
    
    // Over allocate buffer to detect too large datagrams
    std::array<uint8_t, sizeof(frame) + 32> buf{};

    size_t received;

    try {
        received = sock_->receive(buf.data(), buf.size());
    } catch (const std::system_error& e) {
        // Spurious notification on the poll set, this should not happen but handle it anyways
        ROS_WARN("Spurious wakeup on receiver socket");
        return;
    }

    // Warn if datagram size too large (i.e. newer version with more messages)
    if (received > sizeof(frame)) {
        ROS_WARN_STREAM("Expected " << sizeof(frame) << " bytes for status frame, got " << received);
    } else if (received < sizeof(frame)) {
        // Fail if datagram too small
        ROS_ERROR_STREAM("Status frame too small, dropping this frame, expected " << sizeof(frame) << ", got " << received);
        return;
    }

    std::memcpy(&frame, buf.data(), sizeof frame);

    if (frame.magic != MAGIC_RTCU_STATUS) {
        ROS_WARN_STREAM("Magic number mismatch for status frame, expected " << std::hex << MAGIC_RTCU_STATUS
                        << ", got " << std::hex << frame.magic);
        return;
    }

    uint8_t effective_mission = frame.ami_target;

    if (mission_overwrite_ != 0) {
        effective_mission = mission_overwrite_;
    }

    // Publish ros topics
    hphlib::Status status{};
    status.header.stamp = ros::Time::now();
    status.state = decodeFsm(frame.as_fsm_state);
    status.mission = effective_mission;
    status.asms_on = frame.asmsOn();
    status_pub_.publish(status);

    // Stage telemetry
    steer_tele_.stage("rdy", frame.steeringOperational());
    steer_tele_.stage("flt", frame.steeringControllerFault());
    steer_tele_.stage("range-wd", frame.steeringSensorWatchdogOkay());
    steer_tele_.stage("range-flt", frame.steeringSensorFault());
    steer_tele_.stage("state", frame.steering_fsm_state.native());
    steer_tele_.report();
    
    mission_tele_.stage("fsm", decodeFsm(frame.as_fsm_state));
    mission_tele_.stage("mission", hphlib::vehicle::decodeAmi(effective_mission));
    mission_tele_.report();

    // Report LV telemetry
    lv_tele_.stage("vlt", frame.lv_voltage.native());
    lv_tele_.stage("asms", frame.asmsOn());
    lv_tele_.stage("res", frame.resRemoteAlive());
    lv_tele_.report();

    // Report HV telemetry
    hv_tele_.stage("vlt", frame.hv_voltage.native());
    hv_tele_.stage("amp", frame.hv_current.native());
    hv_tele_.stage("sc", frame.hvShutdownCircuitClosed());
    hv_tele_.stage("prechrg", frame.hvPrechargeReady());
    hv_tele_.stage("imd-err", frame.hvImdError());
    hv_tele_.stage("bms-err", frame.hvBmsError());
    hv_tele_.stage("bms-crit-vlt", frame.hvBmsCriticalVoltage());
    hv_tele_.stage("bms-crit-temp", frame.hvBmsCriticalTemperature());
    hv_tele_.stage("bms-timeout", frame.hvBmsTimeout());
    hv_tele_.stage("bms-temp-loss", frame.hvBmsTemperatureLoss());
    hv_tele_.report();

    // Report EBS telemetry
    ebs_tele_.stage("rdy", frame.ebsReadyToActivate());
    ebs_tele_.stage("arm", frame.ebsArmed());
    ebs_tele_.stage("sb", frame.ebsServiceBrakeEngagaed());
    ebs_tele_.stage("trig", frame.ebsTriggered());
    ebs_tele_.stage("drive-st", frame.ebsDrivingStateSet());
    ebs_tele_.stage("pres-lo", frame.ebsLowPressure());
    ebs_tele_.stage("pres-hi", frame.ebsHighPressure());
    ebs_tele_.stage("pres-crit", frame.ebsCriticalPressure());
    ebs_tele_.stage("pres-wd-ok", frame.ebsPressureSensorsWatchdogOkay());
    ebs_tele_.report();

    // Report inverter telemetry
    ts_fl_tele_.stage("rdy", frame.tsFlReady());
    ts_fl_tele_.stage("err", frame.tsFlError());
    ts_fl_tele_.stage("on", frame.tsFlOn());
    ts_fl_tele_.stage("temp-mot", frame.tsFlHighTempMotor());
    ts_fl_tele_.stage("temp-inv", frame.tsFlHighTempInverter());
    ts_fl_tele_.stage("temp-igbt", frame.tsFlHighTempIGBT());
    ts_fl_tele_.report();

    ts_fr_tele_.stage("rdy", frame.tsFrReady());
    ts_fr_tele_.stage("err", frame.tsFrError());
    ts_fr_tele_.stage("on", frame.tsFrOn());
    ts_fr_tele_.stage("temp-mot", frame.tsFrHighTempMotor());
    ts_fr_tele_.stage("temp-inv", frame.tsFrHighTempInverter());
    ts_fr_tele_.stage("temp-igbt", frame.tsFrHighTempIGBT());
    ts_fr_tele_.report();

    ts_rl_tele_.stage("rdy", frame.tsRlReady());
    ts_rl_tele_.stage("err", frame.tsRlError());
    ts_rl_tele_.stage("on", frame.tsRlOn());
    ts_rl_tele_.stage("temp-mot", frame.tsRlHighTempMotor());
    ts_rl_tele_.stage("temp-inv", frame.tsRlHighTempInverter());
    ts_rl_tele_.stage("temp-igbt", frame.tsRlHighTempIGBT());
    ts_rl_tele_.report();

    ts_rr_tele_.stage("rdy", frame.tsRrReady());
    ts_rr_tele_.stage("err", frame.tsRrError());
    ts_rr_tele_.stage("on", frame.tsRrOn());
    ts_rr_tele_.stage("temp-mot", frame.tsRrHighTempMotor());
    ts_rr_tele_.stage("temp-inv", frame.tsRrHighTempInverter());
    ts_rr_tele_.stage("temp-igbt", frame.tsRrHighTempIGBT());
    ts_rr_tele_.report();
}
