#include <ros/ros.h>
#include <ros/poll_manager.h>
#include <hphlib/io/UdpSocket.h>
#include <hphlib/misc/UdpMonitor.h>
#include <hphlib/PackedEndian.h>
#include <hphlib/util.h>
#include <telemetry/Runner.h>
#include <thread>
#include <hphlib/misc/PollService.h>
#include "ControlTransmitter.h"
#include "StatusReceiver.h"

using hphlib::UdpMonitor;

void run_main(ros::NodeHandle& n) {

    // Delay MAB driver to prevent launching missions while master is launching, which seems to cause race conditions in ROS
    // TODO: Bug probably elsewhere, remove if working
    /*for (int i = 10; i > 0; --i) {
        ros::spinOnce();
        
        if (!ros::ok()) {
            return;
        }
        
        ROS_INFO_STREAM("Delaying launch for " << i << " seconds");
        
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }*/

    uint16_t sink = getRequiredRosParamPort(n, "sink_port");

    auto sock = std::make_shared<hphlib::UdpSocket>(sink);
    auto tele = std::make_shared<telemetry::Runner>("rtcu");

    sock->setBlocking(false);

    ControlTransmitter transmitter(sock, tele, n);
    StatusReceiver receiver(sock);

    ROS_INFO_STREAM("RTCU driver listening on port " << sink);

    ros::spin();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "driver_rtcu");
    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }

    return EXIT_SUCCESS;
}
