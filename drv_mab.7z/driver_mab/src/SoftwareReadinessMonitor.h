#pragma once

#include <ros/subscriber.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <hphlib/Health.h>

class SoftwareReadinessMonitor {
private:
    ros::Subscriber sub_;
    hphlib::vehicle::StatusMonitor* vehicle_mon_;

    int last_msg_;
    ros::Time last_time_;

    void callback(const hphlib::Health::ConstPtr& msg);

public:
    SoftwareReadinessMonitor(ros::NodeHandle& n, const std::string& health_topic, hphlib::vehicle::StatusMonitor& status_monitor);

    bool readyToStartDriving() const;
};
