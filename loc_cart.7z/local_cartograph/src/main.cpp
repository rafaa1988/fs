#include "cartograph.h"
#include <ros/ros.h>
//#include <telemetry/Runner.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "local_cartograph");

    ros::NodeHandle n("~");

    //telemetry::Runner tele("local_cartograph");
    Cartograph local_cartograph(n);

    ROS_INFO("local_cartograph node launched");

    ros::spin();

    return EXIT_SUCCESS;
}