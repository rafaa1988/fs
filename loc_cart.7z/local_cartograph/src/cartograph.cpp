#include "cartograph.h"
#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/extract_indices.h>
#include <boost/make_shared.hpp>

constexpr size_t max_number_tracked_cones = 10000;

Cartograph::Cartograph(ros::NodeHandle& n)
    : number_of_input_topics(getRequiredRosParam<int>(n, "number_of_input_topics"))
    , topics_subcribe(getRequiredRosParam<std::vector<std::string>>(n, "topics_subcribe"))
    , topic_publish(getRequiredRosParam<std::string>(n, "topic_publish"))
    , map_frame_id(getRequiredRosParam<std::string>(n, "map_frame_id"))
    , once_seen_filter_on(getRequiredRosParam<bool>(n, "once_seen_filter_on"))
    , nn_xy_radius(getRequiredRosParam<float>(n, "nn_xy_radius"))
    , max_duration_not_seen(getRequiredRosParam<int>(n, "max_duration_not_seen"))
    , one_time_max_duration_not_seen(getRequiredRosParam<int>(n, "one_time_max_duration_not_seen"))
    , max_duration_not_seen_for_pub(getRequiredRosParam<int>(n, "max_duration_not_seen_for_pub"))
    , min_limit_for_duration_not_seen_of_tracked_cones(
            getRequiredRosParam<int>(n, "min_limit_for_duration_not_seen_of_tracked_cones"))
    , init_duration_not_seen_for_new_cones(getRequiredRosParam<int>(n, "init_duration_not_seen_for_new_cones"))
    , is_first_vision_output(true)
    , tracked_cones_map_pub(n.advertise<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_publish, 1))
{
    //Plausibility Check of launch file params
    if(static_cast<size_t>(number_of_input_topics) != topics_subcribe.size()) {
        ROS_ERROR_STREAM("number_of_input_topics " << number_of_input_topics << " != topics_subcribe.size() " <<
                                                   topics_subcribe.size());
        ros::shutdown();
    }

    // Adjust duration thresholds to "number_of_input_topics" to make the launch file params more intuitiv.
    // The "Cartograph::vision_callback" is called "number_of_input_topics" * input topics times per second.
    // Example: Two Pointcloud Topics (each published with 12,5 Hz by a validation node) are subscribed. Therefor the
    // member function "void Cartograph::setTrConesProcessedDuration()" will increment the duration not seen of all
    // "tracked_cones" by one 2 * 12,5 (= 25) times per second.
    max_duration_not_seen = max_duration_not_seen * number_of_input_topics;
    one_time_max_duration_not_seen = one_time_max_duration_not_seen * number_of_input_topics;
    max_duration_not_seen_for_pub = max_duration_not_seen_for_pub * number_of_input_topics;
    min_limit_for_duration_not_seen_of_tracked_cones = min_limit_for_duration_not_seen_of_tracked_cones
            * number_of_input_topics;
    // loop over all input topics
    for (size_t i = 0; i < topics_subcribe.size(); ++i) {
        //Create subcriber with specific input topic. All use the same instance pointer (this).
        vision_subs.push_back(n.subscribe(topics_subcribe[i], 1, &Cartograph::vision_callback, this));
    }
    //create boost shared pointer
    vision_output = boost::make_shared<pcl::PointCloud<pcl::PointXYZRGBA>>();
}

void Cartograph::vision_callback(const pcl::PointCloud<pcl::PointXYZRGBA> input_cones)
{
    //Devel: Time measurement
    ros::Time callback_begin = ros::Time::now();

    //get new vision output. The tf_listener is used to transform the vision output to the map frame.
    pcl_ros::transformPointCloud (map_frame_id, input_cones, *vision_output, tf_listener);
    vision_output->header = input_cones.header;
    if(is_first_vision_output) {//First loop: all cones from vision_output are used to initiliaze tracked_cones
        visionOutputToTrackedCones();
        is_first_vision_output = false;
    }
    else {//normal loop

        //NN suchen
        fuseVisionWithTrackedCones();

        //Wenn kein NN für VisOut-cone vorhanden zu trCones hinzufügen
        visionOutputToTrackedCones();

        //Löschen der trCones[i] wenn zu lange not seen
        deleteNotSeenCones();

        //trCones are saved in ConesMap. The colour which occured most often is set.
        trackedConesToOutput();

        //publish Cones-Map
        cartograph_output.header.stamp = input_cones.header.stamp;
        cartograph_output.header.frame_id = map_frame_id;
        tracked_cones_map_pub.publish(cartograph_output);

        cartograph_output.clear();
    }
    //label all trCones as not processed and and add an increment for the duration not seen;
    setTrConesProcessedDuration();
    vision_output->clear();

    //Devel: Time measurement
   ros::Duration duration_callback = ros::Time::now() - callback_begin;
   ROS_INFO("duration_callback %f Sec", duration_callback.toSec());
   ROS_INFO_STREAM("duration_callback " << duration_callback.toNSec() << " NSec");
}


/**
 * save VisionOutput in tracked_cones
 */
void Cartograph::visionOutputToTrackedCones()
{
    for(const auto& curr_cone : *vision_output){
        t_trackedCone tracked_cone;
        tracked_cone.position.x = curr_cone.x;
        tracked_cone.position.y = curr_cone.y;
        tracked_cone.position.z = curr_cone.z;

        switch (curr_cone.rgba){
            case hphlib::REF_COLOR_YELLOW:
                tracked_cone.colour.blue = 0;
                tracked_cone.colour.red = 0;
                tracked_cone.colour.yellow = 1;
                tracked_cone.colour.finish = 0;
                break;
            case hphlib::REF_COLOR_BLUE:
                tracked_cone.colour.blue = 1;
                tracked_cone.colour.red = 0;
                tracked_cone.colour.yellow = 0;
                tracked_cone.colour.finish = 0;
                break;
            case hphlib::REF_COLOR_RED:
                tracked_cone.colour.blue = 0;
                tracked_cone.colour.red = 1;
                tracked_cone.colour.yellow = 0;
                tracked_cone.colour.finish = 0;
                break;
            case hphlib::REF_COLOR_FINISH:
                tracked_cone.colour.blue = 0;
                tracked_cone.colour.red = 0;
                tracked_cone.colour.yellow = 0;
                tracked_cone.colour.finish = 1;
                break;
            default:
                // Should not happen because validation node uses hphlib REF_COLORs
                ROS_ERROR_STREAM("Color " << curr_cone.rgba << "is not handled in switch statement");
                continue;
        }
        tracked_cone.duration_not_seen = init_duration_not_seen_for_new_cones;
        tracked_cone.processed = 1;
        tracked_cones.push_back(tracked_cone);
    }

    //check if unexpected big number of cones is tracked.
    if(tracked_cones.size() >= max_number_tracked_cones)
    {
        ROS_ERROR("More than %li Cones tracked! Clearing tracked Cones vector",tracked_cones.size());
        tracked_cones.clear();
    }
}

void Cartograph::fuseVisionWithTrackedCones()
{
    //search NN for every cone deteceted by the vision
    const size_t vis_out_size = vision_output->size();
    pcl::PointIndices::Ptr found_nn(new pcl::PointIndices());
    for(size_t i = 0; i < vis_out_size;++i)
    {
        //search NN
        int indice_NN = -1;
        float current_min_dist = nn_xy_radius;
        for(size_t k = 0; k < tracked_cones.size();++k)
        {
            if(tracked_cones[k].processed == 1)
                continue;
            float distance = returnXyDistance(vision_output->points[i],tracked_cones[k]);
            if (distance < current_min_dist)
            {
                indice_NN = k;
                current_min_dist = distance;
            }
        }

        //If NN found
        if(indice_NN != -1)
        {
            //set processed true and update duration not seen. In the current implementation the "duration_not_seen" of
            // a tracked cone may become negative when it was seen often recently.
            tracked_cones[indice_NN].processed = 1;
            tracked_cones[indice_NN].duration_not_seen -= (number_of_input_topics + 1);//N
            //a negative limit for the "duration_not_seen" is set
            if (tracked_cones[indice_NN].duration_not_seen < min_limit_for_duration_not_seen_of_tracked_cones)
                tracked_cones[indice_NN].duration_not_seen = min_limit_for_duration_not_seen_of_tracked_cones;

            //set position from actual vision update
            tracked_cones[indice_NN].position.x = vision_output->points[i].x;
            tracked_cones[indice_NN].position.y = vision_output->points[i].y;
            tracked_cones[indice_NN].position.z = vision_output->points[i].z;

            //update colour counters from current vision update
            switch (vision_output->points[i].rgba){
                case hphlib::REF_COLOR_YELLOW:
                    tracked_cones[indice_NN].colour.yellow += 1;
                    break;
                case hphlib::REF_COLOR_BLUE:
                    tracked_cones[indice_NN].colour.blue += 1;
                    break;
                case hphlib::REF_COLOR_RED:
                    tracked_cones[indice_NN].colour.red += 1;
                    break;
                case hphlib::REF_COLOR_FINISH:
                    tracked_cones[indice_NN].colour.finish += 1;
                    break;
                default:
                    // Should not happen because validation node uses hphlib REF_COLORs
                    ROS_ERROR_STREAM("Color " << vision_output->points[i].rgba << "is not handled in switch statement!");
                    continue;
            }
            found_nn->indices.push_back(i);
        }
    }

    //Removes cones from vision_output for which a nearest neighbour was found
    pcl::ExtractIndices<pcl::PointXYZRGBA> remove_nn;
    remove_nn.setInputCloud(vision_output);
    remove_nn.setIndices(found_nn);
    remove_nn.setNegative(true);
    remove_nn.filter(*vision_output);
}

/**
 * Cones which should be published are push_backed to cartograph_output.
 */
void Cartograph::trackedConesToOutput()
{
    for (size_t i = 0; i < tracked_cones.size();++i)
    {
        //Check if the cone was seen recently
        if (tracked_cones[i].duration_not_seen >= max_duration_not_seen_for_pub) {
            continue;
        }

        // If the once_seen_filter_on is set true and the cone was only seen once:
        //Do not publish the current cone and continue with the next cone
        if (once_seen_filter_on
        && tracked_cones[i].colour.blue + tracked_cones[i].colour.red
           + tracked_cones[i].colour.yellow <= 1) {
            continue;
        }

        //Copy the current tracked cone to pcl::PointXYZRGBA point cloud
        pcl::PointXYZRGBA cur_cone;
        //Copy position
        cur_cone.x = tracked_cones[i].position.x;
        cur_cone.y = tracked_cones[i].position.y;
        cur_cone.z = tracked_cones[i].position.z;

        //Set the cone colour which was seen most often by the validation nodes
        if(tracked_cones[i].colour.blue >= tracked_cones[i].colour.red
           && tracked_cones[i].colour.blue >= tracked_cones[i].colour.yellow
           && tracked_cones[i].colour.blue >= tracked_cones[i].colour.finish) //Set Cone blue. If blue was occuring more often then the other colours.
            cur_cone.rgba = hphlib::REF_COLOR_BLUE;
        else if(tracked_cones[i].colour.red >= tracked_cones[i].colour.blue
           && tracked_cones[i].colour.red >= tracked_cones[i].colour.yellow
              && tracked_cones[i].colour.red >= tracked_cones[i].colour.finish) //Set Cone red
            cur_cone.rgba = hphlib::REF_COLOR_RED;
        else if(tracked_cones[i].colour.yellow >= tracked_cones[i].colour.blue
           && tracked_cones[i].colour.yellow >= tracked_cones[i].colour.red
              && tracked_cones[i].colour.yellow >= tracked_cones[i].colour.finish) //Set Cone yellow
            cur_cone.rgba = hphlib::REF_COLOR_YELLOW;
        else if(tracked_cones[i].colour.finish >= tracked_cones[i].colour.blue
                && tracked_cones[i].colour.finish >= tracked_cones[i].colour.red
                && tracked_cones[i].colour.finish >= tracked_cones[i].colour.yellow) //Set Cone finish
            cur_cone.rgba = hphlib::REF_COLOR_FINISH;
        cartograph_output.push_back(cur_cone);
    }
}

/**
 * 1. labels all tracked_cones as not processed.
 * 2. Increments the duration not seen of all tracked_cones by one
 */
void Cartograph::setTrConesProcessedDuration()
{
    for(size_t i = 0; i < tracked_cones.size();++i)
    {
        tracked_cones[i].processed = 0;
        tracked_cones[i].duration_not_seen += 1;
    }
}

float Cartograph::returnXyDistance(const pcl::PointXYZRGBA& aPoint, const t_trackedCone& anotherPoint)
{
    return sqrt((  aPoint.x - anotherPoint.position.x)
                * (aPoint.x - anotherPoint.position.x)
                + (aPoint.y - anotherPoint.position.y)
                * (aPoint.y - anotherPoint.position.y));
}

void Cartograph::deleteNotSeenCones()
{
    std::vector<t_trackedCone>::size_type i = 0;
    while ( i < tracked_cones.size() )
    {
        if ( tracked_cones[i].duration_not_seen > max_duration_not_seen  )
        {
            tracked_cones.erase( tracked_cones.begin() + i );
        }
        // if "duration_not_seen" of current cone exeeds the "one_time_max_duration_not_seen" threshold and was only
        // seen once by the validation nodes the cone will be erased from the "tracked_cones" vector
        else if(tracked_cones[i].duration_not_seen > one_time_max_duration_not_seen
                && tracked_cones[i].colour.blue + tracked_cones[i].colour.red
                + tracked_cones[i].colour.yellow <= 1)
        {
            tracked_cones.erase( tracked_cones.begin() + i );
        }
        else {
            ++i;
        }
    }
    ROS_INFO("tracked_cones.size() %li",tracked_cones.size());
}