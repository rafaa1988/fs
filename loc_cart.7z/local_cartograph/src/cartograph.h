#pragma once
#include "ros/ros.h"
#include <pcl_ros/point_cloud.h>
#include <tf/transform_listener.h>

#include <math.h>

//structs
typedef struct {
    float x;
    float y;
    float z;
} t_position;
typedef struct {
    float red;      //small red cones
    float yellow;
    float blue;
    float finish; //big red cones for track finish
} t_colour;
typedef struct {
    t_position position;
    t_colour colour;
    int duration_not_seen;
    bool processed;
} t_trackedCone ;


class Cartograph
{
public:
    Cartograph(ros::NodeHandle& n);
    //delete not needed default constructors and assignments
    Cartograph(const Cartograph&) = delete;
    Cartograph& operator=(const Cartograph&) = delete;
    Cartograph(Cartograph&&) = delete;
    Cartograph& operator=(Cartograph&& ) = delete;

private:
    //user params
    int number_of_input_topics;
    std::vector<std::string> topics_subcribe;
    std::string topic_publish;
    std::string map_frame_id;
    bool  once_seen_filter_on;
    float nn_xy_radius;     //[m]    Max radius for Nearest Neighbour (NN) search
    int   max_duration_not_seen;
    int   one_time_max_duration_not_seen;
    int max_duration_not_seen_for_pub;
    int min_limit_for_duration_not_seen_of_tracked_cones;
    int init_duration_not_seen_for_new_cones;

    //Variables
    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr vision_output;
    pcl::PointCloud<pcl::PointXYZRGBA> cartograph_output;
    std::vector <t_trackedCone> tracked_cones;
    bool is_first_vision_output;
    tf::TransformListener tf_listener;
    std::vector<ros::Subscriber> vision_subs;
    ros::Publisher tracked_cones_map_pub;

    //Callbacks
    void vision_callback(const pcl::PointCloud<pcl::PointXYZRGBA> input_cones);

    //functions
    void visionOutputToTrackedCones();
    void fuseVisionWithTrackedCones();
    void trackedConesToOutput();
    void setTrConesProcessedDuration();
    static float returnXyDistance(const pcl::PointXYZRGBA& aPoint, const t_trackedCone&  anotherPoint);
    void deleteNotSeenCones();
};
