#include <ros/ros.h>
#include <hphlib/util.h>
#include "PidController.h"
#include "PathFollower.h"
#include "OldPathFollower.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "path_follower");
    ros::NodeHandle n("~");

    bool use_old_path_follower = getRequiredRosParam<bool>(n, "use_old_path_follower");
    
    ROS_INFO("path_follower node launched");

    if (use_old_path_follower) {
        OldPathFollower oldPathFollower(n);
        ros::spin();
    } else {
        PathFollower lane_follower(n);
        ros::spin();
    }

    return EXIT_SUCCESS;
}
