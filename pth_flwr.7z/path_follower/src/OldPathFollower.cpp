//
// Created by niclas on 28.06.18.
//

#include <hphlib/Control.h>
#include "OldPathFollower.h"


OldPathFollower::OldPathFollower(ros::NodeHandle n) : input_topic_path_(getRequiredRosParam<std::string>(n, "input_topic_path"))
        , path_sub_(n.subscribe(input_topic_path_, 1, &OldPathFollower::callback, this))
        , control_publisher_(n.advertise<hphlib::Control>("/control", 1))
        , marker_pub_(n.advertise<visualization_msgs::Marker>("visualization_marker", 2)) {}


Eigen::Vector3f stampedPoseToEigen(const geometry_msgs::PoseStamped& pose) {
    return Eigen::Vector3f(static_cast<const float &>(pose.pose.position.x),
                           static_cast<const float &>(pose.pose.position.y),
                           static_cast<const float &>(pose.pose.position.z));
}


float calcSteeringAngle(const nav_msgs::Path& path_) {

    //assert path has always at least two nodes

    if (path_.poses.size() < 2) {
        return 0.0f;
    }

    Eigen::Vector3f forward(1.0f, 0, 0); //experiment

    Eigen::Vector3f target = stampedPoseToEigen(path_.poses.at(1));

    // calculate angle between first point and forward vector
    if (target[1] < 0) {
        return static_cast<float>(std::acos(target.dot(forward) / target.norm()) * RAD_TO_DEG);
    } else {
        return static_cast<float>(-std::acos(target.dot(forward) / target.norm()) * RAD_TO_DEG);
    }

}

visualization_msgs::Marker createMarkerControl(const hphlib::Control& ctrl_msg) {

    visualization_msgs::Marker marker;

    //set header of message
    marker.header.stamp = ros::Time::now();
    marker.header.frame_id = "base_link";

    // marker scale based on target_velocity
    marker.scale.x = ctrl_msg.target_velocity;
    marker.scale.y = 0.2;
    marker.scale.z = 0.1;

    // marker color
    marker.color.b = 1.0; //color is blue
    marker.color.a = 1.0;

    // set angle
    marker.pose.orientation = tf::createQuaternionMsgFromYaw(ctrl_msg.steering_angle);

    return marker;
}

void OldPathFollower::callback(const nav_msgs::Path::ConstPtr& trajectory_path_) {

    hphlib::Control controlMessage;

    controlMessage.steering_angle = calcSteeringAngle(*trajectory_path_);
    controlMessage.target_velocity = 5.0f / 3.6f; // 5km/h

    control_publisher_.publish(controlMessage);
    marker_pub_.publish(createMarkerControl(controlMessage));
}



