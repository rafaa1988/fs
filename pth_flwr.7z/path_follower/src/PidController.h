//
// Created by nikolai on 20.06.18.
//
#pragma once

//TODO Anti-Windup (from max_control_value?)
class PidController {
public:
    PidController(double proportional_term, double integral_term, double derivative_term, double loop_interval_time,
                  double max_control_value, double min_control_value);
    double calcControlValue(const double& error_value);
    double proportional_term_;
    double integral_term_;
    double derivative_term_;
private:
    const double loop_interval_time_;
    const double max_control_value_;
    const double min_control_value_;
    double integrated_error_;
    double previous_error;

};