//
// Created by nikolai on 20.06.18.
//
#pragma once

#include "PidController.h"
#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <visualization_msgs/Marker.h>
#include <eigen3/Eigen/Eigen>
#include <hphlib/misc/LowPassFilter.h>
#include <hphlib/Lap.h>
//forward declaration
/*namespace Eigen {
    class Vector3f;
}*/

class PathFollower {
public:
    PathFollower(ros::NodeHandle& n);

private:
    hphlib::LowPassFilter steering_filter_;

    ros::Time last_callback_time_;

    const std::string input_topic_path_;
    const float forward_looking_radius_;
    const bool use_kinematics_model_;
    const float min_velocity;
    const float max_velocity;
    int lap_count;
    ros::Subscriber path_sub_;
    ros::Subscriber lap_counter_sub_;
    ros::Publisher control_publisher_;
    ros::Publisher marker_pub_;

    visualization_msgs::Marker marker_radius_;
    visualization_msgs::Marker marker_target_;
    visualization_msgs::Marker marker_angular_error_;

    bool count_laps = false;
    int current_lap = 0;
    
    float steering_overcompensation_;

    void callback(nav_msgs::Path path);
    void lapCallback(hphlib::Lap lap);
    Eigen::Vector3d getTargetOnPath(const nav_msgs::Path& path) const;
    double calcAngularErrorWithSeek(const Eigen::Vector3d& target_on_path) const;
    double steeringFromKinematics(double beta);
    //float calcCrossTrackError() const;
};

