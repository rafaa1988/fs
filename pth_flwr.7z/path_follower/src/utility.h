//
// Created by nikolai on 20.06.18.
//
#pragma once

#include <eigen3/Eigen/Eigen>
#include <visualization_msgs/Marker.h>
#include <tf/tf.h>

constexpr double RAD_2_DEG = 180.0/M_PI;

//TODO: Understand this copied function
inline double angleBetweenVectors(const Eigen::Vector3d& vector1, const Eigen::Vector3d& vector2) {
    return std::acos(vector1.dot(vector2)/(vector1.norm() * vector2.norm()));
}

inline double distance(double x, double y) {
    return sqrt( x * x + y * y);
}

void poseToMarker(const Eigen::Vector3d& pose,  visualization_msgs::Marker& marker) {
    marker.pose.position.x = pose(0);
    marker.pose.position.y = pose(1);
    marker.pose.position.z = pose(2);
}

void angleToMarker(const double& angle,  visualization_msgs::Marker& marker) {
    marker.pose.orientation = tf::createQuaternionMsgFromYaw(angle);

}

