//
// Created by nikolai on 20.06.18.
//

#include "PathFollower.h"
#include <hphlib/util.h>
#include <hphlib/Control.h>
#include "utility.h"

constexpr double WHEEL_BASE = 1.555f; //lenght between front and rear axles
constexpr double LENGHT_BETWEEN_COG_AND_REAR_AXLES = WHEEL_BASE / 2.0;



PathFollower::PathFollower(ros::NodeHandle &n)
    : steering_filter_(getRequiredRosParam<float>(n, "filter_cutoff_hz"))
    , last_callback_time_(ros::Time::now()) // Just initialize to now, low pass ignores dt for first sampling anyways
    , input_topic_path_(getRequiredRosParam<std::string>(n, "input_topic_path"))
    , forward_looking_radius_(getRequiredRosParam<float>(n, "forward_looking_radius"))
    , use_kinematics_model_(getRequiredRosParam<bool>(n, "use_kinematics_model"))
    , min_velocity(static_cast<float>(getRequiredRosParam<double>(n, "min_velocity")) / 3.6f)
    , max_velocity(static_cast<float>(getRequiredRosParam<double>(n, "max_velocity")) / 3.6f)
    , path_sub_(n.subscribe(input_topic_path_, 1, &PathFollower::callback, this))
    , lap_counter_sub_(n.subscribe("/laps", 1, &PathFollower::lapCallback, this))
    , control_publisher_(n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "output_topic"), 1))
    , marker_pub_(n.advertise<visualization_msgs::Marker>("visualization_marker", 2))
    , steering_overcompensation_(getRequiredRosParam<float>(n, "steering_overcompensation"))
{
    count_laps = n.getParam("/trackdrive_lap_count", lap_count);

    std::cout << lap_count << std::endl;

    marker_radius_.header.frame_id = "/base_link";
    marker_radius_.header.stamp = ros::Time::now();
    marker_radius_.ns = "forward_looking_radius";
    marker_radius_.id = 0;
    marker_radius_.type = visualization_msgs::Marker::SPHERE;
    // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
    marker_radius_.action = visualization_msgs::Marker::ADD;
    marker_radius_.pose.position.x = 0;
    marker_radius_.pose.position.y = 0;
    marker_radius_.pose.position.z = 0;
    marker_radius_.pose.orientation.x = 0.0;
    marker_radius_.pose.orientation.y = 0.0;
    marker_radius_.pose.orientation.z = 0.0;
    marker_radius_.pose.orientation.w = 1.0;
    marker_radius_.scale.x = forward_looking_radius_ * 2;
    marker_radius_.scale.y = forward_looking_radius_ * 2;
    marker_radius_.scale.z = 0.1;
    marker_radius_.color.r = 0.0f;
    marker_radius_.color.g = 1.0f;
    marker_radius_.color.b = 0.0f;
    marker_radius_.color.a = 0.05;
    marker_radius_.lifetime = ros::Duration();

    marker_target_ = marker_radius_;
    marker_target_.header.frame_id = "/base_link";
    marker_target_.header.stamp = ros::Time::now();
    marker_target_.ns = "target";
    marker_target_.type = visualization_msgs::Marker::CUBE;
    marker_target_.scale.x = 0.2;
    marker_target_.scale.y = 0.2;
    marker_target_.scale.z = 0.03;
    marker_target_.color.r = 1.0f;
    marker_target_.color.g = 0.0f;
    marker_target_.color.b = 0.0f;
    marker_target_.color.a = 0.8;

    marker_angular_error_ = marker_radius_;
    marker_angular_error_.header.frame_id = "/base_link";
    marker_angular_error_.header.stamp = ros::Time::now();
    marker_angular_error_.ns = "angular_error";
    marker_angular_error_.type = visualization_msgs::Marker::ARROW;
    marker_angular_error_.pose.position.x = 0.0;
    marker_angular_error_.pose.position.y = 0.0;
    marker_angular_error_.pose.position.z = 0.0;
    marker_angular_error_.scale.x = forward_looking_radius_;
    marker_angular_error_.scale.y = 0.2;
    marker_angular_error_.scale.z = 0.03;
    marker_angular_error_.color.r = 1.0f;
    marker_angular_error_.color.g = 0.0f;
    marker_angular_error_.color.b = 0.0f;
    marker_angular_error_.color.a = 0.8;

}

//TODO TIMER CALLBACK
void PathFollower::callback(nav_msgs::Path path) {

    // Calculate delta time for filters
    float dt = static_cast<float>((ros::Time::now() - last_callback_time_).toSec());
    
    hphlib::Control control{};
    control.header.stamp = ros::Time::now();

    //assert path has always at least one nodes (excluding the first one which is always the origin)
    if (path.poses.size() <= 1) {
        // If not one node, we just drive very carefully and hopefully get a path
        control.steering_angle = steering_filter_.feed(0.0f, dt);
        control.target_velocity = 0.5f;
    } else {

        //calc target point on path
        Eigen::Vector3d target_on_path = getTargetOnPath(path);
        poseToMarker(target_on_path, marker_target_);

        //seek(target_point, currheading = x-axis)
        double angular_error = calcAngularErrorWithSeek(target_on_path);
        angleToMarker(angular_error, marker_angular_error_);


        // ROS_INFO_STREAM("angular_error " << - angular_error * RAD_2_DEG);


        double error_value_for_control = 0.0;

        if(use_kinematics_model_)
            error_value_for_control = steeringFromKinematics(angular_error);
        else
            error_value_for_control = angular_error;
            
        // Overcompensate as fuck (for the safety)
        error_value_for_control *= steering_overcompensation_;

        //Transform to steering coordinate convention
        error_value_for_control = - error_value_for_control * RAD_2_DEG;

        float filtered_angle = hphlib::clamp(steering_filter_.feed(static_cast<float>(error_value_for_control), dt), -30.0f, 30.0f);

        //calculate steering angle
        control.steering_angle = filtered_angle;

//         ROS_INFO_STREAM("predicted " << control.steering_angle);
	//linear mapping of the velocity

        float velocity_multiplier = ((30.0f - std::abs(filtered_angle)) / 30.0f);
        control.target_velocity = min_velocity + velocity_multiplier * (max_velocity - min_velocity);
    }

    control.finish_mission = count_laps && current_lap >= lap_count;
    control_publisher_.publish(control);

    marker_pub_.publish(marker_radius_);
    marker_pub_.publish(marker_target_);
    marker_pub_.publish(marker_angular_error_);
}

Eigen::Vector3d PathFollower::getTargetOnPath(const nav_msgs::Path& path) const {

    //TODO Evtl alternativ statt radius um base_link, distanz über path aufsummieren
    //go through path poses until dist > forward_looking_radius
    size_t i;
    for(i = 0; i<path.poses.size(); i++) {
        if(distance(path.poses[i].pose.position.x, path.poses[i].pose.position.y)
                 > forward_looking_radius_ )
            break;

    }
    //Keep index i in vector size
    if(i == path.poses.size()) {
        i = i-1;
    }

    //use this pose and the pose before
    //if pose is first pose use robot pose instead the pose before
    geometry_msgs::Pose out_of_radius = path.poses[i].pose;
    geometry_msgs::Pose before_out_of_radius;
    double distance_of_before;
    if(i > 1) {
        before_out_of_radius = path.poses[i-1].pose;
        //calc distance of pose before
        distance_of_before = distance(before_out_of_radius.position.x, before_out_of_radius.position.y);
    }

    else { //use robot pose //TODO use actual robot pose with tf or odom
        before_out_of_radius.position.x = 0.0;
        before_out_of_radius.position.y = 0.0;
        before_out_of_radius.position.y = 0.0;
        before_out_of_radius.orientation.x = 0.0;
        before_out_of_radius.orientation.y = 0.0;
        before_out_of_radius.orientation.z = 1.0;
        before_out_of_radius.orientation.w = 0.0;
        //calc distance of pose before
        distance_of_before = 0.0;
    }

    // calc delta x and delta y (geradensteigung)
    double distance_between_poses = distance(out_of_radius.position.x - before_out_of_radius.position.x,
            out_of_radius.position.y - before_out_of_radius.position.y);


//    std::cout << "i " << i << "dist " << distance_between_poses << std::endl;

    double delta_x_norm = (out_of_radius.position.x - before_out_of_radius.position.x) / distance_between_poses;
    double delta_y_norm = (out_of_radius.position.y - before_out_of_radius.position.y) / distance_between_poses;
    double delta_distance = forward_looking_radius_ - distance_of_before;

    //Use a linear interpolation between the points to get a target between them.
    Eigen::Vector3d target_on_path = Eigen::Vector3d(before_out_of_radius.position.x + delta_x_norm * delta_distance,
                                                     before_out_of_radius.position.y + delta_y_norm * delta_distance,
                                                        0.0);
    return target_on_path;
}

/**
 *
 * @return needed Schwimmwinkel (Beta in single track model)
 */
double PathFollower::calcAngularErrorWithSeek(const Eigen::Vector3d& target_on_path) const {
    return atan2f(target_on_path.y(), target_on_path.x());
}

/**
 *
 * @param beta desired Schwimmwinkel
 * @return Steering angle
 */
double PathFollower::steeringFromKinematics(double beta) {
    return atan(tan(beta) * WHEEL_BASE / LENGHT_BETWEEN_COG_AND_REAR_AXLES);

}


void PathFollower::lapCallback(hphlib::Lap lap) {
    current_lap = lap.current_lap;
}
