//
// Created by nikolai on 20.06.18.
//

#include <hphlib/util.h>
#include "PidController.h"

PidController::PidController(double proportional_term, double integral_term, double derivative_term,
                             double loop_interval_time, double max_control_value, double min_control_value) :
          proportional_term_(proportional_term)
        , integral_term_(integral_term)
        , derivative_term_(derivative_term)
        , loop_interval_time_(loop_interval_time)
        , max_control_value_(max_control_value)
        , min_control_value_(min_control_value)
        , integrated_error_(0.0)
        , previous_error(0.0)
{}

double PidController::calcControlValue(const double &error_value) {
    double  delta_integrated_error = error_value * loop_interval_time_;
    integrated_error_ += delta_integrated_error;
    double derivated_error = (error_value - previous_error) / loop_interval_time_;

    //use PID formula
    double control_value = proportional_term_ * error_value + integral_term_ * integrated_error_
           + derivative_term_ * derivated_error;
    previous_error = error_value;

    //anti-wind-up for integrated_error_ using clamping:
    if((control_value < min_control_value_ && delta_integrated_error < 0.0)
       || (control_value > max_control_value_ && delta_integrated_error > 0.0))
        integrated_error_ -= delta_integrated_error;

    //Check if control value is in specified range
    return hphlib::clamp(control_value, min_control_value_, max_control_value_);
}
