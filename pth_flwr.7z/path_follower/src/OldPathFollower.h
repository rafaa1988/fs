//
// Created by niclas on 28.06.18.
//

#pragma once

#include <nav_msgs/Path.h>
#include <ros/node_handle.h>
#include <visualization_msgs/Marker.h>
#include <eigen3/Eigen/Eigen>
#include <tf/tf.h>
#include <hphlib/util.h>

class OldPathFollower {
public:
    OldPathFollower(ros::NodeHandle n);

    std::string input_topic_path_;
    ros::Subscriber path_sub_;
    ros::Publisher control_publisher_;
    ros::Publisher marker_pub_;

    void callback(const nav_msgs::Path_<std::allocator<void>>::ConstPtr &trajectory_path_);
};

