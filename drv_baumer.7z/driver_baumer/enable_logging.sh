#!/usr/bin/env bash

# This little bash script creates an empty file at ~/.local/share/Baumer/
# The baumer api detects the file and stores log (csv) files there
# refer to Programmers Guide page 134 for more information
# to disable logging just delete the file with: 
#
# rm ~/.local/share/Baumer/bgapi2_trace_enable.ini

path="/.local/share/Baumer"
file="/bgapi2_trace_enable.ini"

mkdir $HOME$path
touch $HOME$path$file

