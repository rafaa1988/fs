#include <bgapi2_genicam.hpp>
#include <ros/ros.h>
#include "cameraSettings.h"
#include <hphlib/util.h>

void cameraSettings::setCameraSettings(BGAPI2::Device &device, const ros::NodeHandle &n) {
    fNumber = getRequiredRosParam<double>(n, "fNumber");
    exposureTimeMicroseconds = getRequiredRosParam<double>(n, "exposureTimeMicroseconds");
    
    autoExposureEnabled = getRequiredRosParam<bool>(n, "autoExposureEnabled");
    slowestExposureTime = getRequiredRosParam<double>(n, "slowestExposureTime");
    fastestExposureTime = getRequiredRosParam<double>(n, "fastestExposureTime");
    autoExposureBrightness = getRequiredRosParam<double>(n, "autoExposureBrightness");

    whiteBalanceAfterNFrames = getRequiredRosParam<int>(n, "whiteBalanceAfterNFrames");

    triggerActivated = getRequiredRosParam<bool>(n, "triggerActivated");
    acquisitionFrameRate = getRequiredRosParam<int>(n, "acquisitionFrameRate");

    //Setup Region of Interest:
    ROI_OffsetX = getRequiredRosParam<int>(n, "ROI_OffsetX");
    ROI_OffsetY = getRequiredRosParam<int>(n, "ROI_OffsetY");
    ROI_Height = getRequiredRosParam<int>(n, "ROI_Height");
    ROI_Width = getRequiredRosParam<int>(n, "ROI_Width");

    bufferTimeoutMilliseconds = getRequiredRosParam<int>(n, "bufferTimeoutMilliseconds");
    publishIncompleteImages = getRequiredRosParam<bool>(n, "publishIncompleteImages");

    //-1 equals full width and height
    if (ROI_Height == -1) {
        ROI_OffsetY = 0;
        ROI_Height = static_cast<int>(device.GetRemoteNode("SensorHeight")->GetInt());
    }

    if (ROI_Width == -1) {
        ROI_OffsetX = 0;
        ROI_Width = static_cast<int>(device.GetRemoteNode("SensorWidth")->GetInt());
    }
    
    device.GetRemoteNode("ExposureTime")->SetDouble(exposureTimeMicroseconds);
    device.GetRemoteNode("AcquisitionFrameRateEnable")->SetBool(true);
    device.GetRemoteNode("AcquisitionFrameRate")->SetDouble(acquisitionFrameRate);
    device.GetRemoteNode("WhiteBalance")->SetValue("AutoWhiteBalance");

    if (triggerActivated) {
        device.GetRemoteNode("TriggerMode")->SetString("On");
        device.GetRemoteNode("TriggerActivation")->SetString("RisingEdge");
        device.GetRemoteNode("TriggerDelay")->SetDouble(0.0f);
        device.GetRemoteNode("TriggerSource")->SetString("Line0");
    } else {
        device.GetRemoteNode("TriggerMode")->SetString("Off");
    }
    
    ROS_INFO_STREAM("Using ROI: (" << ROI_OffsetX << "x" << ROI_OffsetY << ") by (" << ROI_Width << "x" << ROI_Height << ")");

    // First set offsets to 0 such that if an offset was set setting width or height doesn't exceed image
    device.GetRemoteNode("OffsetX")->SetInt(0);
    device.GetRemoteNode("OffsetY")->SetInt(0);
    
    // Now set height or width
    device.GetRemoteNode("Width")->SetInt(ROI_Width);
    device.GetRemoteNode("Height")->SetInt(ROI_Height);
    
    // Lastly set actual offset, size of ROI now shouldn't exceed image
    device.GetRemoteNode("OffsetX")->SetInt(ROI_OffsetX);
    device.GetRemoteNode("OffsetY")->SetInt(ROI_OffsetY);
}
