#include <ros/ros.h>
#include "bgapi2_genicam.hpp"
#include <opencv2/core/core.hpp>
#include <sensor_msgs/CompressedImage.h>
#include <sensor_msgs/Image.h>
#include <hphlib/util.h>
#include "autoexposure.h"
#include <fstream>
#include <thread>
#include "cameraSettings.h"
#include <camera_info_manager/camera_info_manager.h>
#include <opencv2/imgcodecs.hpp>

//Template for deallocating baumer objects (trying to prevent duplicate free)
template <typename T>
struct baumerDeallocator {
    void operator()(T* pointer) {
        if (pointer->IsOpen()) {
            pointer->Close();
        }
    }
};


typedef std::unique_ptr<BGAPI2::System, baumerDeallocator<BGAPI2::System>> System;
typedef std::unique_ptr<BGAPI2::Device, baumerDeallocator<BGAPI2::Device>> Device;
typedef std::unique_ptr<BGAPI2::Interface, baumerDeallocator<BGAPI2::Interface>> Interface;
typedef std::unique_ptr<BGAPI2::DataStream, baumerDeallocator<BGAPI2::DataStream>> DataStream;

int reconnectTimeoutSeconds;

int main(int argc, char** argv) {

    //initializing ROS and read parameters
    ros::init(argc, argv, "driver_baumer");
    ros::NodeHandle n("~");

    std::string serialString = getRequiredRosParam<std::string>(n, "serial");
    std::string tfFrame = getRequiredRosParam<std::string>(n, "tfFrame");

    //camera info name is only for convenience, because it can't be set in the calibrator and otherwise has to be set manually
    std::string cameraInfoURL = getRequiredRosParam<std::string>(n, "cameraInfoURL");
    std::string cameraInfoName = getRequiredRosParam<std::string>(n, "cameraInfoName");

    std::string networkInterfaceName = getRequiredRosParam<std::string>(n, "networkInterfaceName");

    ROS_INFO_STREAM("Camera driver " << cameraInfoName << " node launched");

    telemetry::Runner runner(cameraInfoName + "_camera");

    bool compress = getRequiredRosParam<bool>(n, "compress");
    int compression_quality = 85;
    n.getParam("compressionQuality", compression_quality);

    ros::Publisher image_publisher;
    ros::Publisher cam_info_publisher= n.advertise<sensor_msgs::CameraInfo>("camera_info", 1);

    if (compress) {
        image_publisher = n.advertise<sensor_msgs::CompressedImage>("image_compressed", 1);
    } else {
        image_publisher = n.advertise<sensor_msgs::Image>("image_raw", 1);
    }

    reconnectTimeoutSeconds = getRequiredRosParam<int>(n, "reconnectTimeoutSeconds");

    // enable debug output (you have to execute enable_logging.sh first)
    BGAPI2::Trace::ActivateOutputToFile(true, (BGAPI2::String) "bgapi2_trace.log");
    BGAPI2::Trace::ActivateOutputToDebugger(false);

    // activate tracing of all information
    BGAPI2::Trace::ActivateMaskError(true);
    BGAPI2::Trace::ActivateMaskWarning(true);
    BGAPI2::Trace::ActivateMaskInformation(true);

    // enable all logging flags
    BGAPI2::Trace::ActivateOutputOptionPrefix(true);
    BGAPI2::Trace::ActivateOutputOptionTimestamp(true);
    BGAPI2::Trace::ActivateOutputOptionTimestampDiff(true);

    BGAPI2::Trace::Enable(true);
    
    //DECLARATIONS OF BAUMER VARIABLES
    BGAPI2::ImageProcessor * imgProcessor = NULL;

    BGAPI2::SystemList *systemList = NULL;
    System pSystem;

    BGAPI2::InterfaceList *interfaceList = NULL;
    Interface pInterface;

    BGAPI2::DeviceList *deviceList = NULL;
    Device pDevice;

    BGAPI2::DataStreamList *datastreamList = NULL;
    DataStream pDataStream;

    BGAPI2::BufferList *bufferList = NULL;
    BGAPI2::Buffer * pBuffer = NULL;
    BGAPI2::String sBufferID;

    camera_info_manager::CameraInfoManager camInfoManager(n);
    sensor_msgs::CameraInfo cameraInfo;


    try {
        while (pDevice == nullptr) {


            //Get ImageProcessor info
            imgProcessor = BGAPI2::ImageProcessor::GetInstance();
            ROS_DEBUG_STREAM("ImageProcessor version:    " << imgProcessor->GetVersion());
            if (imgProcessor->GetNodeList()->GetNodePresent("DemosaicingMethod") != 0) {
                imgProcessor->GetNodeList()->GetNode("DemosaicingMethod")->SetString(
                        "NearestNeighbor"); // NearestNeighbor, Bilinear3x3, Baumer5x5
                ROS_DEBUG_STREAM("    Demosaicing method:    "
                                         << imgProcessor->GetNodeList()->GetNode("DemosaicingMethod")->GetString());
            }

            //Print detected systems
            systemList = BGAPI2::SystemList::GetInstance();
            systemList->Refresh();
            ROS_DEBUG_STREAM("Detected systems:  " << systemList->size());


            for (BGAPI2::SystemList::iterator sysIterator = systemList->begin();
                 sysIterator != systemList->end(); sysIterator++) {

                try {
                    sysIterator->second->Open();

                    interfaceList = sysIterator->second->GetInterfaces();
                    //COUNT AVAILABLE INTERFACES
                    interfaceList->Refresh(100); // timeout of 100 msec
                    ROS_INFO_STREAM("Detected interfaces: " << interfaceList->size() << " on " << sysIterator->first);

                    //OPEN THE NEXT INTERFACE IN THE LIST

                    for (BGAPI2::InterfaceList::iterator ifIterator = interfaceList->begin();
                         ifIterator != interfaceList->end(); ifIterator++) {
                        try {

                            ifIterator->second->Open();
                            //search for any camera is connected to this interface

                            // Skip other network interfaces. Needed, because Baumer API does not actually guarantee return value after timeout
                            if (ifIterator->second->GetDisplayName() != networkInterfaceName.c_str()) {
                                continue;
                            }

                            deviceList = ifIterator->second->GetDevices();
                            deviceList->Refresh(100);

                            ROS_INFO_STREAM("Detected devices: " << deviceList->size() << " on " << ifIterator->first);

                            //Loop through camera devices and open Device with serial number
                            for (BGAPI2::DeviceList::iterator devIterator = deviceList->begin();
                                 devIterator != deviceList->end(); devIterator++) {

                                if (devIterator->second->GetSerialNumber() == serialString.c_str()) {
                                    pDevice.reset(devIterator->second);
                                    pInterface.reset(ifIterator->second);
                                    pSystem.reset(sysIterator->second);
                                }
                            }

                            if (pDevice == nullptr) {
                                ifIterator->second->Close();
                            }
                        } catch (BGAPI2::Exceptions::ResourceInUseException &ex) {
                            ROS_WARN_STREAM("Interface " << ifIterator->first << " already opened ");
                        }
                    }

                    //if a camera is connected to the system interface then leave the system loop
                    if (pDevice != nullptr) {
                        break;
                    } else {
                        sysIterator->second->Close();
                    }
                } catch (BGAPI2::Exceptions::ResourceInUseException &ex) {
                    ROS_WARN_STREAM(" System " << sysIterator->first << " already opened ");
                }
            }

            if (pDevice == nullptr) {
                ROS_ERROR_STREAM("Device with serial " << serialString << " not found!");
                ROS_ERROR_STREAM("Trying again in " << reconnectTimeoutSeconds << " seconds...");
                std::this_thread::sleep_for(std::chrono::seconds(reconnectTimeoutSeconds));
            }
        }

        ROS_INFO_STREAM("Found device with serial " << serialString << ". Starting acquisition.");

        pDevice->Open();

//#define PRINTFUNCTIONS
#ifdef PRINTFUNCTIONS
        for (auto it = pDevice->GetRemoteNodeList()->begin(); it != pDevice->GetNodeList()->end(); it++) {
            if (pDevice->GetRemoteNodeList()->GetNodePresent(it->first)) {
                std::cout << it->first << " : ";
                try {
                    std::cout << pDevice->GetRemoteNode(it->first)->GetInterface() << std::endl;
                } catch (...) {
                    std::cout << "Unknown" << std::endl;
                }
            }
        }
#endif

        cameraSettings settings{};

        //set camera settings as defined in config file
        settings.setCameraSettings(*pDevice, n);

        //set camera info name and load from calibration file specified as parameter
        if (!camInfoManager.setCameraName(cameraInfoName)) {
            ROS_WARN_STREAM("Could not set cameraInfoName, it may contain illegal characters!");
        }


        if (camInfoManager.validateURL(cameraInfoURL)) {
            camInfoManager.loadCameraInfo(cameraInfoURL);

            // get current CameraInfo data now as it never changes during acquisition
            cameraInfo = camInfoManager.getCameraInfo();

            // Manually add ROI settings if configured.
            // So no recalibration is necessary when adjusting ROI
            cameraInfo.roi.x_offset = static_cast<unsigned int>(settings.ROI_OffsetX);
            cameraInfo.roi.y_offset = static_cast<unsigned int>(settings.ROI_OffsetY);
            cameraInfo.roi.width = static_cast<unsigned int>(settings.ROI_Width);
            cameraInfo.roi.height = static_cast<unsigned int>(settings.ROI_Height);

        } else {
            ROS_ERROR_STREAM("Invalid CameraInfo URL! Please check, that " << cameraInfoURL << " for camera " << serialString << " exists.");
            ROS_ERROR_STREAM("Error Code: " << camInfoManager.validateURL(cameraInfoURL));
        }

        //setup auto exposure object
        std::unique_ptr<AutoExposure> autoexposure;

        if (settings.autoExposureEnabled) {
            autoexposure = std::make_unique<AutoExposure>(settings.autoExposureBrightness,
                                                     settings.exposureTimeMicroseconds,
                                                     settings.fNumber,
                                                     settings.slowestExposureTime,
                                                     settings.fastestExposureTime,
                                                     runner);
        }


        datastreamList = pDevice->GetDataStreams();
        datastreamList->Refresh();

        //open all datastreams
        for (auto dsIt = datastreamList->begin(); dsIt != datastreamList->end(); dsIt++) {
            dsIt->second->Open();
            pDataStream.reset(dsIt->second);
            break;
        }


        if (pDataStream == nullptr) {
            ROS_ERROR_STREAM(" No DataStream found ");
            return EXIT_FAILURE;
        }

        //BufferList
        bufferList = pDataStream->GetBufferList();

        // 4 buffers using internal buffer mode
        for (int i = 0; i < 4; i++) {
            pBuffer = new BGAPI2::Buffer();
            bufferList->Add(pBuffer);
        }


        for (auto bufIterator = bufferList->begin(); bufIterator != bufferList->end(); bufIterator++) {
            bufIterator->second->QueueBuffer();
        }

        pDataStream->StartAcquisitionContinuous();

        //START CAMERA
        pDevice->GetRemoteNode("AcquisitionStart")->Execute();

        BGAPI2::Buffer *pBufferFilled = NULL;


        //reset frame counter
        pDevice->GetRemoteNode("FrameCounter")->SetInt(0);

        //needed for timestamps
        bool firstAcquisition = true;
        ros::Time firstBufferFilledTimeROS;
        bo_uint64 firstBufferFilledTimeCamera = 0;

        while (ros::ok() && pDataStream->GetIsGrabbing()) {

            pBufferFilled = pDataStream->GetFilledBuffer(static_cast<bo_uint64>(settings.bufferTimeoutMilliseconds));

            if (pBufferFilled == NULL) {
                ROS_ERROR_STREAM("Error: Buffer Timeout after " << settings.bufferTimeoutMilliseconds << "msec");
                ROS_ERROR("Shutting down driver...");
                break;

            } else {

                bool incomplete = pBufferFilled->GetIsIncomplete() != 0;
                runner.stage("ImageIncomplete", incomplete);

                if (incomplete) {
                    ROS_WARN_STREAM("Image is incomplete");

                    //requeue buffer if incomplete image should not be published
                    if (!settings.publishIncompleteImages) {
                        pBufferFilled->QueueBuffer();
                        continue;
                    }
                }

                try {
                
                    bo_int64 frameCounter = pDevice->GetRemoteNode("FrameCounter")->GetInt();

                    auto now = ros::Time::now();

                    //create imageMsg with camera image
                    BGAPI2::Image *pTransformImage = NULL;
                    BGAPI2::Image *pImage = imgProcessor->CreateImage((bo_uint) pBufferFilled->GetWidth(),
                                                                      (bo_uint) (int) pBufferFilled->GetHeight(),
                                                                      pBufferFilled->GetPixelFormat(),
                                                                      pBufferFilled->GetMemPtr(),
                                                                      pBufferFilled->GetMemSize());

                    // using the first acquisition as reference
                    if (firstAcquisition) {

                        // Get transmission delay through buffer size (assumes 1 Gbit LAN, always)
                        // auto size = pBufferFilled->GetHeight() * pBufferFilled->GetWidth() * 3;
                        auto size = pImage->GetTransformBufferLength(pBufferFilled->GetPixelFormat());
                        
                        // Actual network transmission much slower, therefore use factor to add extra transmission delay
                        constexpr float empirical_network_factor = 2.0f;
                        
                        float transmission_delay = size / 128'000'000.0f * empirical_network_factor;
                        double exposure_time = pDevice->GetRemoteNode("ExposureTime")->GetDouble() / 1'000'000.0;

                        ROS_INFO_STREAM("Transmission delay for image of size " << size << " is " << transmission_delay << " secs");
                        ROS_INFO_STREAM("Exposure delay for image is " << exposure_time);

                        // Add tranmission time since GetTimestamp() is image timestamp at start of acquisition and we are synchronizing
                        // the current acqui
                        firstBufferFilledTimeCamera = pBufferFilled->GetTimestamp();

                        firstBufferFilledTimeROS = now - ros::Duration(transmission_delay + exposure_time);

                        firstAcquisition = false;
                    }

                    //set white balance after set amount of frames
                    if (frameCounter == settings.whiteBalanceAfterNFrames) {
                        pDevice->GetRemoteNode("WhiteBalance")->Execute();
                        ROS_INFO("Set white balance!");
                    }

                    //calculate time stamp
                    //convert nanosecondsSinceFirstBufferFilled to ROS duration
                    bo_uint64 nanosecondsSinceFirstBufferFilled = pBufferFilled->GetTimestamp() - firstBufferFilledTimeCamera;
                    ros::Duration durationSinceFirstBufferFill(static_cast<uint32_t>(nanosecondsSinceFirstBufferFilled / 1'000'000'000),
                                           static_cast<uint32_t>(nanosecondsSinceFirstBufferFilled % 1'000'000'000));
                    ros::Time messageTimestamp = firstBufferFilledTimeROS + durationSinceFirstBufferFill;


                    if (std::string(pImage->GetPixelformat()).substr(0, 4) == "Mono") {
                        ROS_ERROR_STREAM("Mono image detected! Something somewhere went wrong!");
                        continue;
                    }

                    pImage->TransformImage("BGR8", &pTransformImage);

                    auto transformBuffer = (unsigned char *) pTransformImage->GetBuffer();

                    if (compress) {
                        sensor_msgs::CompressedImage msg;
                        msg.header.frame_id = tfFrame;
                        msg.header.stamp = messageTimestamp;

                        cv::Mat cv_img(pImage->GetHeight(), pImage->GetWidth(), CV_8UC3, transformBuffer);

                        cv::imencode(".jpg", cv_img, msg.data, { cv::IMWRITE_JPEG_QUALITY, compression_quality });

                        image_publisher.publish(msg);
                    } else {

                        // create image message
                        sensor_msgs::Image imageMsg;
                        imageMsg.header.frame_id = tfFrame;
                        imageMsg.header.stamp = messageTimestamp;
                        imageMsg.height = pImage->GetHeight();
                        imageMsg.width = pImage->GetWidth();
                        imageMsg.encoding = "bgr8";
                        imageMsg.step = pImage->GetWidth() * 3;

                        // Fill image message
                        imageMsg.data = decltype(imageMsg.data)(imageMsg.width * imageMsg.height * 3, 0);
                        std::memcpy(&imageMsg.data[0], transformBuffer, imageMsg.data.size());

                        //publish image
                        image_publisher.publish(imageMsg);
                    }

                    //set camera info header
                    if (camInfoManager.isCalibrated()) {
                        cameraInfo.header.stamp = messageTimestamp;
                        cameraInfo.header.frame_id = tfFrame;
                    } else {
                        ROS_WARN_STREAM("cameraInfoManager not calibrated!");
                    }

                    cam_info_publisher.publish(cameraInfo);

                    //auto expose next frame
                    if (settings.autoExposureEnabled) {
                        double exposureTime = autoexposure->predictExposureTime(pImage, transformBuffer);
                        pDevice->GetRemoteNode("ExposureTime")->SetDouble(exposureTime);
                        runner.stage("ExposureTime", exposureTime);
                    }
                    pImage->Release();
                    pTransformImage->Release();
                    runner.report();


                } catch (BGAPI2::Exceptions::IException& ex) {
                    ROS_ERROR_STREAM("Exception while receiving image: " << "Exception Type:" << ex.GetType() << "\nFunction name: " << ex.GetFunctionName() << "\nDescription: " << ex.GetErrorDescription());
                } catch (std::exception& ex) {
                    ROS_ERROR_STREAM("Exception while receiving image: " << ex.what());
                } catch (...) {
                    ROS_ERROR("Unknown exception while receiving image");
                }

                //QUEUE BUFFER AFTER USE
                pBufferFilled->QueueBuffer();
            }

            // Reset the event mode to EventMode_Disabled .
            pDevice->UnregisterDeviceEvent();
            ros::spinOnce();
        }

        //stop acquisition when driver is stopped
        pDevice->UnregisterDeviceEvent();
        pDevice->GetRemoteNode("AcquisitionStop")->Execute();
        ROS_INFO("Stopped acquisition");

        pDevice->Close();

        // clearing buffers not working...
        // => Bgapi_ObjectInvalidException
        bufferList->DiscardAllBuffers();

        while(bufferList->size() > 0) {
            pBuffer = bufferList->begin()->second;
            bufferList->RevokeBuffer(pBuffer);
            delete pBuffer;
        }


        BGAPI2::SystemList::ReleaseInstance();
        BGAPI2::ImageProcessor::ReleaseInstance();

    } catch (BGAPI2::Exceptions::IException& ex) {
        ROS_ERROR_STREAM("Exception Type:" << ex.GetType() << "\nFunction name: " << ex.GetFunctionName() << "\nDescription: " << ex.GetErrorDescription());
    }

    return EXIT_SUCCESS;
}

