//
// Created by horsepower on 18.02.18.
//

#include <iomanip>
#include <cmath>
#include "autoexposure.h"



AutoExposure::AutoExposure(double optimalBrightness,
                           double startExposureTime,
                           double fNumber,
                           double slowestExpTime,
                           double fastestExpTime,
                           telemetry::Runner& telemetryRunner) : runner(telemetryRunner) {
    B_opt = optimalBrightness;
    FNumber = fNumber;
    EV_pre = 2*log2(fNumber) - log2(startExposureTime); //formula to calculate exposure value (found in literature)
    T_min = fastestExpTime;
    T_max = slowestExpTime;
    T_pre = startExposureTime;
}


double AutoExposure::predictExposureTime(BGAPI2::Image *pImage, const unsigned char *imageBuffer) {

    double averageLuminanceBrightness = 0;
    double pixelWeight;

    //calculate average luminance brightness for every tenth pixel
    //this loop takes about 0.01s
    for(uint16_t row = 0; row < pImage->GetHeight(); row+=10) {
        for(uint16_t col = 0; col < pImage->GetWidth(); col+=10) {
            if (row > (pImage->GetHeight()/4) && row < (3*pImage->GetHeight()/4)) {
                //bottom half of image
                pixelWeight = 1.80;
            } else {
                //top half is less important
                pixelWeight = 0.20;
            }

            //using ITU BT.709 photometric standard
            averageLuminanceBrightness += pixelWeight*(0.0722 * (int)imageBuffer[pImage->GetWidth()*3*row + col*3+0] + //blue
                                         0.7152 * (int)imageBuffer[pImage->GetWidth()*3*row + col*3+1] + //green
                                         0.2126 * (int)imageBuffer[pImage->GetWidth()*3*row + col*3+2]);  // Red value of pixel

        }
    }
    //divide by number of pixels
    averageLuminanceBrightness = averageLuminanceBrightness/(pImage->GetWidth() * pImage->GetHeight());

    //formula to calculate optimal exposure value (found in literature)
    EV_opt = EV_pre + std::log2(averageLuminanceBrightness) - std::log2(B_opt);
    double T_opt = pow(2, -(EV_opt-2*log2(FNumber)));

#ifdef PRINT
    //print current difference between optimal and current brightness
    std::cout << B_opt-averageLuminanceBrightness << std::endl;


    if (T_opt > T_max) {
        std::cout << "scene too dark. optimal exposure time = " << T_opt << std::endl;
        T_opt = T_max;
    } else if (T_opt < T_min) {
        std::cout << T_opt << std::endl;
        T_opt = T_min;
        std::cout << "scene too bright. optimal exposure time = " << std::endl;
    } else {
        std::cout << T_opt << std::endl;
    }
#endif

    runner.stage("optimalExposure", T_opt);
    runner.stage("sceneBrightness", averageLuminanceBrightness);
    runner.stage("sceneTooDark", T_opt > T_max);
    runner.stage("sceneTooBright", T_opt < T_min);

    if (T_opt > T_max) {
        T_opt = T_max;
    } else if (T_opt < T_min) {
        T_opt = T_min;
    }

    EV_pre = 2*log2(FNumber) - log2(T_opt);

    //correction factor is absolute difference between optimal and current brightness
    double correctionFactor = std::min<double>(fabs(B_opt-averageLuminanceBrightness), 1);
    runner.stage("exposureCorrectionFactor", correctionFactor);

    //weighing the old and new time to prevent oscillation
    T_pre = (1-correctionFactor) * T_pre + correctionFactor * T_opt;

    runner.report();
    return T_pre;
}




