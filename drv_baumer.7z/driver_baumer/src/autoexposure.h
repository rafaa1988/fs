//
// Created by horsepower on 18.02.18.
//

#pragma once

#include <bits/unique_ptr.h>
#include <bgapi2_genicam.hpp>
#include <queue>
#include <telemetry/Runner.h>

class AutoExposure {

private:

    double B_opt;
    double EV_pre;
    double EV_opt;
    double FNumber;
    double T_min;
    double T_max;
    double T_pre;
    telemetry::Runner& runner;

public:
    AutoExposure(double optimalBrightness, double startExposureTime, double fNumber, double slowestExpTime,
                 double fastestExpTime, telemetry::Runner &telemetryRunner);

    double predictExposureTime(BGAPI2::Image *pImage,const unsigned char *imageBuffer);
};

