
struct cameraSettings {

    bool triggerActivated;
    double acquisitionFrameRate;

    //default values for config (only for future reference)
    double fNumber; // = 1.4;
    double exposureTimeMicroseconds; // = 50'000;

    bool autoExposureEnabled; // = true;
    double slowestExposureTime; // = 60'000;
    double fastestExposureTime; // = 4;
    double autoExposureBrightness; // = 0.5;

    int ROI_OffsetX; // = 0;
    int ROI_OffsetY; // = 0;
    int ROI_Height; // = -1;
    int ROI_Width; // = -1;

    int bufferTimeoutMilliseconds; // = 1000;
    bool publishIncompleteImages; // = true;

    int whiteBalanceAfterNFrames;

    void setCameraSettings(BGAPI2::Device& device, const ros::NodeHandle& n);
};