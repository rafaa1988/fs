# ROS Node template
This is a template package for creating new ROS nodes. Create a new node by

1. Copying this folder and renaming it to your new package name, from now on
referred to as `package`
2. Changing `<name>` in `package.xml` to `package`. You should also update `<description>`
3. Changing `project()` at the start of `CMakeLists.txt` to `package`
4. Configure `launch` files as appropriate
5. Modifying this Readme to fit the new package
