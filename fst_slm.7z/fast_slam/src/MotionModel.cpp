#include "MotionModel.h"

std::default_random_engine MotionModel::rng;


float MotionModel::std_x;
float MotionModel::std_y;
float MotionModel::std_theta;