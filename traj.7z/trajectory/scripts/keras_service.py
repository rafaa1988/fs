#!/usr/bin/env python3

# Packet format:
# i32: SeqNo
# i32: NoImages
# RawImageData * NoImages

MAXIMUM_BUFFER_SIZE = 150000


def main():
    from argparse import ArgumentParser

    parser = ArgumentParser(description="Python Unix Domain Socket classification service")
    parser.add_argument('name', help="Abstract name of socket")
    parser.add_argument('model', help="Path to model")
    parser.add_argument('mode', help="UNUSED")
    parser.add_argument('gpu_frac', help="maximum gpu percentage")
    args = parser.parse_args()

    import keras
    import numpy as np
    import socket
    import struct
    import sys
    import tensorflow
    from collections import deque

    # Configure tensorflow to not eat up GPU
    config = tensorflow.ConfigProto()
    #config.gpu_options.allow_growth = True
    #sess = tensorflow.Session(config=config)


    gpu_options = tensorflow.GPUOptions(per_process_gpu_memory_fraction=float(args.gpu_frac))
    sess = tensorflow.Session(config=tensorflow.ConfigProto(gpu_options=gpu_options))
    keras.backend.tensorflow_backend.set_session(sess)

    # Load keras model from specified file path
    model = keras.models.load_model(args.model)

    # Automatically detect the input shape of the model and calculated expected raw bytes
    size_per_image = 150 * 300 * 3
    print("Expecting images of size " + str(size_per_image) + " bytes")

    # Bind a Unix domain datagram socket on the specified abstract name
    s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    s.bind('\0' + args.name)
    print("Listening on abstract unix domain socket \"" + args.name + "\"")

    speeds = deque([0,0,0,0,0], maxlen=5)

    while True:
        (data, addr) = s.recvfrom(MAXIMUM_BUFFER_SIZE)
        (seqno, amount, current_checkpoint, cone_hits) = struct.unpack('IIII', data[0:16])

        # Calculate expected datagram size based on raw image size, specified amount and the header size
        expected_size = 4 + 4 + 4 + 4 + amount * size_per_image

        # Terminate on size mismatch, something fishy is going on
        if expected_size != len(data):
            raise RuntimeError("Unexpected packet size, expected " + str(expected_size) + ", got " + str(len(data)),
                               file=sys.stderr)


        # Reshape images to fit model input
        images = np.reshape(np.frombuffer(data, offset=16, dtype=np.uint8), (amount,) + (300, 150, 3))

        # normalize image
        # images = images.astype(np.float32)
        # images *= 1.0/255.0

        speedArray = np.asarray(speeds, dtype=np.float32)
        speedArray = speedArray.reshape((1,5))

        pred = model.predict([images, speedArray])
        angle = pred[0][0][0]
        speed = pred[1][0][0]

        #print("angle: {} speed: {}".format(angle, speed))

        #speed prediction gets saved in ring buffer
        speeds.append(speed)

        # send control message via driver
        # packet only sends unsigned integers, therefore multiply with 100 to keep 2 decimal places
        steering = (angle+1)*30.0 * 100
        out_packet = struct.pack('I', seqno)
        out_packet = out_packet + struct.pack('I', int(np.clip(steering, 0, 60.0 * 100)))
        out_packet = out_packet + struct.pack('I', int(np.clip(speed * 100.0, 0.0, 100.0)))
        out_packet = out_packet + struct.pack('c', b"\0") # reset flag originally used in RL, kept for interface

        s.sendto(out_packet, addr)

if __name__ == '__main__':
    main()
