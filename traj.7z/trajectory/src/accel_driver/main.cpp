#include <ros/ros.h>
#include <hphlib/util.h>

#include "AccelDriver.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "accel_driver");
    ros::NodeHandle n("~");

    AccelDriver accel_driver(n);

    ros::spin();
}
