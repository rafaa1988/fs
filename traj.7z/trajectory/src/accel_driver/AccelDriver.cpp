#include <nav_msgs/Path.h>

#include <hphlib/util.h>
#include <hphlib/eigen.h>
#include <hphlib/Control.h>
#include <eigen_conversions/eigen_msg.h>

#include "AccelDriver.h"

using namespace Eigen;

AccelDriver::AccelDriver(ros::NodeHandle &n)
    : cones_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "topic_cones"), 1, &AccelDriver::conesCallback, this))
    , odometry_sub_(n.subscribe("/odometry/filtered", 1, &AccelDriver::odometryCallback, this))
    , distance_tracker_sub_(n.subscribe("/odometry/distance_driven", 1, &AccelDriver::distanceDrivenCallback, this))
    , trajectory_pub_(n.advertise<nav_msgs::Path>(getRequiredRosParam<std::string>(n, "topic_midway_out"), 1))
    , control_pub_(n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "topic_control"), 1))
    , left_bounds_pub_(n.advertise<nav_msgs::Path>("/accel_driver/left_boundary", 1))
    , right_bounds_pub_(n.advertise<nav_msgs::Path>("/accel_driver/right_boundary", 1))
    , left_fit_pub_(n.advertise<nav_msgs::Path>("/accel_driver/left_fit", 1))
    , right_fit_pub_(n.advertise<nav_msgs::Path>("/accel_driver/right_fit", 1))
    , wdog_(n, "/control/wd")
    , boundaries_angle(getRequiredRosParam<double, float>(n, "boundaries_angle") / 180.0f * M_PI)
    , trigger_finish(getRequiredRosParam<bool>(n, "trigger_finish"))
    , max_velocity(getRequiredRosParam<double, float>(n, "max_velocity") / 3.6f)
    , controller_p_factor(getRequiredRosParam<double, float>(n, "controller_p_factor"))
    , controller_d_factor(getRequiredRosParam<double, float>(n, "controller_d_factor"))
{
    wdog_.enable();
}

void findBoundary(const pcl::PointCloud<pcl::PointXYZRGBA> &cones, const Vector2f &start, Vector2f direction,
                  float boundaries_angle, uint32_t cone_color, std::vector<Vector2f> &boundary) {
    Vector2f current = start;
    long current_idx = -1;
    boundary.push_back(current);

    for (;;) {
        long next_idx = -1;
        float closest_dist = std::numeric_limits<float>::max();

        for (size_t i = 0; i < cones.size(); i++) {
            pcl::PointXYZRGBA cone = cones[i];
            if (cone.rgba != cone_color && cone.rgba != hphlib::REF_COLOR_RED && cone.rgba != hphlib::REF_COLOR_FINISH)
                continue;

            Vector2f cv(cone.x, cone.y);
            Vector2f cone_dir = (cv - current);
            float dist = cone_dir.norm();
            if (dist <= 1)
                continue;
            float angle = std::atan2(cone_dir.y(), cone_dir.x()) - std::atan2(direction.y(), direction.x());

            if (std::abs(angle) < boundaries_angle || (boundary.size() < 2 && std::abs(angle) < boundaries_angle)) {
                // the cone is in the right direction and has the right angle
                if (dist < closest_dist && (cone.rgba == cone_color ||
                                            ((cone_color == hphlib::REF_COLOR_BLUE && cone.y > 0) ||
                                             (cone_color == hphlib::REF_COLOR_YELLOW && cone.y < 0)))) {
                    next_idx = i;
                    closest_dist = dist;
                }
            }
        }

        if (current_idx == next_idx || next_idx == -1)
            break;

        Vector2f next(cones[next_idx].x, cones[next_idx].y);
        direction = (next - current);
        current = next;
        current_idx = next_idx;
        boundary.push_back(current);
    }
}

void AccelDriver::conesCallback(const pcl::PointCloud<pcl::PointXYZRGBA> cones) {
    std::vector<Vector2f> left_boundary;
    std::vector<Vector2f> right_boundary;

    Vector2f closest_left = Vector2f::Zero();
    Vector2f closest_right = Vector2f::Zero();
    float closest_left_dist = std::numeric_limits<float>::max();
    float closest_right_dist = std::numeric_limits<float>::max();

    int finish_left = 0;
    int finish_right = 0;

    bool drive_slow = false;

    if (cones.size() >= 4) {
        // find cones on the left and on the right that are the closest to the car
        for (auto &cone: cones) {
            Vector2f cv(cone.x, cone.y);
            if (cone.y > 0) {
                // left
                if (cv.norm() < closest_left_dist) {
                    closest_left = cv;
                    closest_left_dist = cv.norm();
                }
                if (cone.rgba == hphlib::REF_COLOR_FINISH || cone.rgba == hphlib::REF_COLOR_RED) {
                    // this is a finish cone
                    // check if it is behind the car and closer than 20m
                    if (cone.x < 0 && cone.y < 5 && cv.norm() < 30) {
                        finish_left++;
                    }
                }
            } else if (cone.y < 0) {
                // right
                if (cv.norm() < closest_right_dist) {
                    closest_right = cv;
                    closest_right_dist = cv.norm();
                }
                if (cone.rgba == hphlib::REF_COLOR_FINISH || cone.rgba == hphlib::REF_COLOR_RED) {
                    // this is a finish cone
                    // check if it is behind the car and closer than 20m
                    if (cone.x < 0 && cone.y > -5 && cv.norm() < 30) {
                        finish_right++;
                    }
                }
            }
        }

        // generate boundaries from those points forward
        if (closest_left_dist != std::numeric_limits<float>::max()) {
            std::vector<Vector2f> left_boundary_forward;
            std::vector<Vector2f> left_boundary_backward;
            findBoundary(cones, closest_left, Vector2f(1, 0), boundaries_angle, hphlib::REF_COLOR_BLUE,
                         left_boundary_forward);
//            findBoundary(cones, closest_left, Vector2f(-1, 0), boundaries_angle, hphlib::REF_COLOR_BLUE,
//                         left_boundary_backward);

            left_boundary.reserve(left_boundary_forward.size() + left_boundary_backward.size());

            left_boundary.insert(left_boundary.end(), left_boundary_backward.rbegin(), left_boundary_backward.rend());
            left_boundary.insert(left_boundary.end(), left_boundary_forward.begin(), left_boundary_forward.end());
        }

        if (closest_right_dist != std::numeric_limits<float>::max()) {
            std::vector<Vector2f> right_boundary_forward;
            std::vector<Vector2f> right_boundary_backward;
            findBoundary(cones, closest_right, Vector2f(1, 0), boundaries_angle, hphlib::REF_COLOR_YELLOW,
                         right_boundary_forward);
//            findBoundary(cones, closest_right, Vector2f(-1, 0), boundaries_angle, hphlib::REF_COLOR_YELLOW,
//                         right_boundary_backward);

            right_boundary.reserve(right_boundary_forward.size() + right_boundary_backward.size());

            right_boundary.insert(right_boundary.end(), right_boundary_backward.rbegin(),
                                  right_boundary_backward.rend());
            right_boundary.insert(right_boundary.end(), right_boundary_forward.begin(),
                                  right_boundary_forward.end());
        }
    } else {
        drive_slow = true;
    }

    nav_msgs::Path left_bounds = vectorListToPath(left_boundary);
    nav_msgs::Path right_bounds = vectorListToPath(right_boundary);

    left_bounds.header.stamp = ros::Time::now();
    left_bounds.header.frame_id = "base_link";

    right_bounds.header = left_bounds.header;

    left_bounds_pub_.publish(left_bounds);
    right_bounds_pub_.publish(right_bounds);


    float steering_angle = 0;
    if (left_boundary.size() < 2 || right_boundary.size() < 2) {
        // we cant operate on this little information
        // publish 0 steering angle and hope for the best
        drive_slow = true;
    } else {
        float left_m, left_b, right_m, right_b;

        // fit the points with a linear function
        linearFit(left_boundary, left_m, left_b);
        linearFit(right_boundary, right_m, right_b);

        // generate vectors to publish the fitted lines
        std::vector<Vector2f> left_fit_points;
        std::vector<Vector2f> right_fit_points;
        left_fit_points.emplace_back(-200, -200 * left_m + left_b);
        left_fit_points.emplace_back(200, 200 * left_m + left_b);
        right_fit_points.emplace_back(-200, -200 * right_m + right_b);
        right_fit_points.emplace_back(200, 200 * right_m + right_b);

        nav_msgs::Path left_fit = vectorListToPath(left_fit_points);
        nav_msgs::Path right_fit = vectorListToPath(right_fit_points);

        left_fit.header = left_bounds.header;
        right_fit.header = left_bounds.header;

        left_fit_pub_.publish(left_fit);
        right_fit_pub_.publish(right_fit);

        // calculate vehicle heading from last odometry message
        Vector2f vv = Vector2f(last_odometry.twist.twist.linear.x, last_odometry.twist.twist.linear.y);

        Quaterniond rotation;
        tf::quaternionMsgToEigen(last_odometry.pose.pose.orientation, rotation);
        Vector3d head_vec3 = rotation.toRotationMatrix() * Vector3d(1, 0, 0);
        Vector2f head_vec(head_vec3.x(), head_vec3.y());

        // calculate perpendicular distance to base_link which is located in 0,0
        float dq = -(left_b + right_b) / 2.0f;
        float m = (left_m + right_m) / 2;
        float dqd = -vv.norm() * std::sin(std::atan(m) - std::atan2(vv.y(), vv.x()));

        steering_angle = controller_d_factor * dq + controller_p_factor * dqd;
    }


    hphlib::Control control;
    control.header.stamp = ros::Time::now();
    control.steering_angle = steering_angle * 180.0f / M_PI;

    if (true || !drive_slow) {
        control.target_velocity = max_velocity;
    } else {
        control.target_velocity = 5.0f / 3.6f;
    }

    if (trigger_finish && distance_driven > 50 && finish_left >= 4 && finish_right >= 4) {
        // we drove at least 30 meters and see a at least 2 finish cone on both sides behind the car. lets finish
        control.finish_mission = true;
    }

    control_pub_.publish(control);
}

void AccelDriver::odometryCallback(const nav_msgs::Odometry odom) {
    last_odometry = odom;
}

void AccelDriver::distanceDrivenCallback(hphlib::Distance distance) {
    distance_driven = distance.distance;
}