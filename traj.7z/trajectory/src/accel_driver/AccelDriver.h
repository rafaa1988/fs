#pragma once

#include <ros/ros.h>
#include <nav_msgs/Odometry.h>

#include <hphlib/Distance.h>
#include <hphlib/misc/Watchdog.h>

#include <hphlib/pcl.h>

class AccelDriver {
private:
    ros::Subscriber cones_sub_;
    ros::Subscriber odometry_sub_;
    ros::Subscriber distance_tracker_sub_;
    ros::Publisher trajectory_pub_;
    ros::Publisher control_pub_;

    ros::Publisher left_bounds_pub_;
    ros::Publisher right_bounds_pub_;
    ros::Publisher left_fit_pub_;
    ros::Publisher right_fit_pub_;

    hphlib::Watchdog wdog_;

    float boundaries_angle;
    bool trigger_finish;

    float max_velocity;

    float controller_p_factor;
    float controller_d_factor;

    float distance_driven = 0;

    nav_msgs::Odometry last_odometry;

    void conesCallback(pcl::PointCloud<pcl::PointXYZRGBA> cones);
    void odometryCallback(nav_msgs::Odometry odom);
    void distanceDrivenCallback(hphlib::Distance distance);
public:
    AccelDriver(ros::NodeHandle &n);
};
