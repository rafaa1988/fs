#pragma once

#include <nav_msgs/Odometry.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <hphlib/misc/map/MapLoader.h>
#include <ros/ros.h>

class MessageListener {
private:
    ros::Publisher marker_array_pub_;

    visualization_msgs::Marker area_marker;

    std::vector<hphlib::MapSection> sections_;

public:


    explicit MessageListener(ros::NodeHandle &n);

    void odometryCallback(const nav_msgs::Odometry::ConstPtr &msg);

};