//
// Created by niclas on 16.07.18.
//

#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <hphlib/util.h>
#include "MessageListener.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "skidpad");
    ros::NodeHandle n("~");
    std::string topic_map_filtered = getRequiredRosParam<std::string>(n, "topic_map_filtered");

    MessageListener listener(n);

    auto odometry_sub = n.subscribe< >(
            topic_map_filtered,
            1,
            &MessageListener::odometryCallback,
            &listener
    );

    ros::spin();
}
