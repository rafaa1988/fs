#include "MessageListener.h"
#include <hphlib/util.h>


MessageListener::MessageListener(ros::NodeHandle& n) : marker_array_pub_(n.advertise<visualization_msgs::MarkerArray>("/visualization_marker_array", 1))
{
    area_marker.id = 0;
    area_marker.ns = "skidpad_areas";
    area_marker.color.r = 1.0f;
    area_marker.color.a = 1.0f;
    area_marker.scale.x = 0.05f;
    area_marker.scale.y = 0.05f;
    area_marker.type = visualization_msgs::Marker::LINE_STRIP;

    area_marker.header.stamp = ros::Time::now();
    area_marker.header.frame_id = "map";

    auto map = hphlib::MapLoader::load(getRequiredRosParam<std::string>(n, "map_name"));
    if (map) {
        sections_ = (*map).sections;
    }
}

void addVertexToMarker(visualization_msgs::Marker& marker, const Eigen::Vector2f& vertex) {
    geometry_msgs::Point point;
    point.x = vertex[0];
    point.y = vertex[1];
    marker.points.push_back(point);
}

bool checkIfPositionInArea(const std::vector<geometry_msgs::Point>& vectorOfPolygonPoints, double x, double y) {
    size_t i;
    size_t j;
    bool result = false;

    for (i = 0, j = vectorOfPolygonPoints.size() - 1; i < vectorOfPolygonPoints.size(); j = i++) {

        if (((vectorOfPolygonPoints[i].y > y) != (vectorOfPolygonPoints[j].y > y)) &&
            (x < (vectorOfPolygonPoints[j].x - vectorOfPolygonPoints[i].x) * (y - vectorOfPolygonPoints[i].y) /
                 (vectorOfPolygonPoints[j].y - vectorOfPolygonPoints[i].y) + vectorOfPolygonPoints[i].x)) {
            result = !result;
        }
    }
    return result;
}


void MessageListener::odometryCallback(const nav_msgs::Odometry::ConstPtr &msg) {

    visualization_msgs::MarkerArray allSections;

    int marker_id = 0;
    for (const auto& section : sections_) {
        area_marker.points.clear();
        if (section.vertices.empty()) {
            continue;
        }
        for (const auto& vertex : section.vertices) {
            addVertexToMarker(area_marker, vertex);
        }
        // add first point for loop closure ;)
        addVertexToMarker(area_marker, section.vertices[0]);
        allSections.markers.push_back(area_marker);
        area_marker.id = marker_id;

        if (checkIfPositionInArea(area_marker.points,
                                  msg->pose.pose.position.x, msg->pose.pose.position.y)) {
            area_marker.color.r = 0.0f;
            area_marker.color.g = 1.0f;
            std::cout << "IN AREA: " << area_marker.id << std::endl;
        }

        marker_id++;
    }

    marker_array_pub_.publish(allSections);
}

