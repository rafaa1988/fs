#include <nav_msgs/Path.h>
#include <visualization_msgs/MarkerArray.h>
#include <hphlib/util.h>

#include "RandomTree.h"

using namespace hphlib;

bool intersects_circle(Eigen::Vector2f start, Eigen::Vector2f direction, Eigen::Vector2f &center, float radius) {
    start = start - center;
    float a = start.squaredNorm() - radius * radius;
    float b = 2 * (start.x() * direction.x() + start.y() * direction.y());
    float c = direction.squaredNorm();
    float disc = b * b - 4 * a * c;

    if (disc <= 0)
        return false;

    float sqrtdisc = std::sqrt(disc);
    float t1 = (-b + sqrtdisc) / (2 * a);
    float t2 = (-b - sqrtdisc) / (2 * a);

    return (0 < t1 && t1 < 1) || (0 < t2 && t2 < 1);
}

RandomTree::RandomTree(ros::NodeHandle &n)
    : cones_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "topic_cones"), 1, &RandomTree::pointCloudCallback, this))
    , odo_sub_(n.subscribe(getRequiredRosParam<std::string>(n, "topic_odometry"), 1, &RandomTree::odometryCallback, this))
    , path_pub_(n.advertise<nav_msgs::Path>(getRequiredRosParam<std::string>(n, "topic_path"), 1))
    , marker_pub_(n.advertise<visualization_msgs::MarkerArray>("visualization_marker", 0))
{
    // Initialize tree and scoring parameters

    parameters.link_length = getRequiredRosParam<double, float>(n, "link_length");
    parameters.link_count = getRequiredRosParam<int, size_t>(n, "link_count");
    parameters.initial_root_count = getRequiredRosParam<int>(n, "initial_root_count");
    parameters.angle_increment_rad = static_cast<float>(getRequiredRosParam<int>(n, "angle_increment_deg") * M_PI / 180);

    parameters.growth_score_threshold = getRequiredRosParam<int>(n, "growth_score_threshold");
    parameters.growth_direction_change_threshold = getRequiredRosParam<int>(n, "growth_direction_change_threshold");

    parameters.wrong_side_color_penalty_factor = getRequiredRosParam<double, float>(n, "wrong_side_color_penalty_factor");
    parameters.direction_change_penalty_factor = getRequiredRosParam<double, float>(n, "direction_change_penalty_factor");
    parameters.curve_penalty_factor = getRequiredRosParam<double, float>(n, "curve_penalty_factor");
    parameters.previous_path_distance_factor = getRequiredRosParam<double, float>(n, "previous_path_distance_factor");

    parameters.cone_check_distance = getRequiredRosParam<double, float>(n, "cone_check_distance");
    parameters.cone_min_perpendicular_distance = getRequiredRosParam<double, float>(n, "cone_min_perpendicular_distance");
    parameters.cone_max_perpendicular_distance = getRequiredRosParam<double, float>(n, "cone_max_perpendicular_distance");
    parameters.wrong_cones_penalty_factor = getRequiredRosParam<double, float>(n, "wrong_cones_penalty_factor");

    parameters.collision_check_distance = getRequiredRosParam<double, float>(n, "collision_check_distance");
    parameters.collision_check_radius = getRequiredRosParam<double, float>(n, "collision_check_radius");

    parameters.path_average_count = getRequiredRosParam<int, size_t>(n, "path_average_count");

    parameters.scale_with_velocity =getRequiredRosParam<bool>(n, "scale_with_velocity");

    std::string color_mode = getRequiredRosParam<std::string>(n, "color_mode");
    if (color_mode == "score")
        parameters.color_mode = RandomTreeColorMode::Score;
    else if (color_mode == "state")
        parameters.color_mode = RandomTreeColorMode::State;

    // Initialize visualization marker
    marker_lines.header.frame_id = "/base_link";
    marker_lines.ns = "random_tree";
    marker_lines.id = 0;
    marker_lines.type = visualization_msgs::Marker::LINE_LIST;
    marker_lines.action = visualization_msgs::Marker::ADD;
    marker_lines.pose.orientation.w = 1.0;
    marker_lines.scale.x = 0.025f;
    marker_lines.color.a = 1.0f;
    marker_lines.lifetime = ros::Duration();

    marker_best_path = marker_lines;
    marker_best_path.id = 1;
    marker_best_path.scale.x = 0.1f;
    marker_best_path.color.r = 1.0f;
    marker_best_path.color.g = 1.0f;
    marker_best_path.color.a = 1.0f;
    marker_best_path.lifetime = ros::Duration();


    marker_points = marker_lines;
    marker_points.id = 2;
    marker_points.type = visualization_msgs::Marker::SPHERE;

    marker_points.scale.x = 0.2f;
    marker_points.scale.y = 0.2f;
    marker_points.scale.z = 0.2f;

    marker_points.color.r = 1.0f;
    marker_points.color.a = 1.0f;

    // Initialize first path to be straight for correct conditioning
    for (size_t i = 0; i < parameters.link_count; i++) {
        path.push_back(Eigen::Vector2f(i +1, 0));
    }

    Eigen::VectorXf x(path.size()+1);
    Eigen::VectorXf y(path.size()+1);

    x(0) = 0;
    y(0) = 0;
    for (size_t i = 0; i < path.size(); i++) {
        x(i+1) = path[i].x();
        y(i+1) = path[i].y();
    }
    path_spline.fit(0, 0, 1, parameters.link_length, 200, 0.1, x, y);

    for (size_t i = 0; i < parameters.path_average_count; i++) {
        previous_path_splines.push_back(path_spline);
    }
}

void RandomTree::initRoots() {
    roots.clear();
    for (int i = 0; i < parameters.initial_root_count; i++) {
        roots.emplace_back();
        roots.back().position = Eigen::Vector2f::Zero();
        roots.back().direction = Eigen::Rotation2Df((i-static_cast<int>(std::ceil(parameters.initial_root_count / 2))) *
                                                    parameters.angle_increment_rad / 2.0f).toRotationMatrix() * Eigen::Vector2f(1, 0);
        roots.back().rotation = static_cast<RotationDirection>(i);
    }
}

void RandomTree::findBestPath() {
    // recursively search for best path in all roots
    float min_score = std::numeric_limits<float>::infinity();
    for (auto root: roots) {
        auto root_path = root.calcBestPath();
        if (root_path.second <= min_score) {
            path = root_path.first;
            min_score = root_path.second;
        }
    }

    // check if the path is shorter than expected.
    // if it is take the last link and continue it
    // this counts on the fact the we will eventually find a better path
    if (path.size() < parameters.link_count) {
        Eigen::Vector2f direction;
        if (path.size() > 1) {
            // take the direction from the last link
            direction = path[path.size() - 1] - path[path.size() - 2];
        } else {
            // simply project forward
            direction = Eigen::Vector2f(1, 0);
        }
        for (size_t i = path.size(); i < parameters.link_count; i++) {
            Eigen::Vector2f end = path.back();
            path.push_back(end + direction * parameters.link_length);
        }
    }
}

void RandomTree::updatePathAverage() {
    TrackSpline new_path;

    Eigen::VectorXf x(path.size() + 1);
    Eigen::VectorXf y(path.size() + 1);

    x(0) = 0;
    y(0) = 0;
    for (size_t i = 0; i < path.size(); i++) {
        x(i+1) = path[i].x();
        y(i+1) = path[i].y();
    }

    new_path.fit(0, 0, 1, parameters.link_length, 200, 0.1, x, y);

    if (previous_path_splines.size() >= parameters.path_average_count) {
        TrackSpline old_spline = previous_path_splines.front();
        for (size_t i = 0; i < old_spline.size(); i++) {
            path_spline.x().y()(i) -= old_spline.x().y()(i) / parameters.path_average_count;
            path_spline.x().yp()(i) -= old_spline.x().yp()(i) / parameters.path_average_count;
            path_spline.x().ypp()(i) -= old_spline.x().ypp()(i) / parameters.path_average_count;
            path_spline.x().yppp()(i) -= old_spline.x().yppp()(i) / parameters.path_average_count;

            path_spline.y().y()(i) -= old_spline.y().y()(i) / parameters.path_average_count;
            path_spline.y().yp()(i) -= old_spline.y().yp()(i) / parameters.path_average_count;
            path_spline.y().ypp()(i) -= old_spline.y().ypp()(i) / parameters.path_average_count;
            path_spline.y().yppp()(i) -= old_spline.y().yppp()(i) / parameters.path_average_count;
        }
        previous_path_splines.erase(previous_path_splines.begin());
    }

    for (size_t i = 0; i < new_path.size(); i++) {
        path_spline.x().y()(i) += new_path.x().y()(i) / parameters.path_average_count;
        path_spline.x().yp()(i) += new_path.x().yp()(i) / parameters.path_average_count;
        path_spline.x().ypp()(i) += new_path.x().ypp()(i) / parameters.path_average_count;
        path_spline.x().yppp()(i) += new_path.x().yppp()(i) / parameters.path_average_count;

        path_spline.y().y()(i) += new_path.y().y()(i) / parameters.path_average_count;
        path_spline.y().yp()(i) += new_path.y().yp()(i) / parameters.path_average_count;
        path_spline.y().ypp()(i) += new_path.y().ypp()(i) / parameters.path_average_count;
        path_spline.y().yppp()(i) += new_path.y().yppp()(i) / parameters.path_average_count;
    }

    previous_path_splines.push_back(new_path);
}

void RandomTree::pointCloudCallback(Cones cones) {
    EigenVector cone_positions;
    cone_positions.reserve(cones.size());

    std::transform(cones.begin(), cones.end(), cone_positions.begin(), [](pcl::PointXYZRGBA cone) -> Eigen::Vector2f {
        return Eigen::Vector2f(cone.x, cone.y);
    });

    marker_lines.points.clear();
    marker_lines.colors.clear();
    marker_points.points.clear();

    initRoots();

    for(auto &root: roots) {
        root.grow(nullptr, cones, cone_positions, path, current_velocity);
    }

    float min = std::numeric_limits<float>::infinity();
    float max = 0;
    for (auto &root: roots) {
        root.calcMinMaxScore(min, max);
    }

    for (auto &root: roots) {
        root.visualize(marker_lines, marker_points, min, max);
    }

    findBestPath();
    updatePathAverage();

    nav_msgs::Path pose_path;

    pose_path.header.stamp = ros::Time::now();
    pose_path.header.frame_id = "base_link";

    pose_path.poses.reserve(path_spline.size() + 1);

    for (size_t i = 0; i < path_spline.size(); i++) {
        geometry_msgs::PoseStamped pose;
        pose.pose.position.x = path_spline.p(i).x();
        pose.pose.position.y = path_spline.p(i).y();
        pose_path.poses.push_back(pose);
    }

    path_pub_.publish(pose_path);


    marker_best_path.points.clear();
    geometry_msgs::Point point;
    for (size_t i = 0; i < path_spline.size(); i++) {
        marker_best_path.points.push_back(point);
        tf::pointEigenToMsg(Eigen::Vector3d(path_spline.p(i).x(), path_spline.p(i).y(), 0), point);
        marker_best_path.points.push_back(point);
    }

    visualization_msgs::MarkerArray marker_array;
    marker_array.markers.push_back(marker_lines);
    marker_array.markers.push_back(marker_best_path);
    marker_array.markers.push_back(marker_points);

    marker_pub_.publish(marker_array);
}

void RandomTree::odometryCallback(nav_msgs::Odometry odometry) {
    (void)odometry;
    current_velocity = static_cast<float>(std::sqrt(std::pow(odometry.twist.twist.linear.x, 2.0f) +
                                                    std::pow(odometry.twist.twist.linear.y, 2.0f)));
}