#include <ros/ros.h>
#include <hphlib/util.h>
#include <pcl_ros/point_cloud.h>
#include "RandomTree.h"


int main(int argc, char** argv) {
    ros::init(argc, argv, "random_tree");
    ros::NodeHandle n("~");

    RandomTree tree(n);

    ros::spin();
}
