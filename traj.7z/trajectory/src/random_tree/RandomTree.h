#pragma once

#include <cmath>
#include <algorithm>
#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <visualization_msgs/Marker.h>
#include <eigen_conversions/eigen_msg.h>

#include <eigen3/Eigen/Eigen>
#include <eigen3/Eigen/StdVector>
#include <hphlib/pcl.h>
#include <hphlib/misc/spline/TrackSpline.h>
#include <nav_msgs/Odometry.h>
#include "../../../hphlib/include/hphlib/pcl.h"

typedef pcl::PointCloud<pcl::PointXYZRGBA> Cones;
typedef std::vector<Eigen::Vector2f,Eigen::aligned_allocator<Eigen::Vector2f>> EigenVector;

constexpr float VIS_POINT_SCORE = 100;

enum RotationDirection {
    Left,
    Straight,
    Right
};

enum RandomTreeColorMode {
    Score,
    State
};

struct RandomTreeParameters {
    float link_length = 0.5f;
    size_t link_count = 8;
    int initial_root_count = 5;
    float angle_increment_rad = static_cast<const float>(25 * M_PI / 180);

    int growth_score_threshold = 500;
    int growth_direction_change_threshold = 5;

    float wrong_side_color_penalty_factor = 10.0f;
    float direction_change_penalty_factor = 2.0f;
    float curve_penalty_factor = 1.2f;
    float previous_path_distance_factor = 1.0f;

    // score 2 parameters
    float cone_check_distance = 5.0f;
    float cone_min_perpendicular_distance = 1.0f;
    float cone_max_perpendicular_distance = 3.0f;
    float wrong_cones_penalty_factor = 0.5f;

    float collision_check_distance = 1.5f;
    float collision_check_radius = 0.5f;

    size_t path_average_count = 10;

    bool scale_with_velocity = false;

    RandomTreeColorMode color_mode;

    RandomTreeParameters() = default;
};

static RandomTreeParameters parameters;


inline bool is_on_left_side(Eigen::Vector2f position, Eigen::Vector2f direction, Eigen::Vector2f point) {
    return direction.x() * (point.y() - position.y()) > direction.y()*(point.x() - position.x());
}

inline bool both_sides_red(const pcl::PointXYZRGBA *left, const pcl::PointXYZRGBA *right) {
    return (left && (left->rgba == hphlib::REF_COLOR_FINISH || left->rgba == hphlib::REF_COLOR_RED)) &&
           (right && (right->rgba == hphlib::REF_COLOR_FINISH || right->rgba == hphlib::REF_COLOR_RED));
}

// https://math.stackexchange.com/a/275537
bool intersects_circle(Eigen::Vector2f start, Eigen::Vector2f direction, Eigen::Vector2f &center, float radius);

inline float calc_perpendicular_distance(const Eigen::Vector2f &position, const Eigen::Vector2f &direction, const Eigen::Vector2f &point) {
    Eigen::Vector2f end = position + direction;
    return static_cast<float>(std::abs(direction.y() * point.x() - direction.x() * point.y() + end.x() * position.y() - end.y() * position.x()) / direction.norm());
}

struct TreeNode {
    TreeNode *parent = nullptr;
    std::vector<TreeNode> children;

    size_t depth = 0;
    float score = 0;
    float normalized_score = 0;
    int direction_changes = 0;
    int curve_segment_count = 0;
    bool has_collision = false;
    bool wrong_color = false;
    Eigen::Vector2f position;
    Eigen::Vector2f direction;
    float link_length = 0;
    RotationDirection rotation;

    float calcScore(const Cones &cones, const EigenVector &cone_positions, const EigenVector &last_path) {
        float new_score = 0;

        const pcl::PointXYZRGBA *closest_left = nullptr;
        const pcl::PointXYZRGBA *closest_right = nullptr;
        float closest_left_dist_sq = std::numeric_limits<float>::max();
        float closest_right_dist_sq = std::numeric_limits<float>::max();

        for (size_t i = 0; i < cones.size(); i++) {
            auto cone_position = cone_positions[i];
            float sq_dist = (cone_position - (position + direction * link_length)).squaredNorm();
            float dist = std::sqrt(sq_dist);

            // find the closest cone on either side
            if (is_on_left_side(position, direction, cone_position) && sq_dist < closest_left_dist_sq) {
                closest_left_dist_sq = sq_dist;
                closest_left = &cones[i];
            } else if (sq_dist < closest_right_dist_sq) {
                closest_right_dist_sq = sq_dist;
                closest_right = &cones[i];
            }

            // check if closer than 1.5m. if it is we should check for direct collision
            if (sq_dist < parameters.collision_check_distance * parameters.collision_check_distance) {
                if (intersects_circle(position,
                                      direction * parameters.collision_check_distance,
                                      cone_position,
                                      parameters.collision_check_radius)) {
                    has_collision = true;
                    break;
                }
            }

            if (dist > 1) {
                new_score += std::pow(1.0f / (dist / 2.0f), 2);
            }
        }

        (void) last_path;
        if (has_collision) {
            // set infinity score too avoid further processing
            new_score = std::numeric_limits<float>::infinity();
        } else {

            // take distance to old path into consideration
            Eigen::Vector2f end = position + direction * parameters.link_length;
            if (depth - 1 < last_path.size()) {
                // scale distance to corresponding node in old path with the factor in relation to the depth.
                // this should keep the first path segments more stable.
                int depth_weight = ((parameters.link_count + 1) - depth) / parameters.link_count;
                new_score += (last_path[depth - 1] - end).norm() * parameters.previous_path_distance_factor * depth_weight * depth_weight;
            }

            if (closest_left) {
                // check if this cone makes sense on the left side

                if (closest_left->rgba == hphlib::REF_COLOR_BLUE || both_sides_red(closest_left, closest_right)) {
                    Eigen::Vector2f cone(closest_left->x, closest_left->y);
                    float perp_dist = calc_perpendicular_distance(position, direction, cone);
                    new_score += 1.0f / std::pow(perp_dist / 2.0f, 2)  + std::pow(perp_dist, 2);
                    //new_score += std::exp(std::sqrt(closest_left_dist_sq));
                } else {
                    wrong_color = true;
                }
            }

            if (closest_right) {
                // check if this cone makes sense on the right side
                if (closest_right->rgba == hphlib::REF_COLOR_YELLOW || both_sides_red(closest_left, closest_right)) {
                    Eigen::Vector2f cone(closest_right->x, closest_right->y);
                    float perp_dist = calc_perpendicular_distance(position, direction, cone);
                    new_score += 1.0f / std::pow(perp_dist / 2.0f, 2)  + std::pow(perp_dist, 2);
                    //new_score += std::exp(std::sqrt(closest_right_dist_sq));
                } else {
                    wrong_color = true;
                }
            }

            if (wrong_color) {
                new_score *= parameters.wrong_side_color_penalty_factor; // punish wrong color
                wrong_color = true;
            }

            if (closest_left == nullptr && closest_right == nullptr) {
                // did not find any cones?!
                new_score = std::numeric_limits<float>::infinity();
            }
        }

        new_score *= std::pow(parameters.direction_change_penalty_factor, direction_changes);
        new_score *= std::pow(parameters.curve_penalty_factor, curve_segment_count);

        return new_score;
    }

    float calcScore2(const Cones &cones, const EigenVector &cone_positions, const EigenVector &last_path) {
        int left_cones = 0;
        int left_blue = 0;
        int left_yellow = 0;
        int right_cones = 0;
        int right_blue = 0;
        int right_yellow = 0;
        float new_score = 0;

        for (size_t i = 0; i < cones.size(); i++) {
            auto cone_position = cone_positions[i];
            float sq_dist = (cone_position - (position + direction * link_length)).squaredNorm();
            float dist = std::sqrt(sq_dist);

            if (dist < parameters.cone_check_distance) {
                // find the closest cone on either side
                float perp_dist = calc_perpendicular_distance(position, direction, cone_position);
                if (perp_dist > parameters.cone_min_perpendicular_distance &&
                    perp_dist < 2) {
                    if (is_on_left_side(position, direction, cone_position)) {
                        left_cones++;
                        if (cones[i].rgba == hphlib::REF_COLOR_BLUE)
                            left_blue++;
                        else if (cones[i].rgba == hphlib::REF_COLOR_YELLOW)
                            left_yellow++;
                    } else {
                        right_cones++;
                        if (cones[i].rgba == hphlib::REF_COLOR_YELLOW)
                            right_yellow++;
                        else if (cones[i].rgba == hphlib::REF_COLOR_BLUE)
                            right_blue++;
                    }
                }
            }

            // check if closer than 1.5m. if it is we should check for direct collision
            if (sq_dist < parameters.collision_check_distance * parameters.collision_check_distance) {
                if (intersects_circle(position,
                                      direction * parameters.collision_check_distance,
                                      cone_position,
                                      parameters.collision_check_radius)) {
                    has_collision = true;
                    break;
                }
            }
        }

        (void) last_path;
        if (has_collision) {
            // set infinity score too avoid further processing
            new_score = std::numeric_limits<float>::infinity();
        } else {
            if (left_blue + right_yellow - (left_yellow + right_blue) * parameters.wrong_cones_penalty_factor > 0)
                new_score = 1.0f / (left_blue + right_yellow - (left_yellow + right_blue) * parameters.wrong_cones_penalty_factor);
            else
                new_score = parameters.growth_score_threshold - 1;
        }

        new_score *= std::pow(parameters.direction_change_penalty_factor, direction_changes);
        new_score *= std::pow(parameters.curve_penalty_factor, curve_segment_count);

        return new_score;
    }

    void updateScore(const Cones &cones, const EigenVector &cone_positions, const EigenVector &last_path) {
        bool change_from_left_to_right = (parent ? parent->rotation == RotationDirection::Left && rotation == RotationDirection::Right : false);
        bool change_from_right_to_left = (parent ? parent->rotation == RotationDirection::Right && rotation == RotationDirection::Left : false);
        direction_changes = (parent ? parent->direction_changes + static_cast<int>(change_from_left_to_right) + static_cast<int>(change_from_right_to_left) : 0);
        curve_segment_count = (parent ? parent->curve_segment_count + static_cast<int>(rotation != RotationDirection::Straight) : 0);
        score = (parent ? parent->score : 0) + calcScore2(cones, cone_positions, last_path);
        normalized_score = score / depth;
    };

    std::pair<EigenVector, float> calcBestPath() {
        std::pair<EigenVector, float> best_path;
        best_path.second = std::numeric_limits<float>::infinity();

        // collect the best path from our children recursively
        for (auto &child: children) {
            auto path = child.calcBestPath();
            if (path.second < best_path.second && path.first.size () >= best_path.first.size()) {
                best_path = path;
            }
        }

        if (best_path.first.empty()) {
            // no children. set our normalized score as path score
            best_path.second = normalized_score;
        }

        best_path.first.insert(best_path.first.begin(), position + direction * parameters.link_length);

        return best_path;
    };

    void calcMinMaxScore(float &min, float &max) {
        min = std::min(min, normalized_score);
        max = std::max(max, normalized_score);

        for (auto &child: children) {
            child.calcMinMaxScore(min, max);
        }
    }

    void grow(TreeNode *parent, const Cones &cones, const EigenVector &cone_positions,  const EigenVector &last_path, float current_velocity) {
        this->parent = parent;
        if (!parent) {
            depth = 1;
            link_length = parameters.link_length;
            if (parameters.scale_with_velocity) {
                link_length = std::max(link_length, link_length * current_velocity);
            }
        } else {
            depth = parent->depth + 1;
            link_length = parent->link_length;
        }

        updateScore(cones, cone_positions, last_path);

        if (depth >= parameters.link_count)
            return;

        if (normalized_score < parameters.growth_score_threshold && !has_collision) {
            for (int i = 0; i < 3; i++) {
                children.emplace_back();
                children.back().position = position + (direction * link_length);
                children.back().direction = Eigen::Rotation2Df((i-1) * parameters.angle_increment_rad).toRotationMatrix() * direction;
                children.back().rotation = static_cast<RotationDirection>(i);
                children.back().grow(this, cones, cone_positions, last_path, current_velocity);
            }
        }
    };

    void visualize(visualization_msgs::Marker &lines, visualization_msgs::Marker &points, float min_score, float max_score) {
        geometry_msgs::Point start, end;
        Eigen::Vector2f endv = position + direction * link_length;
        tf::pointEigenToMsg(Eigen::Vector3d(position.x(), position.y(), 0), start);
        tf::pointEigenToMsg(Eigen::Vector3d(endv.x(), endv.y(), 0), end);

        lines.points.push_back(start);
        lines.points.push_back(end);

        std_msgs::ColorRGBA color;
        color.a = 1;

        if (parameters.color_mode == RandomTreeColorMode::State) {
            if (has_collision) {
                color.r = 1;
            } else if (wrong_color) {
                color.b = 1;
            } else {
                color.g = 1;
            }
        } else {
            float alpha = normalized_score / parameters.growth_score_threshold;

            color.r = alpha;
            color.g = 1 - alpha;
        }


        lines.colors.push_back(color);
        lines.colors.push_back(color);

        if (normalized_score < VIS_POINT_SCORE) {
            points.points.push_back(end);
        }

        for (auto &child: children) {
            child.visualize(lines, points, min_score, max_score);
        }
    }
};

class RandomTree {
private:
    ros::Subscriber cones_sub_;
    ros::Subscriber odo_sub_;
    ros::Publisher path_pub_;
    ros::Publisher marker_pub_;

    visualization_msgs::Marker marker_lines;
    visualization_msgs::Marker marker_best_path;
    visualization_msgs::Marker marker_points;

    std::vector<TreeNode> roots;

    EigenVector path;

    hphlib::TrackSpline path_spline;

    std::vector<hphlib::TrackSpline> previous_path_splines;
    float path_spline_count = 1;
    float current_velocity = 0;

    void initRoots();
    void findBestPath();
    void updatePathAverage();

    void pointCloudCallback(Cones cloud);
    void odometryCallback(nav_msgs::Odometry odometry);

public:
    RandomTree(ros::NodeHandle &n);
};