#pragma once
#include <nav_msgs/Path.h>
#include "utility.h"

class PathFollowing {

public:
    PathFollowing() = default;


    float calcSteeringAngleSeek(nav_msgs::Path path_, float velocity);

    float calcSteeringAnglePathFollowing(nav_msgs::Path path_, float velocity);
};


