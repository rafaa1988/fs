#pragma once

class Controller {
private:
    // distance from CG to the front axis
    float lf;
    // distance from CG to the rear axis
    float lr;

    // factor for proportional term
    float pk1;
    // factor for derivative term
    float pk2;
public:
    Controller(float lf, float lr, float pk1, float pk2) : lf(lf), lr(lr), pk1(pk1), pk2(pk2) {};

    float calc(float kappa, float dq, float dqd);
};
