#include <eigen_conversions/eigen_msg.h>
#include <tf/transform_datatypes.h>
#include "Markers.h"

Markers::Markers(ros::NodeHandle n)
    : pub_(n.advertise<visualization_msgs::MarkerArray>("visualization_marker_array", 0))
{
    marker_position_on_track.header.frame_id = "map";
    marker_position_on_track.ns = "global_driver";
    marker_position_on_track.id = 0;
    marker_position_on_track.type = visualization_msgs::Marker::CYLINDER;
    marker_position_on_track.action = visualization_msgs::Marker::ADD;
    marker_position_on_track.pose.orientation.w = 1.0;
    marker_position_on_track.scale.x = 0.2f;
    marker_position_on_track.scale.y = 0.2f;
    marker_position_on_track.scale.z = 0.1f;
    marker_position_on_track.color.g = 1.0f;
    marker_position_on_track.color.a = 1.0f;

    marker_vel_pos_on_track = marker_position_on_track;
    marker_vel_pos_on_track.id = 3;
    marker_vel_pos_on_track.color.b = 1.0f;

    marker_distance_to_vehicle = marker_position_on_track;
    marker_distance_to_vehicle.id = 1;
    marker_distance_to_vehicle.type = visualization_msgs::Marker::LINE_LIST;
    marker_distance_to_vehicle.scale.x = 0.1f;
    marker_distance_to_vehicle.color.r = 0.0f;
    marker_distance_to_vehicle.color.g = 0.0f;
    marker_distance_to_vehicle.color.b = 1.0f;
    marker_distance_to_vehicle.color.a = 1.0f;

    marker_steering_angle = marker_position_on_track;
    marker_steering_angle.header.frame_id = "base_link";
    marker_steering_angle.id = 2;
    marker_steering_angle.type = visualization_msgs::Marker::ARROW;
    marker_steering_angle.scale.x = 2.0f;
    marker_steering_angle.scale.y = 0.2f;
    marker_steering_angle.color.r = 1.0f;
    marker_steering_angle.color.g = 0.0f;
    marker_steering_angle.color.b = 0.0f;
    marker_steering_angle.color.a = 1.0f;
}

void Markers::setPositionOnTrack(const Eigen::Vector2f &p) {
    position = p;
}

void Markers::setVelocityCheckPoint(const Eigen::Vector2f &p) {
    velocity_position = p;
}

void Markers::setDistanceToVehicle(const Eigen::Vector2f &direction) {
    this->direction = direction;
}

void Markers::setSteeringAngle(float angle) {
    steering_angle = angle;
}

void Markers::publish() {
    visualization_msgs::MarkerArray array;
    geometry_msgs::Point point;

    tf::pointEigenToMsg(Eigen::Vector3d(velocity_position.x(), velocity_position.y(), 0), point);
    marker_vel_pos_on_track.pose.position = point;

    tf::pointEigenToMsg(Eigen::Vector3d(position.x(), position.y(), 0), point);
    marker_position_on_track.pose.position = point;


    marker_distance_to_vehicle.points.clear();
    marker_distance_to_vehicle.points.push_back(point);

    tf::pointEigenToMsg(Eigen::Vector3d(position.x() + direction.x(), position.y() + direction.y(), 0), point);
    marker_distance_to_vehicle.points.push_back(point);

    marker_steering_angle.pose.orientation = tf::createQuaternionMsgFromYaw(-steering_angle);

    array.markers.push_back(marker_position_on_track);
    array.markers.push_back(marker_vel_pos_on_track);
    array.markers.push_back(marker_distance_to_vehicle);
    array.markers.push_back(marker_steering_angle);

    pub_.publish(array);
}


