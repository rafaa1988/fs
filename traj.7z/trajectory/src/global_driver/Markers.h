#pragma once

#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

#include <eigen3/Eigen/Eigen>

class Markers {
private:
    ros::Publisher pub_;

    visualization_msgs::Marker marker_position_on_track;
    visualization_msgs::Marker marker_vel_pos_on_track;
    visualization_msgs::Marker marker_distance_to_vehicle;
    visualization_msgs::Marker marker_steering_angle;

    Eigen::Vector2f position;
    Eigen::Vector2f velocity_position;
    Eigen::Vector2f direction;
    float steering_angle;
public:
    explicit Markers(ros::NodeHandle n);

    void setPositionOnTrack(const Eigen::Vector2f &p);
    void setVelocityCheckPoint(const Eigen::Vector2f &p);
    void setDistanceToVehicle(const Eigen::Vector2f &direction);
    void setSteeringAngle(float angle);
    void publish();
};