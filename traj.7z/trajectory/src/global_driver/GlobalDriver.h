#pragma once

#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>

#include <hphlib/Lap.h>

#include "Controller.h"
#include "Markers.h"
#include "track_providers/TrackProvider.h"

/**
 * A global track driving controller
 * Largely based on reasearch found in https://d-nb.info/997159340/34
 * [Querregelung eines Versuchsfahrzeugs entlang vorgegebener Bahnen] Steefen Kehl
 */
class GlobalDriver {
private:
    ros::NodeHandle &node_handle;
    ros::Subscriber odometry_sub_;
    ros::Subscriber lap_counter_sub_;
    ros::Publisher smoothed_midway_pub_;
    ros::Publisher control_pub_;

    TrackParameters track_parameters;
    float velocity_lookahead_time;
    float min_velocity;
    float max_velocity;
    float min_turn_radius;
    float max_turn_radius;
    std::string mission;
    int lap_count;

    Controller controller;

    std::unique_ptr<TrackProvider> track_provider = nullptr;

    Markers markers;

    int current_lap = 0;

    ros::Timer drive_line_publish_timer;

    size_t last_location_on_track = std::numeric_limits<size_t>::max();

    void odometryCallback(nav_msgs::Odometry odometry);
    void lapCallback(hphlib::Lap lap);

    void initialize();

    /**
     * Publish the desired control
     * @param angle Angle in radians
     */
    void publishControl(float velocity, float angle, bool finished);
    void publishDriveLine();
public:
    GlobalDriver(ros::NodeHandle &n);
};