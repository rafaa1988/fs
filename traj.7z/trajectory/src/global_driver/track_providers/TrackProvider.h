#pragma once

#include <functional>

#include <hphlib/misc/spline/TrackSpline.h>

#include "../TrackParameters.h"

class TrackProvider {
protected:
    const TrackParameters track_parameters;
    const std::function<void()> path_ready_callback;

public:
    hphlib::TrackSpline track;

    TrackProvider(const TrackParameters parameters, std::function<void()> ready_callback)
            : track_parameters(parameters), path_ready_callback(ready_callback)
    {}

    virtual ~TrackProvider() = default;
};