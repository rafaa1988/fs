
#include <hphlib/misc/map/Map.h>
#include <hphlib/misc/map/MapLoader.h>
#include "SkidPadTP.h"

SkidPadTP::SkidPadTP(const TrackParameters parameters, const std::function<void()> &ready_callback)
    : TrackProvider(parameters, ready_callback)
{
    boost::optional<hphlib::Map> map = hphlib::MapLoader::load("skidpad.json");

    if (map) {
        std::cout << "Skidpad map loaded" << std::endl;
        track.fit(track_parameters.alpha, track_parameters.beta, track_parameters.gamma,
                  track_parameters.track_sampling_distance, track_parameters.internal_knot_weight,
                  track_parameters.spline_sampling_distance, false, map->drive_line);
        track.calculateOrientationAndCurvature();

        std::cout << "Track fitted" << std::endl;
        path_ready_callback();
    }
}
