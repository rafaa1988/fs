#include <hphlib/util.h>

#include "TrackdriveTP.h"

TrackdriveTP::TrackdriveTP(ros::NodeHandle &n, const TrackParameters parameters, const std::function<void()> &ready_callback)
    : TrackProvider(parameters, ready_callback)
{

    std::string topic_midway = "/slam/midway";
    if (getOptionalRosParam<std::string>(n, "topic_midway"))
        topic_midway = *getOptionalRosParam<std::string>(n, "topic_midway");

    midway_sub_ = n.subscribe(topic_midway, 1, &TrackdriveTP::midwayCallback, this);
}


void TrackdriveTP::midwayCallback(nav_msgs::Path midway) {
    ROS_INFO_STREAM("Midway received");
    track.fit(track_parameters.alpha, track_parameters.beta, track_parameters.gamma,
              track_parameters.track_sampling_distance, track_parameters.internal_knot_weight,
              track_parameters.spline_sampling_distance, true, midway);
    track.calculateOrientationAndCurvature();

    ROS_INFO_STREAM("Track fitted");

    midway_sub_.shutdown();
    path_ready_callback();
}