#pragma once

#include <ros/ros.h>
#include "TrackProvider.h"

class TrackdriveTP : public TrackProvider {
private:
    ros::Subscriber midway_sub_;

    void midwayCallback(nav_msgs::Path midway);
public:
    TrackdriveTP(ros::NodeHandle &n, const TrackParameters parameters, const std::function<void()> &ready_callback);

    TrackdriveTP(const TrackdriveTP& that) = delete;
    TrackdriveTP& operator=(const TrackdriveTP& that) = delete;
};