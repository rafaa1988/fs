#pragma once

#include "TrackProvider.h"

class SkidPadTP : public TrackProvider
{
public:
    SkidPadTP(const TrackParameters parameters, const std::function<void()> &ready_callback);
};