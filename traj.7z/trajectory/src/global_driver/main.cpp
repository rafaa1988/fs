#include <ros/ros.h>
#include <hphlib/util.h>
#include <pcl_ros/point_cloud.h>
#include <hphlib/vehicle/StatusMonitor.h>

#include "GlobalDriver.h"


int main(int argc, char** argv) {
    ros::init(argc, argv, "global_driver");
    ros::NodeHandle n("~");
    hphlib::vehicle::StatusMonitor vehicle_mon(n);
    std::unique_ptr<GlobalDriver> driver(std::make_unique<GlobalDriver>(n));

    // register vehicle status callbacks to reset the driver model (brute force style)
    vehicle_mon.set_ready_callback([&] () {
        driver = std::make_unique<GlobalDriver>(n);
    });

    ros::spin();
}
