#pragma once

struct TrackParameters {
    float alpha;
    float beta;
    float gamma;
    float track_sampling_distance;
    float internal_knot_weight;
    float spline_sampling_distance;

    TrackParameters(float alpha, float beta, float gamma, float sampling_dist, float knot_weight, float spline_sampling_dist)
            : alpha(alpha), beta(beta), gamma(gamma), track_sampling_distance(sampling_dist),
              internal_knot_weight(knot_weight), spline_sampling_distance(spline_sampling_dist)
    {}

    TrackParameters(const TrackParameters& that) = default;
};