#include <cmath>
#include "Controller.h"

// implemented as suggested in https://d-nb.info/997159340/34
float Controller::calc(float kappa, float dq, float dqd) {
    // inversion based pre control based on track curvature
    float dff = -std::atan((lf + lr) * kappa * std::sqrt(1.0f - lr * lr * kappa * kappa));

    float dfb = pk1 * dq + pk2 * dqd;

    return dff + dfb;
}
