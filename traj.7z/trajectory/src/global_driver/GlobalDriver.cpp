#include <tf/transform_datatypes.h>
#include <eigen_conversions/eigen_msg.h>

#include <hphlib/util.h>
#include <hphlib/Control.h>
#include <hphlib/misc/map/Map.h>
#include <hphlib/misc/map/MapLoader.h>
#include <hphlib/eigen.h>

#include "GlobalDriver.h"
#include "track_providers/SkidPadTP.h"
#include "track_providers/TrackdriveTP.h"

using namespace Eigen;
using namespace hphlib;

GlobalDriver::GlobalDriver(ros::NodeHandle &n)
    : node_handle(n)
    , lap_counter_sub_(n.subscribe("/laps", 1, &GlobalDriver::lapCallback, this))
    , smoothed_midway_pub_(n.advertise<nav_msgs::Path>(getRequiredRosParam<std::string>(n, "topic_midway_out"), 1))
    , control_pub_(n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "topic_control"), 1))
    , track_parameters(getRequiredRosParam<double, float>(n, "spline_first_derivative_factor"),
                       getRequiredRosParam<double, float>(n, "spline_second_derivative_factor"),
                       getRequiredRosParam<double, float>(n, "spline_third_derivative_factor"),
                       getRequiredRosParam<double, float>(n, "track_sampling_distance"),
                       getRequiredRosParam<double, float>(n, "internal_knot_weight"),
                       getRequiredRosParam<double, float>(n, "spline_sampling_distance"))
    , velocity_lookahead_time(getRequiredRosParam<double, float>(n, "velocity_lookahead_time"))
    , min_velocity(getRequiredRosParam<double, float>(n, "min_velocity") / 3.6f)
    , max_velocity(getRequiredRosParam<double, float>(n, "max_velocity") / 3.6f)
    , min_turn_radius(getRequiredRosParam<double, float>(n, "min_turn_radius"))
    , max_turn_radius(getRequiredRosParam<double, float>(n, "max_turn_radius"))
    , mission(getRequiredRosParam<std::string>(n, "mission"))
    , lap_count(0)
    , controller(Controller(getRequiredRosParam<double, float>(n, "front_axis_distance"),
                            getRequiredRosParam<double, float>(n, "rear_axis_distance"),
                            getRequiredRosParam<double, float>(n, "controller_p_factor"),
                            getRequiredRosParam<double, float>(n, "controller_d_factor")))
    , markers(n)
{
    if (mission == "trackdrive") {
        track_provider = std::make_unique<TrackdriveTP>(n, track_parameters, [&] () {
            initialize();
        });
        n.getParam("/trackdrive_lap_count", lap_count);
        std::cout << lap_count << std::endl;

    } else if (mission == "skidpad") {
        track_provider = std::make_unique<SkidPadTP>(track_parameters, [&]() {
            initialize();
        });
    }
}

void GlobalDriver::odometryCallback(nav_msgs::Odometry odometry) {
    // get vehicle position
    Vector2f pv = Vector2f(odometry.pose.pose.position.x, odometry.pose.pose.position.y);
    Vector2f vv = Vector2f(odometry.twist.twist.linear.x, odometry.twist.twist.linear.y);

    // only allow the search to look 20 * h before and after the last position
    size_t start_idx = circular_mod(static_cast<int>(last_location_on_track - 20), track_provider->track.size());
    size_t end_idx = last_location_on_track + 20;
    if (last_location_on_track == std::numeric_limits<size_t>::max()) {
        // we did not locate us once on the track. set start to 0 and end to max
        start_idx = 0;
        end_idx = track_provider->track.size();
    }

    // find closest point on trajectory
    // currently we do this iteratively. we should consider smarter approach
    float dist = std::numeric_limits<float>::max();
    size_t idx = 0;
    for (size_t i = start_idx; i < end_idx; i++) {
        float d = (pv - track_provider->track.p(i % track_provider->track.size())).squaredNorm();
        if (d < dist) {
            idx = i;
            dist = d;
        }
    }

    last_location_on_track = idx;
    // advance the position a tiny bit to slightly look ahead
    idx = (idx + 1) % track_provider->track.size();

    Quaterniond rotation;
    tf::quaternionMsgToEigen(odometry.pose.pose.orientation, rotation);
    Vector3d head_vec3 = rotation.toRotationMatrix() * Vector3d(1, 0, 0);
    Vector2f head_vec(head_vec3.x(), head_vec3.y());

    float dq = track_provider->track.thetaAngle().block<1,2>(idx, 0) * (pv - track_provider->track.p(idx));
    float dqd = -vv.norm() * std::sin(track_provider->track.theta()(idx) - std::atan2(head_vec.y(), head_vec.x()));

    float steering_angle = controller.calc(track_provider->track.kappa()(idx), dq, dqd);

    // calculate the desired velocity based on the current velocity
    size_t velocity_idx = (idx + static_cast<size_t>(vv.norm() * velocity_lookahead_time /
                                                     track_parameters.spline_sampling_distance)) % track_provider->track.size();

    // curvature of track is 1 / (turn radius).
    // we should aim for maximum speed if kappa < epsilon and low speed in turns
    // we assume that the minimum radius is 3m (taken from the FSG rules)
    float turn_radius = std::abs(1 / track_provider->track.kappa()(velocity_idx));
    // TODO replace linear mapping with something that tries to maximize the lateral force and also takes the steering speed into account
    float velocity = min_velocity + (max_velocity - min_velocity) * (turn_radius - min_turn_radius) / (max_turn_radius - min_turn_radius);

    velocity = clamp(velocity, min_velocity, max_velocity);

    bool finished = false;
    if (mission == "trackdrive") {
        if (current_lap >= lap_count) {
            finished = true;
        }
    }

    publishControl(velocity, steering_angle, finished);

    markers.setPositionOnTrack(track_provider->track.p(idx));
    markers.setVelocityCheckPoint(track_provider->track.p(velocity_idx));
    markers.setDistanceToVehicle(track_provider->track.thetaAngle().block<1,2>(idx, 0) * dq);
    markers.setSteeringAngle(steering_angle);
    markers.publish();
}

void GlobalDriver::lapCallback(hphlib::Lap lap) {
    current_lap = lap.current_lap;
}

void GlobalDriver::publishControl(float velocity, float angle, bool finished) {
    hphlib::Control control;

    control.header.stamp = ros::Time::now();
    control.steering_angle = angle / M_PI * 180.0f;
    control.target_velocity = velocity;
    control.finish_mission = finished;

    control_pub_.publish(control);
}

void GlobalDriver::initialize() {
    // publish drive line after waiting for 1 second
    auto cb = [this](auto &_) { (void)_; this->publishDriveLine(); };

    drive_line_publish_timer = node_handle.createTimer(ros::Duration(1.0f), cb, true);

    odometry_sub_ = node_handle.subscribe("/odometry/map_filtered", 1, &GlobalDriver::odometryCallback, this);
}

void GlobalDriver::publishDriveLine() {
    nav_msgs::Path smoothed_midway;
    smoothed_midway.poses.reserve(track_provider->track.size() + 1);

    size_t end = track_provider->track.size();

    if (mission != "trackdrive")
        end--;

    for (size_t i = 0; i <= end; i++) {
        Vector2f p = track_provider->track.p(i % track_provider->track.size());
        geometry_msgs::PoseStamped pose;
        pose.pose.position.x = p.x();
        pose.pose.position.y = p.y();
        pose.pose.orientation = tf::createQuaternionMsgFromYaw(0);
        smoothed_midway.poses.push_back(pose);
    }

    smoothed_midway.header.stamp = ros::Time::now();
    smoothed_midway.header.frame_id = "map";

    smoothed_midway_pub_.publish(smoothed_midway);
}
