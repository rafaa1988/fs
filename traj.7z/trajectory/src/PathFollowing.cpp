//
// Created by horsepower on 20.04.18.
//

#include "PathFollowing.h"

/**
 * using the SEEK method (https://www.red3d.com/cwr/steer)
 * @param path_
 * @param velocity
 * @return
 */
float PathFollowing::calcSteeringAngleSeek(nav_msgs::Path path_, float velocity) {

    //assert path has always at least two nodes
    if (path_.poses.size() < 2) {
        return 0.0f;
    }
    //std::cout << stampedPoseToEigen(path_.poses[1]) << std::endl;
    //assert(path_.poses.size() >= 2);

    //future location. add 1m/s compensate for standing vehicle

    Eigen::Vector3f forwardVelocity = Eigen::Vector3f(1.0f + velocity, 0, 0);
    Eigen::Vector3f desired = stampedPoseToEigen(path_.poses.at(1));

    if (desired[1] < 0) {
        return angleBetweenVectors(forwardVelocity, desired) * RAD_2_DEG;
    } else {
        return -angleBetweenVectors(forwardVelocity, desired) * RAD_2_DEG;
    }

//
//    desired.normalize();
//    desired *= (2.0f+2.0f); //max speed
//
//    Eigen::Vector3f force = desired - forwardVelocity;
//
//    if (force[1] < 0) {
//        return angleBetweenVectors(forwardVelocity, force) * RAD_2_DEG;
//    } else {
//        return -angleBetweenVectors(forwardVelocity, force) * RAD_2_DEG;
//    }

}

/**
 * Using Path Following method (https://www.red3d.com/cwr/steer)
 * @param path_
 * @param velocity
 * @return
 */
float PathFollowing::calcSteeringAnglePathFollowing(nav_msgs::Path path_, float velocity) {
    Eigen::Vector3f futureLocation(velocity, 0, 0);
    Eigen::Vector3f closestPathSegment(0,0,0);
    Eigen::Vector3f closestPoint(0,0,0);

    float minDistance = std::numeric_limits<float>::max();

    //calc min distance to path
    for (size_t i = 1; i < path_.poses.size(); ++i) {
        Eigen::Vector3f beginning = stampedPoseToEigen(path_.poses[i-1]);
        Eigen::Vector3f end = stampedPoseToEigen(path_.poses[i]);
        Eigen::Vector3f lineSegment = end - beginning;

        //scalar projection
        Eigen::Vector3f beginningToFutureLocation = (futureLocation - beginning);
        float angle = angleBetweenVectors(beginningToFutureLocation, lineSegment);
        float distance = beginningToFutureLocation.norm() * std::cos(angle);

        if (distance < minDistance) {
            minDistance = distance;
            closestPathSegment = lineSegment;
            closestPoint = lineSegment.normalized() * std::cos(angle) * beginningToFutureLocation.norm();
        }
    }

    // if future location is near the path, do nothing
    const float PATH_RADIUS = 0.2f;
    const float MAX_SPEED = 2.0f;

    if (minDistance <= PATH_RADIUS) {
        return 0.0f;
    }

    //move along path a little bit (1 meter)
    Eigen::Vector3f target = closestPoint + 1.0f * closestPathSegment.normalized();
    std::cout << target << std::endl;

    //seek the target
    Eigen::Vector3f forwardVelocity = Eigen::Vector3f(1.0f + velocity, 0, 0);
    Eigen::Vector3f desired = target.normalized() * MAX_SPEED;
    Eigen::Vector3f force = desired - forwardVelocity;

    if (force[1] < 0) {
        return angleBetweenVectors(forwardVelocity, force) * RAD_2_DEG;
    } else {
        return -angleBetweenVectors(forwardVelocity, force) * RAD_2_DEG;
    }
}