//
// Created by niclas on 29.05.18.
//

#include "Converter.h"

constexpr float MAX_DISTANCE = 15.0f;

void drawPointOnTopdownImg(cv::Mat& topdownImg, cv::Point3d pt, float distance, uint32_t color, int resolution) {

    int radius = static_cast<int>(resolution * 0.5);

    // Discard if maximum distance to camera exceeded
    if (distance > MAX_DISTANCE) {
        return;
    }

    pt.y += MAX_DISTANCE;
    pt *= resolution;

    cv::Point pixelCoords = cv::Point(static_cast<int>(std::round(pt.x)), static_cast<int>(std::round(pt.y)));

    if (hphlib::sameRgb(color, hphlib::REF_COLOR_BLUE)) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(255, 0, 0), CV_FILLED);
    } else if (hphlib::sameRgb(color, hphlib::REF_COLOR_YELLOW)) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 255, 255), CV_FILLED);
    } else if (hphlib::sameRgb(color, hphlib::REF_COLOR_RED)) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 0, 255), CV_FILLED);
    } else if (hphlib::sameRgb(color, hphlib::REF_COLOR_FINISH)) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 255, 0), CV_FILLED);
    }

    // draw car (approx. 1.2m wide and 2.4m long)
    cv::Point carStart(0, static_cast<int>(resolution * MAX_DISTANCE) - static_cast<int>(resolution * 0.6));
    cv::Point carEnd(static_cast<int>(resolution * 0.6), static_cast<int>(resolution * MAX_DISTANCE) + static_cast<int>(resolution * 0.6));
    cv::rectangle(topdownImg, carStart, carEnd, cv::Scalar(255, 255, 255), CV_FILLED);
}


cv::Mat Converter::topdownImageFromPointCloud(const pcl::PointCloud<pcl::PointXYZRGB>& pointcloud) {

    const int resolution = 10;
    auto topdownImg = cv::Mat(static_cast<int>(2 * resolution * MAX_DISTANCE), static_cast<int>(resolution * MAX_DISTANCE), CV_8UC3, cv::Scalar(0, 0, 0));

    for (const auto& pt : pointcloud) {
        float distance = std::sqrt((pt.x * pt.x) + (pt.y * pt.y) + (pt.z * pt.z));
        drawPointOnTopdownImg(topdownImg, cv::Point3d(pt.x, pt.y, pt.z), distance, pt.rgba, resolution);
    }

    return topdownImg;

}
