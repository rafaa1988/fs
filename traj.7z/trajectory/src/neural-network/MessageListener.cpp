#include <ros/ros.h>
#include <pcl_ros/transforms.h>
#include <hphlib/pcl.h>
#include <hphlib/Control.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/OccupancyGrid.h>
#include <opencv2/opencv.hpp>
#include "MessageListener.h"
#include <std_msgs/Float32.h>
#include <hphlib/util.h>
#include "../utility.h"
#include "../PathFollowing.h"
#include "KerasClassifier.h"
#include "Converter.h"
#include <Eigen/Core>
#include <hphlib/util.h>

MessageListener::MessageListener(ros::NodeHandle& n) : runner_("trajectory-nn"), externalClassifier(n),
                                                       gain_factor(getRequiredRosParam<float>(n, "gain_factor")),
                                                       max_velocity(getRequiredRosParam<double, float>(n, "max_velocity_kph") / 3.6f),
                                                       min_velocity(getRequiredRosParam<double, float>(n, "min_velocity_kph") / 3.6f)
{
    control_publisher_ = n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "topic_control"), 1);
    marker_publisher_ = n.advertise<visualization_msgs::Marker>("marker_current", 1);
    reset_publisher_ = n.advertise<std_msgs::Empty>("/sim/reset", 1);
}

void angleToMarker(float angle, float x_scale, visualization_msgs::Marker& marker) {

    marker.header.stamp = ros::Time::now();
    marker.header.frame_id = "base_link";

    marker.scale.x = x_scale * 2;
    marker.scale.y = 0.2;
    marker.scale.z = 0.1;

    marker.color.r = 1.0;
    marker.color.a = 1.0;

    marker.pose.orientation = tf::createQuaternionMsgFromYaw(angle);
}

void MessageListener::pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg) {

    hphlib::Control control{};
    control.header.stamp = ros::Time::now();

    cv::Mat topdown = conv.topdownImageFromPointCloud((*msg));

    float angle_prediction = 0.0f;
    float speed_prediction = 0.0f;
    bool reset = false;

    try {
        runner_.reportProcessingTime([&] () {
            angle_prediction = externalClassifier.classify_image(topdown).steering_angle;
            speed_prediction = externalClassifier.classify_image(topdown).cruise_speed;
            reset = externalClassifier.classify_image(topdown).reset;
        });
    } catch (std::system_error& error1) {
        std::cout << error1.what() << std::endl;
    }

    angle_prediction = -30.0f + (angle_prediction / 100.0f);
    speed_prediction = (speed_prediction / 100.0f)  * max_velocity ;

    control.steering_angle = hphlib::clamp(angle_prediction, -30.0f, 30.0f);
    control.target_velocity = hphlib::clamp(speed_prediction, min_velocity, max_velocity);


    // linear mapping of velocity to steering_angle
    //float velocity_multiplier = hphlib::clamp((1.0f - std::abs(angle_prediction)), 0.0f, 1.0f);
    //control.target_velocity = min_velocity + velocity_multiplier * (max_velocity - min_velocity);

    visualization_msgs::Marker marker;
    angleToMarker(static_cast<float>(control.steering_angle * -DEG_TO_RAD), control.target_velocity,  marker);

    if (reset) {
        reset_publisher_.publish(std_msgs::Empty());
        externalClassifier.cone_hits = 0;
        externalClassifier.current_checkpoint = 0;
    }

    marker_publisher_.publish(marker);
    control_publisher_.publish(control);
}


void MessageListener::eventCallback(const simulation::DrivingEvent::ConstPtr &msg) {

    std::string content = msg->event;

    if (content.find("ConeHitEvent") != std::string::npos) {
        std::cout << "CONE HIT" << std::endl;
        externalClassifier.cone_hits++;
    } else if (content.find("checkpoint") != std::string::npos) {
        std::cout << "CHECKPOINT" << std::endl;
        externalClassifier.current_checkpoint++;
    }

}