#pragma once

#define FDEEP_FLOAT_TYPE double
#include <fdeep/fdeep.hpp>
#include <opencv2/imgproc/imgproc.hpp>

class KerasClassifier {
private:
    fdeep::model model_;

public:
    explicit KerasClassifier(const std::string& path);

    float predict(cv::Mat sub_img);
};
