#pragma once

#include <opencv2/imgproc/imgproc.hpp>
#include <hphlib/PackedEndian.h>
#include <hphlib/misc/RosStreamCapturer.h>
#include <hphlib/io/UnixDomainDatagramSocket.h>
#include <ros/node_handle.h>

struct ControlCommands {
    float steering_angle = 0.0f;
    float cruise_speed = 0.0f;
    bool reset = false;
};


class ExternalKerasClassifier {

private:
    hphlib::UnixDomainDatagramSocket sock_;
    hphlib::UnixDomainDatagramSocket::Endpoint remote_;
    int seq_no_;
    std::vector<uint8_t> out_packet_;
    bool classification_model_;
    bool reinforcement_learning = false;

public:

    explicit ExternalKerasClassifier(ros::NodeHandle& n);

    ControlCommands classify_image(cv::Mat &image);
    ControlCommands classify_image_reinforcement(cv::Mat &image);

    int current_checkpoint = 0;
    int cone_hits = 0;
};