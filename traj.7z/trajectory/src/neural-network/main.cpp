#include <ros/ros.h>
#include <hphlib/util.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include "MessageListener.h"
#include <simulation/DrivingEvent.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "trajectory");
    ros::NodeHandle n("~");

    std::string topic_cones_map = getRequiredRosParam<std::string>(n, "topic_cones_map");
    //std::string topic_path      = getRequiredRosParam<std::string>(n, "topic_path");

    MessageListener listener(n);

    // Message filter?
    auto pointcloud_subscriber = n.subscribe<pcl::PointCloud<pcl::PointXYZRGB>>(
            topic_cones_map,
            1,
            &MessageListener::pointcloudCallback,
            &listener
    );

    auto event_subscriber = n.subscribe<simulation::DrivingEvent>(
            "/sim/driving_events",
            1,
            &MessageListener::eventCallback,
            &listener
    );


    ROS_INFO("Fired up trajectory on %s", topic_cones_map.c_str());
    ros::spin();
}
