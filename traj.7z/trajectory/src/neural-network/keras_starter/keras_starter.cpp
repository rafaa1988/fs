#include <ros/ros.h>
#include <ros/callback_queue.h>
#include <hphlib/os.h>
#include <hphlib/util.h>
#include <boost/filesystem/path.hpp>
#include <hphlib/misc/RosStreamCapturer.h>
#include <csignal>

std::string findLocalPath(const char* sub_path) {
    boost::filesystem::path exec(hphlib::os::getCurrentProcessExecutablePath());

    return (exec.parent_path() / sub_path).string();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "keras starter");
    ros::NodeHandle n("~");

    std::string script_path = findLocalPath("keras_service.py");
    std::string model  = getRequiredRosParam<std::string>(n, "model");
    std::string socket = getRequiredRosParam<std::string>(n, "socket");
    std::string mode = getRequiredRosParam<std::string>(n, "mode");
    float gpu_frac = getRequiredRosParam<float>(n, "gpu_frac");

    const char* args[] = {
            "python3",
            script_path.c_str(),
            socket.c_str(),
            model.c_str(),
            mode.c_str(),
            std::to_string(gpu_frac).c_str(),
            nullptr
    };

    hphlib::RosStreamCapturer capturer;

    pid_t python_pid;

    capturer.capture([&python_pid, args] () {
        python_pid = hphlib::os::execute(
                args[0],
                const_cast<char *const *>(args),
                hphlib::os::ExecuteMode::SearchExecutable
        );
    });

    while (ros::ok()) {
        ros::getGlobalCallbackQueue()->callAvailable(ros::WallDuration(0.1));

        auto exit_code = hphlib::os::checkTerminated(python_pid);

        if (exit_code) {
            ROS_ERROR_STREAM("Child has unexpectedly died with exit code " << *exit_code << ", very sad");
            return *exit_code;
        }
    }

    // ROS was interrupted, kill off that bastardly child
    hphlib::os::signal(python_pid, SIGINT);
    hphlib::os::waitTerminated(python_pid);
}