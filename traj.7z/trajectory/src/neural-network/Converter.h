//
// Created by niclas on 29.05.18.
//
#include <opencv2/imgproc.hpp>
#include <hphlib/pcl.h>

#pragma once

class Converter {

    public:
    cv::Mat topdownImageFromPointCloud(const pcl::PointCloud<pcl::PointXYZRGB>& pointcloud);

};
