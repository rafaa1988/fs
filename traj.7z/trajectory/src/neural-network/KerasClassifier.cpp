#include "KerasClassifier.h"
#include <opencv2/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>

KerasClassifier::KerasClassifier(const std::string &path)
    : model_(fdeep::load_model(path, true)) {}

float KerasClassifier::predict(cv::Mat sub_img) {
    const auto input = fdeep::tensor3_from_bytes(sub_img.ptr(),
                                                 static_cast<size_t>(sub_img.rows),
                                                 static_cast<size_t>(sub_img.cols),
                                                 static_cast<size_t>(sub_img.channels()),
                                                 0.0f,
                                                 1.0f);

    auto pred = model_.predict_class({input});

    auto check_pred = model_.predict({input});
    //std::cout << fdeep::show_tensor3s(check_pred) << std::endl;
    if (check_pred[0].get(pred, 0, 0) < 0.01) {
        std::cout << "ZERO" << std::endl;
        return 0.0f;
    }


    return (static_cast<float>(pred) - 30.0f) / 30.0f;
}
