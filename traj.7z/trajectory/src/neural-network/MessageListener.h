#pragma once

#include <pcl_ros/point_cloud.h>
#include "../search/AStar.h"
#include "../search/ObstacleGrid.h"
#include "KerasClassifier.h"
#include "Converter.h"
#include <nav_msgs/Path.h>
#include <opencv2/opencv.hpp>
#include <visualization_msgs/Marker.h>
#include <telemetry/Runner.h>
#include "ExternalKerasClassifier.h"
#include <simulation/DrivingEvent.h>

class MessageListener {
private:
    telemetry::Runner runner_;

public:

    MessageListener(ros::NodeHandle &n);

    ros::Publisher control_publisher_;
    ros::Publisher marker_publisher_;
    ros::Publisher reset_publisher_;

    ExternalKerasClassifier externalClassifier;

    Converter conv;

    void pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg);
    void eventCallback(const simulation::DrivingEvent::ConstPtr &msg);

    float gain_factor;
    float max_velocity;
    float min_velocity;
};