#include <hphlib/util.h>
#include <hphlib/os.h>
#include <csignal>
#include <boost/filesystem/path.hpp>
#include <hphlib/io/Pipe.h>
#include "ExternalKerasClassifier.h"



template <typename T>
void append_bytes(std::vector<uint8_t>& vec, const T& val) {
    const uint8_t* begin = reinterpret_cast<const uint8_t*>(&val);
    const uint8_t* end = begin + sizeof(val);

    vec.insert(vec.end(), begin, end);
}

ExternalKerasClassifier::ExternalKerasClassifier(ros::NodeHandle &n)
    : sock_(hphlib::UnixDomainDatagramSocket::Endpoint::abstract(getRequiredRosParam<std::string>(n, "keras_local_name").c_str()))
    , remote_(hphlib::UnixDomainDatagramSocket::Endpoint::abstract(getRequiredRosParam<std::string>(n, "keras_remote_name").c_str()))
    , classification_model_(getRequiredRosParam<bool>(n, "classification_model"))
{
    auto reinforce = getOptionalRosParam<bool>(n, "reinforcement_learning");
    if (reinforce.is_initialized() && reinforce.get()) {
        reinforcement_learning = true;
    }
    // Communication should not exceed 1s, server must have died
    sock_.setReceiveTimeoutMs(1000);
}

ControlCommands ExternalKerasClassifier::classify_image(cv::Mat& image) {

    if (reinforcement_learning) {
        return classify_image_reinforcement(image);
    }

    int size_per_image = image.rows * image.cols * 3;
    size_t expected_size = static_cast<size_t>(8 + size_per_image);

    out_packet_.clear();
    out_packet_.reserve(expected_size);
    append_bytes(out_packet_, seq_no_);
    append_bytes(out_packet_, 1);

    out_packet_.insert(out_packet_.end(), image.datastart, image.dataend);

    try {
        sock_.sendTo(out_packet_.data(), out_packet_.size(), remote_);
    } catch (const std::system_error& error) {
        std::cout << error.what() << std::endl;
    }

    // Reserve vector for receiving response packet
    int response_dgram_size;
    if (classification_model_) {
        response_dgram_size = 5;
    } else {
        response_dgram_size = 8;
    }
    std::vector<uint8_t> response_dgram(response_dgram_size, 0);

    try {
        // Receive classifications by external program
        sock_.receive(response_dgram.data(), response_dgram.size());
    } catch (const std::system_error& error) {
        std::cout << error.what() << std::endl;
    }

    // Compare seq no
    int received_seq_no;
    std::memcpy(&received_seq_no, response_dgram.data(), sizeof received_seq_no);
    std::cout << "received packet no " << received_seq_no << std::endl;

    if (received_seq_no != seq_no_) {
        throw std::runtime_error("Sequence number mismatch");
    }

    // Increment sequence number for next communication
    seq_no_++;

    float prediction;
    if (classification_model_) {
        int prediction_class = response_dgram.data()[4];
        std::cout << prediction_class << " -> ";
        prediction = (prediction_class - 30) / 30.0f;
        std::cout << prediction << std::endl;
    } else {
        std::memcpy(&prediction, response_dgram.data() + 4, 4);
    }

    ControlCommands commands {};
    commands.steering_angle = prediction;

    return commands; // float pos
}


ControlCommands ExternalKerasClassifier::classify_image_reinforcement(cv::Mat& image) {
    int size_per_image = image.rows * image.cols * 3;

    // seq_no, quantity, current_checkpoint, cone_hits
    size_t expected_size = static_cast<size_t>(4 + 4 + 4 + 4 + size_per_image);

    out_packet_.clear();
    out_packet_.reserve(expected_size);
    append_bytes(out_packet_, seq_no_);
    append_bytes(out_packet_, 1);
    append_bytes(out_packet_, current_checkpoint);
    append_bytes(out_packet_, cone_hits);

    out_packet_.insert(out_packet_.end(), image.datastart, image.dataend);

    sock_.sendTo(out_packet_.data(), out_packet_.size(), remote_);

    // Reserve vector for receiving response packet
    int response_dgram_size;

    //seq_no, angle, speed, reset_flag
    response_dgram_size = 4 + 4 + 4 + 1;

    std::vector<uint8_t> response_dgram(response_dgram_size, 0);

    // Receive classifications by external program
    sock_.receive(response_dgram.data(), response_dgram.size());

    // Compare seq no
    int received_seq_no;
    std::memcpy(&received_seq_no, response_dgram.data(), sizeof received_seq_no);

    if (received_seq_no != seq_no_) {
        throw std::runtime_error("Sequence number mismatch");
    }

    // Increment sequence number for next communication
    seq_no_++;

    int angle;
    int speed;
    bool reset_flag;

    std::memcpy(&angle, response_dgram.data() + 4, 4);
    std::memcpy(&speed, response_dgram.data() + 8, 4);
    std::memcpy(&reset_flag, response_dgram.data() + 12, 1);

    //std::cout << "angle: " << angle << std::endl;
    //std::cout << "speed: " << speed << std::endl;
    //std::cout << "reset_flag: " << reset_flag << std::endl;

    ControlCommands commands{};
    commands.steering_angle = angle;
    commands.cruise_speed = speed;
    commands.reset = reset_flag;

    return commands;
}