#include <ros/ros.h>
#include <hphlib/util.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include "MessageListener.h"

void run_main(ros::NodeHandle& n) {
    MessageListener listener(n);

    ROS_INFO("Fired up legacy trajectory");
    ros::spin();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "trajectory");
    ros::NodeHandle n("~");

#ifdef NDEBUG
    try {
#endif
        run_main(n);
#ifdef NDEBUG
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }
#endif
}
