#include <ros/ros.h>
#include <pcl_ros/transforms.h>
#include <hphlib/pcl.h>
#include <hphlib/util.h>
#include "MessageListener.h"

/**
 * Initial offset in meters for boundary search from center of car
 */
constexpr float BOUNDARY_Y_OFFSET = 2.0f;

MessageListener::MessageListener(ros::NodeHandle& n)
    : map_subscriber_(n.subscribe<pcl::PointCloud<pcl::PointXYZRGB>>(getRequiredRosParam<std::string>(n, "topic_input"), 1, &MessageListener::pointcloudCallback, this))
    , center_line_publisher_(n.advertise<nav_msgs::Path>(getRequiredRosParam<std::string>(n, "topic_output"), 1))
    , left_bound_publisher_(n.advertise<nav_msgs::Path>("left", 1))
    , right_bound_publisher_(n.advertise<nav_msgs::Path>("right", 1))
    , alg_maximum_boundary_jump_squared_(std::pow(getRequiredRosParam<float>(n, "alg_maximum_boundary_jump"), 2.0f))
    , alg_minimum_boundary_jump_squared_(std::pow(getRequiredRosParam<float>(n, "alg_minimum_boundary_jump"), 2.0f))
    , alg_offset_driving_path_(getRequiredRosParam<float>(n, "alg_offset_driving_path"))
    , alg_maximum_boundary_angle_jump_rad_(getRequiredRosParam<float>(n, "alg_maximum_boundary_angle_jump_deg") * DEG_TO_RAD)
    , alg_angle_overcompensation_(getRequiredRosParam<float>(n, "alg_angle_overcompensation"))
{
}


template <typename Pt>
inline float lengthSquared(const Pt& point) {
    return point.x * point.x + point.y * point.y + point.z * point.z;
}

template <typename Pt>
inline float length(const Pt& point) {
    return std::sqrt(lengthSquared(point));
}

template <typename Pt>
inline float normalizedDot(const Pt& p1, const Pt& p2) {
    float dot = p1.x * p2.x + p1.y * p2.y + p1.z * p2.z;

    float p1_l = length(p1);
    float p2_l = length(p2);

    return dot / (p1_l * p2_l);
}

geometry_msgs::PoseStamped poseFromEigen(const Eigen::Vector3f& vec) {
    geometry_msgs::PoseStamped pose;

    pose.pose.position.x = vec[0];
    pose.pose.position.y = vec[1];
    pose.pose.position.z = vec[2];

    return pose;
}

template <typename Pt>
Eigen::Vector3f pclToEigen(const Pt& point) {
    return Eigen::Vector3f(point.x, point.y, point.z);
}


Eigen::Vector3f stampedPoseToEigen(const geometry_msgs::PoseStamped& pose) {
    return Eigen::Vector3f(static_cast<const float &>(pose.pose.position.x),
                           static_cast<const float &>(pose.pose.position.y),
                           static_cast<const float &>(pose.pose.position.z));
}

enum class ConeColor {
    Red,
    Yellow,
    Blue
};

bool isMatchingCone(const pcl::PointXYZRGB& pt, MessageListener::ColorClass clazz) {
    ConeColor cone_color;

    if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_RED)) {
        cone_color = ConeColor::Red;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_BLUE)) {
        cone_color = ConeColor::Blue;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_YELLOW)) {
        cone_color = ConeColor::Yellow;
    } else if (hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_FINISH)) {
        cone_color = ConeColor::Red;
    } else {
        return false;
    }

    if (clazz == MessageListener::ColorClass::BlueOrRed) {
        return cone_color == ConeColor::Blue || cone_color == ConeColor::Red;
    } else if (clazz == MessageListener::ColorClass::YellowOrRed) {
        return cone_color == ConeColor::Yellow || cone_color == ConeColor::Red;
    } else {
        return false;
    }
}

std::pair<size_t, float> MessageListener::next(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, MessageListener::ColorClass clazz, bool weightAngles) {

    size_t best = std::numeric_limits<size_t>::max();
    float best_score = std::numeric_limits<float>::max();

    pcl::PointXYZRGB forward;
    forward.x = 1;

    for (size_t i = 0; i < cloud.size(); ++i) {

        const auto& point(cloud[i]);

        // Skip behind car
        if (point.x <= 0.0f) {
            continue;
        }

        // Skip wrong color
        if (!isMatchingCone(point, clazz)) {
            continue;
        }

        float squared_distance = lengthSquared(point);

        // Ignore if too close to last
        if (squared_distance < alg_minimum_boundary_jump_squared_) {
            continue;
        }

        // Normalized dot in range [0, 1] where 1 is best (straight on a line) and 0 is worst (90° turn)
        // Therefore weight subtracting from 1.1 such that a small weight always remains and normalized dot of 1
        // yields to smallest score
        float angle_weight = weightAngles
            ? 1.1f - normalizedDot(forward, point)
            : 1;

        float score = squared_distance * angle_weight;

        // TODO: Check next cone perpendicular to selected cone is correct color and adjust score accordingly

        if (score < best_score) {
            best = i;
            best_score = score;
        }
    }

    return std::make_pair(best, best_score);
}

nav_msgs::Path drivingPath(const nav_msgs::Path path, float offset) {

    nav_msgs::Path resultPath;
    resultPath.header.frame_id = path.header.frame_id;

    // Add origin to path
    resultPath.poses.push_back(poseFromEigen({0.0f, 0.0f, 0.0f}));

    for (size_t i = 1; i < path.poses.size(); ++i) {

        Eigen::Vector3f first = stampedPoseToEigen(path.poses[i-1]);
        Eigen::Vector3f second = stampedPoseToEigen(path.poses[i]);
        Eigen::Vector3f diff = second - first;
        diff.normalize();
        Eigen::Vector3f toCenter = diff.cross(Eigen::Vector3f::UnitZ());

        resultPath.poses.push_back(poseFromEigen(second + (offset * toCenter)));
    }

    return resultPath;

}

std::pair<nav_msgs::Path, float> MessageListener::boundary(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass color, float initial_y_offset) {

    nav_msgs::Path path;
    path.header.frame_id = cloud.header.frame_id;

    // Initially go left or right for first cone depending on initial y offset
    Eigen::Affine3f initial_offset_transform = Eigen::Affine3f::Identity();
    initial_offset_transform.translate(Eigen::Vector3f(0.0f, -initial_y_offset, 0.0f));

    // Immediately apply reverse of initial offset to stacked reverse transform
    Eigen::Affine3f reverse_transform = Eigen::Affine3f::Identity();
    reverse_transform.translate(Eigen::Vector3f(0.0f, initial_y_offset, 0.0f));

    // Rewrite working copy to initial offset
    pcl::PointCloud<pcl::PointXYZRGB> copy;
    pcl::transformPointCloud(cloud, copy, initial_offset_transform);

    pcl::PointCloud<pcl::PointXYZRGB> temp;

    float overall_score = 0.0f;

    int i, path_max = 4;

    for (i = 0; i < path_max; ++i) {
        // Don't weight angles for first cone as not on boundary yet
        auto pair = next(copy, color, i != 0);
        size_t cone_i = pair.first;

        // Stop if no more cones found
        if (cone_i == std::numeric_limits<size_t>::max()) {
            break;
        }

        const auto& cone(copy[cone_i]);

        // Abort if too far to cone
        if (lengthSquared(cone) >= alg_maximum_boundary_jump_squared_) {
            break;
        }

        float angle = 0.0f;

        // Don't rotate for first cone since angle is expected to be large as origin is not on boundary yet
        if (i != 0) {
            angle = std::atan2(cone.y, cone.x);

            // Break if angle absurd
            if (std::abs(angle) > alg_maximum_boundary_angle_jump_rad_) {
                break;
            }
        }

        overall_score += pair.second;

        // Overcompensate angle to lean into curves
        angle *= alg_angle_overcompensation_;

        path.poses.push_back(poseFromEigen(reverse_transform * pclToEigen(cone)));

        Eigen::Affine3f frame_transform = Eigen::Affine3f::Identity();
        frame_transform.rotate(Eigen::AngleAxisf(-angle, Eigen::Vector3f::UnitZ())).translate(Eigen::Vector3f(-cone.x, -cone.y, -cone.z));

        pcl::transformPointCloud(copy, temp, frame_transform);
        copy.swap(temp);

        // Apply inverse of all transformations in reverse order to get identity with forward transform
        reverse_transform.translate(Eigen::Vector3f(cone.x, cone.y, cone.z)).rotate(Eigen::AngleAxisf(angle, Eigen::Vector3f::UnitZ()));

        // Swap and pop used cone
        // std::swap(copy[i], copy.back());
        // copy.points.pop_back();
    }

    // Add score for every cone below wanted path max
    return std::make_pair(path, overall_score + (30 * (path_max - i)));
}

void MessageListener::pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg) {

    const auto left = boundary(*msg, ColorClass::BlueOrRed, BOUNDARY_Y_OFFSET);
    const auto leftPath = left.first;
    const auto right = boundary(*msg, ColorClass::YellowOrRed, -BOUNDARY_Y_OFFSET);
    const auto rightPath = right.first;

    nav_msgs::Path leftCenter = drivingPath(leftPath, alg_offset_driving_path_);
    nav_msgs::Path rightCenter = drivingPath(rightPath, -alg_offset_driving_path_);

    // Lower score is better
    if (left.second < right.second) {
        center_line_publisher_.publish(leftCenter);
    } else {
        center_line_publisher_.publish(rightCenter);
    }

    left_bound_publisher_.publish(leftPath);
    right_bound_publisher_.publish(rightPath);
}