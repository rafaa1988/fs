#pragma once

#include <pcl_ros/point_cloud.h>
#include <nav_msgs/Path.h>

class MessageListener {
public:

    enum class ColorClass {
        YellowOrRed,
        BlueOrRed
    };

private:

    ros::Subscriber map_subscriber_;

    ros::Publisher center_line_publisher_;
    ros::Publisher left_bound_publisher_;
    ros::Publisher right_bound_publisher_;

    // Algorithm parameters
    float alg_maximum_boundary_jump_squared_;
    float alg_minimum_boundary_jump_squared_;
    float alg_offset_driving_path_;
    float alg_maximum_boundary_angle_jump_rad_;
    float alg_angle_overcompensation_;

    std::pair<nav_msgs::Path, float> boundary(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, ColorClass color, float initial_y_offset);

    std::pair<size_t, float> next(const pcl::PointCloud<pcl::PointXYZRGB>& cloud, MessageListener::ColorClass clazz, bool weightAngles = false);

    void pointcloudCallback(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &msg);

public:

    explicit MessageListener(ros::NodeHandle &n);

};