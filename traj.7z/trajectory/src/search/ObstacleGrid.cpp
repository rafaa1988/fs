//
// Created by horsepower on 17.04.18.
//

#include "ObstacleGrid.h"

ObstacleGrid::ObstacleGrid(const int distSideways, const int distForward, const int tilesPerMeter, const char *tf_frame) {

    distSideways_ = distSideways;
    distForward_ = distForward;
    tilesPerMeter_ = tilesPerMeter;

    infoData.map_load_time = ros::Time::now();

    infoData.width = static_cast<unsigned int>(distForward * tilesPerMeter);
    infoData.height = static_cast<unsigned int>(2 * distSideways * tilesPerMeter);
    infoData.resolution = 1.0f / tilesPerMeter;

    geometry_msgs::Pose origin;
    origin.position.x = 0;
    origin.position.y = -distSideways;
    origin.position.z = 0;
    infoData.origin = origin;

    occupancyGrid.info = infoData;
    occupancyGrid.header.frame_id = tf_frame;

    for (size_t i = 0; i < infoData.width * infoData.height; ++i) {
        occupancyGrid.data.push_back(0);
    }
}

/**
 * set obstacle in grid. Input is position in meters!
 * @param obstacle
 * @return
 */
bool ObstacleGrid::setObstacle(const Eigen::Vector3f& obstacle) {
    Eigen::Vector3f gridCoordinates = pointAsGridCoordinates(obstacle);
    return setObstacleInGrid(gridCoordinates[0], gridCoordinates[1], 100);
}

/**
 * Using the DDA line algorithm
 * @param firstPoint
 * @param secondPoint
 * @return
 */
bool ObstacleGrid::setObstacleLine(const Eigen::Vector3f& firstPoint, const Eigen::Vector3f& secondPoint) {
    Eigen::Vector3f gridCoordinatesFirst = pointAsGridCoordinates(firstPoint);
    Eigen::Vector3f gridCoordinatesSecond = pointAsGridCoordinates(secondPoint);

    int deltaX = static_cast<int>(gridCoordinatesSecond[0] - gridCoordinatesFirst[0]);
    int deltaY = static_cast<int>(gridCoordinatesSecond[1] - gridCoordinatesFirst[1]);

    int steps = std::max(std::abs(deltaX), std::abs(deltaY));

    float xInc = deltaX / static_cast<float>(steps);
    float yInc = deltaY / static_cast<float>(steps);

    float x = gridCoordinatesFirst[0];
    float y = gridCoordinatesFirst[1];

    for (int i = 0; i <= steps; ++i) {
        setObstacleInGrid(static_cast<int>(x), static_cast<int>(y), 100);
        x += xInc;
        y += yInc;
    }

    return true;
}

/**
 * set obstacle in grid at coordinates
 * @param x
 * @param y
 */
bool ObstacleGrid::setObstacleInGrid(int x, int y, signed char obstacleValue = 100) {
    if (x < 0 ||
        x > distForward_*tilesPerMeter_ ||
        y < 0 ||
        y > 2 * distSideways_*tilesPerMeter_) {
        return false;
    }

    //row-major order in array
    int position = (infoData.width * y) + x;
    occupancyGrid.data[position] = obstacleValue;
    return true;
}


bool ObstacleGrid::pointInGrid(const Eigen::Vector3f& point) {
    Eigen::Vector3f gridCoordinates = pointAsGridCoordinates(point);
    return !(gridCoordinates[0] < 0 ||
        gridCoordinates[0] > distForward_*tilesPerMeter_ ||
        gridCoordinates[1] < 0 ||
        gridCoordinates[1] > 2 * distSideways_*tilesPerMeter_);
}


Eigen::Vector3f ObstacleGrid::pointAsGridCoordinates(const Eigen::Vector3f& point) {
    Eigen::Vector3f gridCoordinates = point * tilesPerMeter_;
    gridCoordinates[1] += distSideways_ * tilesPerMeter_;
    return gridCoordinates;
}

Eigen::Vector3f ObstacleGrid::gridCoordinatesAsPoint(const Eigen::Vector3f& gridCoordinates) {
    Eigen::Vector3f point = gridCoordinates;
    point = gridCoordinates / tilesPerMeter_;
    point[1] -= distSideways_;
    return point;
}

