//
// Created by horsepower on 17.04.18.
//

#pragma once

#include <pcl_ros/transforms.h>
#include <nav_msgs/OccupancyGrid.h>

class ObstacleGrid {

private:
    nav_msgs::MapMetaData infoData;

    int distSideways_ = 0;
    int distForward_ = 0;
    int tilesPerMeter_ = 1;

public:

    ObstacleGrid() = default;

    nav_msgs::OccupancyGrid occupancyGrid;
    ObstacleGrid(int distSideways, int distForward, int tilesPerMeter, const char *tf_frame);

    bool setObstacle(const Eigen::Vector3f &obstacle);

    bool setObstacleLine(const Eigen::Vector3f &firstPoint, const Eigen::Vector3f &secondPoint);

    bool pointInGrid(const Eigen::Vector3f &point);

    Eigen::Vector3f pointAsGridCoordinates(const Eigen::Vector3f &point);

    Eigen::Vector3f gridCoordinatesAsPoint(const Eigen::Vector3f &gridCoordinates);

    bool setObstacleInGrid(int x, int y, signed char obstacleValue);
};
