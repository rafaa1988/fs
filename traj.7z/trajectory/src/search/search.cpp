//
// Created by niclas on 29.05.18.
//

//

#include "search.h"
#ifdef SEARCH

nav_msgs::Path MessageListener::drivingPath(const nav_msgs::Path& leftPath, const nav_msgs::Path& rightPath) {

    nav_msgs::Path resultPath;
    resultPath.header.frame_id = leftPath.header.frame_id;

    grid = ObstacleGrid(SEARCH_DIST_SIDEWAYS, SEARCH_DIST_FORWARD, TILES_PER_METER, leftPath.header.frame_id.c_str());

    for (const auto& pose : leftPath.poses) {
        grid.setObstacle(stampedPoseToEigen(pose));
    }

    for (const auto& pose : rightPath.poses) {
        grid.setObstacle(stampedPoseToEigen(pose));
    }

    createObstacleMap(leftPath);
    createObstacleMap(rightPath);


    //offset paths in the center direction
    nav_msgs::Path leftCenterPath = offsetPath(leftPath, OFFSET_OBSTACLE_PATH);
    nav_msgs::Path rightCenterPath = offsetPath(rightPath, -OFFSET_OBSTACLE_PATH);

    /*
    addOffsetPose(leftCenterPath, OFFSET_OBSTACLE_PATH);
    addOffsetPose(rightCenterPath, -OFFSET_OBSTACLE_PATH);
    createObstacleMap(rightCenterPath);
    createObstacleMap(leftCenterPath);
    */

    // determine goal coordinates:
    // if both paths are empty, then drive 2m forward
    Eigen::Vector3f goalPoint = Eigen::Vector3f(2.0f, 0.0f, 0.0f);

    //select longest boundary path

    nav_msgs::Path goalPathCenter;
    if (leftPath.poses.size() > rightPath.poses.size()) {
        goalPathCenter = offsetPath(leftPath, OFFSET_DRIVING_PATH);
    } else {
        goalPathCenter = offsetPath(rightPath, -OFFSET_DRIVING_PATH);
    }

    //take last point on path, that is in the grid
    for (const auto& pose : goalPathCenter.poses) {
        if (grid.pointInGrid(stampedPoseToEigen(pose))) {
            goalPoint = stampedPoseToEigen(pose);
        }
    }

    generator.initWithOccupancyGrid(grid.occupancyGrid);
    Eigen::Vector3f originGridCoords = grid.pointAsGridCoordinates(Eigen::Vector3f(0,0,0));
    Eigen::Vector3f goalGridCoords = grid.pointAsGridCoordinates(goalPoint);

    // find path
    auto aStarPath = generator.findPath({static_cast<int>(originGridCoords[0]), static_cast<int>(originGridCoords[1])},
                                        {static_cast<int>(goalGridCoords[0]), static_cast<int>(goalGridCoords[1])}, 5000);


    // if no path found, then drive 2m forward
    if (aStarPath.empty()) {
        ROS_INFO("no path found!");
        resultPath.poses.push_back(poseFromEigen(Eigen::Vector3f(0,0,0)));
        resultPath.poses.push_back(poseFromEigen(Eigen::Vector3f(2,0,0)));
    } else {
        //reverse to get path from origin to goal instead of backwards path
        std::reverse(aStarPath.begin(), aStarPath.end());

        //convert to nav_msgs::Path message

        for (size_t i = 0; i < aStarPath.size(); ++i) {
            //TODO: Proportional to number of turns...
            if (i % SMOOTHING_NUMBER == 0 || i == aStarPath.size()-1) {
                Eigen::Vector3f pointCoords = grid.gridCoordinatesAsPoint(Eigen::Vector3f(aStarPath[i].x, aStarPath[i].y, 0));
                resultPath.poses.push_back(poseFromEigen(pointCoords));
            }
        }
    }

    grid_cell_publisher_.publish(grid.occupancyGrid);

    (void) resultPath;

    if (leftCenterPath.poses.size() > rightCenterPath.poses.size()) {
        return leftCenterPath;
    } else {
        return rightCenterPath;
    }
    //return resultPath;
}





void MessageListener::createObstacleMap(const nav_msgs::Path obstaclePath) {

    for (size_t i = 1; i < obstaclePath.poses.size(); ++i) {
        Eigen::Vector3f first = stampedPoseToEigen(obstaclePath.poses[i-1]);
        Eigen::Vector3f second = stampedPoseToEigen(obstaclePath.poses[i]);
        grid.setObstacleLine(first, second);
    }
}

void MessageListener::addOffsetPose(nav_msgs::Path& path_, const float yOffset) {
    Eigen::Vector3f offsetVector(0, yOffset, 0);
    path_.poses.insert(path_.poses.begin(), poseFromEigen(offsetVector));
}


#endif
