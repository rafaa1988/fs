//
// Created by niclas on 29.05.18.
//

#ifdef TRAJECTORY_SEARCH_H

class search {

    nav_msgs::Path drivingPath(const nav_msgs::Path &leftPath, const nav_msgs::Path &rightPath);

    void createObstacleMap(nav_msgs::Path obstaclePath);
    void addOffsetPose(nav_msgs::Path &path_, float yOffset);

};


#endif //TRAJECTORY_SEARCH_H
