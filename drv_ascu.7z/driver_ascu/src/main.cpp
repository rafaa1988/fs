#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <boost/filesystem.hpp>
#include <fstream>
#include <regex>
#include <chrono>
#include <thread>

// ----- WARNING THRESHOLDS ------
// Threshold as ratio above which CPU is critically utilized
constexpr float CPU_UTIL_CRITICAL_THRESHOLD = 0.75f;

// Threshold in °C above which CPU is considered hot
constexpr float CPU_TEMP_CRITICAL_THRESHOLD = 80.0f;

// Threshold in MB below which memory left is critical
constexpr float MAIN_MEMORY_CRITICAL_THRESHOLD = 500.0f;

// Threshold in GB below which disk space left is critical
constexpr float DISK_SPACE_CRITICAL_THRESHOLD = 5;

const char* thermalPath = "/sys/class/thermal";
const char* meminfoPath = "/proc/meminfo";

unsigned long long int lastTotalUser;
unsigned long long int lastTotalUserLow;
unsigned long long int lastTotalIdle;
unsigned long long int lastTotalSys;

/**
 * Get the list of all files in given directory and its sub directories.
 *
 * Arguments
 * 	dirPath : Path of directory to be traversed
 * 	dirSkipList : List of folder names to be skipped
 *
 * Returns:
 * 	vector containing paths of all the files in given directory and its sub directories
 *
 */
std::vector<std::string> getAllFilesInDir(const std::string &dirPath, 	const std::vector<std::string> &dirSkipList = { })
{

    // Create a vector of string
    std::vector<std::string> listOfFiles;
    try {
        // Check if given path exists and points to a directory
        if (boost::filesystem::exists(dirPath) && boost::filesystem::is_directory(dirPath))
        {
            // Create a Recursive Directory Iterator object and points to the starting of directory
            boost::filesystem::recursive_directory_iterator iter(dirPath);

            // Create a Recursive Directory Iterator object pointing to end.
            boost::filesystem::recursive_directory_iterator end;

            // Iterate till end
            while (iter != end)
            {
                // Check if current entry is a directory and if exists in skip list
                if (boost::filesystem::is_directory(iter->path()) &&
                    (std::find(dirSkipList.begin(), dirSkipList.end(), iter->path().filename()) != dirSkipList.end()))
                {
                    // Skip the iteration of current directory pointed by iterator
                    // Boost Filesystem  API to skip current directory iteration
                    iter.no_push();

                }
                else
                {
                    // Add the name in vector
                    listOfFiles.push_back(iter->path().string());
                }

                boost::system::error_code ec;
                // Increment the iterator to point to next entry in recursive iteration
                iter.increment(ec);
                if (ec) {
                    std::cerr << "Error While Accessing : " << iter->path().string() << " :: " << ec.message() << '\n';
                }
            }
        }
    }
    catch (std::system_error & e)
    {
        std::cerr << "Exception :: " << e.what();
    }
    return listOfFiles;
}

std::vector<std::string> findFilesContainingString(const std::vector<std::string>& directory, const std::string& searchString) {
    std::vector<std::string> result;
    for (auto& file : directory) {
        if (file.find(searchString) != std::string::npos) {
            result.push_back(file);
        }
    }
    return result;
}

/**
 * Get the current cpu utilisation
 * @return Utilisation of entire cpu (average of all cores) in range [0.0, 1.0]. -1.0 on error
 */
double getCurrentCPUUtilisation(){
    double percent;
    FILE* file;
    unsigned long long totalUser, totalUserLow, totalSys, totalIdle, total;

    file = fopen("/proc/stat", "r");
    auto result = fscanf(file, "cpu %llu %llu %llu %llu", &totalUser, &totalUserLow,
           &totalSys, &totalIdle);
    if (result != 4) {
        throw std::runtime_error("cpu utilisation read failed");
    }

    fclose(file);


    if (totalUser < lastTotalUser || totalUserLow < lastTotalUserLow ||
        totalSys < lastTotalSys || totalIdle < lastTotalIdle){
        //Overflow detection. Just skip this value.
        percent = -1.0;
    }
    else{
        total = (totalUser - lastTotalUser) + (totalUserLow - lastTotalUserLow) +
                (totalSys - lastTotalSys);
        percent = total;
        total += (totalIdle - lastTotalIdle);
        percent /= total;
        percent *= 100;
    }

    lastTotalUser = totalUser;
    lastTotalUserLow = totalUserLow;
    lastTotalSys = totalSys;
    lastTotalIdle = totalIdle;

    return percent / 100.0f;
}


float getAvgCpuClock() {
    float acc_clock = 0;
    int cpu_count = 0;

    std::ifstream fin("/proc/cpuinfo", std::ios::in);

    for (std::string line; getline(fin, line);) {
        if (line.find("cpu MHz") != std::string::npos) {
            std::regex rgx("[0-9]+.[0-9]+");
            std::smatch matches;
            if (std::regex_search(line, matches, rgx)) {
                acc_clock += std::stof(matches[0]);
                cpu_count++;
            }

        }
    }

    return acc_clock / cpu_count;
}




int main(int argc, char** argv) {
    ros::init(argc, argv, "driver_ascu");

    ros::NodeHandle n("~");

    telemetry::Runner tele("ascu");

    ROS_INFO("ASCU node launched");

    std::string temperatureFile;

    if (boost::filesystem::is_directory(thermalPath)) {
        auto thermalDirectories = findFilesContainingString(getAllFilesInDir(thermalPath), "thermal");
        for (auto &dir : thermalDirectories) {
            for (auto &file : findFilesContainingString(getAllFilesInDir(dir), "type")) {
                std::ifstream infile(file);
                for (std::string line; getline(infile, line);) {
                    if (line == "x86_pkg_temp") {
                        temperatureFile = dir + "/temp";
                    }
                }
            }
        }
    }

    ros::SteadyTimerCallback cb = [&] (const auto& ev) {
        (void) ev;

        std::ifstream temp(temperatureFile);
        for (std::string t; getline(temp, t); ) {
            float temperature = std::stof(t) / 1000.0f;
            tele.stage("cpu-temp", temperature);
            tele.stage("cpu-temp-w", temperature > CPU_TEMP_CRITICAL_THRESHOLD);
        }

        if (boost::filesystem::exists(meminfoPath)) {
            std::ifstream mem(meminfoPath);
            for (std::string line; getline(mem, line); ) {
                if (line.find("MemAvailable") != std::string::npos) {
                    //filter out numerical values
                    std::regex rgx("[0-9]+");
                    std::smatch matches;
                    if (std::regex_search(line, matches, rgx)) {
                        int memory = std::stoi(matches[0]) / 1'000;
                        tele.stage("mem-av", memory); //Megabytes
                        tele.stage("mem-av-w", memory < MAIN_MEMORY_CRITICAL_THRESHOLD);
                    }

                }
            }
        }

        boost::filesystem::space_info spaceInfo = boost::filesystem::space("/");
        tele.stage("disk-av", spaceInfo.available / 1'000'000); //Megabytes
        tele.stage("disk-av-w", spaceInfo.available < 1'000'000'000 * DISK_SPACE_CRITICAL_THRESHOLD);

        try {
            boost::filesystem::space_info spaceInfo2 = boost::filesystem::space("/mnt/bags");
            tele.stage("sec-disk-av", spaceInfo2.available / 1'000'000); //Megabytes
            tele.stage("sec-disk-av-w", spaceInfo2.available < 1'000'000'000 * DISK_SPACE_CRITICAL_THRESHOLD);
        } catch (boost::filesystem::filesystem_error &e) {
            ROS_WARN("Could not access /mnt/bags");
        }

        double cpuUtilisation = getCurrentCPUUtilisation();

        if (cpuUtilisation >= 0.0f) {
            tele.stage("cpu-util", cpuUtilisation);
            tele.stage("cpu-util-w", cpuUtilisation > CPU_UTIL_CRITICAL_THRESHOLD);
        }

        float clock = getAvgCpuClock();
        std::cout << clock << std::endl;
        tele.stage("cpu-clock", clock);

        tele.report();
    };

    auto timer = n.createSteadyTimer(ros::WallDuration(0.5), cb);

    ros::spin();

    return EXIT_SUCCESS;
}


