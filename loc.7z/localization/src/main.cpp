#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>

#include <hphlib/util.h>

std::string map_frame;
std::string odom_frame;
std::string base_link_frame;
bool leave_breadcrumbs;

tf::TransformBroadcaster *tf_broadcaster;
tf::StampedTransform tf_map_to_odom;
tf::StampedTransform tf_odom_to_baselink;
ros::Publisher odom_pub;

void initTransforms() {
    tf_map_to_odom.setOrigin(tf::Vector3(0, 0, 0));
    tf_map_to_odom.setRotation(tf::Quaternion::getIdentity());

    tf_odom_to_baselink.setOrigin(tf::Vector3(0, 0, 0));
    tf_odom_to_baselink.setRotation(tf::Quaternion::getIdentity());

    tf_broadcaster->sendTransform(tf_map_to_odom);
    tf_broadcaster->sendTransform(tf_odom_to_baselink);
}

void odomCallback(nav_msgs::Odometry odom) {
    static ros::Time last_time;
    static ros::Time last_bc_time;
    static bool last_time_init = false;

    tf::Vector3 linear_vel;
    tf::Vector3 angular_vel;
    tf::Quaternion angular_delta;
    ros::Duration delta_time;

    if (!last_time_init) {
        last_time = odom.header.stamp;
        last_time_init = true;
    }

    delta_time = odom.header.stamp - last_time;
    last_time = odom.header.stamp;

    if (delta_time < ros::Duration(0)) {
        initTransforms();

        std::cout << "Reset after loop" << std::endl;
    }

    tf::vector3MsgToTF(odom.twist.twist.linear, linear_vel);
    tf::vector3MsgToTF(odom.twist.twist.angular, angular_vel);

    // ignore roll and pitch
    angular_delta.setRPY(0, 0, -angular_vel.z() * delta_time.toSec());

    linear_vel = tf::quatRotate(tf_odom_to_baselink.getRotation(), linear_vel);
    linear_vel.setZ(0);

    tf_odom_to_baselink.setOrigin(tf_odom_to_baselink.getOrigin() + linear_vel * delta_time.toSec());
    tf_odom_to_baselink.setRotation(tf_odom_to_baselink.getRotation() * angular_delta);
    tf_odom_to_baselink.stamp_ = last_time;

    tf_map_to_odom.stamp_ = last_time;

    tf_broadcaster->sendTransform(tf_map_to_odom);
    tf_broadcaster->sendTransform(tf_odom_to_baselink);

    //publish odometry again to fake /odometry/filtered
    odom_pub.publish(odom);


}

int main(int argc, char** argv) {
    ros::init(argc, argv, "Fake localization node started");
    ros::NodeHandle n("~");

    tf_broadcaster = new tf::TransformBroadcaster();

    std::string odo_in_topic = getRequiredRosParam<std::string>(n, "odo_in_topic");
    std::string odo_out_topic = getRequiredRosParam<std::string>(n, "odo_out_topic");
    map_frame = getRequiredRosParam<std::string>(n, "map_frame");
    odom_frame = getRequiredRosParam<std::string>(n, "odom_frame");
    base_link_frame = getRequiredRosParam<std::string>(n, "base_link_frame");

    tf_map_to_odom.frame_id_ = map_frame;
    tf_map_to_odom.child_frame_id_ = odom_frame;

    tf_odom_to_baselink.frame_id_ = odom_frame;
    tf_odom_to_baselink.child_frame_id_ = base_link_frame;

    initTransforms();

    ros::Subscriber sub = n.subscribe(odo_in_topic, 1, &odomCallback);
    odom_pub = n.advertise<nav_msgs::Odometry>(odo_out_topic, 1);

    ros::spin();

    return EXIT_SUCCESS;
}