#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Path.h>

#include <hphlib/util.h>

nav_msgs::Path breadcrumbs;
ros::Publisher breadcrumbs_pub;

tf::TransformListener *tf_listener;

void leaveBreadcrumb() {
    tf::StampedTransform transform;
    tf::Vector3 origin;
    geometry_msgs::PoseStamped point;

    try {
        tf_listener->lookupTransform("map", "base_link", ros::Time(0), transform);
    } catch (const tf::ExtrapolationException& e) {
        // put your hands up in the air. we don't care
        std::cout << "fail" << e.what() << std::endl;
    } catch (const tf2::LookupException& e) {
        // put your hands up in the air. we don't care
        std::cout << "fail" << e.what() << std::endl;
    } catch (const tf2::ConnectivityException& e) {
        // put your hands up in the air. we don't care
        std::cout << "not connected" << std::endl;
    }

    point.header.frame_id = "/map";
    point.header.stamp = ros::Time::now();

    origin = transform.getOrigin();

    point.pose.position.x = origin.x();
    point.pose.position.y = origin.y();
    point.pose.position.z = origin.z();

    point.pose.orientation = tf::createQuaternionMsgFromYaw(0);

    breadcrumbs.poses.push_back(point);

    breadcrumbs_pub.publish(breadcrumbs);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "Fake localization node started");
    ros::NodeHandle n("~");

    tf_listener = new tf::TransformListener();

    breadcrumbs.header.frame_id = "map";

    breadcrumbs_pub = n.advertise<nav_msgs::Path>(
            getRequiredRosParam<std::string>(n, "breadcrumbs_topic"), 1);

    ros::Rate loop_rate(10);

    while(ros::ok()) {
        leaveBreadcrumb();

        ros::spinOnce();

        loop_rate.sleep();
    }

    return 0;
}