#include <cmath>

#include <hphlib/util.h>
#include <nav_msgs/Odometry.h>
#include "Converter.h"

constexpr float WHEEL_BASE = 1.555f;
constexpr float LF = WHEEL_BASE / 2.0f; // distance from front axis to CG
constexpr float LR = WHEEL_BASE / 2.0f; // distance from rear axis to CG

Converter::Converter(ros::NodeHandle &n)
        : wheel_sub_(n, getRequiredRosParam<std::string>(n, "topic_wheel_odometry"), 2)
        , steering_sub_(n, getRequiredRosParam<std::string>(n, "topic_steering"), 2)
        , synchronizer_(SYNC(10), wheel_sub_, steering_sub_)
        , odo_pub_(n.advertise<nav_msgs::Odometry>(getRequiredRosParam<std::string>(n, "topic_out"), 1))
        , wheel_radius_(static_cast<float>(getRequiredRosParam<double>(n, "wheel_radius")))
        , steering_offset_(static_cast<float>(getRequiredRosParam<double>(n, "steering_angle_offset")))
        , covariance_(static_cast<float>(getRequiredRosParam<double>(n, "covariance")))
        , angular_covariance_(static_cast<float>(getRequiredRosParam<double>(n, "angular_covariance")))
{
    synchronizer_.registerCallback(&Converter::callback, this);
}

void Converter::callback(const hphlib::WheelOdometry &wheels, const hphlib::SteeringAngle &steering) {
    // convert input using equations from this paper https://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=7225830

    // calculate angle at CG from steering angle
    float beta = - atanf((LR / (LR + LF)) * tanf(static_cast<float>((steering.angle + steering_offset_) * M_PI / 180)));

    // average speed over all 4 wheels
    float avg_wheel_speed = (wheels.rpm_front_left + wheels.rpm_front_right + wheels.rpm_back_left + wheels.rpm_back_right) / 4.0f;
    // rotate to vehicle frame
    float vx = static_cast<float>(avg_wheel_speed * wheel_radius_ * 2 * M_PI);
    float vy = vx * tanf(beta);

    // calculate yaw rate
    float length_v = vx / cosf(beta);
    float yaw_rate = (length_v / LR) * sinf(beta);

    nav_msgs::Odometry odo;

    odo.header.stamp = wheels.header.stamp;
    odo.header.frame_id = "base_link";

    odo.child_frame_id = "center_of_gravity"; // TODO consider using actual CG

    odo.twist.twist.linear.x = vx;
    odo.twist.twist.linear.y = vy;

    odo.twist.twist.angular.z = yaw_rate;

    odo.twist.covariance = {
            covariance_, 0, 0, 0, 0, 0,
            0, covariance_, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, angular_covariance_
    };

    odo_pub_.publish(odo);
}
