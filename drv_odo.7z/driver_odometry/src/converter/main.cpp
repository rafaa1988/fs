#include <thread>
#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/WheelOdometry.h>
#include <hphlib/SteeringAngle.h>
#include <hphlib/util.h>

#include "Converter.h"


int main(int argc, char** argv) {
    ros::init(argc, argv, "driver_odometry");
    ros::NodeHandle n("~");

    Converter converter(n);

    ros::spin();

    return EXIT_SUCCESS;
}