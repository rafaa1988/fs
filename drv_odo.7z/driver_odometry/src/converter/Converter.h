#pragma once

#include <message_filters/sync_policies/approximate_time.h>
#include <message_filters/subscriber.h>


#include <hphlib/WheelOdometry.h>
#include <hphlib/SteeringAngle.h>

class Converter {
private:
    using SYNC = message_filters::sync_policies::ApproximateTime<hphlib::WheelOdometry, hphlib::SteeringAngle>;

    message_filters::Subscriber<hphlib::WheelOdometry> wheel_sub_;
    message_filters::Subscriber<hphlib::SteeringAngle> steering_sub_;

    message_filters::Synchronizer<SYNC> synchronizer_;

    ros::Publisher odo_pub_;

    float wheel_radius_;
    float steering_offset_;
    float covariance_;
    float angular_covariance_;

public:

    explicit Converter(ros::NodeHandle& n);

    void callback(const hphlib::WheelOdometry& wheelodo, const hphlib::SteeringAngle& steering);
};
