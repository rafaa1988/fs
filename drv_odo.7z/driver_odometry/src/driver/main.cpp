#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/WheelOdometry.h>
#include <hphlib/SteeringAngle.h>
#include <hphlib/util.h>
#include <hphlib/misc/PollService.h>
#include <hphlib/io/UdpSocket.h>
#include <hphlib/PackedEndian.h>

// front left, front right, back left, back right
struct __attribute__((packed)) OdometryFrame {
    little_f64_t hz_front_right;
    little_f64_t hz_front_left;
    little_f64_t hz_rear_right;
    little_f64_t hz_rear_left;
    little_f64_t steering;
};

void run_main(ros::NodeHandle& n) {
    uint16_t sink = getRequiredRosParamPort(n, "odometry_sink_port");
    std::string topic_odometry = getRequiredRosParam<std::string>(n, "topic_odometry");
    std::string topic_steering = getRequiredRosParam<std::string>(n, "topic_steering");
    double wheel_radius = getRequiredRosParam<double>(n, "wheel_radius");

    double conversion_hz_vel = wheel_radius * 2 * M_PI;

    ros::Publisher odo_pub = n.advertise<hphlib::WheelOdometry>(topic_odometry, 1);
    ros::Publisher angle_pub = n.advertise<hphlib::SteeringAngle>(topic_steering, 1);

    telemetry::Runner tele("odo");

    hphlib::UdpSocket sock(sink, true);
    sock.setBlocking(false);

    hphlib::PollService poller(sock, [&] () {
        OdometryFrame frame{};

        hphlib::WheelOdometry odometry_msg;
        hphlib::SteeringAngle steering_msg;

        ssize_t bytes = sock.receiveNoThrow(reinterpret_cast<uint8_t *>(&frame), sizeof frame);

        // Check that wakeup is not spurious
        if (bytes > 0) {
            odometry_msg.header.stamp = ros::Time::now();
            steering_msg.header.stamp = odometry_msg.header.stamp;

            // TODO: Talk to Lohmann to send the values as float32 instead to avoid unnecessary cast
            odometry_msg.rpm_front_left = static_cast<float>(frame.hz_front_left);
            odometry_msg.rpm_front_right = static_cast<float>(frame.hz_front_right);
            odometry_msg.rpm_back_left = static_cast<float>(frame.hz_rear_left);
            odometry_msg.rpm_back_right = static_cast<float>(frame.hz_rear_right);

            steering_msg.angle = static_cast<float>(frame.steering); // TODO: See above

            odo_pub.publish(odometry_msg);
            angle_pub.publish(steering_msg);

            tele.stage("steer", frame.steering.native());
            tele.stage("fl-vel", odometry_msg.rpm_front_left * conversion_hz_vel);
            tele.stage("fr-vel", odometry_msg.rpm_front_right * conversion_hz_vel);
            tele.stage("rl-vel", odometry_msg.rpm_back_left * conversion_hz_vel);
            tele.stage("rr-vel", odometry_msg.rpm_back_right * conversion_hz_vel);
            tele.report();
        }
    });

    ROS_INFO_STREAM("Odometry driver listening on port " << sink);

    ros::spin();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "driver_odometry");
    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }

    return EXIT_SUCCESS;
}
