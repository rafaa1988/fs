#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/os.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <csignal>
#include <thread>

int main(int argc, char** argv) {
    ros::init(argc, argv, "periodic_transform");

    ros::NodeHandle n("~");
    
    hphlib::vehicle::StatusMonitor mon(n);
    
    while (ros::ok()) {
        ros::spinOnce();
        
        // Only republish transform if vehicle state is off, otherwise seems to be causing issues with localization,
        // which is launched from AS_READY onwards
        if (mon.state() == hphlib::vehicle::StatusMonitor::STATE_OFF) {
            // Start transform publisher
            const char* transform_args[] = {
                    "roslaunch",
                    "transform",
                    "eh17d.launch",
                    nullptr
            };

            // Launch transform to appear in bag
            pid_t transform_pid = hphlib::os::execute(transform_args[0], const_cast<char *const *>(transform_args), hphlib::os::ExecuteMode::SearchExecutable);
            
            std::this_thread::sleep_for(std::chrono::seconds(5));
            
            auto opt_term = hphlib::os::checkTerminated(transform_pid);
            
            if (opt_term) {
                ROS_ERROR_STREAM("Child transform has died unexpectedly");
                continue;
            }
            
            hphlib::os::signal(transform_pid, SIGINT);
            hphlib::os::waitTerminated(transform_pid);
        } else  {
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }

    ros::spin();

    return EXIT_SUCCESS;
}
