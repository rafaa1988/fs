#This script should replace a point cloud topic in a rosbag

import rosbag
import rospy
import sensor_msgs.point_cloud2 as pc2
from tqdm import tqdm #pip install tqdm

existing_rosbag_path = "/home/niclas/bags/TEST.bag"
new_rosbag_path = "/home/niclas/bags/new.bag"
topic_name_in_new_bag = "/annotated"
topic_name_from_conversion = "/pcd_cloud"

#copy over all old rosbag contents
print "Copying rosbag"
outbag = rosbag.Bag(new_rosbag_path, 'w')
for topic, msg, t in tqdm(rosbag.Bag(existing_rosbag_path).read_messages()):
	outbag.write(topic, msg, msg.header.stamp if msg._has_header else t)
outbag.close()
print "Copied successfully!"

def callback(point_cloud):
	print "CALLBACK"
	for p in pc2.read_points(point_cloud, field_names = ("x", "y", "z"), skip_nans=True):
		print " x : %f  y: %f  z: %f" %(p[0],p[1],p[2])
    
def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber(topic_name_from_conversion, pc2, callback)
    
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
