console.log('running');
var fs = require('fs');
//create server at localhost:8080
const express = require('express');  //web server
app = express();
const webserver = require('http').createServer(app);
const io = require('socket.io').listen(webserver);	//web socket server
const dgram = require('dgram');
const server = dgram.createSocket('udp4');

webserver.listen(8080);
app.use(express.static('public')); //tell the server that ./public/ contains the static webpages

const scores_path = 'data/scores.txt';

var scores = []

function compare(a,b) {
  if (a.time < b.time)
    return -1;
  if (a.time >= b.time)
    return 1;
  return 0;
}

function sortScores() {
    scores.sort(compare);
}

Number.prototype.toReadableString = function () {
    var secs = parseFloat(this, 10);
    var minutes = Math.floor(secs/60)
    var seconds = Math.floor(secs - (minutes*60))
    var millis =  parseInt( Math.round(1000*(secs - (minutes*60) - seconds),0), 10)
    if (minutes <= 9) minutes = "0"+minutes
    if (seconds <= 9) seconds = "0"+seconds
    if (millis <= 9) millis = "00"+millis 
    else if (millis <= 99) millis = "0"+millis
    return minutes+':'+seconds+':'+millis;
}

function saveScores() {
    fs.writeFile(scores_path, JSON.stringify(scores), function(err) {
    if(err) return console.log(err);
    console.log("Datei gespeichert!");
    }); 
}


function updateScores() {
    io.emit('data', scores);
}

function prompt(question, callback) {
    var stdin = process.stdin,
        stdout = process.stdout;

    stdin.resume();
    stdout.write(question);

    stdin.once('data', function (data) {
        callback(data.toString().trim());
    });
}

server.on('error', (err) => {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  console.log(`server error:\n${err.stack}`);
  server.close();
});

server.on('message', (msg, rinfo) => {
    console.log(`server got: ${msg} from ${rinfo.address}:${rinfo.port}`);
    
    prompt("Neue Zeit "+parseFloat(msg.toString()).toReadableString()+" ! \nName eingeben (leer lassen zum verwerfen): ", function (input) {
        if (input === "") {
            console.log("Zeit wurde nicht gespeichert!")
            return
        }
        var obj = {}
        obj.time = parseFloat(msg.toString(), 10)
        obj.readableTime = parseFloat(msg.toString(), 10).toReadableString()
        obj.name = input.toString()
        scores.push(obj)
        sortScores()
        console.log("Speichern...")
        saveScores()
        updateScores()
    });
});

io.sockets.on('connection', function (socket) {
    console.log("CLIENT CONNECTED")
    updateScores()
});

server.on('listening', () => {
    const address = server.address();
    console.log(`server listening ${address.address}:${address.port}`);
    prompt("Load old scores? (y/n) \n", function (input) {
        if (input === "y" || input === "Y") {
            fs.readFile(scores_path, function read(err, data) {
                if (err) throw err;
                if (data.length > 1) scores = JSON.parse(data)
                if (!(scores instanceof Array)) scores = []
                console.log("Loaded "+scores.length+" scores")
                updateScores()
            });
        }
    });
});

server.bind(12345);