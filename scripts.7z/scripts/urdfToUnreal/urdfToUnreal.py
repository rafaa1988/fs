import xml.etree.ElementTree

file_name = "Chassis-Baugruppe.urdf.xacro"

e = xml.etree.ElementTree.parse(file_name).getroot()

for link in e.findall("link"):
    print link.get('name')
    
print ""
print ""

for joint in e.findall('joint'):
    for parent in joint.findall('parent'):
        print parent.get('link')
    
    print ""
    
    for origin in joint.findall('origin'):
        print origin.get('xyz')
        print origin.get('rpy')
    