


## CONFIG
PATH = "/home/horsepower/bags/track05.bag"
IMG_LEFT = "/camera_left/image"
IMG_RIGHT = "/camera_right/image"
PIXEL = "/reference/cones_pixel"
FOLDER = "output"
SIZE = (1280,500)
minW = 2
scl = 2.4
sclX = 1
sclY = (32/23)+0.2
bd=2
user_control = False
START = 6388

SAVE = True
TIME_WAIT = 0.01

saveSingle = False
singleSize = (int(200),int(200*((32/23)+0.2)))

#!/usr/bin/env python
import roslib 
roslib.load_manifest('rosbag')
import rosbag
from sensor_msgs.msg import Image

from PIL import *
import PIL.Image
from PIL import ImageTk
import os
import Tkinter
import time

class Cone():
    def __init__(self,x,y,w,h,color):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.color = color
        
    def getBB(self):
        x1 = self.x-self.w/2
        x2 = self.x+self.w/2
        y1 = self.y-self.h/2
        y2 = self.y+self.h/2
        return((x1,y1,x2,y2))

class Bag():
    def __init__(self):
        self.path = PATH
        self.bag = rosbag.Bag(self.path)
        self.size = SIZE
        
        self.iL = self.bag.read_messages(connection_filter=self.filter_iL)
        self.iR = self.bag.read_messages(connection_filter=self.filter_iR)
        self.iP = self.bag.read_messages(connection_filter=self.filter_iP)
        
        self.last = None
        
        self.ConesL = []
        self.ConesR = []
        
        self.i = START
        
    def filter_iL(self,topic, datatype, md5sum, msg_def, header):
        if(datatype=="sensor_msgs/Image"):
            if (topic == IMG_LEFT):
                print "############# USING ######################" 
                print topic,' with datatype:', str(datatype)
                return True;
        return False;
    
    def filter_iR(self,topic, datatype, md5sum, msg_def, header):
        if(datatype=="sensor_msgs/Image"):
            if (topic == IMG_RIGHT):
                print "############# USING ######################" 
                print topic,' with datatype:', str(datatype)
                return True;
        return False;
    
    def filter_iP(self,topic, datatype, md5sum, msg_def, header):
        if(datatype=="std_msgs/Int16MultiArray"):
            if (topic == PIXEL):
                print "############# USING ######################" 
                print topic,' with datatype:', str(datatype)
                return True;
        return False;
    
    def next_frame(self):
        topicCL, msgCL, tCL = next(self.iL)
        if self.last == None:
            self.last = next(self.iR)
        topicCR, msgCR, tCR = self.last
        topicP, msgP, tP = next(self.iP)
        
        maxi = (1/12)
        
        #if tCL.to_sec()-tCR.to_sec() > maxi:
        #    topicCR, msgCR, tCR = next(self.iR)
        #if tCL.to_sec()-tCR.to_sec() > maxi:
        #    topicCR, msgCR, tCR = next(self.iR)
        #if tCR.to_sec()-tCL.to_sec() > maxi:
        #    topicCL, msgCL, tCL = next(self.iL)
        
        
        maxi2 = (1/11)
        maxi3 = (1/12)
        maxi4 = 1.0/12
        #print(tP.to_sec()-tCL.to_sec())
        #print(maxi4)
        if tCL.to_sec()-tP.to_sec() > maxi:
            topicP, msgP, tP = next(self.iP)
            self.last = next(self.iR)
            
        if tP.to_sec()-tCL.to_sec() > maxi4:
            topicCL, msgCL, tCL = next(self.iL)
            #topicCR, msgCR, tCR = next(self.iR)
        #print(tP.to_sec()-tCR.to_sec())
        if tP.to_sec()-tCR.to_sec() > maxi2:
            self.last = next(self.iR)
            
            
        topicCR, msgCR, tCR = self.last
            
        
        
        """elif tCL.to_sec()-tP.to_sec() < maxi:
            print("cl < p")
            topicCL, msgCL, tCL = next(self.iL)
            topicCR, msgCR, tCR = next(self.iR)"""
                
        
        

        self.CLData = msgCL.data
        self.pil_img_left = PIL.Image.frombuffer("RGB", self.size, self.CLData, decoder_name='raw')#.rotate(180)
        #self.pil_img = self.pil_img.transpose(PIL.Image.FLIP_LEFT_RIGHT)
        self.pil_img_left = self.pil_img_left.transpose(PIL.Image.FLIP_TOP_BOTTOM)
        
        self.CRData = msgCR.data
        self.pil_img_right = PIL.Image.frombuffer("RGB", self.size, self.CRData, decoder_name='raw')#.rotate(180)
        #self.pil_img = self.pil_img.transpose(PIL.Image.FLIP_LEFT_RIGHT)
        self.pil_img_right = self.pil_img_right.transpose(PIL.Image.FLIP_TOP_BOTTOM)
        
        self.IPData = msgP.data
        
        
    def getName(self):
        n = 6
        x = self.i
        y = n-len(str(self.i))
        i = ""
        for o in range(y):
            i = i + "0"
        #print("save image "+str(self.i))
        return i+str(self.i)
    
    def getNum(self,ii):
        n = 6
        x = ii
        y = n-len(str(ii))
        i = ""
        for o in range(y):
            i = i + "0"
        #print("save image "+str(self.i))
        return i+str(ii)
        
    def save(self):
        path = ""
        p = self.path.split("/")[0:-1]
        name = self.path.split("/")[-1]
        name = name.split(".")[0]
        
        for folder in p:
            path = path +folder+"/"
        npath = path+name+"_output"
        
        #print(path,npath,name)
        
        if SAVE:
            if not os.path.exists(npath):
                os.makedirs(npath)
            self.pil_img_left.save(npath+"/"+self.getName()+"l.png")
            #print "save image@"+path+"output/"+self.getName()+"l.png"
            self.pil_img_right.save(npath+"/"+self.getName()+"r.png")
            #print "save image@"+path+"output/"+self.getName()+"r.png"
        
        
        
        if saveSingle:
            if not os.path.exists(npath+"_cones"):
                os.makedirs(npath+"_cones")
            i = 0
            for cone in self.ConesL:
                coords = cone.getBB()
                imgCL = self.pil_img_left.crop(coords)
                imgCL.resize(singleSize)
                imgCL.save(npath+"_cones/"+self.getName()+"l-Cone"+self.getNum(i)+".png")
                i = i + 1
        
        
        NEntr = 7
        colors = ["red","#99DDFF","yellow"]
        info = ""
        
        self.ConesL = []
        self.ConesR = []
        
        for cone in range(int(len(self.IPData)/NEntr)):
            # LINKS:
            camLX = int(self.IPData[cone*NEntr+0])
            camLY = SIZE[1]-self.IPData[cone*NEntr+1]
            camRX = int(self.IPData[cone*NEntr+2])
            camRY= SIZE[1]-self.IPData[cone*NEntr+3]
            x = self.IPData[cone*NEntr+4]
            y = self.IPData[cone*NEntr+5]
            color = colors[self.IPData[cone*NEntr+6]]
            
            #width = width*multW
            #height = width*multH
            
            
            
            width = int(sclX*x*scl)
            height = int(sclY*x*scl)
            
            camLY = int(camLY-(height/2)*0.7)
            camRY = int(camRY-(height/2)*0.7)
            
            
            if width>minW:
                info = info + "l " + str(camLX) + " " + str(camLY) + " "  + str(width) + " "  + str(height)+" "+color+"\n"
                info = info + "r " + str(camRX) + " " + str(camRY) + " "  + str(width) + " "  + str(height)+" "+color+"\n"
                
            self.ConesL.append(Cone(camLX,camLY,width,height,color))
            self.ConesR.append(Cone(camRX,camRY,width,height,color))
            
        if SAVE:
            f = open(npath+"/"+self.getName()+".pixinfo","w")
            #print(self.getName())
            f.write(info)
            f.close()
        
        self.i = self.i+1
        
        
    def __del__(self):
        self.bag.close()
        
class Frame():
    def __init__(self):
        self.bag = Bag()
        self.root = Tkinter.Tk()
        self.root.bind("<Right>",self.convert)
        
        self.CL = Tkinter.Canvas(self.root,width=1280,height=500)
        self.CL.grid(row=0,column=0)
        self.stkiL = None
        
        self.CR = Tkinter.Canvas(self.root,width=1280,height=500)
        self.CR.grid(row=1,column=0)
        self.stkiR = None
        
        self.CoL = []
        self.CoR = []
        
        self.start = time.time()
        
        
    def convert(self,e):
        self.start = time.time()
        
        self.bag.next_frame()
        self.bag.save()
        
        if self.stkiL != None:
            self.CL.delete(self.stkiL)
        self.tkiL = PIL.ImageTk.PhotoImage(self.bag.pil_img_left)
        self.stkiL = self.CL.create_image(SIZE[0]/2,SIZE[1]/2,image=self.tkiL)
        
        if self.stkiR != None:
            self.CR.delete(self.stkiR)
        self.tkiR = PIL.ImageTk.PhotoImage(self.bag.pil_img_right)
        self.stkiR = self.CR.create_image(SIZE[0]/2,SIZE[1]/2,image=self.tkiR)
        
        # draw bbox
        for cone in self.CoL:
            self.CL.delete(cone)
        for cone in self.bag.ConesL:
            x1 = cone.x-cone.w/2
            x2 = cone.x+cone.w/2
            y1 = cone.y-cone.h/2
            y2 = cone.y+cone.h/2
            self.CoL.append(self.CL.create_rectangle(x1,y1,x2,y2,fill="",outline=cone.color,width=bd))
            
        # draw bbox
        for cone in self.CoR:
            self.CR.delete(cone)
        for cone in self.bag.ConesR:
            x1 = cone.x-cone.w/2
            x2 = cone.x+cone.w/2
            y1 = cone.y-cone.h/2
            y2 = cone.y+cone.h/2
            self.CoR.append(self.CR.create_rectangle(x1,y1,x2,y2,fill="",outline=cone.color,width=bd))
            
        if not user_control:
            t = round(time.time()-self.start,2)
            print "Frame:",self.bag.getName(),"Time (sec):",t
            self.root.after(int(TIME_WAIT*1000),self.convert,[None])
            
        
    def loop(self):
        self.root.after(50,self.convert,[None])
        self.root.mainloop()
        


def main():
    frame = Frame()
    frame.loop()
    
main()
    
