
#include "MessageListener.h"
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <hphlib/Distance.h>

MessageListener::MessageListener(ros::NodeHandle& n) : runner_("distance_tracker"),
                                                       vehicle_mon_(n),
                                                       topic_output_(getRequiredRosParam<std::string>(n, "topic_output_distance"))
{
    distance_publisher_ = n.advertise<hphlib::Distance>(topic_output_, 1);

    // register vehicle status callbacks
    vehicle_mon_.set_ready_callback([&] () {
        distance_driven = 0;
        firstUpdate = true;
    });
}


float magnitudeOfVector(const geometry_msgs::Vector3& vector) {
    return static_cast<float>(std::sqrt(vector.x * vector.x + vector.y * vector.y));
}

void MessageListener::reset_distance() {
    distance_driven = 0;
    firstUpdate = false;
}

void MessageListener::odometryCallback(const nav_msgs::Odometry::ConstPtr &msg) {

    ros::Time current_timestamp = msg->header.stamp;

    // skip on first update
    if (firstUpdate) {
        last_timestamp = current_timestamp;
        reset_distance();
        return;
    }

    // calculate time difference
    double timeDelta = (current_timestamp - last_timestamp).toSec();

    // reset if time delta not plausible
    if (timeDelta < -10) {
        last_timestamp = current_timestamp;
        reset_distance();
        return;
    }

    //calculate distance between frames
    auto distance = magnitudeOfVector(msg->twist.twist.linear) * timeDelta;

    distance_driven += distance;

    // create distance message
    hphlib::Distance distance_msg;
    distance_msg.header.stamp = current_timestamp;
    distance_msg.distance = static_cast<float>(distance_driven);

    distance_publisher_.publish(distance_msg);

    runner_.report("dist", distance_driven);

    last_timestamp = current_timestamp;
}
