#pragma once
#include <hphlib/util.h>
#include <telemetry/Runner.h>
#include <nav_msgs/Odometry.h>
#include <hphlib/vehicle/StatusMonitor.h>

class MessageListener {
private:
    telemetry::Runner runner_;
    bool firstUpdate = true;

    void reset_distance();

public:

    MessageListener(ros::NodeHandle &n);

    hphlib::vehicle::StatusMonitor vehicle_mon_;

    ros::Publisher distance_publisher_;

    ros::Time last_timestamp;
    std::string topic_output_;

    double distance_driven;

    void odometryCallback(const nav_msgs::Odometry::ConstPtr &msg);


};