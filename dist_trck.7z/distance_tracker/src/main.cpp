#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <nav_msgs/Odometry.h>
#include "MessageListener.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "distance_tracker");

    ros::NodeHandle n("~");

    std::string topic_odometry = getRequiredRosParam<std::string>(n, "topic_odometry");

    MessageListener listener(n);

    auto odometry_sub = n.subscribe<nav_msgs::Odometry>(
            topic_odometry,
            1,
            &MessageListener::odometryCallback,
            &listener
    );

    ros::spin();

    return EXIT_SUCCESS;
}
