namespace cpp validation_rpc

struct Capabilities {
    1: i32 height,
    2: i32 width,
    3: i32 channels
}

service ValidationService {
    list<i32> classify(1: binary batch),
    Capabilities capabilities()
}