#include "Decompressor.h"
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <sensor_msgs/Image.h>

Decompressor::Decompressor(ros::NodeHandle &n, const std::string &in_topic, const std::string &out_topic)
    : sub_(n.subscribe<sensor_msgs::CompressedImage>(in_topic, 1, &Decompressor::callback, this))
    , pub_(n.advertise<sensor_msgs::Image>(out_topic, 1))
{
}

void Decompressor::callback(const sensor_msgs::CompressedImage::ConstPtr& msg) {
    cv::Mat mat = cv::imdecode(msg->data, CV_LOAD_IMAGE_COLOR);
    cv_bridge::CvImage img(msg->header, sensor_msgs::image_encodings::BGR8, mat);
    pub_.publish(img.toImageMsg());
}
