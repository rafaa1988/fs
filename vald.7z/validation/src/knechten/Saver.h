#pragma once

#include <string>
#include <boost/filesystem/path.hpp>
#include <opencv2/core/mat.hpp>
#include <validation/shared/Classification.h>

class Saver {
private:
    boost::filesystem::path root_;
    boost::filesystem::path export_main_;
    size_t index_;

public:
    explicit Saver(const std::string& export_root);

    void exportImg(validation::Classification clazz, const cv::Mat& img);

    void setBag(const std::string& bag_path);
};
