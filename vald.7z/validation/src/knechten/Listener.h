#pragma once

#include <hphlib/misc/CloudToCameraTransformer.h>
#include <validation/shared/Classifier.h>
#include "Saver.h"

class Listener {

    Saver& saver_;

    size_t image_counter_;

    std::unique_ptr<validation::Classifier> classifier_;

    cv::Mat drawWindow(const cv::Mat& cone_img, const std::string& predict);

public:
    explicit Listener(Saver& saver, std::unique_ptr<validation::Classifier> classifier);

    void callback(hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform transform);

    size_t imageCounter() const;
};