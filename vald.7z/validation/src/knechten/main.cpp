#include <boost/program_options.hpp>
#include <ros/ros.h>
#include <hphlib/misc/FastPlayback.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud2.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include "Listener.h"
#include "Decompressor.h"
#include "Saver.h"
#include <validation/shared/classifiers/FrugallyClassifier.h>

int main(int argc, char** argv) {

    bool show_help = false;
    int export_size = 32;

    boost::program_options::options_description desc("Options");

    std::string out_path;
    std::string model;
    std::vector<std::string> bags;

    desc.add_options()
            ("help,h", boost::program_options::bool_switch(&show_help), "Show help")
            ("out,o", boost::program_options::value<std::string>(&out_path)->required(), "Path to output folder")
            ("bag,b", boost::program_options::value<std::vector<std::string>>(&bags)->required(), "Bag files to read")
            ("size", boost::program_options::value<int>(&export_size), "Export width and height in pixels")
            ("model", boost::program_options::value<std::string>(&model), "Optional model to show classification");

    // Treat all positional arguments as bag argument
    boost::program_options::positional_options_description positional;
    positional.add("bag", -1);

    boost::program_options::variables_map vm;

    try {
        boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(desc).positional(positional).run(), vm);

        if (show_help) {
            std::cout << "Usage: " << argv[0] << " OPTIONS BAG1 [BAG2 [..]]\n" << desc;
            return EXIT_SUCCESS;
        }

        boost::program_options::notify(vm);
    } catch (const std::exception& e) {
        std::cerr << "Error parsing arguments: " << e.what() << "\n";
        return EXIT_FAILURE;
    }

    ros::init(argc, argv, "manual_classify");
    std::shared_ptr<ros::NodeHandle> nh = std::make_shared<ros::NodeHandle>("~");

    std::unique_ptr<validation::classifiers::FrugallyClassifier> classifier;

    if (!model.empty()) {
        classifier = std::make_unique<validation::classifiers::FrugallyClassifier>(model);
    }

    Saver saver(out_path);

    Listener listener(saver, std::move(classifier));

    // Set up camera transformer
    hphlib::CloudToCameraTransformer<pcl::PointXYZ> left_transformer(
            *nh,
            "/master/image_raw",
            "/master/camera_info",
            "/lidar/DetectL/cones",
            [&listener] (auto transform) {
                listener.callback(std::move(transform));
            },
            true
    );

    hphlib::CloudToCameraTransformer<pcl::PointXYZ> right_transformer(
            *nh,
            "/slave1/image_raw",
            "/slave1/camera_info",
            "/lidar/DetectR/cones",
            [&listener] (auto transform) {
                listener.callback(std::move(transform));
            },
            true
    );

    Decompressor left_decompressor{*nh, "/master/compressed", "/master/image_raw"};
    Decompressor right_decompressor{*nh, "/slave1/compressed", "/slave1/image_raw"};

    hphlib::FastPlayback playback(nh);

    playback.addTopic<sensor_msgs::CompressedImage>("/master/compressed");
    playback.addTopic<sensor_msgs::CompressedImage>("/slave1/compressed");
    playback.addTopic<sensor_msgs::CameraInfo>("/master/camera_info");
    playback.addTopic<sensor_msgs::CameraInfo>("/slave1/camera_info");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_left/ibeo_layer_0");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_left/ibeo_layer_1");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_left/ibeo_layer_2");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_left/ibeo_layer_3");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_right/ibeo_layer_0");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_right/ibeo_layer_1");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_right/ibeo_layer_2");
    playback.addTopic<sensor_msgs::LaserScan>("/ibeo_lux_right/ibeo_layer_3");
    playback.addTopic<sensor_msgs::PointCloud2>("/ibeo_lux_left/ibeo_pointcloud");
    playback.addTopic<sensor_msgs::PointCloud2>("/ibeo_lux_right/ibeo_pointcloud");
    playback.addTopic<tf2_msgs::TFMessage>("/tf_static");

    try {

        for (const auto &bag_path : bags) {
            std::cerr << "Reading " << bag_path << "...\n";

            saver.setBag(bag_path);

            rosbag::Bag bag(bag_path);

            playback.play(bag);
        }
    } catch (...) {
        // At least output image counter on crashes so that training can be resumed
        ROS_WARN_STREAM("Unrecoverable error, image counter was " << listener.imageCounter());
        throw;
    }
}