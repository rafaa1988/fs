#include "Saver.h"

#include <iostream>
#include <boost/filesystem/operations.hpp>
#include <opencv2/imgcodecs.hpp>
#include <sstream>
#include <regex>
#include <boost/range/iterator_range.hpp>

using namespace boost::filesystem;
using validation::Classification;

size_t findLowestAvailableConeNumber(const std::string &folder) {

    std::regex re("([0-9]+)\\.jpg");
    std::cmatch m;

    size_t result = 0;

    // If directory doe snot exist, start at 0
    if (!boost::filesystem::exists(folder)) {
        return 0;
    }

    for (const auto& entry : boost::make_iterator_range(boost::filesystem::recursive_directory_iterator(folder))) {

        std::string file_name = static_cast<boost::filesystem::path>(entry).filename().string();

        if (std::regex_match(file_name.c_str(), m, re)) {
            size_t no = std::stoull(m[1]);

            result = std::max(result, no + 1);
        }

    }

    return result;
}

const char* folderName(Classification clazz) {
    switch (clazz) {
        case Classification::Blue:
            return "blue";
        case Classification::Red:
            return "red";
        case Classification::Yellow:
            return "yellow";
        case Classification::Finish:
            return "finish";
        case Classification::None:
            return "nocone";
        default:
            throw std::logic_error("Unknown classification");
    }
}

Saver::Saver(const std::string &export_root)
    : root_(export_root)
{
}

void Saver::setBag(const std::string &bag_path) {
    path bag(bag_path);

    export_main_ = root_ / path(bag_path).filename();

    // Reset index
    index_ = findLowestAvailableConeNumber(export_main_.string());

    std::cout << "Starting with cone " << index_ << std::endl;

    // Create all subdirectories
    create_directories(export_main_ / folderName(Classification::None));
    create_directories(export_main_ / folderName(Classification::Blue));
    create_directories(export_main_ / folderName(Classification::Red));
    create_directories(export_main_ / folderName(Classification::Yellow));
    create_directories(export_main_ / folderName(Classification::Finish));

    std::cerr << "Exporting to " << export_main_ << "\n";
}

void Saver::exportImg(Classification clazz, const cv::Mat &img) {

    std::stringstream filename;
    filename << index_++ << ".jpg";

    auto export_path = export_main_ / folderName(clazz) / filename.str();

    std::cerr << "Saving to " << export_path << "\n";

    if (!cv::imwrite(export_path.string(), img)) {
        throw std::runtime_error("Failed to save image " + export_path.string());
    }
}
