#include "Listener.h"
#include <validation/shared/shared.h>

#include <cv_bridge/cv_bridge.h>
#include <opencv2/highgui.hpp>

using validation::Classification;

cv::Mat Listener::drawWindow(const cv::Mat& cone_img, const std::string& predict) {

    cv::Scalar black  {  0.0f,   0.0f,   0.0f};
    cv::Scalar blue   {255.0f,   0.0f,   0.0f};
    cv::Scalar gray   { 50.0f,  50.0f,  50.0f};
    cv::Scalar red    {  0.0f,   0.0f, 255.0f};
    cv::Scalar white  {255.0f, 255.0f, 255.0f};
    cv::Scalar yellow {  0.0f, 255.0f, 255.0f};

    cv::Mat window(300, 500, CV_8UC3, { 50.0f, 50.0f, 50.0f});

    cv::rectangle(window, { 10, 180, 120, 50}, white, CV_FILLED);
    cv::rectangle(window, {140, 180, 120, 50}, black, CV_FILLED);
    cv::rectangle(window, {270, 180, 120, 50}, red, CV_FILLED);
    cv::rectangle(window, { 10, 240, 120, 50}, yellow, CV_FILLED);
    cv::rectangle(window, {140, 240, 120, 50}, blue, CV_FILLED);
    cv::rectangle(window, {270, 240, 120, 50}, red, CV_FILLED);

    cv::putText(window, "(U) Skip",    { 20, 210}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, black, 1, cv::LINE_AA);
    cv::putText(window, "(I) No cone", {150, 210}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);
    cv::putText(window, "(O) Finish",  {280, 210}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);

    cv::putText(window, "(J) Yellow",  { 20, 270}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, black, 1, cv::LINE_AA);
    cv::putText(window, "(K) Blue",    {150, 270}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);
    cv::putText(window, "(L) Red",     {280, 270}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);

    cv::Mat cone_copy = cone_img;
    cv::resize(cone_copy, cone_copy, {150, 150});
    cv::Mat cone_dst = window({10, 10, 150, 150});
    cone_copy.copyTo(cone_dst);

    std::stringstream ctr_text;
    ctr_text << "Img counter: " << image_counter_;
    cv::putText(window, ctr_text.str(), {300, 25}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);
    cv::putText(window, predict,        {300, 50}, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.7f, white, 1, cv::LINE_AA);

    return window;
}

Listener::Listener(Saver &saver, std::unique_ptr<validation::Classifier> classifier)
    : saver_(saver)
    , image_counter_(0)
    , classifier_(std::move(classifier))
{
}

void Listener::callback(hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform transform) {

    image_counter_++;


    pcl::PointCloud<pcl::PointXYZRGBA> out_cloud_input_frame;
    out_cloud_input_frame.header.frame_id = transform.cloud->header.frame_id;

    auto share = cv_bridge::toCvShare(transform.image, "bgr8");

    cv::Mat in_image_bgr(share->image);
    cv::imshow("Voll", in_image_bgr);

    for (size_t i = 0; i < transform.transforms.size(); ++i) {

        const cv::Rect2d& target(transform.transforms[i].projectedBox);

        cv::Mat cropped_image = validation::extractSubImage(in_image_bgr, transform, i);

        if (cropped_image.empty()) {
            continue;
        }

        std::string predict;

        if (classifier_) {
            std::vector<cv::Mat> batch = {cropped_image.clone()};
            predict = std::string("Prediction: ") + decodeClassification(classifier_->classify_batch(batch)[0]);
        }

        const char* WND_NAME = "Bild";

        bool stop;

        boost::optional<Classification> classification;

        do {

            cv::imshow(WND_NAME, drawWindow(cropped_image, predict));

            stop = true;

            int key = cv::waitKey(10);

            if (key == 'j') {
                classification = Classification::Yellow;
            } else if (key == 'k') {
                classification = Classification::Blue;
            } else if (key == 'l') {
                classification = Classification::Red;
            } else if (key == 'u') {
                // Skip...
            } else if (key == 'i') {
                classification = Classification::None;
            } else if (key == 'o') {
                classification = Classification::Finish;
            } else if (key == 'f') {
                // Fast skip, super secret
                return;
            } else if (key == 'q') {
                // Goodbye, cruel world
                std::exit(EXIT_SUCCESS);
            } else {
                stop = false;
            }

        } while (!stop);

        if (classification) {
            // Export the original image
            saver_.exportImg(*classification, cropped_image);

            // Augment data by translating target rectangle
            double stride = target.width * 0.06;

            std::vector<cv::Point2d> offsets = {
                    { stride, 0},
                    {-stride, 0},
                    {0, stride},
                    {0, -stride}
            };

            for (const auto& offset : offsets) {
                cv::Rect2d new_target(target.x + offset.x, target.y + offset.y, target.width, target.height);

                auto sub_img = validation::extractSubImage(in_image_bgr, new_target);

                if (!sub_img.empty()) {
                    saver_.exportImg(*classification, sub_img);
                }
            }
        }
    }
}

size_t Listener::imageCounter() const {
    return image_counter_;
}
