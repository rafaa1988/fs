#pragma once

#include <ros/ros.h>
#include <sensor_msgs/CompressedImage.h>

class Decompressor {
private:
    ros::Subscriber sub_;
    ros::Publisher pub_;

public:
    Decompressor(ros::NodeHandle& n, const std::string& in_topic, const std::string& out_topic);

    // Binding this, do not move or copy
    Decompressor(const Decompressor& that) = delete;
    Decompressor& operator=(const Decompressor& that) = delete;

    void callback(const sensor_msgs::CompressedImage::ConstPtr& msg);
};
