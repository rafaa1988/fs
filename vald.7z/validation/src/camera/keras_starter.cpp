#include <hphlib/util.h>
#include <ros/ros.h>
#include <validation/shared/KerasDaemon.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "keras starter");

    ros::NodeHandle n("~");

    std::string model  = getRequiredRosParam<std::string>(n, "model");
    uint16_t port      = getRequiredRosParamPort(n, "port");

    validation::KerasDaemon daemon(n, model.c_str(), port, false /* Don't ignore GPU for validation */);

    ros::spin();
}