#include "MessageListener.h"
#include <validation/shared/shared.h>
#include <cv_bridge/cv_bridge.h>
#include <hphlib/pcl.h>
#include <hphlib/util.h>
#include <opencv/cv.h>
#include <ros/ros.h>

MessageListener::MessageListener(const std::string& publisher_3d_topic, ros::NodeHandle& node,
                                 std::unique_ptr<validation::Classifier> classifier)
    : publisher_3d_(node.advertise<pcl::PointCloud<pcl::PointXYZRGBA>>(publisher_3d_topic, 1))
    , classifier_(std::move(classifier))
    , tele_(getRequiredRosParam<std::string>(node, "tele_node"))
    , debug_export_(false)
{
    node.getParam("debug_export", debug_export_);

    if (debug_export_) {
        debug_ns_ = node.getNamespace();

        for (char& c : debug_ns_) {
            if (c == '/') {
                c = '_';
            }
        }
    }
}

template <typename T, typename Alloc>
void deleteSwapAndPop(std::vector<T, Alloc> &vec, size_t index) {
    std::swap(vec[index], vec.back());
    vec.pop_back();
}

void MessageListener::callback(hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform transform) {
    tele_.reportProcessingTime([&] () {
        // Copy input cloud to allow filtering, input cloud must not be used afterwards
        pcl::PointCloud<pcl::PointXYZ> filtered_candidates;
        pcl::copyPointCloud(*transform.cloud, filtered_candidates);

        auto share = cv_bridge::toCvShare(transform.image, "bgr8");

        const cv::Mat in_image_bgr(share->image);

        // Extract all sub images for the projected boxes, sub images may be empty if they do not have
        // sufficient overlap with camera image
        std::vector<cv::Mat> sub_images;
        sub_images.reserve(transform.transforms.size());

        for (size_t i = 0; i < transform.transforms.size(); ++i) {
            sub_images.push_back(validation::extractSubImage(in_image_bgr, transform, i));
        }

        // Clear empty images from sub images, input candidates copy and transforms such that all indices match
        // after deleting
        for (size_t i = 0; i < sub_images.size(); ++i) {
            if (sub_images[i].empty()) {
                deleteSwapAndPop(sub_images, i);
                deleteSwapAndPop(transform.transforms, i);
                deleteSwapAndPop(filtered_candidates.points, i);
                --i;
            }
        }

        // Classify result
        auto classifications = classifier_->classify_batch(sub_images);

        // If debug exporting, debug export
        if (debug_export_) {
            for (size_t i = 0; i < classifications.size(); ++i) {
                std::stringstream path;
                path << "/tmp/" << debug_ns_ << "_" << transform.image->header.seq << "_" << i << "_"
                     << decodeClassification(classifications[i]) << ".png";

                cv::imwrite(path.str(), sub_images[i]);
            }
        }

        // Reduce result to point cloud, filtering no cone classifications
        pcl::PointCloud<pcl::PointXYZRGBA> out_cloud_input_frame;
        // Copy all the headers but no points
        pcl::copyPointCloud(filtered_candidates, std::vector<int>{}, out_cloud_input_frame);

        for (size_t i = 0; i < classifications.size(); ++i) {
            if (classifications[i] != validation::Classification::None) {
                out_cloud_input_frame.push_back(
                        pointWithColor(filtered_candidates[i], classificationRefColor(classifications[i])));
            }
        }

        publisher_3d_.publish(out_cloud_input_frame);
    });
}
