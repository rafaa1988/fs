#include <ros/ros.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <hphlib/util.h>
#include "MessageListener.h"
#include "MultiPassMessageListener.h"
#include <validation/shared/classifiers/FrugallyClassifier.h>
#include <validation/shared/classifiers/ExternalKerasClassifier.h>

void run_main(ros::NodeHandle& n) {
    bool use_multi_pass             = getRequiredRosParam<bool>(n, "multi_pass");
    std::string topic_image         = getRequiredRosParam<std::string>(n, "topic_image");
    std::string topic_info          = getRequiredRosParam<std::string>(n, "topic_info");
    std::string topic_candidates    = getRequiredRosParam<std::string>(n, "topic_candidates");
    std::string topic_publish_3d    = getRequiredRosParam<std::string>(n, "topic_publish_3d");
    std::string selected_classifier = getRequiredRosParam<std::string>(n, "classifier");

    std::unique_ptr<validation::Classifier> classifier;

    if (selected_classifier == "frugally") {
        classifier = std::make_unique<validation::classifiers::FrugallyClassifier>(n);
    } else if (selected_classifier == "keras") {
        classifier = std::make_unique<validation::classifiers::ExternalKerasClassifier>(n);
    } else {
        throw std::runtime_error("Unsupported classifier: " + selected_classifier);
    }

    if (use_multi_pass) {

        size_t max_validations = getRequiredRosParam<int, size_t>(n, "multi_pass_validations");
        std::string tele_node = getRequiredRosParam<std::string>(n, "tele_node");

        MultiPassMessageListener listener(n, topic_image, topic_info, topic_candidates, topic_publish_3d,
                                          std::move(classifier), max_validations, tele_node);

        ros::spin();
    } else {
        MessageListener listener(topic_publish_3d, n, std::move(classifier));

        hphlib::CloudToCameraTransformer<pcl::PointXYZ> transformer(n, topic_image, topic_info, topic_candidates,
                                                                    [&listener](auto transform) {
                                                                        listener.callback(std::move(transform));
                                                                    }, true);

        ros::spin();
    }
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "validation camera");
    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }
}
