#include "MultiPassMessageListener.h"
#include <cv_bridge/cv_bridge.h>
#include <image_geometry/pinhole_camera_model.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <validation/shared/shared.h>
#include <validation/shared/Classification.h>
#include <hphlib/optional.h>

#define x_assert(x) if (!(x)) {throw std::runtime_error(std::string("Assertion failed: ") + #x);}

MultiPassMessageListener::MultiPassMessageListener(ros::NodeHandle &n, const std::string &topic_img,
                                                   const std::string &topic_info, const std::string &topic_pcl,
                                                   const std::string& topic_publish_3d,
                                                   std::unique_ptr<validation::Classifier>&& classifier,
                                                   size_t max_validations, const std::string& tele_node)
    : img_sub_(n, topic_img, 2)
    , info_sub_(n, topic_info, 2)
    , pcl_sub_(n, topic_pcl, 2)
    , synchronizer_(SYNC(10), img_sub_, info_sub_, pcl_sub_)
    , classifier_(std::move(classifier))
    , pub_(n.advertise<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_publish_3d, 1))
    , distribution_(-0.15f, 0.15f)
    , max_validations_(max_validations)
    , runner_(tele_node)
{
    synchronizer_.registerCallback(&MultiPassMessageListener::callback, this);
}

void MultiPassMessageListener::callback(const sensor_msgs::Image::ConstPtr &img,
                                       const sensor_msgs::CameraInfo::ConstPtr &info,
                                       const pcl::PointCloud<pcl::PointXYZ>::ConstPtr &pcl) {

    runner_.reportProcessingTime([&] () {

        // Create output cloud by copying input without points
        pcl::PointCloud<pcl::PointXYZRGBA> out_cloud{};
        pcl::copyPointCloud(*pcl, std::vector<int>{}, out_cloud);

        // If no input, stop immediately
        if (pcl->empty()) {
            pub_.publish(out_cloud);
            return;
        }

        // Create OpenCV image from camera image for maximum computer vision
        auto share = cv_bridge::toCvShare(img, "bgr8");
        const cv::Mat in_image_bgr(share->image);

        // Create camera model to project
        image_geometry::PinholeCameraModel camera_model;
        camera_model.fromCameraInfo(info);

        size_t maximum_individual_validations = 4;
        size_t maximum_total_misses = max_validations_;

        std::vector<cv::Mat> images;
        std::vector<std::vector<size_t>> indices(pcl->size(), std::vector<size_t>{});

        pcl::PointCloud<pcl::PointXYZRGBA> debug_cloud;
        pcl::copyPointCloud(*pcl, std::vector<int>{}, debug_cloud);

        size_t total_misses = 0;

        for (size_t point_index = 0;
                images.size() < max_validations_ && total_misses < maximum_total_misses;
                point_index = (point_index + 1) % pcl->size()) {

            size_t sub_images_for_point = indices[point_index].size();

            // Break as soon as the first point would exceed the allowed amount of individual validations
            // so we don't validate the same point excessively often
            if (sub_images_for_point > maximum_individual_validations) {
                break;
            }

            const auto& pcl_pt(pcl->points[point_index]);

            // Create stamped point that is candidate in pcl coordinates
            tf::Stamped<tf::Point> stamped_pt {
                    {pcl_pt.x, pcl_pt.y, pcl_pt.z},
                    pcl_conversions::fromPCL(pcl->header.stamp),
                    pcl->header.frame_id
            };

            // If more than one image already exists, add random offset to increase quality of classification
            if (sub_images_for_point > 0) {
                stamped_pt.m_floats[0] += distribution_(engine_);
                stamped_pt.m_floats[1] += distribution_(engine_);
            }

            // Span rectangle on camera image, may throw lookup error if no tf data available yet
            cv::Rect target;
            try {
                target = hphlib::spanRectangle(stamped_pt, hphlib::CLOUD_TO_CAMERA_DEFAULT_BOX_SIZE, camera_model,
                                               tf_listener_);
            } catch (const tf::LookupException& ex) {
                ROS_WARN_STREAM("Failed to span rectangle on camera image: " << ex.what());
                return;
            }

            // Try to extract sub image, may be partially reflected etc. or empty if completely unsuitable
            auto sub_img = validation::extractSubImage(in_image_bgr, target);

            // If empty, this was a miss, continue with the next point
            if (sub_img.empty()) {
                total_misses++;
                continue;
            }

            debug_cloud.push_back(pointWithColor({static_cast<float>(stamped_pt.m_floats[0]),
                                                  static_cast<float>(stamped_pt.m_floats[1]),
                                                  static_cast<float>(stamped_pt.m_floats[2])}, hphlib::LIDAR_COLOR_DIRT));
            indices[point_index].push_back(images.size());
            images.push_back(std::move(sub_img));
        }

        // Classify sub images
        auto classifications = classifier_->classify_batch(images);

        for (size_t i = 0; i < pcl->size(); ++i) {

            const auto& sub_indices(indices[i]);

            // If this point has not been classified, i.e. because it was invalid, skip it
            if (sub_indices.empty()) {
                continue;
            }

            bool first = true;
            validation::Classification last_classification = validation::Classification::None;

            for (auto classification_index : sub_indices) {
                // A classifier may return less results, ensure we are not out of bounds
                if (classification_index >= classifications.size()) {
                    continue;
                }

                auto clazz = classifications[classification_index];

                if (clazz != validation::Classification::None) {
                    debug_cloud.points[classification_index].rgba = validation::classificationRefColor(clazz);
                }

                // If a classification already exists but the next mismatches, invalidate by setting to empty and breaking
                if (!first && last_classification != clazz) {
                    last_classification = validation::Classification::None;
                    break;
                }

                last_classification = clazz;
                first = false;
            }

            if (last_classification != validation::Classification::None) {
                out_cloud.push_back(pointWithColor(pcl->points[i], validation::classificationRefColor(last_classification)));
            }
        }

        pub_.publish(out_cloud);
    });
}
