#pragma once

#include <hphlib/pcl.h>
#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <telemetry/Runner.h>
#include <tf/transform_listener.h>
#include <validation/shared/Classifier.h>

class MultiPassMessageListener {
private:
    using SYNC = message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::CameraInfo, pcl::PointCloud<pcl::PointXYZ>>;

    tf::TransformListener tf_listener_;

    message_filters::Subscriber<sensor_msgs::Image> img_sub_;
    message_filters::Subscriber<sensor_msgs::CameraInfo> info_sub_;
    message_filters::Subscriber<pcl::PointCloud<pcl::PointXYZ>> pcl_sub_;
    message_filters::Synchronizer<SYNC> synchronizer_;

    std::unique_ptr<validation::Classifier> classifier_;

    ros::Publisher pub_;

    std::mt19937 engine_;
    std::uniform_real_distribution<float> distribution_;

    size_t max_validations_;

    telemetry::Runner runner_;

    void callback(const sensor_msgs::Image::ConstPtr& img, const sensor_msgs::CameraInfo::ConstPtr& info, const pcl::PointCloud<pcl::PointXYZ>::ConstPtr& pcl);

public:
    MultiPassMessageListener(ros::NodeHandle& n, const std::string& topic_img, const std::string& topic_info,
                             const std::string& topic_pcl, const std::string& topic_publish_3d,
                             std::unique_ptr<validation::Classifier>&& classifier, size_t max_validations,
                             const std::string& tele_node);
};
