#pragma once

#include <sensor_msgs/Image.h>
#include <pcl_ros/point_cloud.h>
#include <validation/shared/Classifier.h>
#include <string>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <hphlib/ParallelizedProcessingService.h>
#include <hphlib/optional.h>
#include <telemetry/Runner.h>

class MessageListener {

    ros::Publisher publisher_3d_;
    tf::TransformListener tf_listener_;
    std::unique_ptr<validation::Classifier> classifier_;
    telemetry::Runner tele_;
    bool debug_export_;
    std::string debug_ns_;

public:

    MessageListener(const std::string& publisher_3d_topic, ros::NodeHandle& node, std::unique_ptr<validation::Classifier> classifier);

    void callback(hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform transform);
};
