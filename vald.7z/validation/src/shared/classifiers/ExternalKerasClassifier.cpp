#include <hphlib/util.h>
#include <hphlib/os.h>
#include <csignal>
#include <boost/filesystem/path.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <hphlib/io/Pipe.h>
#include <validation/shared/classifiers/ExternalKerasClassifier.h>

using validation::Classification;
using validation::classifiers::ExternalKerasClassifier;

ExternalKerasClassifier::ExternalKerasClassifier(ros::NodeHandle &n)
    : client_(getRequiredRosParam<std::string>(n, "keras_remote_host").c_str(),
              getRequiredRosParamPort(n, "keras_remote_port"))
{
}

std::vector<Classification> ExternalKerasClassifier::classify_batch(std::vector<cv::Mat> &images) {

    std::vector<Classification> result(images.size(), Classification::None);

    try {
        auto classes = client_.classify_batch(images);
        std::transform(classes.begin(), classes.end(), result.begin(), [] (auto x) { return static_cast<Classification>(x); });
        return result;
    } catch (const validation::KerasClient::ConnectionRefusedException& e) {
        ROS_WARN_STREAM("Failed to contact external classification service; not up");
        return result;
    }
}