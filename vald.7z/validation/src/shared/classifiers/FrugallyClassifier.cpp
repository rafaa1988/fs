#include <validation/shared/classifiers/FrugallyClassifier.h>

#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <hphlib/util.h>

using validation::Classification;
using validation::classifiers::FrugallyClassifier;

std::ostream& operator<<(std::ostream& str, const fdeep::shape3& s) {
    return str << "(" << s.width_ << ", " << s.height_ << ", " << s.depth_ << ")";
}

FrugallyClassifier::FrugallyClassifier(ros::NodeHandle &n)
        : FrugallyClassifier(getRequiredRosParam<std::string>(n, "frugally_model")) {}

FrugallyClassifier::FrugallyClassifier(const std::string &path)
        : model_(fdeep::load_model(path)), counter_(0) {
    auto shapes = model_.get_input_shapes();

    // If the model has more than one input shape I really don't know what that means, but for sure the input shape
    // cannot automatically be determined
    if (shapes.size() != 1) {
        std::stringstream stream;
        stream << "Expceted model to have 1 input shape, got " << shapes.size();
        throw std::runtime_error(stream.str());
    }

    shape_ = shapes.back();

    // Only support models that accept 3-channel images as input
    if (shape_->depth_ != 3) {
        std::stringstream stream;
        stream << "Expected model input shape to be of form (*, *, 3), got " << *shape_;
        throw std::runtime_error(stream.str());
    }

    ROS_INFO_STREAM("Initialized frugally classifier with model of shape " << *shape_);
}

std::vector<Classification> FrugallyClassifier::classify_batch(std::vector<cv::Mat> &images) {

    // Dynamically determine size of sub images based on model input shape
    cv::Size e_size(static_cast<int>(shape_->width_), static_cast<int>(shape_->height_));

    std::vector<Classification> result;
    result.reserve(images.size());

    for (auto& img : images) {

        // Resize cropped image to fit model
        cv::resize(img, img, e_size);

        // Debug: Dump image
        // std::stringstream path;
        // path << "/tmp/" << counter_++ << ".jpg";
        // cv::imwrite(path.str(), sub_img);

        // Keras models always use RGB, OpenCV uses BGR, do conversion
        cv::cvtColor(img, img, CV_BGR2RGB);

        // Create tensor from the raw BGR image bytes
        const auto input = fdeep::tensor3_from_bytes(img.ptr(), img.rows, img.cols, img.channels(),
                                                     0.0f, 255.0f);

        // Predict class, classification enum directly mapped to class indices, cast and push
        result.push_back(static_cast<Classification>(model_.predict_class({input})));
    }

    return result;
}