#include <hphlib/util.h>
#include <hphlib/os.h>
#include <csignal>
#include <boost/filesystem/path.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <hphlib/io/Pipe.h>
#include <validation/shared/KerasClient.h>
#include <ValidationService.h>

void validation::KerasClient::DeleteClient::operator()(validation_rpc::ValidationServiceClient* pt) const {
    delete pt;
}

void validation::KerasClient::DeleteCapabilities::operator()(validation_rpc::Capabilities* pt) const {
    delete pt;
}

validation::KerasClient::KerasClient(const char* host, uint16_t port)
    : sock_(std::make_shared<apache::thrift::transport::TSocket>(host, port))
    , transport_(std::make_shared<apache::thrift::transport::TBufferedTransport>(sock_))
    , protocol_(std::make_shared<apache::thrift::protocol::TBinaryProtocol>(transport_))
    , service_(new validation_rpc::ValidationServiceClient(protocol_))
{
}

void validation::KerasClient::ensureCapabilitiesKnown() {

    // If we do not know the capabilities of the external classifier yet, request them
    if (!caps_) {

        validation_rpc::Capabilities caps;

        try {
            transport_->open();
            service_->capabilities(caps);
        } catch (const apache::thrift::transport::TTransportException &e) {
            if (e.getType() == apache::thrift::transport::TTransportException::TTransportExceptionType::NOT_OPEN) {
                // "NOT_OPEN" is a poor description but will normally be connection refused
                throw ConnectionRefusedException();
            } else {
                throw;
            }
        }

        ROS_INFO_STREAM("External classifier reported capabilities: width="  << caps.width
                                                              << ", height=" << caps.height
                                                              << ", depth="  << caps.channels);

        if (caps.channels != 3) {
            throw std::runtime_error("Reported capabilities unsupported: depth != 3");
        }

        caps_.reset(new validation_rpc::Capabilities(caps));
    }
}

std::vector<uint32_t> validation::KerasClient::classify_batch(std::vector<cv::Mat> &images) {

    // Always ensure capabilities are known, this way ensure that the RPC service is available.
    // If we do not ensure availability, might create the false impression we are ready to operate when the RPC service
    // is down, simply because no images were present
    ensureCapabilitiesKnown();

    // If empty return without further work
    if (images.empty()) {
        return {};
    }

    cv::Size2i size(caps_->width, caps_->height);

    for (auto& img : images) {
        // Resize all image to required size for network
        cv::resize(img, img, size);

        // Keras models always use RGB, OpenCV uses BGR, do conversion
        cv::cvtColor(img, img, CV_BGR2RGB);
    }

    size_t size_per_image = static_cast<unsigned int>(caps_->width * caps_->height * caps_->channels);
    size_t expected_size  = static_cast<size_t>(size_per_image * images.size());

    // Insert all images into binary buffer
    std::string buf;
    buf.reserve(expected_size);

    for (const auto& img : images) {
        buf.insert(buf.end(), img.datastart, img.dataend);
    }

    // Perform classification
    std::vector<int32_t> classes;
    service_->classify(classes, buf);

    // Transform to unsigned ints
    std::vector<uint32_t> result;
    result.reserve(classes.size());
    std::transform(classes.begin(), classes.end(), std::back_inserter(result), [] (auto x) { return static_cast<uint32_t >(x); });

    return result;
}