#include <hphlib/util.h>
#include <validation/shared/shared.h>

cv::Rect overlapRect(const cv::Rect& rect, const cv::Mat& mat) {
    int common_left   = hphlib::clamp(rect.x, 0, mat.cols);
    int common_top    = hphlib::clamp(rect.y, 0, mat.rows);
    int common_right  = hphlib::clamp(rect.br().x, 0, mat.cols);
    int common_bottom = hphlib::clamp(rect.br().y, 0, mat.rows);

    int overlap_width  = common_right  - common_left;
    int overlap_height = common_bottom - common_top;

    return cv::Rect{common_left, common_top, overlap_width, overlap_height};
}

cv::Mat validation::extractSubImage(const cv::Mat &in_image_bgr,
                        const hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform &transform,
                        size_t i) {
    return extractSubImage(in_image_bgr, transform.transforms[i].projectedBox);
}

cv::Mat validation::extractSubImage(const cv::Mat &in_image_bgr, const cv::Rect& target) {
    if (target.width <= 0 || target.height <= 0) {
        // Bullshit
        return {};
    }

    cv::Rect overlap = overlapRect(target, in_image_bgr);

    float ratio = static_cast<float>(overlap.area()) / target.area();

    if (ratio < 0.5f) {
        // Need at least 50% overlap with camera image or the image is just not good enough
        return {};
    } else if (ratio == 1.0f) {
        // If full overlap, just copy
        return in_image_bgr(target).clone();
    } else {
        // Reflect on border
        int reflect_left   = overlap.x - target.x;
        int reflect_top    = overlap.y - target.y;
        int reflect_right  = target.br().x - overlap.br().x;
        int reflect_bottom = target.br().y - overlap.br().y;

        cv::Mat result;

        cv::copyMakeBorder(in_image_bgr(overlap), result, reflect_top, reflect_bottom, reflect_left, reflect_right, cv::BORDER_REFLECT);

        return result;
    }
}