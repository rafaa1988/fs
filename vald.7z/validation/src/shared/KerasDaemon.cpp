#include <validation/shared/KerasDaemon.h>
#include <hphlib/os.h>
#include <csignal>

validation::KerasDaemon::KerasDaemon(ros::NodeHandle& n, const char* model_path, uint16_t port, bool suppress_gpu) {

    std::string port_str = std::to_string(port);

    if (suppress_gpu) {
        // TODO: Should not stick around
        if (::setenv("CUDA_VISIBLE_DEVICES", "", 1) != 0) {
            throw std::system_error(errno, std::system_category(), "Failed to set environment");
        }
    }

    timer_ = n.createSteadyTimer(ros::WallDuration(0.2), &validation::KerasDaemon::timerCallback, this);

    const char* args[] = {
            "rosrun",
            "validation",
            "keras_service.py",
            "--port",
            port_str.c_str(),
            model_path,
            nullptr
    };

    capturer_.capture([this, &args] () {
        this->child_pid_ = hphlib::os::execute(
                args[0],
                const_cast<char *const *>(args),
                hphlib::os::ExecuteMode::SearchExecutable
        );
    });
}

void validation::KerasDaemon::timerCallback(const ros::SteadyTimerEvent& ev) {
    (void) ev;

    auto exit_code = hphlib::os::checkTerminated(child_pid_);

    if (exit_code) {
        std::stringstream estream;
        estream << "Child has unexpectedly died with exit code " << *exit_code;
        throw std::runtime_error(estream.str());
    }
}

validation::KerasDaemon::~KerasDaemon() {
    // Signal child to die and join
    hphlib::os::signal(child_pid_, SIGINT);
    hphlib::os::waitTerminated(child_pid_);
}