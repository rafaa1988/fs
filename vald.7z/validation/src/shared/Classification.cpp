#include <hphlib/pcl.h>
#include <validation/shared/Classification.h>

namespace validation {
    const char *decodeClassification(Classification clazz) {
        switch (clazz) {
            case Classification::Red:
                return "red";
            case Classification::Blue:
                return "blue";
            case Classification::Yellow:
                return "yellow";
            case Classification::None:
                return "nocone";
            case Classification::Finish:
                return "finish";
            default:
                return "invalid";
        }
    }

    uint32_t classificationRefColor(Classification clazz) {
        switch (clazz) {
            case Classification::Red:
                return hphlib::REF_COLOR_RED;
            case Classification::Blue:
                return hphlib::REF_COLOR_BLUE;
            case Classification::Yellow:
                return hphlib::REF_COLOR_YELLOW;
            case Classification::Finish:
                return hphlib::REF_COLOR_FINISH;
            default:
                throw std::runtime_error("No ref color for classification");
        }
    }
}