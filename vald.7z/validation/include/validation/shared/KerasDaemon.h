#pragma once

#include <hphlib/misc/RosStreamCapturer.h>
#include <ros/node_handle.h>
#include <ros/steady_timer.h>

namespace validation {
    /**
     * Runs a keras validation service daemon in a new process, interrupting and waiting on it upon destruction
     *
     * @author Maximilian Schier
     */
    class KerasDaemon {
    private:
        ros::SteadyTimer timer_;
        pid_t child_pid_;
        hphlib::RosStreamCapturer capturer_;

        void timerCallback(const ros::SteadyTimerEvent& ev);

    public:
        /**
         * Create new service daemon
         * @param n Node handle, used to periodically check child health while ros is spinning
         * @param model_path Path to model, passed to child to load model from
         * @param port TCP/IP port to register Keras service on
         * @param suppress_gpu Whether to suppress GPU detection for the child process
         */
        KerasDaemon(ros::NodeHandle& n, const char* model_path, uint16_t port, bool suppress_gpu = true);

        // Binding this, do not move or copy
        KerasDaemon(const KerasDaemon& that) = delete;
        KerasDaemon& operator=(const KerasDaemon& that) = delete;

        ~KerasDaemon();
    };
}