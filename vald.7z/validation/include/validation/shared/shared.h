#pragma once

#include <opencv-3.3.1-dev/opencv2/opencv.hpp>
#include <pcl_ros/point_cloud.h>
#include <hphlib/misc/CloudToCameraTransformer.h>

namespace validation {
    /**
     * Create sub image for classifier, potentially applying modifications like reflecting
     * @param in_image_bgr Image in BGR 8-bit
     * @param transform Camera transform
     * @param index Element index to extract
     * @return Sub image for classification or empty material if not suitable
     */
    cv::Mat extractSubImage(const cv::Mat &in_image_bgr,
                            const hphlib::CloudToCameraTransformer<pcl::PointXYZ>::Transform &transform,
                            size_t index);

    /**
     * Create sub image for classifier, potentially applying modifications like reflecting
     * @param in_image_bgr Image in BGR 8-bit
     * @param target Target rectangle to classify, may exceed image boundaries
     * @return Sub image for classification or empty material if not suitable
     */
    cv::Mat extractSubImage(const cv::Mat &in_image_bgr, const cv::Rect& target);

    /**
     * Return the index of the maximum element of the given container
     * @tparam Container Container type
     * @param c Container to find argmax for
     * @return Index of max
     */
    template<typename Container>
    auto argmax(const Container &c) {
        return std::distance(c.begin(), std::max_element(c.begin(), c.end()));
    }
}