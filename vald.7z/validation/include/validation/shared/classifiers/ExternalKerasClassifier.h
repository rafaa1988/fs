#pragma once

#include <validation/shared/Classifier.h>
#include <validation/shared/KerasClient.h>
#include <hphlib/PackedEndian.h>
#include <hphlib/misc/RosStreamCapturer.h>
#include <hphlib/io/UnixDomainDatagramSocket.h>
#include <ros/node_handle.h>

namespace validation {
    namespace classifiers {
        class ExternalKerasClassifier : public validation::Classifier {
        private:
            validation::KerasClient client_;

        public:
            explicit ExternalKerasClassifier(ros::NodeHandle &n);
            std::vector<Classification> classify_batch(std::vector<cv::Mat> &images) override;
        };
    }
}