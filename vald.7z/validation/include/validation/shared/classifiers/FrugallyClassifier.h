#pragma once

#include <validation/shared/Classifier.h>
#include <boost/optional.hpp>
#define FDEEP_FLOAT_TYPE double
#include <fdeep/fdeep.hpp>
#include <ros/node_handle.h>

namespace validation {
    namespace classifiers {
        class FrugallyClassifier : public Classifier {
        private:
            fdeep::model model_;
            boost::optional<fdeep::shape3> shape_;
            size_t counter_;

        public:
            explicit FrugallyClassifier(ros::NodeHandle &n);

            explicit FrugallyClassifier(const std::string &path);

            std::vector<Classification> classify_batch(std::vector<cv::Mat> &images) override;
        };
    }
}