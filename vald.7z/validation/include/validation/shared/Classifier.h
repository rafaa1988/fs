#pragma once

#include <opencv-3.3.1-dev/opencv2/core/mat.hpp>
#include <validation/shared/Classification.h>

namespace validation {
    class Classifier {
    public:
        /**
         * Classify batch of sub images. Default implementation calls classification operator repeatedly, overriding
         * implementations may be more efficient than calling classification operator repeatedly
         * @param images Vector fo images in BGR8 format to classify, classifier may modify images
         * @return Vector of classifications, same order as input
         */
        virtual std::vector<Classification> classify_batch(std::vector<cv::Mat> &images) = 0;

        virtual ~Classifier() = default;
    };
}