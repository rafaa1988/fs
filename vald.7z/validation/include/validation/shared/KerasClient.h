#pragma once

#include <hphlib/PackedEndian.h>
#include <hphlib/misc/RosStreamCapturer.h>
#include <hphlib/io/UnixDomainDatagramSocket.h>
#include <ros/node_handle.h>
#include <thrift/transport/TSocket.h>
#include <thrift/transport/TTransportUtils.h>
#include <thrift/protocol/TBinaryProtocol.h>

// Forward declarations, want to abstract generated code from exported header files
namespace validation_rpc {
    class Capabilities;
    class ValidationServiceClient;
}

namespace validation {
    class KerasClient {
    public:

        class ConnectionRefusedException : public std::exception {};

    private:
        // Custom deleters required to abstract forward declarations from generated code
        class DeleteCapabilities {
        public:
            void operator()(validation_rpc::Capabilities* pt) const;
        };

        class DeleteClient {
        public:
            void operator()(validation_rpc::ValidationServiceClient* pt) const;
        };

        std::shared_ptr<apache::thrift::transport::TSocket> sock_;
        std::shared_ptr<apache::thrift::transport::TBufferedTransport> transport_;
        std::shared_ptr<apache::thrift::protocol::TBinaryProtocol> protocol_;

        std::unique_ptr<validation_rpc::Capabilities, DeleteCapabilities> caps_;
        std::unique_ptr<validation_rpc::ValidationServiceClient, DeleteClient> service_;

        static void delete_capabilities(validation_rpc::Capabilities* caps);
        static void delete_client(validation_rpc::ValidationServiceClient* client);

    public:
        KerasClient(const char* host, uint16_t port);

        void ensureCapabilitiesKnown();

        /**
         * Classify a batch of images, number of classified images may be lower than input size if too many images
         * to transmit to external service in one packet, in which case only start of vector may be transmitted
         * @param images Images to classify
         * @return Classifications for these images
         */
        std::vector<uint32_t> classify_batch(std::vector<cv::Mat> &images);
    };
}