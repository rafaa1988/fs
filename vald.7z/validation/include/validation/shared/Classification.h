#pragma once

#include <cstdint>

namespace validation {

    enum class Classification : uint8_t {
        Red = 0, Blue = 1, Yellow = 2, Finish = 3, None = 4
    };

    const char *decodeClassification(Classification clazz);

    uint32_t classificationRefColor(Classification clazz);
}