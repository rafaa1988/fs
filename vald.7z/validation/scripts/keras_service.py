#!/usr/bin/env python3

from argparse import ArgumentParser
import keras
import numpy as np
import sys
import tensorflow
from gen_py.validation_rpc import ValidationService
from gen_py.validation_rpc.ttypes import Capabilities
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from thrift.server import TServer


class ValidationHandler:
    def __init__(self, path):
        self.model = keras.models.load_model(path)
        self.img_shape = self.model.input_shape[1:4]
        # Self check, ensures that there is no additional delay on first prediction requested through RPC
        self.model.predict_classes(np.random.random((1,) + self.img_shape))
        print("Model self check okay", file=sys.stderr)

    def capabilities(self):
        return Capabilities(self.img_shape[0], self.img_shape[1], self.img_shape[2])

    def classify(self, batch):
        vec = np.frombuffer(batch, dtype=np.uint8)
        images = np.reshape(vec, (-1,) + self.img_shape)
        return self.model.predict_classes(images)


def main():
    parser = ArgumentParser(description="Keras RPC service")
    parser.add_argument('model', type=str, help="Path to model")
    parser.add_argument('--port', type=int, default=9090, help="Port to listen on")
    args = parser.parse_args()

    # Don't eat up entire GPU, grow dynamically
    config = tensorflow.ConfigProto()
    config.gpu_options.allow_growth = True
    sess = tensorflow.Session(config=config)
    keras.backend.tensorflow_backend.set_session(sess)

    handler = ValidationHandler(args.model)
    processor = ValidationService.Processor(handler)
    transport = TSocket.TServerSocket(host='127.0.0.1', port=args.port)
    tfactory = TTransport.TBufferedTransportFactory()
    pfactory = TBinaryProtocol.TBinaryProtocolFactory()

    server = TServer.TSimpleServer(processor, transport, tfactory, pfactory)
    print("Starting RPC server on  port {}...".format(args.port), file=sys.stderr)
    sys.stderr.flush()
    server.serve()

if __name__ == '__main__':
    main()