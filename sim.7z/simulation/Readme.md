# Simulation driver package

Contains all nodes that interface with the eh17d sensor simulation implemented in Unreal Engine,
which is provided in a separate repository.