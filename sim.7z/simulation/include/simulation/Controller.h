#pragma once

#include <hphlib/io/UdpSocket.h>
#include <string>

namespace simulation {
    class Controller {
        hphlib::UdpSocket::Endpoint remote_;
        hphlib::UdpSocket sock_;

    public:
        Controller(const std::string &remote_host, uint16_t remote_port);

        void send(float steering_deg, float velocity, bool reset);
    };
}