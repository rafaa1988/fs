#pragma once

#include <hphlib/PackedEndian.h>

namespace simulation {
    struct __attribute__((packed)) ControlPacket {
        /**
         * Steering angle in deg where 0.0f is neutral and positive is towards right
         */
        little_f32_t steering;

        /**
         * Target velocity in m/s where positive is forwards
         */
        little_f32_t velocity;

        /**
         * Reset level if true
         */
         bool reset;
    };
}