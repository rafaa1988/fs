#include <iostream>
#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/misc/PollService.h>
#include <hphlib/io/UdpSocket.h>

#include <simulation/DrivingEvent.h>

// MAIN
int main(int argc, char **argv) {
    ros::init(argc, argv, "driving_events");
    ros::NodeHandle n("~");

    uint16_t port = getRequiredRosParamPort(n, "port");
    std::string topic_events = getRequiredRosParam<std::string>(n, "topic_events");
    ros::Publisher events_pub = n.advertise<simulation::DrivingEvent>(topic_events, 1);


    hphlib::UdpSocket sock(port, true);

    std::vector<uint8_t> buf(1024, 0);

    hphlib::PollService poller(sock, [&] () {

        ssize_t bytes = sock.receiveNoThrow(&buf.front(), buf.size());

        if (bytes > 0) {

            std::cout << &buf.front()<< std::endl;

            simulation::DrivingEvent event;
            std::string event_name(buf.begin(), buf.end());
            event_name.erase(std::find(event_name.begin(), event_name.end(), '\0'), event_name.end());
            event.event = event_name;
            events_pub.publish(event);
            std::fill(buf.begin(), buf.end(), 0);


        }
    });

    ros::spin();
}