#include <ros/ros.h>
#include <hphlib/PackedEndian.h>
#include <hphlib/util.h>
#include <hphlib/io/UdpSocket.h>
#include <hphlib/misc/PollService.h>
#include <nav_msgs/Odometry.h>

struct __attribute__((packed)) OdometryFrame {
    little_f32_t velocity_x;
    little_f32_t velocity_y;
    little_f32_t yaw_rate;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "simulation_odometry");

    ros::NodeHandle n("~");

    uint16_t sink_port    = getRequiredRosParamPort(n, "sink_port");
    std::string frame_id  = getRequiredRosParam<std::string>(n, "frame_id");
    std::string topic_out = getRequiredRosParam<std::string>(n, "topic_out");

    ros::Publisher pub = n.advertise<nav_msgs::Odometry>(topic_out, 1);

    hphlib::UdpSocket sock(sink_port, true);

    hphlib::PollService poller(sock, [&] () {
        OdometryFrame frame{};

        sock.receive(reinterpret_cast<uint8_t *>(&frame), sizeof frame);

        nav_msgs::Odometry msg{};
        msg.header.frame_id = frame_id;
        msg.header.stamp = ros::Time::now();

        msg.twist.twist.linear.x = frame.velocity_x;
        msg.twist.twist.linear.y = frame.velocity_y;
        msg.twist.twist.angular.z = frame.yaw_rate;

        pub.publish(msg);
    });

    ROS_INFO_STREAM("Receiving virtual odometry on port " << sink_port);

    ros::spin();
}