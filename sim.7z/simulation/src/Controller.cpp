#include <simulation/Controller.h>
#include <simulation/ControlPacket.h>

simulation::Controller::Controller(const std::string &remote_host, uint16_t remote_port)
    : remote_(remote_host.c_str(), remote_port)
    , sock_(hphlib::UdpSocket::DYNAMIC_PORT)
{
}

void simulation::Controller::send(float steering_deg, float velocity, bool reset=false) {
    ControlPacket packet{};
    packet.steering = steering_deg;
    packet.velocity = velocity;
    packet.reset = reset;

    sock_.sendTo(reinterpret_cast<const uint8_t *>(&packet), sizeof packet, remote_);
}
