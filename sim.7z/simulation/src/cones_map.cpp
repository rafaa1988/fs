#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <hphlib/PackedEndian.h>
#include <hphlib/misc/UdpMonitor.h>
#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include <std_msgs/Int16MultiArray.h>
#include <std_msgs/Float32.h>
#include <pcl_ros/point_cloud.h>

constexpr float xFOV = 75.0f;
constexpr float HEIGHT_CONE_METERS = 0.27f;
constexpr float AR_CONE = 0.23f/HEIGHT_CONE_METERS;
constexpr float IMAGE_HEIGHT = 500.0f;
constexpr float IMAGE_WIDTH = 1280.0f;

// Color constants as defined in simulation engine
constexpr int COLOR_RED = 0;
constexpr int COLOR_BLUE = 1;
constexpr int COLOR_YELLOW = 2;
constexpr int COLOR_FINISH = 3;

struct __attribute__((packed)) ConePos {
    little_f32_t x;
    little_f32_t y;
    little_f32_t z;
    little_int32_t leftCamX;
    little_int32_t leftCamY;
    little_int32_t rightCamX;
    little_int32_t rightCamY;
    little_int32_t color;
};

struct __attribute__((packed)) RefHeader {
    little_f32_t steering;
    little_f32_t throttle;
};

/**
 * Convert ConePos to PointCloud2
 * @param cones
 * @param count
 * @return
 */
pcl::PointCloud<pcl::PointXYZRGB> dataToPointCloud(const ConePos* cones, int count, const std::string &tf_frame) {

    pcl::PointCloud<pcl::PointXYZRGB> cloud{};

    cloud.header.frame_id = tf_frame;
    cloud.header.stamp    = pcl_conversions::toPCL(ros::Time::now());

    for (int i = 0; i < count; ++i) {
        const ConePos &cone = cones[i];

        pcl::PointXYZRGB pt{};
        pt.x = cone.x;
        pt.y = -cone.y; // ROS has inverted y axis
        pt.z = cone.z;

        // Set the RGB fields of the point cloud point to match the color of the reference cone
        if (cone.color == COLOR_RED) {
            pt.rgba = hphlib::REF_COLOR_RED;
        } else if (cone.color == COLOR_BLUE) {
            pt.rgba = hphlib::REF_COLOR_BLUE;
        } else if (cone.color == COLOR_YELLOW) {
            pt.rgba = hphlib::REF_COLOR_YELLOW;
        } else if (cone.color == COLOR_FINISH) {
            pt.rgba = hphlib::REF_COLOR_FINISH;
        } else {
            ROS_WARN("Unknown color constant: %d", cone.color);
        }

        cloud.push_back(pt);
    }

    return cloud;
}

/**
 * extracts pixels from ConePos and returns msg
 * @param cPos
 * @param count number of cones
 * @return
 */
std_msgs::Int16MultiArray dataToPixelMsg(ConePos *cPos, int count) {

    std::vector<int16_t> dataVec = {};

    for (int i = 0; i < count; ++i) {

        //fancy math
        float yFOV = static_cast<float>(2 * std::atan((std::tan(xFOV * DEG_TO_RAD / 2) / (IMAGE_WIDTH / IMAGE_HEIGHT))));
        float extraDistance = HEIGHT_CONE_METERS/std::tan(yFOV);
        int heightPx = static_cast<int>(((IMAGE_HEIGHT/2) * extraDistance) / (cPos[i].x + extraDistance));
        int widthPx = static_cast<int>(AR_CONE * heightPx);

        dataVec.push_back(static_cast<short &&>(cPos[i].leftCamX.native()));
        dataVec.push_back(static_cast<short &&>(cPos[i].leftCamY.native()));
        dataVec.push_back(static_cast<short &&>(cPos[i].rightCamX.native()));
        dataVec.push_back(static_cast<short &&>(cPos[i].rightCamY.native()));
        dataVec.push_back(static_cast<short &&>(heightPx));
        dataVec.push_back(static_cast<short &&>(widthPx));
        dataVec.push_back(static_cast<short &&>(cPos[i].color.native()));
    }

    std_msgs::Int16MultiArray msg;
    // set up dimensions
    msg.layout.dim.emplace_back();
    msg.layout.dim[0].size = static_cast<unsigned int>(dataVec.size());
    msg.layout.dim[0].stride = 1;
    msg.layout.dim[0].label = "x"; // or whatever name you typically use to index vec1

    // copy in the data
    msg.data.clear();
    msg.data.insert(msg.data.end(), dataVec.begin(), dataVec.end());

    return msg;
}


// MAIN
int main(int argc, char **argv) {

    ros::init(argc,argv, "SIMsalabim");
    ros::NodeHandle n("~");

    uint16_t port           = getRequiredRosParamPort(n, "port");
    std::string topic_pixel = getRequiredRosParam<std::string>(n, "topic_pixel");
    std::string topic_map   = getRequiredRosParam<std::string>(n, "topic_map");
    std::string tf_frame    = getRequiredRosParam<std::string>(n, "tf_frame");

    ros::Publisher cones_map = n.advertise<pcl::PointCloud<pcl::PointXYZRGB>>(topic_map, 1);
    ros::Publisher cones_pixel = n.advertise<std_msgs::Int16MultiArray>(topic_pixel, 1);
    ros::Publisher steering_pub = n.advertise<std_msgs::Float32>("steering", 1);
    ros::Publisher throttle_pub = n.advertise<std_msgs::Float32>("throttle", 1);

    hphlib::UdpMonitor sock(hphlib::UdpSocket(port), "Reference map", 250);

    ROS_INFO_STREAM("Cheat mode activated on port " << port);

    struct __attribute__((packed)) {
        RefHeader header;
        ConePos cones[100];
    } buf{};

    while (ros::ok()) {

        ros::spinOnce();

        ssize_t bytes_received;

        try {
            bytes_received = sock.receive(reinterpret_cast<uint8_t *>(&buf), sizeof buf);
        } catch (const hphlib::UdpMonitor::TimeoutException&) {
            continue;
        }

        int cone_count = (bytes_received - sizeof(RefHeader)) / sizeof(ConePos);

        //publish messages
        cones_map.publish(dataToPointCloud(buf.cones, cone_count, tf_frame));
        cones_pixel.publish(dataToPixelMsg(buf.cones, cone_count));

        std_msgs::Float32 steering_msg{};
        steering_msg.data = buf.header.steering.native();

        std_msgs::Float32 throttle_msg{};
        throttle_msg.data = buf.header.throttle.native();

        steering_pub.publish(steering_msg);
        throttle_pub.publish(throttle_msg);

    }

    return EXIT_SUCCESS;
}


