#include <chrono>
#include <thread>
#include "PathListener.h"
#include "../misc/util.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "Virtual car driver");
    ros::NodeHandle n("~");

    std::string host          = getRequiredRosParam<std::string>(n, "remote_host");
    int port                  = getRequiredRosParam<int>(n, "remote_port");
    float max_throttle        = getRequiredRosParam<float>(n, "max_throttle");
    float steering_correction = getRequiredRosParam<float>(n, "steering_correction");

    ROS_INFO("Vroom, vroom, car driver is go");

    PathListener listener(n, host, static_cast<uint16_t>(port), max_throttle, steering_correction);

    ros::SteadyTimerCallback timer_cb = [&] (const auto &ev) {
        (void) ev;

        listener.sendCommand();
    };

    ros::SteadyTimer timer = n.createSteadyTimer(ros::WallDuration(0.02f), timer_cb);

    ros::spin();

}
