#pragma once

#include <nav_msgs/Path.h>
#include <ros/node_handle.h>
#include <simulation/Controller.h>
#include <hphlib/Control.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Empty.h>

class PathListener {
private:
    simulation::Controller controller_;

    ros::Subscriber sub_;
    ros::Subscriber sub_reset;

    float max_throttle_;
    float steering_correction_;

    float steering_deg_;
    float velocity_;

    size_t reset_counter_ = 0;

    void callback(const hphlib::Control::ConstPtr& msg);

public:

    PathListener(ros::NodeHandle n, const std::string& remote_host, uint16_t remote_port,
                 float max_throttle,
                 float steering_correction);
    // Binding this, do not copy or move
    PathListener(const PathListener& that) = delete;

    PathListener& operator=(const PathListener& that) = delete;

    void sendCommand();

    void callbackResetLevel(const std_msgs::Empty::ConstPtr &msg);
};