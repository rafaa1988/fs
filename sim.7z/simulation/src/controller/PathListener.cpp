#include <hphlib/util.h>
#include "PathListener.h"

PathListener::PathListener(ros::NodeHandle n, const std::string &remote_host,
                           uint16_t remote_port, float max_throttle, float steering_correction)
    : controller_(remote_host, remote_port)
    , sub_(n.subscribe(getRequiredRosParam<std::string>(n, "topic_control"), 1, &PathListener::callback, this))
    , sub_reset(n.subscribe(getRequiredRosParam<std::string>(n, "topic_reset"), 1, &PathListener::callbackResetLevel, this))
    , max_throttle_(max_throttle)
    , steering_correction_(steering_correction)
    , steering_deg_(0.0f)
    , velocity_(0.0f)
{
}

void PathListener::sendCommand() {
    controller_.send(steering_deg_, velocity_, reset_counter_ > 0);
    if (reset_counter_ > 0) {
        reset_counter_--;
    }
}

void PathListener::callback(const hphlib::Control::ConstPtr& msg) {
    steering_deg_ = msg->steering_angle;
    velocity_ = msg->target_velocity;
}


void PathListener::callbackResetLevel(const std_msgs::Empty::ConstPtr &msg) {
    (void) msg;
    reset_counter_+= 10;
}