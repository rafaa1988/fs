/*
 * Driver for virtual cameras
 *
 * Receive virtual camera data via UDP packets and publish as ROS images and camera info
 *
 * Authors:
 *      Maximilian Schier       <max.schier@gmail.com>
 */

#include <boost/endian/conversion.hpp>
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/CameraInfo.h>
#include <hphlib/misc/UdpMonitor.h>
#include <hphlib/util.h>
#include <hphlib/PackedEndian.h>

/*
 * Packets received for the camera have the following format:
 *
 * +---------------------------------+
 * | Scan line (i32, LE)             |
 * +---------------------------------+
 * | B, G, R, A (All u8)             | } * Width
 * +---------------------------------+
 *
 * The virtual camera progressively sends scan lines, where each received packet is one scan line.
 * The packet has a header containing scan line index, where 0 is top.
 *
 * The pixels of the scan line follow from left to right, where each pixel is an ARGB u32 LE, that can
 * also be interpreted as a B, G, R, A u8 field, because both are the same thing.
 *
 * Total amount of pixels following is equal to the image width, which is currently not transmitted,
 * but should ideally be in the future.
 */

// Structure describes the pixel format as published for ROS (BigEndian RGB 24bpp)
struct __attribute__((packed)) RosImagePixel {
    uint8_t R;
    uint8_t G;
    uint8_t B;
};

// Structure describes the pixel format of the received network packet (LittleEndian ARGB 32bpp)
struct __attribute__((packed)) PacketImagePixel {
    uint8_t B;
    uint8_t G;
    uint8_t R;
    uint8_t A;
};

/**
 * Create raw image message for the virtual renderer camera
 * @param pixels Pixel content of image
 * @param width Width of image in pixels, should match accompanying info message
 * @param height height of image in pixels, should match accompanying info message
 * @param tf_frame Frame where optical center of camera is located, should match accompanying info message
 * @param image_time Time image was taken, should match accompanying info message
 * @return Created message
 */
sensor_msgs::Image createImgMsg(const std::vector<RosImagePixel> &pixels, unsigned int width, unsigned int height,
                                const std::string &tf_frame, const ros::Time& image_time)
{

    sensor_msgs::Image msg;

    msg.header.frame_id = tf_frame;
    msg.header.stamp    = image_time;

    msg.width  = width;
    msg.height = height;

    msg.encoding = sensor_msgs::image_encodings::RGB8;

    // Since our encoding is RGB8, it doesn't matter whether data is interpreted as BE or LE since a color channel
    // has just one byte, set to LE because why not.
    msg.is_bigendian = 0;

    // Step is bitmap stride, exactly the size of a pixel times width since our vector has no padding
    // in between pixels or rows
    msg.step = sizeof(RosImagePixel) * width;

    // Alias pixels as byte array to store into message data vector
    const uint8_t* pixel_begin = reinterpret_cast<const uint8_t *>(&*pixels.begin());
    const uint8_t* pixel_end = reinterpret_cast<const uint8_t *>(&*pixels.end());
    msg.data = std::move(std::vector<unsigned char>(pixel_begin, pixel_end));

    return msg;
}

/**
 * Create a camera info message for the virtual renderer camera. Assumes that the camera is in fact a perfect pinhole
 * camera and has no lens distortions
 * @param width Width of image in pixels
 * @param height Height of image in pixels
 * @param x_fov_rad Field of view of the camera along the horizontal pane in radian(!)
 * @param tf_frame Frame where the optical center of the camera is located (that is, the principal point)
 * @param image_time Time image was taken, should match accompanying image message
 * @return Created message
 */
sensor_msgs::CameraInfo createInfoMsg(unsigned int width, unsigned int height, double x_fov_rad,
                                      const std::string &tf_frame, const ros::Time& image_time)
{
    sensor_msgs::CameraInfo msg;

    msg.header.frame_id = tf_frame;
    msg.header.stamp    = image_time;

    msg.width  = width;
    msg.height = height;

    // Standard distortion model used by ROS
    msg.distortion_model = "plumb_bob";

    // Assume that the renderer camera (that is the OpenGL or DirectX renderer used by the simulation engine)
    // can be modeled as a perfect pinhole camera

    // A perfect pinhole camera has its principal point at the center of the projection area (the image)
    double c_x = 0.5 * width;
    double c_y = 0.5 * height;

    // Focal length, that is length between pinhole and projection area is same for both f_x and f_y for a perfect
    // pinhole camera
    //
    //   |\     /        //
    //   | \   /         //
    //   |  \ /          //
    // w |-f-X) x_fov    //
    //   |  / \          //
    //   | /   \         //
    //   |/     \        //

    double f = 0.5 * (width / std::tan(x_fov_rad * 0.5));

    // No distortion for perfect pinhole camera
    msg.D = {0.0, 0.0, 0.0, 0.0, 0.0};

    // Intrinsic camera matrix for raw image, see sensor msg documentation
    msg.K = {
            f,   0.0, c_x,
            0.0, f,   c_y,
            0.0, 0.0, 1.0
    };

    // Rectification matrix is always identity for monocular cameras, see sensor msg documentation
    msg.R = {
            1.0, 0.0, 0.0,
            0.0, 1.0, 0.0,
            0.0, 0.0, 1.0
    };

    // Intrinsic camera matrix for rectified image, see sensor msg documentation
    msg.P = {
            f,   0.0, c_x, 0.0,
            0.0, f,   c_y, 0.0,
            0.0, 0.0, 1.0, 0.0
    };

    // No binning (super-sampling)
    msg.binning_x = 0;
    msg.binning_y = 0;

    return msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Virtual camera driver");
    ros::NodeHandle n;

    uint16_t cam_port      = getRequiredRosParamPort(n, "cam/port");
    std::string info_topic = getRequiredRosParam<std::string>(n, "cam/info_topic");
    std::string raw_topic  = getRequiredRosParam<std::string>(n, "cam/raw_topic");
    std::string tf_frame   = getRequiredRosParam<std::string>(n, "cam/tf_frame");

    // TODO: The protocol for communication should be modified to allow automatic sending of these
    // TODO: camera configuration parameters instead of having to provide them manually, which is error prone
    int width              = getRequiredRosParam<int>(n, "cam/width");
    int height             = getRequiredRosParam<int>(n, "cam/height");
    double x_fov_deg       = getRequiredRosParam<double>(n, "cam/x_fov");

    ros::Publisher image_publisher = n.advertise<sensor_msgs::Image>(raw_topic, 1);
    ros::Publisher camera_info_publisher = n.advertise<sensor_msgs::CameraInfo>(info_topic, 1);

    hphlib::UdpMonitor sock(hphlib::UdpSocket(cam_port), "Virtual camera", 250);

    // Image can get quite large so locate it on the heap
    std::vector<RosImagePixel> image(static_cast<size_t>(width * height));

    ROS_INFO("Camera is go for %s and %s on port %d", info_topic.c_str(),raw_topic.c_str(), cam_port);

    little_int32_t scan_line{};

    // The actual useful size read per scan line from the buffer
    size_t useful_buffer_size = sizeof(scan_line) + sizeof(PacketImagePixel) * width;

    // The  buffer is allocated with 1 extra byte, this way the program can detect too large packets
    // If the buffer would fit perfectly, the socket library would only write up to the size of the buffer
    // and packets would not be detectable
    size_t full_buffer_size = useful_buffer_size + 1;

    std::vector<uint8_t> buffer(full_buffer_size);

    ssize_t read_bytes;

    while (ros::ok()) {

        try {
            read_bytes = sock.receive(&buffer[0], full_buffer_size);
        } catch (const hphlib::UdpMonitor::TimeoutException&) {
            ros::spinOnce();
            continue;
        }

        if (static_cast<size_t>(read_bytes) != useful_buffer_size) {
            ROS_WARN("Received packet of size %d (or larger), expected %d, skipping this packet", read_bytes, useful_buffer_size);
            continue;
        }

        // Read scan line header from start of packet
        std::memcpy(&scan_line, &buffer[0], sizeof scan_line);

        if (scan_line > height - 1 || scan_line < 0) {
            ROS_WARN("Received scanline %d not in range %d-%d, skipping this line", scan_line, 0, height - 1);
            continue;
        }

        // Copy all pixels and convert pixel format, since all pixels are defined on a byte level the endianness
        // of the system does not matter during conversions
        for (int x = 0; x < width; ++x) {

            // Index of pixel in ROS image
            int image_index = scan_line * width + x;

            PacketImagePixel pixel{};
            std::memcpy(&pixel, &buffer[sizeof(scan_line)+x*sizeof(PacketImagePixel)], sizeof pixel);

            image[image_index].R = pixel.R;
            image[image_index].G = pixel.G;
            image[image_index].B = pixel.B;
        }

        // Publish and spin when last scan line received
        if (scan_line == (height - 1)) {

            ros::Time image_time = ros::Time::now();

            image_publisher.publish(createImgMsg(
                    image,
                    static_cast<unsigned int>(width),
                    static_cast<unsigned int>(height),
                    tf_frame,
                    image_time
            ));

            camera_info_publisher.publish(createInfoMsg(
                    static_cast<unsigned int>(width),
                    static_cast<unsigned int>(height),
                    x_fov_deg * DEG_TO_RAD,
                    tf_frame,
                    image_time
            ));

            ros::spinOnce();
        }
    }

    return EXIT_SUCCESS;
}