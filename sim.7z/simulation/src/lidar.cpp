/*
 * Driver for virtual lidar
 *
 * Receive virtual lidar data via UDP packets and publish as ROS scan lines
 *
 * Authors:
 *      Maximilian Schier       <max.schier@gmail.com>
 *      Niclas Wüstenbecker
 */

#include <boost/endian/conversion.hpp>
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <hphlib/misc/UdpMonitor.h>
#include <hphlib/pcl.h>
#include <hphlib/util.h>
#include <hphlib/PackedEndian.h>
#include <hphlib/misc/PollService.h>

/*
 * Packets received for the lidar have the following format:
 *
 * +---------------------------------+
 * | Scan line (i32, LE)             |
 * +---------------------------------+
 * | Depth [m] (f32, LE)             | } * Horizontal Resolution
 * +---------------------------------+
 * 
 * The virtual lidar progressively sends scan lines, where each received packet is one scan line.
 * The packet has a header containing scan line index, where 0 is top.
 *
 * The depth measurements of the scan line follow in meters, a total of the horizontal resolution of the lidar.
 *
 * The horizontal resolution is currently not submitted, but should be in the future.
 */

// TODO: Don't hard-code any of this, best to include in transmission

constexpr int LAYER_COUNT = 4;

/**
 * Horizontal resolution (scan samples) of this lidar
 */
constexpr int HORIZONTAL_RESOLUTION = 220;

/**
 * Left most angle in ° that the lidar scans, usually negative
 */
constexpr float HORIZONTAL_START_ANGLE = -1.0471975512f; // -60.0°

/**
 * Right most angle in ° that the lidar scans, usually positive
 */
constexpr float HORIZONTAL_STOP_ANGLE = 0.87266462599f; // 50.0°

constexpr float VERTICAL_START_ANGLE = -0.020943951f; //-1,2°
constexpr float VERTICAL_STOP_ANGLE  =  0.020943951f; // 1,2°

/**
 * Depending on the RViz or receiver configuration, the Lidar can be mirrored along the horizontal
 * axis so that X coordinates are inverted
 */
constexpr bool HorizontallyInvertLidar = false;

/**
 * Fov of the lidar, automatically determined
 */
constexpr float HORIZONTAL_FOV = HORIZONTAL_STOP_ANGLE - HORIZONTAL_START_ANGLE;

// Representation of lidar network packet
struct __attribute__((packed)) LidarPacket {
    little_int32_t layer;                             // Indicates layer
    little_f32_t   distances[HORIZONTAL_RESOLUTION];  // Distance measurement points
};

// DATA TO LaserScan
sensor_msgs::LaserScan dataToLaserScan(const LidarPacket& packet, const std::string* frames) {
	ros::Time scan_time = ros::Time::now();
	sensor_msgs::LaserScan msg;
	
	std::string layer_id_stream = frames[packet.layer];
	msg.header.frame_id = layer_id_stream;
	msg.header.stamp = scan_time;

	msg.angle_min = static_cast<float>(HORIZONTAL_START_ANGLE);
	msg.angle_max = static_cast<float>(HORIZONTAL_STOP_ANGLE);
	msg.angle_increment = static_cast<float>(HORIZONTAL_FOV / (HORIZONTAL_RESOLUTION - 1));

    // Virtual lidar is perfect and takes a snap shot of the entire surroundings at once, no delay between scan points
	msg.time_increment = 0.0f;

	msg.range_min = 0.0004;
	msg.range_max = 200.0;
	msg.ranges.resize(HORIZONTAL_RESOLUTION);
	msg.intensities.resize(HORIZONTAL_RESOLUTION);
	
	for (int i = 0; i < HORIZONTAL_RESOLUTION; ++i){
		// Read distance at this scan point from buffer (add offset of header)
		float dis = packet.distances[i];
		
		int effectiveIndex = HorizontallyInvertLidar ? (HORIZONTAL_RESOLUTION - 1 - i) : i;
		
		// Store inverted in message, set to 0 if virtual lidar reports very far range
		if (dis > 199.0) {
			msg.ranges[effectiveIndex] = 0;
		} else {
			msg.ranges[effectiveIndex] = dis;
		}
	}
	
	return msg;
}

pcl::PointCloud<pcl::PointXYZRGBL> cloudFromLayerPackets(const std::vector<LidarPacket>& packets, const std::string& frame) {
    pcl::PointCloud<pcl::PointXYZRGBL> result;

    for (const auto& packet : packets) {
        float vertical_angle = VERTICAL_START_ANGLE + (packet.layer / static_cast<float>(LAYER_COUNT - 1))
                                                      * (VERTICAL_STOP_ANGLE - VERTICAL_START_ANGLE);

        for (size_t i = 0; i < HORIZONTAL_RESOLUTION; ++i) {
            float horizontal_angle = HORIZONTAL_START_ANGLE + (i / static_cast<float>(HORIZONTAL_RESOLUTION - 1))
                                                              * (HORIZONTAL_STOP_ANGLE - HORIZONTAL_START_ANGLE);

            // Convert from spherical to Euclidean coordinate system
            pcl::PointXYZRGBL this_point;
            this_point.x = std::cos(vertical_angle) * std::cos(horizontal_angle) * packet.distances[i];
            this_point.y = std::cos(vertical_angle) * std::sin(horizontal_angle) * packet.distances[i];
            this_point.z = std::sin(vertical_angle) * packet.distances[i];

            // No classification on virtual lidar
            this_point.rgba = hphlib::LIDAR_COLOR_NEUTRAL;

            result.push_back(this_point);
        }
    }

    result.header.stamp = pcl_conversions::toPCL(ros::Time::now());
    result.header.frame_id = frame;

    return result;
}

// MAIN
int main(int argc, char **argv)
{

	ros::init(argc,argv, "SIMsalabim");
	ros::NodeHandle n("~");

    std::string layers[4];
    std::string frames[4];
    std::string pc_frame;
    ros::Publisher publishers[4];
        
    uint16_t port = getRequiredRosParamPort(n, "port");
    layers[0] = getRequiredRosParam<std::string>(n, "layer0");
    layers[1] = getRequiredRosParam<std::string>(n, "layer1");
    layers[2] = getRequiredRosParam<std::string>(n, "layer2");
    layers[3] = getRequiredRosParam<std::string>(n, "layer3");
    frames[0] = getRequiredRosParam<std::string>(n, "frame0");
    frames[1] = getRequiredRosParam<std::string>(n, "frame1");
    frames[2] = getRequiredRosParam<std::string>(n, "frame2");
    frames[3] = getRequiredRosParam<std::string>(n, "frame3");
    pc_frame = getRequiredRosParam<std::string>(n, "pc_frame");
        
	publishers[0] = n.advertise<sensor_msgs::LaserScan>(layers[0], 1);
	publishers[1] = n.advertise<sensor_msgs::LaserScan>(layers[1], 1);
	publishers[2] = n.advertise<sensor_msgs::LaserScan>(layers[2], 1);
	publishers[3] = n.advertise<sensor_msgs::LaserScan>(layers[3], 1);

    ros::Publisher pcl_publisher(n.advertise<pcl::PointCloud<pcl::PointXYZRGBL>>(getRequiredRosParam<std::string>(n, "pc_topic"), 1));

    hphlib::UdpSocket sock(port, true /* reuse */);

    LidarPacket packet{};

    std::vector<LidarPacket> layer_buffer(LAYER_COUNT, LidarPacket{});

    hphlib::PollService poll(sock, [&] () {
        size_t rx_bytes = sock.receive(reinterpret_cast<uint8_t *>(&packet), sizeof packet);

        if (rx_bytes != sizeof packet) {
            // Warn if the packet had an incorrect size, chances are misconfiguration
            ROS_WARN_STREAM("Lidar: Received packet of size " << rx_bytes << " but expected " << sizeof packet);
        }

        if (packet.layer >= LAYER_COUNT || packet.layer < 0) {
            ROS_ERROR_STREAM("Received invalid layer header: " << packet.layer);
            return;
        }

        // Buffer last version of each layer received
        layer_buffer[packet.layer] = packet;

        // Publish point cloud whenever highest layer is received. This is unreliable and lead to bad PCLs
        // if a layer is dropped.
        // TODO: Use reliable transport
        if (packet.layer == LAYER_COUNT - 1) {
            pcl_publisher.publish(cloudFromLayerPackets(layer_buffer, pc_frame));
        }

        publishers[packet.layer].publish(dataToLaserScan(packet, frames));
    });

    ROS_INFO_STREAM("Lidar is go on port " << port);

	ros::spin();

	return EXIT_SUCCESS;
}
