#pragma once
#include <hphlib/pcl.h>
#include <hphlib/Distance.h>
#include <hphlib/SlamStatus.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <telemetry/Runner.h>

class LapCounter {
private:
    hphlib::vehicle::StatusMonitor vehicle_mon_;

    std::string topic_output_;

    int min_lap_length_;
    int max_distance_to_cones_;

    uint8_t current_lap_;
    float distance_of_current_lap_start_;

    ros::Publisher lap_publisher;

    telemetry::Runner runner_;

public:

    explicit LapCounter(ros::NodeHandle& n);

    void countLaps(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr& front_cones,
              const hphlib::Distance::ConstPtr& distance);
};

