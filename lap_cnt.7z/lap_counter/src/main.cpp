#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <hphlib/util.h>
#include "LapCounter.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "lap_counter");

    ros::NodeHandle n("~");

    std::string topic_cones_map = getRequiredRosParam<std::string>(n, "topic_cones_map");
    std::string topic_distance = getRequiredRosParam<std::string>(n, "topic_distance");

    std::string topic_output_laps = getRequiredRosParam<std::string>(n, "topic_output_laps");

    message_filters::Subscriber<pcl::PointCloud<pcl::PointXYZRGBA>> front_cones_sub(n, topic_cones_map, 1);
    message_filters::Subscriber<hphlib::Distance>                   distance_sub(n, topic_distance, 1);


    typedef message_filters::sync_policies::ApproximateTime<pcl::PointCloud<pcl::PointXYZRGBA>, hphlib::Distance> MySyncPolicy;

    message_filters::Synchronizer<MySyncPolicy> sync(MySyncPolicy(1), front_cones_sub, distance_sub);

    LapCounter lapCounter(n);

    sync.registerCallback(&LapCounter::countLaps, &lapCounter);

    ros::spin();

    return EXIT_SUCCESS;
}