#include "LapCounter.h"
#include <hphlib/pcl.h>
#include <hphlib/Lap.h>
#include <hphlib/util.h>

LapCounter::LapCounter(ros::NodeHandle &n)
    : vehicle_mon_(n)
    , topic_output_(getRequiredRosParam<std::string>(n, "topic_output_laps"))
    , min_lap_length_(getRequiredRosParam<int>(n, "min_lap_length"))
    , max_distance_to_cones_(getRequiredRosParam<int>(n, "max_distance_to_cones"))
    , current_lap_(0)
    , distance_of_current_lap_start_(0.0f)
    , runner_("lap_ctr")
{
    lap_publisher = n.advertise<hphlib::Lap>(topic_output_, 1);

    // reset laps an vehicle ready
    vehicle_mon_.set_ready_callback([&] () {
        distance_of_current_lap_start_ = 0.0f;
        current_lap_ = 0;
    });
}

void LapCounter::countLaps(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &front_cones,
                          const hphlib::Distance::ConstPtr &distance) {

    float totalDistance = distance->distance;
    float distanceInCurrentLap = totalDistance - distance_of_current_lap_start_;

    // don't count laps that are very short
    if (distanceInCurrentLap >= min_lap_length_) {

        bool leftCloseCone = false;
        bool rightCloseCone = false;

        // look for cones behind the car that are close to the left and to the right of the vehicle
        for (const auto &pt : front_cones->points) {
            if (std::sqrt(hphlib::distanceSquaredFromOrigin(pt)) <= max_distance_to_cones_ &&
                ( hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_FINISH) || hphlib::sameRgb(pt.rgba, hphlib::REF_COLOR_RED))) {
                if (pt.y > 0 && pt.x <= 0) {
                    leftCloseCone = true;
                } else if (pt.y < 0 && pt.x <= 0) {
                    rightCloseCone = true;
                }
            }
        }

        // only count lap when a cone to the left and the right of the vehicle was detected
        if (leftCloseCone && rightCloseCone) {
            current_lap_++;
            distance_of_current_lap_start_ = totalDistance;
        }
    }

    // create and publish lap message
    hphlib::Lap lap_msg;
    lap_msg.header.stamp = ros::Time::now();
    lap_msg.current_lap = current_lap_;
    lap_publisher.publish(lap_msg);

    runner_.report("ctr", current_lap_);
}
