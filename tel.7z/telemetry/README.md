# Telemetry library

## General

This package implements the telemetry runner library `telemetry` used by other nodes to report telemetry data.
The telemetry core service `telemetry_core` is also implemented, which collects telemetry data, refragments for
transmission and sends it to a remote host.

![Telemetry structure](structure.svg)

## Core service

The core service collects all nodes telemetry messages via a UDP socket. The messages are merged into one collected 
message object. A second thread of the core service periodically pulls in the merged results and clears them. This way
only new telemetry data is send (if a data piece hasn't been reported again since the last clearing, it is not part of
the collected data anymore). The dispatch thread then breaks the data into chunks fitting within the MTU of the
connection to ensure minimum data loss and sends away the data via UDP.