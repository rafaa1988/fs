#pragma once

#include <nlohmann/json.hpp>
#include <ros/ros.h>
#include <hphlib/io/UnixDomainDatagramSocket.h>
#include <hphlib/misc/PollService.h>

/**
 * @brief Collect telemetry data for batched sending
 *
 * The spooler asynchronously listens on a Unix domain socket, collecting telemetry data pieces of telemetry runners
 * and merging them into one JSON object for periodic batched sending, which is performed by the Dispatch.
 *
 * @author Maximilian Schier
 */
class AsyncSpooler {
private:
    hphlib::UnixDomainDatagramSocket socket_;
    hphlib::PollService service_;
    std::shared_ptr<nlohmann::json> collected_msgs_;
    std::array<uint8_t, 256*256> buffer_;

    void cb();

public:
    /**
     * Construct a new spooler using the given IO service and merging messages into the specified JSON object.
     * The spooler will start to work immediately when the IO service is run.
     * @param n NodeHandle
     * @param collected_msgs Shared pointer to JSON object to merge messages into
     */
    explicit AsyncSpooler(std::shared_ptr<nlohmann::json> collected_msgs);

    // Capturing this in lambda, must not move or copy
    AsyncSpooler(const AsyncSpooler& that) = delete;
    AsyncSpooler& operator=(const AsyncSpooler& that) = delete;
};
