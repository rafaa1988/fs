#include <atomic>
#include <iostream>
#include <ros/ros.h>
#include <hphlib/async/ShutdownMonitor.h>
#include <std_msgs/String.h>
#include <telemetry/Runner.h>
#include "AsyncSpooler.h"
#include "AsyncDispatch.h"

void run_main(ros::NodeHandle& n) {
    // Collected object store, cleared on each dispatch
    auto collected = std::make_shared<nlohmann::json>(nlohmann::json::object());

    // Collect incoming telemetry on unix domain socket
    AsyncSpooler collector(collected);

    // Dispatch collected telemetry periodically
    AsyncDispatch dispatch(n, collected);

    ros::spin();
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "telemetry_core");
    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }
}
