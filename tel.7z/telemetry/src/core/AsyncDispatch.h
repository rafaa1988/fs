#pragma once

#include <nlohmann/json.hpp>
#include <ros/steady_timer.h>
#include <ros/publisher.h>

class AsyncDispatch {
private:
    ros::SteadyTimer timer_;
    std::shared_ptr<nlohmann::json> collected_msgs_;

    double start_time_;

    ros::Publisher local_publisher_;

    void cb(const ros::SteadyTimerEvent& ev);

public:
    AsyncDispatch(ros::NodeHandle& n, std::shared_ptr<nlohmann::json> collected_msgs);
};
