#include <hphlib/util.h>
#include "AsyncSpooler.h"
#include "../shared/constants.h"

hphlib::UnixDomainDatagramSocket makeSocket() {
    hphlib::UnixDomainDatagramSocket sock(hphlib::UnixDomainDatagramSocket::Endpoint::abstract(telemetry::CORE_SERVICE_COLLECTOR_ADDRESS));
    sock.setBlocking(false);
    return sock;
}

AsyncSpooler::AsyncSpooler(std::shared_ptr<nlohmann::json> collected_msgs)
    : socket_(makeSocket())
    , service_(socket_, [this] () { this->cb(); })
    , collected_msgs_(std::move(collected_msgs))
{
}

void AsyncSpooler::cb() {

    size_t rx_count;
    nlohmann::json patch;

    // Receive next telemetry runner message, catch spurious wake-ups though they should not happen
    try {
        rx_count = socket_.receive(buffer_.data(), buffer_.size());
    } catch (const std::system_error& e) {
        if (hphlib::isBlockingException(e)) {
            ROS_INFO("Spurious wakeup");
            return;
        } else {
            throw;
        }
    }

    try {
        patch = nlohmann::json::from_ubjson(buffer_.begin(), buffer_.begin() + rx_count);
    } catch (const std::exception& e) {
        ROS_WARN_STREAM("Failed to decode runner message: " << e.what());
        return;
    }

    try {
        collected_msgs_->merge_patch(patch);
    } catch (const std::exception& e) {
        ROS_WARN_STREAM("Failed to merge runner message: " << patch << ", " << e.what());
        *collected_msgs_ = nlohmann::json::object();
        return;
    }
}
