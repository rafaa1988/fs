#include <ros/ros.h>
#include <telemetry/Telemetry.h>
#include <hphlib/util.h>
#include <std_msgs/UInt8MultiArray.h>
#include <std_msgs/String.h>
#include "AsyncDispatch.h"

AsyncDispatch::AsyncDispatch(ros::NodeHandle& n, std::shared_ptr<nlohmann::json> collected_msgs)
    : timer_(n.createSteadyTimer(ros::WallDuration(0.02), &AsyncDispatch::cb, this))
    , collected_msgs_(std::move(collected_msgs))
    , start_time_(ros::Time::now().toSec())
    , local_publisher_(n.advertise<telemetry::Telemetry>("bmsgs", 1))
{
}

void AsyncDispatch::cb(const ros::SteadyTimerEvent &ev) {
    (void) ev;

    if (!collected_msgs_->empty()) {
        auto now = ros::Time::now().toSec();

        (*collected_msgs_)["_time"] = now - start_time_;
        (*collected_msgs_)["_abs_time"] = now;

        // Publish to ROS
        telemetry::Telemetry ros_msg;
        ros_msg.header.frame_id = "0"; // No frame associated, convention
        ros_msg.header.stamp = ros::Time::now();
        ros_msg.data = nlohmann::json::to_ubjson(*collected_msgs_);
        local_publisher_.publish(ros_msg);
    }

    collected_msgs_->clear();
}
