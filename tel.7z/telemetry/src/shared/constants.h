#pragma once

#include <string>

namespace telemetry {
    constexpr const char* CORE_SERVICE_COLLECTOR_ADDRESS = "hph-telemetry-collector";
}