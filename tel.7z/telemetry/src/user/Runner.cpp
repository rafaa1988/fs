#include "telemetry/Runner.h"
#include "../shared/constants.h"

using namespace nlohmann;

constexpr auto forced_report_interval = std::chrono::seconds(3);

telemetry::Runner::Runner(const std::string &node_name)
    : node_name_(node_name)
    , socket_(hphlib::UnixDomainDatagramSocket::Endpoint::unnamed())
    , core_endpoint_(hphlib::UnixDomainDatagramSocket::Endpoint::abstract(telemetry::CORE_SERVICE_COLLECTOR_ADDRESS))
    , stage_("{}"_json)
    , last_("{}"_json)
    , next_forced_report_(std::chrono::steady_clock::now() + forced_report_interval)
{
}

void telemetry::Runner::report() {

    auto now = std::chrono::steady_clock::now();

    // Force restaging unmodified values after this report. Good to do this periodically, otherwise the external
    // logger could not resynchronize after detaching and would never receive the state of unmodified values.
    if (now >= next_forced_report_) {
        last_.clear();
        next_forced_report_ += forced_report_interval;
    }

    if (stage_.empty()) {
        // If a node has no values, i.e. because all unchanged, add a dummy keep alive so that the node can actually
        // report and the external monitor does not view the node as dead
        stage_[node_name_]["_ka"] = true;
    }

    auto serialized = nlohmann::json::to_ubjson(stage_);
    stage_.clear();

    try {
        socket_.sendTo(serialized.data(), serialized.size(), core_endpoint_);
    } catch (const std::exception &ex) {
        ROS_DEBUG_STREAM("Failed to report to telemetry core: " << ex.what());
    }
}

