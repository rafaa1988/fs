
#include <chrono>
#include <thread>
#include "user/include/telemetry/Reporter.h"

int main() {
    using namespace std::chrono_literals;

    telemetry::Reporter m("blubb-node");

    for (float t = 0.0f;; t += 0.1f) {
        m.report("sin", std::sin(t));

        for (int i = 0; i < 10; i++) {
            std::stringstream key_stream;
            key_stream << "Key" << i;

            std::string value(300, 'A' + i);

            m.report(key_stream.str(), value);
        }

        std::this_thread::sleep_for(1000ms);
    }
}