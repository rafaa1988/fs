#pragma once

#include <boost/asio/local/datagram_protocol.hpp>
#include <hphlib/io/UnixDomainDatagramSocket.h>
#include <chrono>
#include <ros/ros.h>
#include <string>
#include <nlohmann/json.hpp>

namespace telemetry {

    /**
     * Reports key value pairs to the telemetry core service through a local UDP socket by encoding
     * the data in JSON. Telemetry data is then collected by the core and periodically send to the remote station.
     * For each key only the latest value is send, updates exceeding the core sending frequency are therefore dropped
     * and only the latest value is transmitted.
     * @brief Report telemetry data to the telemetry core service
     * @author Maximilian Schier
     */
    class Runner {
    private:
        std::string node_name_;
        hphlib::UnixDomainDatagramSocket socket_;
        hphlib::UnixDomainDatagramSocket::Endpoint core_endpoint_;

        nlohmann::json stage_;
        nlohmann::json last_;

        std::chrono::steady_clock::time_point next_forced_report_;

    public:
        /**
         * Instantiate new reporter
         * @param node_name Node name of this reporter, all keys are grouped by this name, should be unique among nodes
         * and node instances
         */
        explicit Runner(const std::string &node_name);

        /**
         * Report a value under given key, also reports any previously staged values not reported.
         * @tparam T Type of value, must be encodable as JSON
         * @param key Key name
         * @param value Value, encoded representation should not exceed 1000 bytes or this telemetry data may not be
         * able to be send by the core service (exceeding the MTU of the connection) since the core service cannot
         * currently split individual value pieces.
         */
        template<typename T>
        void report(const std::string &key, const T &value) {
            stage(key, value);
            report();
        }

        /**
         * Report previously staged values
         */
        void report();

        template <typename Func>
        void reportProcessingTime(Func f) {
            auto s = std::chrono::high_resolution_clock::now();

            f();

            std::chrono::duration<double, std::ratio<1, 1>> secs = std::chrono::high_resolution_clock::now() - s;

            report("t_proc", secs.count());
        }

        /**
         * Stage a key value pair for reporting. Will be reported with the next call to report(). Note that the default
         * does not stage values that have not been changed since the last force clear.
         * @tparam T Type of value, must be encodable as JSON
         * @param key Key name
         * @param value Value, encoded representation should not exceed 1000 bytes or this telemetry data may not be
         * able to be send by the core service (exceeding the MTU of the connection) since the core service cannot
         * currently split individual value pieces.
         */
        template <typename T>
        void stage(const std::string& key, const T &value) {

            // Check whether the last reported value for this node and key matches the value to stage. If that is the
            // case, there is no reason to report the same value again so save bandwidth and just return

            auto it = last_.find(node_name_);

            if (it != last_.end()) {
                auto val_it = it->find(key);

                if (val_it != it->end()) {
                    if (*val_it == value) {
                        // Abort if value matches last reported value
                        return;
                    }
                }
            }

            stage_[node_name_][key] = value;
            last_[node_name_][key] = value;
        }
    };
}
