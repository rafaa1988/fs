#include <ros/ros.h>
#include "NeighbourBasedDetection.h"

int main(int argc, char **argv) {
    ros::init(argc, argv, "cone_detection");
    ros::NodeHandle n("~");
    NeighbourBasedDetection cone_detection(n);

    ROS_INFO_STREAM("Fired up cone_detection on " << n.getNamespace());

    ros::spin();

    return EXIT_SUCCESS;
}