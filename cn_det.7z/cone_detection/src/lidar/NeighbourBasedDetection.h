#pragma once

#include <utility>
#include <pcl_ros/point_cloud.h>
#include <ros/node_handle.h>
#include <telemetry/Runner.h>
#include "pcl_extensions.h"

struct cluster {
    float x;
    float y;
    float z;
    std::vector<pcl::PointXYZRGBA> points;
    uint32_t rgba;
    int neighbour_counter;
};

/**
 * Instantiating a Node which subscribes to one Lidar Driver and detects potential cones which can be validated by a camera
 * based classification.
 * Detection algorithm:
 * 1. Euclidean Clustering:
 * 1.1 Remove Points outside specified range
 * 1.2 if ignore_ground == true -> flag from Ibeo Lux Sensor is used to remove ground points
 * 2. Cluster density based filter: Discards cluster with to many neighbour cluster. Because they occur mostly in a
 * cluttered environment (like bushes, grass) and on big objects.
 * All clusters with more than'max_neighbours' within 'neighbour_search_radius' are
 * discarded (because occurring in a cluttered environment like bushes, grass).
 * 3. Sort objects by relevance for the validation node: The published cones are sorted by the distance to the car.
 */
class NeighbourBasedDetection {

private:
    //rosparam
    std::string topic_subscribe;
    std::string topic_publish;
    std::string topic_publish_for_icp;
    double max_distance_squared;                // points outside the max_distance are discarded
    double min_distance_squared;                // points inside the min_distance are discarded
    double cluster_radius;              // cluster_radius for euclidean clustering
    double neighbour_search_radius;     // for Cluster density based filter
    std::size_t min_points;             // min points needed on a cluster
    int max_neighbours;                 // max number of neighbour clusters allowed (in neighbour_search_radius) for valid objects
    bool ignore_ground;                  // if ignore_ground == true -> flag from Ibeo Lux Sensor is used to remove ground points

    //variables
    ros::Publisher publisher, publisher_for_icp;
    ros::Subscriber subscriber;
    std::vector<cluster> clusters;
    telemetry::Runner tele_;


    //functions
    double distance_squared_3d_clusters(const cluster &a, const cluster &b);
    int count_neighbours(cluster curr_cluster);
    static bool compare_by_distance_to_car(const pcl::PointXYZRGBA& a, const pcl::PointXYZRGBA& b);
    static double distance_squared_2d_points(const pcl::PointXYZRGBA &a, const pcl::PointXYZRGBA &b);
    void callback(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &input_cloud);
    cluster* get_cluster(pcl::PointXYZRGBA point);

public:
    explicit NeighbourBasedDetection(ros::NodeHandle& n);
    NeighbourBasedDetection(const NeighbourBasedDetection& that) = delete;
    NeighbourBasedDetection(NeighbourBasedDetection&& that) = delete;
    NeighbourBasedDetection& operator=(const NeighbourBasedDetection& that) = delete;
    NeighbourBasedDetection& operator=(NeighbourBasedDetection && that) = delete;
};

