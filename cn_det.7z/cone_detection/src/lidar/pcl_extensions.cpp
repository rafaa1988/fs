#include "pcl_extensions.h"

float dist_xy_squared(const pcl::PointXYZ& a, const pcl::PointXYZ& b) {
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

pcl::PointXYZ& operator+=(pcl::PointXYZ& a, const pcl::PointXYZ& b) {
    a.x += b.x;
    a.y += b.y;
    a.z += b.z;

    return a;
}

pcl::PointXYZ& operator/=(pcl::PointXYZ& a, float c) {
    a.x /= c;
    a.y /= c;
    a.z /= c;

    return a;
}