#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include "NeighbourBasedDetection.h"

NeighbourBasedDetection::NeighbourBasedDetection(ros::NodeHandle &n)
    : topic_subscribe(getRequiredRosParam<std::string>(n, "topic_subscribe"))
    , topic_publish(getRequiredRosParam<std::string>(n, "topic_publish"))
    , topic_publish_for_icp(getRequiredRosParam<std::string>(n, "topic_publish_for_icp"))
    , max_distance_squared(std::pow(getRequiredRosParam<double>(n, "max_distance"), 2.0))
    , min_distance_squared(std::pow(getRequiredRosParam<double>(n, "min_distance"), 2.0))
    , cluster_radius(getRequiredRosParam<double>(n, "cluster_radius"))
    , neighbour_search_radius(getRequiredRosParam<double>(n, "neighbour_search_radius"))
    , min_points(getRequiredRosParam<int>(n, "min_points"))
    , max_neighbours(getRequiredRosParam<int>(n, "max_neighbours"))
    , ignore_ground(getRequiredRosParam<bool>(n, "ignore_ground"))
    , publisher(n.advertise<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_publish, 1))
    , publisher_for_icp(n.advertise<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_publish_for_icp, 1))
    , subscriber(n.subscribe<pcl::PointCloud<pcl::PointXYZRGBA>>(topic_subscribe, 1, &NeighbourBasedDetection::callback, this))
    , tele_(getRequiredRosParam<std::string>(n, "tele_node"))
{
}


double NeighbourBasedDetection::distance_squared_2d_points(const pcl::PointXYZRGBA &a, const pcl::PointXYZRGBA &b) {
    return (a.x-b.x) * (a.x-b.x) + (a.y-b.y) * (a.y-b.y);
}

double NeighbourBasedDetection::distance_squared_3d_clusters(const cluster &a, const cluster &b) {
    return (a.x-b.x) * (a.x-b.x) + (a.y-b.y) * (a.y-b.y) + (a.z-b.z) * (a.z-b.z);
}


cluster* NeighbourBasedDetection::get_cluster(pcl::PointXYZRGBA point) {
    for(size_t i = 0; i < clusters.size(); i++) {
        auto curr_cluster = clusters[i];
        float distance = (curr_cluster.x - point.x) * (curr_cluster.x - point.x)
                + (curr_cluster.y - point.y) * (curr_cluster.y - point.y);
        if (distance <= cluster_radius * cluster_radius) {
            return &clusters[i];
        }
    }
    return nullptr;
}


/**
 * Count Neighbours of a given cluster.
 * @param curr_cluster
 * @return Number of neighbours of curr_cluster
 */
int NeighbourBasedDetection::count_neighbours(cluster curr_cluster) {
    int counted_neighbours = 0;
    for(size_t i = 0; i < clusters.size(); i++) {
       if(distance_squared_3d_clusters(curr_cluster, clusters[i]) < neighbour_search_radius * neighbour_search_radius)
           counted_neighbours = counted_neighbours + 1;
    }
    return counted_neighbours;
}

/**
 * Compares two clusters by their distance to the car
 * @param a Cluster a (its centroid given as pcl::PointXYZRGBA&)
 * @param b Cluster b (its centroid given as pcl::PointXYZRGBA&)
 * @return
 */
bool NeighbourBasedDetection::compare_by_distance_to_car(const pcl::PointXYZRGBA& a, const pcl::PointXYZRGBA& b)
{
    pcl::PointXYZRGBA zero_point;
    zero_point.x = 0.0;
    zero_point.y = 0.0;
    zero_point.z = 0.0;
    return distance_squared_2d_points(zero_point, a) < distance_squared_2d_points(zero_point, b);
}

/**
 * Callback which detects cones in lidar pointcloud.
 * @param input_cloud lidar pointcloud.
 */
void NeighbourBasedDetection::callback(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &input_cloud) {
    tele_.reportProcessingTime([&] () {
        pcl::PointCloud<pcl::PointXYZRGBA> filtered_points_;
        // clear point clouds every frame
        filtered_points_.clear();
        clusters.clear();

        const auto& points(*input_cloud);
        pcl::PointXYZRGBA point_zero;

        filtered_points_.header = points.header;

        //***1. Euclidean Clustering:***************************************************************************************
        for (size_t i = 0; i < input_cloud->size(); ++i) {
            pcl::PointXYZRGBA point;
            point = points[i];

            double distance_sq = distance_squared_2d_points(point_zero, point);

            // point in max distance?
            if (min_distance_squared < distance_sq && distance_sq < max_distance_squared) {

                bool do_filter_ground = ignore_ground && (point.rgba == 0xff000000);

                if (!do_filter_ground) {
                    cluster * const curr_cluster = get_cluster(point);
                    if (curr_cluster) {
                        curr_cluster->points.push_back(point);
                        float x = 0;
                        float y = 0;
                        float z = 0;
                        size_t n = 0;
                        for (auto p : curr_cluster->points) {
                            x = x + p.x;
                            y = y + p.y;
                            z = z + p.z;
                            n = n + 1;
                        }
                        curr_cluster->x = x / n;
                        curr_cluster->y = y / n;
                        curr_cluster->z = z / n;


                    }
                    else { // create new cluster
                        cluster new_cluster;
                        new_cluster.x = point.x;
                        new_cluster.y = point.y;
                        new_cluster.z = point.z;
                        new_cluster.points.push_back(point);
                        new_cluster.rgba = 0xff00ffff;
                        clusters.push_back(new_cluster);
                    }
                }
            }
        }

        //If publisher_for_icp is subscribed publish unfiltered cluster center for icp_node
        if(publisher_for_icp.getNumSubscribers() > 0) {
             pcl::PointCloud<pcl::PointXYZRGBA> points_for_icp;
             points_for_icp.clear();
             points_for_icp.header = points.header;
             for (auto curr_cluster : clusters) {
                    // convert to point cloud
                    pcl::PointXYZRGBA new_point;
                    new_point.x = curr_cluster.x;
                    new_point.y = curr_cluster.y;
                    new_point.z = curr_cluster.z;
                    new_point.rgba = curr_cluster.rgba;
                    points_for_icp.push_back(new_point);
             }
             publisher_for_icp.publish(points_for_icp);
        }

        //***2. Cluster density based filter:*******************************************************************************
        //Count Neighbours of each cluster
        for (auto & curr_cluster : clusters) {
            curr_cluster.neighbour_counter = count_neighbours(curr_cluster);
            //ROS_INFO("neighbour_counter %i", curr_cluster.neighbour_counter);
        }

        //Filter points by param max_neighbours and param min_points.
        for (auto curr_cluster : clusters) {
            // check if cluster does not has to many neigbour clusters and more than min points
            //ROS_INFO("1 -> %i <= %i", curr_cluster.neighbour_counter, max_neighbours);
            if (curr_cluster.neighbour_counter <= max_neighbours
                    && curr_cluster.points.size() >= min_points) {
                // convert to point cloud
                pcl::PointXYZRGBA new_point;
                new_point.x = curr_cluster.x;
                new_point.y = curr_cluster.y;
                new_point.z = curr_cluster.z;
                new_point.rgba = curr_cluster.rgba;
                filtered_points_.push_back(new_point);
            }
        }

        //***3. Sort objects by relevance for the validation node:**********************************************************
        //Relevance Ranking of detections for validation node. The clusters are ranked by the distance to the car.
        // A small distance to the car means a good rank and therefor an front position in the published pointcloud.
        std::sort(filtered_points_.begin(), filtered_points_.end(), compare_by_distance_to_car);

        publisher.publish(filtered_points_);
    });
}