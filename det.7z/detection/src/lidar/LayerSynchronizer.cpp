#include "LayerSynchronizer.h"
#include "pcl_extensions.h"

LayerSynchronizer::LayerSynchronizer(std::unique_ptr<DetectionAlgorithm> algo, ros::Publisher publisher,
                                     size_t layers, double vertical_angle_min, double vertical_angle_step,
                                     std::string tf_name)
    : algo_(std::move(algo))
    , publisher_(std::move(publisher))
    , reported_layers_(layers, false)
    , vertical_angle_min_(vertical_angle_min)
    , vertical_angle_increment_(vertical_angle_step)
    , tf_name_(std::move(tf_name))
    , seq_no_(0)
{
}

void LayerSynchronizer::report(size_t layer, sensor_msgs::LaserScan scan) {

    double vertical_angle = vertical_angle_min_ + layer * vertical_angle_increment_;

    algo_->feedLayer(scan, vertical_angle);

    // If this layer was already reported since the last fusing, this is suspicious since the lidar driver
    // should always send out all scan lines right after another, warn about it
    if (reported_layers_[layer]) {
        ROS_WARN(
                "Layer %lu has reported more than once. Dropped a frame?",
                layer
        );
    }

    // Set this layer as reported
    reported_layers_[layer] = true;

    // If all layers have reported, that is, no layer has not reported
    if (std::find(reported_layers_.begin(), reported_layers_.end(), false) == reported_layers_.end()) {

        auto fused_plc = algo_->evaluateAndReset();

        fused_plc.header.frame_id = tf_name_;
        fused_plc.header.seq      = seq_no_++;

        // For timestamp of the detection cloud, use the timestamp of the last reported layer. This allows to easily
        // sync the detection message with other sensor input, like camera images
        pcl_conversions::toPCL(scan.header.stamp, fused_plc.header.stamp);
        fused_plc.is_dense        = false;
        fused_plc.width           = static_cast<uint32_t>(fused_plc.size());
        fused_plc.height          = 1;

        publisher_.publish(fused_plc);

        // Reset report flag for all layers
        std::fill(reported_layers_.begin(), reported_layers_.end(), false);
    }
}
