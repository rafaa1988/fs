#include "ScanLineDetector.h"

ScanLineDetector::ScanLineDetector(double min_good_distance, double detect_derivation_jump, double max_cone_width,
                                   double close_cone_threshold, size_t close_cone_min_rays)
        : min_good_lidar_distance_(min_good_distance)
        , detect_derivation_jump_(detect_derivation_jump)
        , max_cone_width_(max_cone_width)
        , close_cone_threshold_(close_cone_threshold)
        , close_cone_min_rays_(close_cone_min_rays)
{
}

void ScanLineDetector::filter_background(sensor_msgs::LaserScan &scan) {

    size_t size = scan.ranges.size();

    // Set three consecutive zeroes to max range
    for (size_t i = 0; i < size - 2; ++i) {
        if (scan.ranges[i] == 0.0 && scan.ranges[i + 1] == 0.0 && scan.ranges[i + 2] == 0.0) {
            scan.ranges[i]     = scan.range_max;
            scan.ranges[i + 1] = scan.range_max;
            scan.ranges[i + 2] = scan.range_max;
        }
    }
}

std::vector<double> ScanLineDetector::find_derivations(const sensor_msgs::LaserScan &scan) {
    size_t size = scan.ranges.size() - 1;

    // Initially all derivations are 0
    std::vector<double> derivations(size, std::numeric_limits<double>::signaling_NaN());

    // Maximum number of invalid ranges that can be skipped while searching for a derivation
    constexpr size_t max_skip = 4;

    for (size_t i = 0; i < size; ++i) {
        // If this range is too close, derivation is invalid
        if (scan.ranges[i] <= min_good_lidar_distance_) {
            continue;
        }

        // We are on a valid range, find the next valid range but do not exceed max_skip or end of data
        for (size_t l = 1; l < max_skip && i + l < scan.ranges.size(); ++l) {
            // If this range is not too close and therefore valid
            if (scan.ranges[i + l] > min_good_lidar_distance_) {
                // Derivation is current range - valid range
                derivations[i] = scan.ranges[i] - scan.ranges[i + l];
                break;
            }
        }
    }

    return derivations;
}

void ScanLineDetector::find_cones(sensor_msgs::LaserScan &scan,
                                  double layer_vertical_angle, pcl::PointCloud<pcl::PointXYZ>& out) {

    filter_background(scan);

    auto derivations = find_derivations(scan);

    size_t too_big = 0, bad_jump = 0, bad_deviation = 0;

    bool on_cone = false;
    size_t cone_start = 0; // Actually not required to initialize, but IDE complains :/

    // Sum of ranges since start of cone
    double sum_distances = 0;

    // Number of valid ranges since start of cone, this is not equal to i - cone_start since some
    // ranges might have been skipped as invalid
    size_t count_ranges = 0;

    for (size_t i = 0; i < scan.ranges.size() - 1; ++i) {

        // Skip if this ranges derivation is bad
        if (std::isnan(derivations[i])) {
            bad_deviation++;
            continue;
        }

        // If delta of distance to next exceeds detection, cone starts at next valid scan line
        if (derivations[i] > detect_derivation_jump_) {
            // Start tracking of cone and skip rest of loop
            on_cone = true;
            // TODO: i + 1 is not guaranteed to be the next valid scan line, thus cone_start might be wrong
            cone_start = i + 1;
            sum_distances = 0;
            count_ranges = 0;
            continue;
        }

        if (on_cone) {
            // Tracking cone of previous range
            size_t rays_since_start = i - cone_start + 1;

            // Update sum
            sum_distances += scan.ranges[i];
            ++count_ranges;
            double avg_distance = sum_distances / count_ranges;

            // Check whether cone was left
            if (derivations[i] < -detect_derivation_jump_) {
                if (avg_distance > close_cone_threshold_ || rays_since_start > close_cone_min_rays_) {
                    // Calculate middle of cone:
                    // Remember: cone_start is index where first ray was on cone, i is index where last ray was on
                    // cone because derivation after i was off cone
                    // TODO: Derivation may have skipped rays, in this case calculation is incorrect
                    double middle_index = (i - cone_start) / 2.0 + cone_start;

                    double angle = middle_index * scan.angle_increment + scan.angle_min;

                    pcl::PointXYZ point{};

                    point.x = static_cast<float>(std::cos(layer_vertical_angle) * std::cos(angle) * avg_distance);
                    point.y = static_cast<float>(std::cos(layer_vertical_angle) * std::sin(angle) * avg_distance);
                    point.z = static_cast<float>(std::sin(layer_vertical_angle) * avg_distance);

                    out.push_back(point);
                } else {
                    bad_jump++;
                }

                // In any case, we are off a cone so reset cone flag and skip
                on_cone = false;
                continue;
            }

            // Check if still believable cone width, otherwise unset on_cone flag and skip
            float angle = scan.angle_increment * rays_since_start;
            double width = std::tan(angle) * avg_distance;

            if (width > max_cone_width_) {
                on_cone = false;
                too_big++;
                continue;
            }
        }
    }

    // ROS_INFO("MAX_WIDTH: %d, BAD_FADEOUT: %d, BAD_DELTA: %d, TOTAL: %d", too_big, bad_jump, bad_deviation, scan.ranges.size());
}
