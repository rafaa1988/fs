#pragma once

#include "../../DetectionAlgorithm.h"
#include "CentroidFuser.h"
#include "ScanLineDetector.h"

/**
 * LIdar Sprung Abtastung - LISA
 *
 * Basic algorithm detecting cones by linear scanning of laser scan layers and marking rapid jumps in depth function
 */
class Lisa : public DetectionAlgorithm {

    /**
     * Detects cones by depth function jump on individual scan lines
     */
    ScanLineDetector detector_;

    /**
     * Fuses candidates of individual scan lines into one point cloud
     */
    CentroidFuser fuser_;

    /**
     * Point cloud of all unfused candidates reported since the last publishing
     */
    pcl::PointCloud<pcl::PointXYZ> candidates_;

public:

    /**
     * Create a new instance of the Lisa algorithm by parsing parameters from the given node handle
     * @param n Node handle containing algorithm parameters
     */
    explicit Lisa(const ros::NodeHandle& n);

    pcl::PointCloud<pcl::PointXYZ> evaluateAndReset() override;

    void feedLayer(sensor_msgs::LaserScan &scan, double layer_vertical_angle) override;

    void reset() override;
};
