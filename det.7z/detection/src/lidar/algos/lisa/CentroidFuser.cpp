#include "CentroidFuser.h"
#include "../../pcl_extensions.h"

CentroidFuser::CentroidFuser(float max_cluster_xy_radius, float min_cluster_distance)
    : max_cluster_xy_radius_(max_cluster_xy_radius), min_cluster_distance_(min_cluster_distance)
{
}

pcl::PointCloud<pcl::PointXYZ> CentroidFuser::fuse(const pcl::PointCloud<pcl::PointXYZ> &candidates) {

    // Vector indicating whether a candidate was already clustered and processed
    std::vector<bool> processed(candidates.size(), false);

    pcl::PointCloud<pcl::PointXYZ> all_centroids;

    // Vector containing all indices of the current cluster
    std::vector<size_t> current_cluster_indices;

    for (size_t i = 0; i < candidates.size(); ++i) {
        if (processed[i]) {
            continue;
        }

        processed[i] = true;

        current_cluster_indices.clear();
        current_cluster_indices.push_back(i);

        // Cluster candidates that are close enough on the xy-plane, can start after i since everything before that
        // has already been processed
        for (size_t k = i + 1; k < candidates.size(); ++k) {
            if (processed[k]) {
                continue;
            }
            // TODO! Find a better solution Maximilian!
            for (auto l:current_cluster_indices) {
                if (dist_xy_squared(candidates[l], candidates[k]) <= max_cluster_xy_radius_ * max_cluster_xy_radius_) {
                    processed[k] = true;
                    current_cluster_indices.push_back(k);
                    break;
                }
            }
        }

        // Calculate center of current cluster
        pcl::PointXYZ centroid{};

        for (auto idx : current_cluster_indices) {
            centroid += candidates[idx];
        }

        centroid /= current_cluster_indices.size();

        all_centroids.push_back(centroid);
    }

    // clear all_centroid from near clusters
    std::vector<bool> valid_centroids_ind(all_centroids.size(), true);

    for (size_t current_ind=0; current_ind<all_centroids.size(); current_ind++) {
        for (size_t compare_ind=0; compare_ind<all_centroids.size(); compare_ind++) {
            if(current_ind == compare_ind) {
                continue;
            }
            if (dist_xy_squared(all_centroids[current_ind],pcl::PointXYZ())<15*15) { // TODO! Hardgecodet!!!!
                continue;
            }
            if(dist_xy_squared(all_centroids[current_ind],all_centroids[compare_ind]) < min_cluster_distance_ * min_cluster_distance_) {
                valid_centroids_ind[current_ind] = false;
                valid_centroids_ind[compare_ind] = false;
            }
        }
    }

    pcl::PointCloud<pcl::PointXYZ> valid_centroids;
    for(size_t ind=0; ind<valid_centroids_ind.size(); ind++) {
        if (valid_centroids_ind[ind]) {
            valid_centroids.push_back(all_centroids[ind]);
        }
    }

    return valid_centroids;
}
