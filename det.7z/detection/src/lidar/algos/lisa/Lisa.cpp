#include "Lisa.h"
#include "../../util.h"

Lisa::Lisa(const ros::NodeHandle &n)
    : detector_(
        getRequiredRosParam<double>(n, "min_good_distance_m"),
        getRequiredRosParam<double>(n, "delta_detect_m"),
        getRequiredRosParam<double>(n, "max_cone_width_m"),
        getRequiredRosParam<double>(n, "close_cone_threshold_m"),
        static_cast<size_t>(getRequiredRosParam<int>(n, "close_cone_min_rays"))
      )
    , fuser_(
        getRequiredRosParam<float>(n, "fuse_cluster_radius_m"),
        getRequiredRosParam<float>(n, "min_cluster_distance")
      )
{
}

pcl::PointCloud<pcl::PointXYZ> Lisa::evaluateAndReset() {
    auto res = fuser_.fuse(candidates_);
    this->reset();
    return res;
}

void Lisa::feedLayer(sensor_msgs::LaserScan &scan, double layer_vertical_angle) {
    detector_.find_cones(scan, layer_vertical_angle, candidates_);
}

void Lisa::reset() {
    candidates_.clear();
}
