#pragma once

#include <pcl_ros/point_cloud.h>
#include <sensor_msgs/LaserScan.h>

/**
 * Detects cone candidates from a single scan line
 */
class ScanLineDetector {
private:
    /**
     * Minimum distance in meters for lidar range to be considered valid
     */
    double min_good_lidar_distance_;

    /**
     * Minimum jump in meters in range to detect start or end of cone
     */
    double detect_derivation_jump_;

    /**
     * Maximum width in meters of a cone
     */
    double max_cone_width_;

    /**
     * Threshold in meters where a cone is considered close, changing how validity
     * of a cone candidate is determined
     */
    double close_cone_threshold_;

    /**
     * Minimum number of rays on cone for a close cone to be considered valid
     */
    size_t close_cone_min_rays_;


public:

    ScanLineDetector(double min_good_distance, double detect_derivation_jump, double max_cone_width,
                     double close_cone_threshold, size_t close_cone_min_rays);

    /**
     * Set background to max range in the given laser scan message
     * @param scan Scan message
     */
    static void filter_background(sensor_msgs::LaserScan& scan);

    /**
     * Compute all derivations. The derivation vector has a size of scan.ranges.size() - 1.
     * The derivation dev[i] is either NaN on error (i.e. invalid scan range) or otherwise
     * scan.ranges[i] - next valid scan.range
     * @param scan
     * @param min_distance
     * @return
     */
    std::vector<double> find_derivations(const sensor_msgs::LaserScan& scan);

    void find_cones(sensor_msgs::LaserScan& scan,
                    double layer_vertical_angle, pcl::PointCloud<pcl::PointXYZ>& out);
};