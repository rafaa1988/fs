# Lisa - *LI*dar *S*prung *A*btastung

### Description

Lidar Sprung Abtastung (Lidar Jump Scanning) implements basic cone detection
by individually searching each Lidar layer linearly calculating the approximate
derivation and marking jumps larger than predefined values. If a forward jump
followed by a backward jump of large enough size is encountered and the width
within that jump is reasonable for a cone, the algorithm places that cone into
a preliminary result set.

When the algorithm is asked to evaluate the whole frame, it simply fuses any
close points in the preliminary result set and returns it.

### Parameters

Name | Type | Description
---|---|---
`min_good_distance_m` | `double` | Minimum distance in Lidar scan in meters to consider good, any closer measurements are ignored
`delta_detect_m` | `double` | Minimum difference in meters of two neighbouring good samples in depth function to consider a jump in either direction
`max_cone_width_m` | `double` | Maximum cone width in meters. Any larger objects are discarded
`close_cone_threshold_m` | `double` | Threshold distance in meters below which cones are considered close and have to be hit by multiple rays. Any further cones have to be hit by just one ray
`close_cone_min_rays` | `int` | Number of rays that have to hit a close cone for it to be considered valid, less rays and the object is discarded
`fuse_cluster_radius_m` | `double` | Radius of the sphere used to cluster candidates during the evaluation phase, all objects fitting within such a large sphere are considered one

*Note*: `close_cone_min_rays` applies to each layer individually, suppose a cone is hit twice on layer `1` and twice on layer 
`2`, if `close_cone_min_rays` is larger than 2, the cone will not be detected despite being hit 4 times.