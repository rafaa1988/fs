#pragma once

#include <pcl_ros/point_cloud.h>

/**
 * Fuses candidates from a point cloud of candidates, to a single centroid point.
 */
class CentroidFuser {

    // Maximum distance on the xy plane for a point to be considered part of a cluster
    float max_cluster_xy_radius_;
    float min_cluster_distance_;

public:

    explicit CentroidFuser(float max_cluster_xy_radius, float min_cluster_distance);

    pcl::PointCloud<pcl::PointXYZ> fuse(const pcl::PointCloud<pcl::PointXYZ>& candidates);
};