#pragma once

#include <ros/ros.h>

constexpr double DEG_TO_RAD = M_PI / 180.0;

/**
 * Get a required ROS parameter or throw if the operation fails
 * @tparam T Parameter type
 * @param n Node handle
 * @param name Parameter name
 * @param out Parameter value stored here on success
 * @returns Value on success
 * @throws std::runtime_error If the parameter could not be read
 */
template <typename T>
T getRequiredRosParam(const ros::NodeHandle& n, const std::string& name) {

    T out;

    if (!n.getParam(name, out)) {
        ROS_ERROR(
                "%s: Parameter %s required but does not exist or has wrong type",
                n.getNamespace().c_str(),
                name.c_str()
        );
        throw std::runtime_error("Failed to get a required parameter, see log for details");
    }

    return out;
}