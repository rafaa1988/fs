#pragma once

#include <pcl_ros/point_cloud.h>
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include "algos/lisa/CentroidFuser.h"
#include "algos/lisa/ScanLineDetector.h"
#include "DetectionAlgorithm.h"

/**
 * Synchronizes the received scan lines. Once every topic has received a scan line, does any full processing
 * like fusing and then publishes the result.
 */
class LayerSynchronizer {

    /**
     * Detection algorithm used
     */
    std::unique_ptr<DetectionAlgorithm> algo_;

    /**
     * Publisher used to publish fused cone cloud
     */
    ros::Publisher publisher_;

    /**
     * Vector indicating whether a layer has reported since the last publishing
     */
    std::vector<bool> reported_layers_;

    /**
     * Vertical angle of first layer in radian
     */
    double vertical_angle_min_;

    /**
     * Vertical angle increment between layers in radian
     */
    double vertical_angle_increment_;

    /**
     * Tf reference name
     */
    std::string tf_name_;

    /**
     * Sequence number for published messages
     */
    uint32_t seq_no_;

public:
    LayerSynchronizer(std::unique_ptr<DetectionAlgorithm> algo, ros::Publisher publisher, size_t layers,
                      double vertical_angle_min, double vertical_angle_step, std::string tf_name);

    /**
     * Called from a callback, reporting that a new laser scan message is available
     * @param layer Layer that the message was received for
     * @param scan Scan message
     */
    void report(size_t layer, sensor_msgs::LaserScan scan);
};
