#pragma once

#include <pcl_ros/point_cloud.h>
#include <sensor_msgs/LaserScan.h>

/**
 * Interface for detection algorithms.
 *
 * Detection algorithms operate on time frames. During a time frame, a listener can feed multiple layers to the
 * algorithm. The algorithm can immediately process this scan layer, or wait until a later point in time.
 *
 * Once all scan layers have been reported, the algorithm will be requested to evaluate the frame and return a point
 * cloud of potential cones.
 *
 * An algorithm can also be asked to reset the current time frame.
 */
class DetectionAlgorithm {
public:
    /**
     * Feed a new layer into the algorithm for the current frame
     * @param scan Scan layer
     */
    virtual void feedLayer(sensor_msgs::LaserScan &scan, double layer_vertical_angle) = 0;

    /**
     * Evaluate the current frame and reset the algorithm state
     * @return Cone candidates
     */
    virtual pcl::PointCloud<pcl::PointXYZ> evaluateAndReset() = 0;

    /**
     * Reset the algorithm state
     */
    virtual void reset() = 0;
};