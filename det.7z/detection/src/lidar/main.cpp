#include <sensor_msgs/point_cloud2_iterator.h>
#include "LaserScanListener.h"
#include "util.h"
#include "LayerSynchronizer.h"
#include "algos/lisa/Lisa.h"

int main(int argc, char **argv) {
    ros::init(argc, argv, "detection-lidar");
    ros::NodeHandle n("~");

    std::string layer_prefix      = getRequiredRosParam<std::string>(n, "topic_layer_prefix");
    std::string topic_map         = getRequiredRosParam<std::string>(n, "topic_map");
    std::string tf_frame          = getRequiredRosParam<std::string>(n, "frame");
    int layer_count_int           = getRequiredRosParam<int>(n, "layer_count");
    double vertical_angle_min     = getRequiredRosParam<double>(n, "vertical_angle_min_deg") * DEG_TO_RAD;
    double vertical_angle_step    = getRequiredRosParam<double>(n, "vertical_angle_step_deg") * DEG_TO_RAD;

    if (layer_count_int < 1) {
        ROS_ERROR("Must have at least one layer, layer_count was %d", layer_count_int);
        return EXIT_FAILURE;
    }

    size_t layer_count = static_cast<size_t>(layer_count_int);

    std::unique_ptr<DetectionAlgorithm> algo(std::make_unique<Lisa>(n));

    LayerSynchronizer sync(
            std::move(algo),
            n.advertise<pcl::PointCloud<pcl::PointXYZ>>(topic_map, 1),
            layer_count,
            vertical_angle_min,
            vertical_angle_step,
            std::move(tf_frame)
    );

    // Vector of all ROS subscribers used, must be kept in memory until subscribers no longer required
    std::vector<ros::Subscriber> subscribers;

    // Vector of listeners, listeners only contain descriptions for the topic the subscriber was subscribed to
    // such as the layer number, listeners are weakly referenced by their subscribers
    std::vector<LaserScanListener> listeners;

    // Must reserve enough capacity for listener vector since subscribers will hold
    // references to the listeners and dynamically growing the vector might move
    // the memory of the vector invalidating the pointers
    listeners.reserve(layer_count);

    // Loop from inclusive low bound to inclusive high bound
    for (size_t i = 0; i < layer_count; ++i) {

        // Topic to subscribe to is prefix + running index
        std::stringstream name_stream;
        name_stream << layer_prefix << i;

        // Create a new listener class that knows its index and the cones map publisher,
        // push it onto the vector of listeners, this will not reallocate the backing memory
        // as the listeners vector has been reserved to fit all earlier
        listeners.emplace_back(i, sync);

        // Create a subscriber with the listeners callback, its instance pointer and the topic name
        subscribers.push_back(n.subscribe<sensor_msgs::LaserScan, LaserScanListener>(
                name_stream.str(),
                1,
                &LaserScanListener::callback,
                &listeners.back()
        ));
    }

    ROS_INFO("Fired up lidar detection on %s", n.getNamespace().c_str());

    ros::spin();

    return EXIT_SUCCESS;
}