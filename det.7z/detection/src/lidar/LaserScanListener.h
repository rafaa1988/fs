#pragma once

#include <sensor_msgs/LaserScan.h>

class LayerSynchronizer;

/**
 * Listeners registered as callbacks for laser scan subscribers
 */
class LaserScanListener {
public:
    /**
     * Construct new laser scan listener
     * @param layer Layer this listener will serve as a subscriber callback for
     * @param synchronizer Synchronizer that messages are reported to
     */
    LaserScanListener(size_t layer, LayerSynchronizer& synchronizer);

    /**
     * Callback called by the subscriber when a laser scan is received
     * @param scan Received scan message
     */
    void callback(const sensor_msgs::LaserScan::ConstPtr& scan);

private:
    size_t layer_;
    LayerSynchronizer* synchronizer_;
};