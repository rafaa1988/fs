#pragma once

#include <ostream>
#include <pcl_ros/point_cloud.h>

/**
 * Calculate the squared distance of points a and b disregarding the z-axis
 * @param a First point
 * @param b Second point
 * @return Squared distance on xy-plane
 */
float dist_xy_squared(const pcl::PointXYZ& a, const pcl::PointXYZ& b);

pcl::PointXYZ operator+(const pcl::PointXYZ& a, const pcl::PointXYZ& b);
pcl::PointXYZ& operator+=(pcl::PointXYZ& a, const pcl::PointXYZ& b);
pcl::PointXYZ& operator/=(pcl::PointXYZ& a, float c);

template <typename PointType, typename Alloc>
std::ostream& operator<<(std::ostream& stream, const std::vector<PointType, Alloc>& cloud) {

    stream << "[";

    auto it = cloud.begin();

    auto end = cloud.end();

    bool first = true;

    for (; it != end; ++it) {
        if (first) {
            first = false;
        } else {
            stream << ", ";
        }

        stream << *it;
    }

    stream << "]";

    return stream;
}