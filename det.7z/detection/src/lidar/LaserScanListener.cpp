#include "LaserScanListener.h"

#include "LayerSynchronizer.h"

LaserScanListener::LaserScanListener(size_t layer, LayerSynchronizer& synchronizer)
        : layer_(layer)
        , synchronizer_(&synchronizer)
{
}

void LaserScanListener::callback(const sensor_msgs::LaserScan::ConstPtr &scan) {
    (void) scan;

    // ROS_INFO("Received laser scan from channel %d", layer_);

    synchronizer_->report(layer_, *scan);
}
