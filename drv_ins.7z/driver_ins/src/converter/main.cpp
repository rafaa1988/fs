#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

#include <hphlib/util.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>

float covariance;
float angular_covariance;
float gps_covariance;
ros::Publisher odo_pub;
ros::Publisher imu_pub;
ros::Publisher fix_pub;


void twistCallback(geometry_msgs::Twist twist) {
    nav_msgs::Odometry odo;

    odo.header.stamp = ros::Time::now();
    odo.header.frame_id = "base_link";

    odo.child_frame_id = "iNat";

    odo.twist.twist = twist;
    odo.twist.covariance = {
            covariance, 0, 0, 0, 0, 0,
            0, covariance, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, angular_covariance
    };

    odo_pub.publish(odo);
}

void imuCallback(sensor_msgs::Imu imu_in) {
    sensor_msgs::Imu imu;

    imu = imu_in;

    imu.header.stamp = ros::Time::now();

    imu.angular_velocity_covariance = {
            angular_covariance, 0, 0,
            0, angular_covariance, 0,
            0, 0, angular_covariance
    };

    imu.linear_acceleration_covariance = {
            covariance, 0, 0,
            0, covariance, 0,
            0, 0, covariance
    };

    imu.orientation_covariance =  {
            angular_covariance, 0, 0,
            0, angular_covariance, 0,
            0, 0, angular_covariance
    };

    imu_pub.publish(imu);
}

void gpsFixCallback(sensor_msgs::NavSatFix fix_in) {
    sensor_msgs::NavSatFix fix;

    fix = fix_in;


    fix.status.status = fix.status.STATUS_FIX;

    fix.position_covariance_type = fix.COVARIANCE_TYPE_APPROXIMATED;
    fix.position_covariance = {
            gps_covariance, 0, 0,
            0, gps_covariance, 0,
            0, 0, gps_covariance
    };

    fix_pub.publish(fix);
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "INS Twist to Odo Converter");
    ros::NodeHandle n("~");

    covariance = static_cast<float>(getRequiredRosParam<double>(n, "covariance"));
    angular_covariance = static_cast<float>(getRequiredRosParam<double>(n, "angular_covariance"));
    gps_covariance = static_cast<float>(getRequiredRosParam<double>(n, "gps_covariance"));
    std::string twist_topic= getRequiredRosParam<std::string>(n, "twist_topic");
    std::string odo_topic= getRequiredRosParam<std::string>(n, "odo_topic");
    std::string imu_in_topic= getRequiredRosParam<std::string>(n, "imu_in_topic");
    std::string imu_out_topic= getRequiredRosParam<std::string>(n, "imu_out_topic");
    std::string gps_in_topic= getRequiredRosParam<std::string>(n, "gps_in_topic");
    std::string gps_out_topic= getRequiredRosParam<std::string>(n, "gps_out_topic");

    odo_pub = n.advertise<nav_msgs::Odometry>(odo_topic, 1);
    ros::Subscriber twist_sub = n.subscribe(twist_topic, 1, &twistCallback);

    imu_pub = n.advertise<sensor_msgs::Imu>(imu_out_topic, 1);
    ros::Subscriber imu_sub = n.subscribe(imu_in_topic, 1, &imuCallback);

    fix_pub = n.advertise<sensor_msgs::NavSatFix>(gps_out_topic, 1);
    ros::Subscriber fix_sub = n.subscribe(gps_in_topic, 1, &gpsFixCallback);

    ros::spin();

    return EXIT_SUCCESS;
}