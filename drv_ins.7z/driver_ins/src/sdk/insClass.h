/*
 * insClass.h
 *
 *  Created on: Oct 19, 2015
 *      Author: tobias
 */

#ifndef __INSCLASS__
#define __INSCLASS__

//#include <semaphore.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
//#include <pthread.h>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <iostream>
#include <sys/types.h>
#include "ixcomhandler.h"

#ifdef __linux
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#elif _WIN32
#include <WinSock2.h>
#include <ws2tcpip.h>
#else
#error platform not supported
#endif

#ifdef _WIN32
#define ins_STRUCT_ATTRIBUTES
#pragma pack(push)
#pragma pack(1)
#else
#define ins_STRUCT_ATTRIBUTES __attribute__ ((__packed__))
#endif

//#define CONF_SAVE		0
//#define CONF_LOAD		1
//#define CONF_FACTORY	2


#define CHANGEPAR true
#define REQUESTPAR false
#define OPEN_CHANNEL 1
#define CLOSE_CHANNEL 0
//#define ALIGNCOMPLTE 0b0010000000000000
//#define ALIGNCOMPLTE		0x2000
#define ALIGNCOMPLTE		(1<<13)
#define RESPONSE_NONE 		-1
#define RESPONSE_OK   		0x0000
#define RESPONSE_INVPAR  	0x0001
#define RESPONSE_INVCHKSM	0x0002
#define RESPONSE_INVLOG		0x0003
#define RESPONSE_INVRATE	0x0004
#define RESPONSE_INVPORT	0x0005
#define RESPONSE_INVCMD		0x0006
#define RESPONSE_INVID		0x0007
#define RESPONSE_INVCH		0x0008
#define RESPONSE_VALOR		0x0009
#define RESPONSE_LOGEX		0x000A
#define RESPONSE_INVTR		0x000B
#define RESPONSE_INTERR		0x000C
#define RESPONSE_RES		0x000D
#define RESPONSE_NOK  2
#define ONE_PARAMETER 1
#define TWO_PARAMETERS 2
#define THREE_PARAMETERS 3
#define SIX_PARAMETERS 6
#define SEVEN_PARAMETER 7
#define EIGTH_PARAMETER 8

#define ARINC825_DOC_TIME			1069
#define ARINC825_DOC_ACCRAW			300
#define ARINC825_DOC_ACCCOR			301
#define ARINC825_DOC_ACCCOMP		302
#define ARINC825_DOC_OMGRAW			303
#define ARINC825_DOC_OMGCOR			304
#define ARINC825_DOC_OMGCOMP		305
#define ARINC825_DOC_RPY			311
#define ARINC825_DOC_VNED			1130
#define ARINC825_DOC_VXYZ			337
#define ARINC825_DOC_LON			1050
#define ARINC825_DOC_LAT			1049
#define ARINC825_DOC_ALT			1051
#define ARINC825_DOC_SYSSTAT		1303
#define ARINC825_DOC_EKF_LOW		1304
#define ARINC825_DOC_EKF_HI			1305
#define ARINC825_DOC_LONSTDDEV		1310
#define ARINC825_DOC_LATSTDDEV		1311
#define ARINC825_DOC_ALTSTDDEV		1314
#define ARINC825_DOC_VELSTDDEV		1312
#define ARINC825_DOC_RPYSTDDEV		1313
#define ARINC825_DOC_MAGICNUM		1315
#define ARINC825_DOC_GNSSLON		1037
#define ARINC825_DOC_GNSSLAT		1036
#define ARINC825_DOC_GNSSALT		1038
#define ARINC825_DOC_GNSSVEL		1608
#define ARINC825_DOC_GNSSINF		1201
#define ARINC825_DOC_GNSSPOSSTDDEV	1605
#define ARINC825_DOC_GNSSVELSTDDEV	1611

#define TMR_MTX_0					0
//#define TMR_MTX_1					1


//#ifdef _WIN32
//#pragma pack(2)
//#endif

//#ifdef __linux
//struct __attribute__ ((__packed__)) useLogData
//#elif _WIN32
//struct useLogData
//#else
//#error platform not supported
//#endif
struct ins_STRUCT_ATTRIBUTES useLogData
{
//		t_XCOM_MSG_INSSOL xcominsSol;
//		t_XCOM_MSG_INSPOSECEF xcominsPosECEF;
//	//	t_XCOM_MSG_INSPOSUTM xcominsPosUTM;
//		t_XCOM_MSG_INSDCM xcominsDCM;
//		t_XCOM_MSG_INSPOSLLH xcominsPosLLH;
//	//	t_XCOM_MSG_INSVELBODY xcominsVelBODY;
//	//	t_XCOM_MSG_IMUCOMP xcomimuCOMP;

	t_XCOM_MSG_INSSOL xcominsSol;
	t_XCOM_MSG_INSPOSECEF xcominsPosECEF;
	t_XCOM_MSG_GNSSSOL xcomgnssSol;
	t_XCOM_MSG_GNSSTIME xcomgnssTime;
	t_XCOM_MSG_IMUCAL xcomimuCal;
	t_XCOM_MSG_INSDCM xcominsDCM;
	t_XCOM_MSG_INSPOSLLH xcominsPosLLH;
	t_XCOM_MSG_IMUCOMP xcomimuComp;
	t_XCOM_MSG_IMUCORR xcomimuCorr;
	t_XCOM_MSG_IMURAW xcomimuRaw;
	t_XCOM_MSG_INSVELBODY xcominsVelBODY;
	t_XCOM_MSG_SYS_TEMP xcomTemp;
	t_XCOM_MSG_EKFSENSORERR2 xcomEkfError2;
	t_XCOM_MSG_EKFSTDDEV2 xcomEkfStdDev2;
};

//#ifdef __linux
//typedef struct __attribute__ ((__packed__))
//#elif _WIN32
//typedef struct
//#else
//#error platform not supported
//#endif
typedef struct ins_STRUCT_ATTRIBUTES
{
	 uint16_t usDivider;
     uint16_t usReserved;
     uint32_t uiDOC;
} t_ARINC825_FRAME;

//#ifdef __linux
//typedef struct __attribute__ ((__packed__))
//#elif _WIN32
//typedef struct
//#else
//#error platform not supported
//#endif
typedef struct ins_STRUCT_ATTRIBUTES
{
	t_ARINC825_FRAME uiDoc300;  // 1
	t_ARINC825_FRAME uiDoc301;  // 2
	t_ARINC825_FRAME uiDoc302;  // 3
	t_ARINC825_FRAME uiDoc303;  // 4
	t_ARINC825_FRAME uiDoc304;  // 5
	t_ARINC825_FRAME uiDoc305;  // 6
	t_ARINC825_FRAME uiDoc311;  // 7
	t_ARINC825_FRAME uiDoc337;  // 8
	t_ARINC825_FRAME uiDoc1130; // 9
	t_ARINC825_FRAME uiDoc1050; // 10
	t_ARINC825_FRAME uiDoc1049; // 11
	t_ARINC825_FRAME uiDoc1051; // 12
	t_ARINC825_FRAME uiDoc1069; // 13
	t_ARINC825_FRAME uiDoc1303; // 14
	t_ARINC825_FRAME uiDoc1304; // 15
	t_ARINC825_FRAME uiDoc1305; // 16
	t_ARINC825_FRAME uiDoc1310; // 17
	t_ARINC825_FRAME uiDoc1311; // 18
	t_ARINC825_FRAME uiDoc1312; // 19
	t_ARINC825_FRAME uiDoc1313; // 20
	t_ARINC825_FRAME uiDoc1314; // 21
	t_ARINC825_FRAME uiDoc1315; // 22 		// define ARINC825_DOC_MAGICNUM		1315
	t_ARINC825_FRAME uiDoc1037; // 23
	t_ARINC825_FRAME uiDoc1036; // 24
	t_ARINC825_FRAME uiDoc1038; // 25
	t_ARINC825_FRAME uiDoc1608; // 26
	t_ARINC825_FRAME uiDoc1201; // 27
	t_ARINC825_FRAME uiDoc1605; // 28
	t_ARINC825_FRAME uiDoc1611; // 29

	t_ARINC825_FRAME uiDoc1613; // 30
	t_ARINC825_FRAME uiDoc1614; // 31
	t_ARINC825_FRAME uiDoc1615; // 32
	t_ARINC825_FRAME uiDoc1616; // 33
	t_ARINC825_FRAME uiDoc1617; // 34
	t_ARINC825_FRAME uiDoc1618; // 35
	t_ARINC825_FRAME uiDoc1619; // 36
	t_ARINC825_FRAME uiDoc1620; // 37
	t_ARINC825_FRAME uiDoc1621; // 38

} t_ARINC825_FRAMEList;

//#ifdef __linux
//struct __attribute__ ((__packed__)) useUdpLogData
//#elif _WIN32
//struct useUdpLogData
//#else
//#error platform not supported
//#endif
struct ins_STRUCT_ATTRIBUTES useUdpLogData
{
//	t_XCOM_MSG_INSPOSLLH xcominsPosLLH;
//	t_XCOM_MSG_INSSOL xcominsSol;

	t_XCOM_MSG_INSSOL xcominsSol;
	t_XCOM_MSG_INSPOSECEF xcominsPosECEF;
	t_XCOM_MSG_GNSSSOL xcomgnssSol;
	t_XCOM_MSG_GNSSTIME xcomgnssTime;
	t_XCOM_MSG_IMUCAL xcomimuCal;
	t_XCOM_MSG_INSDCM xcominsDCM;
	t_XCOM_MSG_INSPOSLLH xcominsPosLLH;
	t_XCOM_MSG_IMUCOMP xcomimuComp;
	t_XCOM_MSG_IMUCORR xcomimuCorr;
	t_XCOM_MSG_IMURAW xcomimuRaw;
	t_XCOM_MSG_INSVELBODY xcominsVelBODY;
	t_XCOM_MSG_SYS_TEMP xcomTemp;
	t_XCOM_MSG_EKFSENSORERR2 xcomEkfError2;
	t_XCOM_MSG_EKFSTDDEV2 xcomEkfStdDev2;
};


//#ifdef __linux
//struct __attribute__ ((__packed__)) retParData
//#elif _WIN32
//struct retParData
//#else
//#error platform not supported
//#endif
struct ins_STRUCT_ATTRIBUTES retParData
{
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysPrjNum;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysPartNum;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysSerialNum;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysMFG;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysCalDate;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysFWVersion;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysNavLib;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysEkfLib;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysEkfParSet;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysNavNum;
	t_XCOM_PAR_XCOM_CHAR32 xcomParSysNavParSet;
	t_XCOM_PAR_SYS_MAINTIMING xcomParSysMaintiming;
	t_XCOM_PAR_SYS_PRESCALER xcomParSysPrescaler;
	t_XCOM_PAR_SYS_UPTIME xcomParSysUpTime;
	t_XCOM_PAR_SYS_OPHOURCNT xcomParSysOpHourCnt;
	t_XCOM_PAR_SYS_BOOTMODE xcomParSysBootMode;
	t_XCOM_PAR_SYS_FPGAVER xcomParSysFpgaVer;
	t_XCOM_PAR_FPGA_MCP23S08 xcomParFpgaMcp23s08;
	t_XCOM_PAR_SYS_CONFIGCRC xcomParSysConfigCrc;
	t_XCOM_PAR_XCOM_CHAR64 xcomParSysOsVersion;
	t_XCOM_PAR_XCOM_NTRIP xcomParNtrip;
	t_XCOM_PAR_DAT_IMU xcomParDatImu;
};

#ifdef _WIN32
#pragma pack(pop)
#endif


using namespace std;

class insCom {


public:

	/*class*/
	insCom(char const *p_Name);
	insCom(const insCom &) = delete;
    insCom& operator=(const insCom &) = delete;
	~insCom();

	t_ARINC825_FRAMEList m_ARINC825_FL;

#ifdef __MINGW32__
    int inet_pton(int af, const char *src, void *dst);  // QT_ch
    const char* inet_ntop(int af, const void *src, char *dst, socklen_t size);  // QT_ch
#endif

	int openNConnectSocket(const char *p_IPAddr,int g_Port);
	int ConnectUDPSocket(const char *p_IPAddr,int g_Port);
	int closeSocket(void);
	int closeUdpSocket(void);

	/*iXCOM*/
	int createMsgOpenChannel(int nofChannel);
	int createMsgCloseChannel(int nofChannel);
	int createMsgCmdLOG(const uint8_t MsgID, const uint8_t trig, const uint16_t parameter, const uint16_t divider);
	int createMsgCmdEKF(int cmd, int NumOfPar, float par[]);

	/*************************************/
	int createMsgCmdCONF(uint32_t cnfCmd);	// SAVE, LOAD, FACTORY
	int createMsgCmdEXTAID(uint16_t cmdID, double dTimeValue, uint16_t usTimeMode, int numOfPar, double par[]);	//	FREEZE_ALT, FREEZE_HDG, FREEZE_VELBODY, EXTAID_POS, EXTAID_VEL, EXTAID_HDG

//	int requestMsg_TEMP();

	//	SYS Parameters
	int requestMsgPARSYS_PRJNUM();
	int requestMsgPARSYS_PARTNUM();
	int requestMsgPARSYS_SERIALNUM();
	int requestMsgPARSYS_MFGDATE();
	int requestMsgPARSYS_CALDATE();
	int requestMsgPARSYS_FWVERSION();
	int requestMsgPARSYS_NAVLIB();
	int requestMsgPARSYS_EKFLIB();
	int requestMsgPARSYS_EKFPARSET();
	int requestMsgPARSYS_NAVNUM();
	int requestMsgPARSYS_NAVPARSET();
	int requestMsgPARSYS_MAINTIMING();
	int requestMsgPARSYS_PRESCALER();
	int requestMsgPARSYS_UPTIME();
	int requestMsgPARSYS_OPHOURCOUNT();
	int requestMsgPARSYS_BOOTMODE();
	int requestMsgPARSYS_FPGAVER();
	int requestMsgPARSYS_CONFIGCRC();
	int requestMsgPARSYS_OSVERSION();


	//	IMU Parameters
	int createMsgPARIMU_PORT();
	int createMsgPARIMU_BAUD();
	int createMsgPARIMU_RATE();
	int createMsgPARIMU_RANGEACC();
	int createMsgPARIMU_RANGEOMG();
	int createMsgPARIMU_MISALIGN(double pImuMisalign[]);
	int createMsgPARIMU_CRCTHR();
	int createMsgPARIMU_TYPE();

	//	GNSS Parameters
	int createMsgPARGNSS_PORT();
	int createMsgPARGNSS_BAUD();
	int createMsgPARGNSS_LATENCY();
	int createMsgPARGNSS_ANTOFFSET(double pLeverArm[], uint8_t Antenna);
	int createMsgPARGNSS_CFGFILE();
	int createMsgPARGNSS_SELRX();
	int createMsgPARGNSS_RTKMODE(uint32_t mode);
	int createMsgPARGNSS_VELLATENCY();
	int createMsgPARGNSS_AIDFRAME();
	int createMsgPARGNSS_DUALANTMODE(uint32_t mode);
	int createMsgPARGNSS_ELEVATIONMASK();
	int createMsgPARGNSS_NTRIP(uint32_t data[],char p_cStream[], char p_cServer[] ,char p_cUser[],char p_cPwd[]);
	int createMsgPARGNSS_RTCMV3CONFIG(uint32_t intValues[]);
	int createMsgPARGNSS_RTCMV3AIDING(char p_RTCMV3[64]);

	//	MAG Parameters
	int createMsgPARMAG_PORT();
	int createMsgPARMAG_BAUD();
	int createMsgPARMAG_RATE();
	int createMsgPARMAG_LATENCY();
	int createMsgPARMAG_MISALIGN();
	int createMsgPARMAG_CFGFILE();


	//	MADC Parameters
	int createMsgPARMADC_ENABLE();
	int createMsgPARMADC_LEVERARM();
	int createMsgPARMADC_LOWPASS();

	//	ODO Parameters
	int createMsgPARODO_SCF();
	int createMsgPARODO_TIMEOUT();
	int createMsgPARODO_MODE();
	int createMsgPARODO_LEVERARM();
	int createMsgPARODO_VELSTDDEV();
	int createMsgPARODO_DIRECTION();
	int createMsgPARODO_CONSTRAINT();
	int createMsgPARODO_UPDATERATE();

	//	MON Parameters
	int createMsgPARMON_LEVEL();
	int createMsgPARMON_TYPE();
	int createMsgPARMON_PORT();
	int createMsgPARMON_BAUD();

	//	REC Parameters
	int createMsgPARREC_CONFIG();
	int createMsgPARREC_START();
	int createMsgPARREC_STOP();
	int createMsgPARREC_POWER();

	//	EKF Parameters
	int createMsgPAREKF_ALIGNMODE(uint32_t *pAlignMode);
	int createMsgPAREKF_ALIGNTIME(uint32_t *pAlignTime);
	int createMsgPAREKF_COARSETIME(uint32_t *pCoarseTime);
	int createMsgPAREKF_HDGPOSTHR(double pEkfAlignThrs[]);
	int createMsgPAREKF_VMEASPOINT(uint32_t intValues[],  double doubleValues[]);
	int createMsgPAREKF_AIDING(uint32_t intValues[]);
	int createMsgPAREKF_FEEDBACK();
	int createMsgPAREKF_DELAY();
	int createMsgPAREKF_STARTUPV2(uint32_t p_intValues[], double p_doubleValues[]);
	int createMsgPAREKF_SMOOTH(uint32_t *pEkfSmooth);
	int createMsgPAREKF_LOWPASS();
	int createMsgPAREKF_DISTANCE();
	int createMsgPAREKF_ZUPT(uint32_t intValues[], double doubleValues[]);
	int createMsgPAREKF_HDGDIFF();
	int createMsgPAREKF_DEFPOS();
	int createMsgPAREKF_DEFHDG();
	int createMsgPAREKF_OUTLIER();
	int createMsgPAREKF_POWERDOWN();
	int createMsgPAREKF_EARTHRAD();
	int createMsgPAREKF_POSAIDSTDDEVTHR();
	int createMsgPAREKF_SCHULERMODE();
	int createMsgPAREKF_STOREDATT();
	int createMsgPAREKF_ODOMETER();
	int createMsgPAREKF_ODOBOGIE();
	int createMsgPAREKF_GNSSLEVERARMEST();
	int createMsgPAREKF_GNSSAIDRATE();
	int createMsgPAREKF_KINALIGNTHR();
	int createMsgPAREKF_PDOPTHR();
	int createMsgPAREKF_DUALANTAID(uint32_t intValues[],  double doubleValues[]);
	int createMsgPAREKF_MAGATTAID();
	int createMsgPAREKF_MADCAID();
	int createMsgPAREKF_ALIGNMENT();
	int createMsgPAREKF_GRAVITYAIDING();

	//	DAT Parameters
	int createMsgPARDAT_POS(uint32_t val[]);
	int createMsgPARDAT_VEL(uint32_t val[]);
	int createMsgPARDAT_IMU(uint32_t val[]);
	int requestMsgPARDAT_IMU();
	int createMsgPARDAT_SYSSTAT();

	//	XCOM Parameters
	int createMsgPARXCOM_RESP();
	int createMsgPARXCOM_PRIMITIVE();
	int createMsgPARXCOM_SERIALPORT();
	int createMsgPARXCOM_NETCONFIG();
	int createMsgPARXCOM_TIMESOURCE();
	int createMsgPARXCOM_UDPCONFIG(uint32_t intValues[], char p_srvAdrr[]);

	//	FPGA Parameters
	int createMsgPARFPGA_IMUSTATREG();
	int createMsgPARFPGA_HDLCREG();
	int createMsgPARFPGA_TIMINGREG();
	int createMsgPARFPGA_TIMER();
	int createMsgPARFPGA_INTERFACE();
	int createMsgPARFPGA_MCP23S08(uint8_t reg);
	int requestMsgPARFPGA_MCP23S08();

	//	CAN Parameters
	int createMsgPARARINC825_PORT(uint32_t intValues[]);
	int createMsgPARARINC825_BAUD(uint32_t intValues[]);
	int createMsgPARARINC825_ENABLE(uint32_t intValues[]);
	int createMsgPARARINC825_BUSRECOVERY(uint32_t intValues[]);

	//	NMEA Parameters
	int createMsgPARNMEA_COM();
	int createMsgPARNMEA_ENABLE();
	int createMsgPARNMEA_TXMASK();
	int createMsgPARNMEA_DECPLACES();

	/*************************************/

	int sentMsg(void);
	int sentNConfirmMsg(uint32_t msTimeOut, char* CmdResp);
	int waitAlignmentDone(uint32_t msTimeOut);
	int parseRxRunData(std::atomic_flag& continue_flag);
	int parseRxRunUdpData(void);
	int getUseData(struct useLogData *p_useData);
	int getUdpUseData(struct useUdpLogData *p_useUdpData);
	int getRetParData(struct retParData *p_retParData);
	void reinitmARINC825_FL(void);
	int setmARINC825FLEntry(uint16_t usFrameId, uint16_t usDivider);
	int createMsgPARARINC825_FrameList(void);


private:
//#ifdef __linux
	void CountDown(uint32_t msTimeOut, uint32_t msStep, int reason);
//	timer_t m_aTimer;
//#endif
	int m_insSocket;
	int m_udpSocket;
	int m_txResponse;
	char m_pcModuleID[256];
	uint32_t m_countDownVal_0;
	uint8_t m_goOnRunning_0;
//	uint32_t m_countDownVal_1;
//	uint8_t m_goOnRunning_1;


	iXComHandler m_ixcomhandler;
	iXComHandler m_uixcomhandler;
	iXComHandler::iXComSendFrame m_sendStruct;

//	pthread_mutex_t m_mx_useData;
//	pthread_mutex_t m_mx_useUdpData;
//	pthread_mutex_t m_mx_retParData;
//	pthread_mutex_t m_mx_globalStatus;
//	pthread_mutex_t m_mx_ARINC825FL;
//	pthread_mutex_t m_mx_rxResp;
//	pthread_mutex_t m_mx_txMsg;
//	pthread_mutex_t m_mx_sentConf;

	mutex m_mx_tmr_0;
//	mutex m_mx_tmr_1;
	mutex m_mx_useData;
	mutex m_mx_useUdpData;
	mutex m_mx_retParData;
	mutex m_mx_globalStatus;
	mutex m_mx_ARINC825FL;
	mutex m_mx_rxResp;
	mutex m_mx_txMsg;
	mutex m_mx_sentConf;
	mutex m_mx_socket;
	mutex m_mx_udpSocket;
	mutex m_mx_rx;
	condition_variable cond_var_m_mx_rx;
	mutex m_mx_gStatus;
	condition_variable cond_var_m_mx_gStatus;

//	sem_t m_sem_rx;
//	sem_t m_sem_gStatus;
	uint16_t m_globalStatus;
	useLogData m_useData;
	useUdpLogData m_udpLog;
	retParData m_retParData;
//	sem_t m_sem_socket;
//	sem_t m_sem_udpsocket;
	struct sockaddr_in m_inatIpAddr;
};

#endif
