/*
 * csdk_welcome.h
 *
 *  Created on: 14.10.2016
 *      Author: zp
 */

#ifndef SRC_CSDK_WELCOME_H_
#define SRC_CSDK_WELCOME_H_

void printWelcome();

#endif /* SRC_CSDK_WELCOME_H_ */
