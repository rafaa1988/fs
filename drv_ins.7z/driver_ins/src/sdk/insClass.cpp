#include "insClass.h"

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <sys/types.h>
//#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include <stdint.h>
#include <stddef.h>
#include <fcntl.h>
#include <stdio.h>

#ifdef __linux
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#elif _WIN32
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <io.h>
#include <semaphore.h>
//#include <chrono>
#include <Windows.h>
#include <ctime>
#else
#error platform not supported
#endif

insCom::insCom(char const *p_Name)
{
	m_countDownVal_0 = 0;
	m_goOnRunning_0 = 1;
//	m_countDownVal_1 = 0;
//	m_goOnRunning_1 = 1;

//	m_aTimer = 0;
	m_insSocket = 0;
	m_udpSocket = 0;
	m_txResponse = RESPONSE_NONE;
	memset(&m_pcModuleID,0,sizeof(m_pcModuleID));
	strncpy(m_pcModuleID,p_Name,sizeof(m_pcModuleID));
	memset(&m_inatIpAddr, 0, sizeof(m_inatIpAddr));

//	m_mx_useData		= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_globalStatus	= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_rxResp			= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_txMsg			= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_useUdpData		= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_retParData		= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_ARINC825FL		= PTHREAD_MUTEX_INITIALIZER;
//	m_mx_sentConf		= PTHREAD_MUTEX_INITIALIZER;


//	sem_init(&m_sem_rx,0,0);
//	sem_init(&m_sem_gStatus,0,0);
//	sem_init(&m_sem_socket,0,0);
//	sem_init(&m_sem_udpsocket,0,0);
	m_globalStatus = 0;
	memset(&m_sendStruct,0,sizeof(m_sendStruct));
	memset(&m_useData, 0, sizeof(useLogData));
	memset(&m_udpLog, 0, sizeof(useUdpLogData));
	
	cout << ">" << m_pcModuleID << " insCom object created" << endl;
}

/*insCom::insCom(const insCom &obj)
{

}*/

insCom::~insCom(void)
{
	cout << ">" << m_pcModuleID << " insCom object deleted" << endl;
}


int insCom::openNConnectSocket(const char *p_IPAddr,int g_Port){

	/*create tcp ip socket*/
	//struct sockaddr_in address;
	
#ifdef _WIN32
WORD wVersionRequested;
WSADATA wsaData;
wVersionRequested = MAKEWORD(1, 1);
WSAStartup(wVersionRequested, &wsaData);
#endif
	
	lock_guard<mutex> lock(m_mx_socket);
	m_insSocket=socket (AF_INET, SOCK_STREAM, 0);
	if ((0 == m_insSocket) || (-1 == m_insSocket))
	{
		return errno;
	}
	/*and connect to it*/
	m_inatIpAddr.sin_family = AF_INET;
	m_inatIpAddr.sin_port = htons (g_Port);
	
#ifdef __linux
	inet_aton (p_IPAddr, &m_inatIpAddr.sin_addr);
#elif _WIN32
	inet_pton(AF_INET, p_IPAddr, &m_inatIpAddr.sin_addr);
#else
#error  platform not supported
#endif

	if (0 != connect ( m_insSocket, (struct sockaddr *) &m_inatIpAddr, sizeof (m_inatIpAddr))) {
		return errno;
	}

//	sem_post(&m_sem_socket);
	return 0;
}

int insCom::ConnectUDPSocket(const char *p_IPAddr,int g_Port){

	lock_guard<mutex> lock(m_mx_udpSocket);

	/*create udp ip socket*/
	int m_udpPort = g_Port;
	struct sockaddr_in m_udpAddress;
//	m_udpSocket=socket (AF_INET, SOCK_DGRAM, 0);
	m_udpSocket=socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP);	// new
	if ((0 == m_udpSocket) || (-1 == m_udpSocket))
	{
		printf(">%s Error udp socket creation; m_udpSocket= %d\n",m_pcModuleID, m_udpSocket);
		perror(m_pcModuleID);
		return(-1);
	}
	/*and connect to it*/
	memset(&m_udpAddress, 0, sizeof(m_udpAddress));
	m_udpAddress.sin_family = AF_INET;
	m_udpAddress.sin_addr.s_addr = htonl(INADDR_ANY);	// new
	m_udpAddress.sin_port = htons(m_udpPort);

//#ifdef __linux
//	inet_aton(p_IPAddr, &m_udpAddress.sin_addr);
//#elif _WIN32
//	inet_pton(AF_INET, p_IPAddr, &m_udpAddress.sin_addr);
//#else
//#error platform not supported
//#endif

//int optval = 1;
//socklen_t optlen = sizeof(optval);
//if (0 == setsockopt(m_udpSocket, SOL_SOCKET, SO_BROADCAST, &optval, optlen))
//{
//	printf (">%s UDP setsockopt: BROADCAST\n",m_pcModuleID);
//}
//else
//{
//	printf(">%s Error udp setsockopt: BROADCAST\n",m_pcModuleID);
//	perror(m_pcModuleID);
//	return(-1);
//}

	//if (0 == bind( m_udpSocket, (struct sockaddr *) &m_udpAddress, sizeof (sockaddr_in)))
	if (0 == ::bind( m_udpSocket, (struct sockaddr *) &m_udpAddress, sizeof (m_udpAddress)))
	{
		//printf (">%s UDP binding: (%s) at Port (%d)\n",m_pcModuleID, inet_ntoa (m_udpAddress.sin_addr),g_Port);
		printf (">%s UDP binding: BROADCAST at Port (%d)\n",m_pcModuleID, g_Port);
	}
	else
	{
		printf(">%s Error udp socket connection\n",m_pcModuleID);
		perror(m_pcModuleID);
		return(-1);
	}
//	sem_post(&m_sem_udpsocket);
	return 0;

}

#ifdef __MINGW32__
int insCom::inet_pton(int af, const char *src, void *dst)   // QT_ch
{
  struct sockaddr_storage ss;
  int size = sizeof(ss);
  char src_copy[INET6_ADDRSTRLEN+1];

  ZeroMemory(&ss, sizeof(ss));
  /* stupid non-const API */
  strncpy (src_copy, src, INET6_ADDRSTRLEN+1);
  src_copy[INET6_ADDRSTRLEN] = 0;

  //if (WSAStringToAddress(src_copy, af, NULL, (struct sockaddr *)&ss, &size) == 0) {
  LPWSTR lpwstr_src_copy = new TCHAR[INET6_ADDRSTRLEN+1];
  MultiByteToWideChar(0, 0, src_copy, (INET6_ADDRSTRLEN+1), lpwstr_src_copy, (INET6_ADDRSTRLEN+1));
  if (WSAStringToAddress(lpwstr_src_copy, af, NULL, (struct sockaddr *)&ss, &size) == 0) {     // QT_ch

    switch(af) {
      case AF_INET:
    *(struct in_addr *)dst = ((struct sockaddr_in *)&ss)->sin_addr;
    return 1;
      case AF_INET6:
    *(struct in6_addr *)dst = ((struct sockaddr_in6 *)&ss)->sin6_addr;
    return 1;
    }
  }
  return 0;
}

const char* insCom::inet_ntop(int af, const void *src, char *dst, socklen_t size)   // QT_ch
{
  struct sockaddr_storage ss;
  unsigned long s = size;

  ZeroMemory(&ss, sizeof(ss));
  ss.ss_family = af;

  switch(af) {
    case AF_INET:
      ((struct sockaddr_in *)&ss)->sin_addr = *(struct in_addr *)src;
      break;
    case AF_INET6:
      ((struct sockaddr_in6 *)&ss)->sin6_addr = *(struct in6_addr *)src;
      break;
    default:
      return NULL;
  }
  /* cannot direclty use &size because of strict aliasing rules */

  //return (WSAAddressToString((struct sockaddr *)&ss, sizeof(ss), NULL, dst, &s) == 0) ? dst : NULL;
  LPWSTR lpwstr_dst = new TCHAR[s];
  MultiByteToWideChar(0, 0, dst, s, lpwstr_dst, s);
  if(WSAAddressToString((struct sockaddr *)&ss, sizeof(ss), NULL, lpwstr_dst, &s) == 0)  // QT_ch
  {
      wcstombs(dst, lpwstr_dst, s);
      return dst;
  }
  else
  {
      return NULL;
  }
}
#endif

int insCom::createMsgCmdCONF(uint32_t confCmd)	// SAVE, LOAD, FACTORY
{

	lock_guard<mutex> lock(m_mx_txMsg);
//	pthread_mutex_lock(&m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->CMD_CONF_SendFrame.uiConfCmdPar = confCmd;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_CONF_SendData);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgCmdEXTAID(uint16_t cmdID, double dTimeValue, uint16_t usTimeMode, int numOfPar, double par[])	//	FREEZE_ALT, FREEZE_HDG, FREEZE_VELBODY, EXTAID_POS, EXTAID_VEL, EXTAID_HDG
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();

	m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.usCmdParID = cmdID;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.dTimeValue = dTimeValue;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.usTimeMode = usTimeMode;

	switch(cmdID)
	{
	case XCOMEXTAID_FREEZE_ALT:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParFreezeAlt[i] = par[i];
		}
		break;

	case XCOMEXTAID_FREEZE_HDG:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParFreezeHdg[i] = par[i];
		}
		break;

	case XCOMEXTAID_FREEZE_VELBODY:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParFreezeVelBody[i] = par[i];
		}
		break;

	case XCOMEXTAID_POS:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.parExtAidPos.dPar[i] = par[i];
//			printf(">>>>>>>>>>>>>>>>>>>> param %d: %f \n", i, par[i]);
		}
//		m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.parExtAidPos.uiAltMS = 0;
		break;

	case XCOMEXTAID_VEL:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParExtAidVel[i] = par[i];
//						printf(">>>>>>>>>>>>>>>>>>>> set param EXTAID_VEL %d: %f \n", i, par[i]);
		}
		break;

	case XCOMEXTAID_HDG:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParExtAidHdg[i] = par[i];
		}
		break;

	case XCOMEXTAID_HGT:
		for(int i = 0; i < numOfPar; i++)
		{
			m_ixcomhandler.getIXComSendDataFrame()->CMD_EXTAID_SendFrame.cmdPar.dParExtAidHgt[i] = par[i];
		}
		break;

	default:
		break;
	}

	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_EXTAID_SendData);

//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgOpenChannel(int nofChannel)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->CMD_XCOM_SendFrame.usChannel = (uint16_t) nofChannel;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_XCOM_SendFrame.usState = (uint16_t) OPEN_CHANNEL;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_XCOM_SendData);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgCloseChannel(int nofChannel)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->CMD_XCOM_SendFrame.usChannel = (uint16_t) nofChannel;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_XCOM_SendFrame.usState = (uint16_t) CLOSE_CHANNEL;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_XCOM_SendData);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::closeSocket(void){

#ifdef __linux
	if (!(0==close(m_insSocket)))
#elif _WIN32
	if (!(0==closesocket(m_insSocket)))
#else
#error platform not supported
#endif
	{
		perror(m_pcModuleID);
		return(-1);
	}
	return (0);
}

int insCom::closeUdpSocket(void){

#ifdef __linux
	if (!(0==close(m_udpSocket)))
#elif _WIN32
	if (!(0==closesocket(m_udpSocket)))
#else
#error platform not supported
#endif
	{
		perror(m_pcModuleID);
		return(-1);
	}
	return (0);
}

int insCom::createMsgCmdLOG(const uint8_t MsgID, const uint8_t trig, const uint16_t parameter, const uint16_t divider)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->CMD_LOG_SendFrame.ucMsgID = (uint8_t) MsgID;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_LOG_SendFrame.ucTrigger = (uint8_t) trig;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_LOG_SendFrame.usDivider = (uint16_t) divider;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_LOG_SendFrame.usPAR = (uint16_t) parameter;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_LOG_SendData);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else

	return (0);
}

int insCom::sentMsg(void)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	
#ifdef __linux
	int result = send(m_insSocket, m_sendStruct.pData, m_sendStruct.dataSizeByte,0);
#elif _WIN32
	int result = send(m_insSocket, (char*)m_sendStruct.pData, m_sendStruct.dataSizeByte,0);
#else
#error platform not supported
#endif

//	pthread_mutex_unlock(&m_mx_txMsg);

	if( -1 == result)
	{
		int errsv = errno;
		perror(m_pcModuleID);
		if(ENOTCONN == errsv)
		{
			printf(">%s send: no TCP connection\n",m_pcModuleID);
			return(-10);
		}
		return(-1);
	}
	else
	{
//		pthread_mutex_lock(&m_mx_rxResp);
		lock_guard<mutex> lock(m_mx_rxResp);
		m_txResponse = RESPONSE_NONE;
//		pthread_mutex_unlock(&m_mx_rxResp);
	}

  return(0);
}

int insCom::sentNConfirmMsg(uint32_t msTimeOut, char* p_CmdResp)
{
	int sentMsgRet = sentMsg();
//	pthread_mutex_lock(&m_mx_sentConf);
	lock_guard<mutex> lock(m_mx_sentConf);
    if(0 == sentMsgRet)
    {

//    	timespec waitTimeOut;

//#ifdef _WIN32
//		SYSTEMTIME sysTime;
//		time_t timeNow;
//		long time_ms;
//#endif


		while(1)
		{
//			double ms2ns = 1e6;
//			long int sPart  = (long int) (msTimeOut / 1000);
//			long int nsPart = (long int) ((msTimeOut % 1000)*ms2ns);
//
//#ifdef __linux
//
//			if(-1 == clock_gettime(CLOCK_REALTIME, &waitTimeOut))
//			{
//				perror(m_pcModuleID);
////				pthread_mutex_unlock(&m_mx_sentConf);
//				return(-1);
//			}
//
//#endif
//
//#ifdef _WIN32
//
//			timeNow = time(0);					// number of seconds since 01.01.1970
//			GetSystemTime(&sysTime);
//			time_ms = sysTime.wMilliseconds;	// milliseconds of the currend second
//
//			waitTimeOut.tv_sec = timeNow;
//			waitTimeOut.tv_nsec = time_ms * 1000000;
//
//
//
//			/*std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
//			auto duration = now.time_since_epoch();
//			auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration);
//			duration -= seconds;
//			auto nanoseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(duration);
//
//			waitTimeOut.tv_sec = seconds.count();
//			waitTimeOut.tv_nsec = nanoseconds.count();*/
//
//			//cout << "---   ---   time   ---   ---   " << waitTimeOut.tv_sec << " : " << waitTimeOut.tv_nsec << endl;
//
//#endif
//
//
//
//			/*add timeout handle ns overflow*/
//			long int tvNsec = waitTimeOut.tv_nsec;
//            long int sumNsec = tvNsec + nsPart;
//			waitTimeOut.tv_nsec = (sumNsec) % 1000000000;
//			waitTimeOut.tv_sec += sPart + (sumNsec) / 1000000000;
//			//__size
//
//


//			chrono::milliseconds ms = chrono::milliseconds(msTimeOut);
//			if(m_mx_rx.try_lock_for(ms)) {
//				m_mx_rx.unlock();
//			} else {
//				return(-1);
//			}

//			thread timerThread(&insCom::CountDown, this, msTimeOut, 1, TMR_MTX_1);
//			timerThread.detach();

//			while(1) {
//				usleep(1);
//				lock_guard<mutex> lock1(m_mx_tmr_1);
//				cout << "mtx locked, " << "count down: " << unsigned(m_countDownVal_1) << endl;
//				if(m_countDownVal_1 == 0) {
//					return(-1);
//				}

//				if(m_mx_rx.try_lock()) {
////					m_mx_rx.unlock();
//					m_goOnRunning_1 = 0;
//					break;
//				}

//			}

//			m_mx_rx.unlock();






//			cout << "/// sem_timedwait /// " << endl;
//			int semTimedWait = sem_timedwait(&m_sem_rx,&waitTimeOut);
//			cout << "/// sem_timedwait /// " << semTimedWait << endl;
//			if(semTimedWait == -1)
//			//if(-1 == sem_timedwait(&m_sem_rx,&waitTimeOut))		// sem_t m_sem_rx auskommentiert: hier Timer implementieren
//			{													// überlegen, wie während des CountDowns geprüft wird, ob wert gesetzt
//				if(ETIMEDOUT == errno)
//				{
////					printf(">%s: timeout\n",m_pcModuleID);
//				}
//				else
//				{
//					perror(m_pcModuleID);
//				}
////				pthread_mutex_unlock(&m_mx_sentConf);
//				return(-1);
//			}




//			cout << "/// waiting... ///" << endl;
			unique_lock<mutex> lock1(m_mx_rx);
			if(cond_var_m_mx_rx.wait_for(lock1, chrono::milliseconds(msTimeOut)) == cv_status::timeout) {
				cout << "RESPONSE TIMEOUT" << endl;
			}
//			cout << "/// waiting done ///" << endl;






			int local_txResponse = RESPONSE_NONE;
//			pthread_mutex_lock (&m_mx_rxResp );
//			lock_guard<mutex> lock(m_mx_rxResp);
//			local_txResponse = m_txResponse;
//			pthread_mutex_unlock (&m_mx_rxResp );

			m_mx_rxResp.lock();
			local_txResponse = m_txResponse;
			m_mx_rxResp.unlock();

			/* message confirmed ok */
			if(RESPONSE_OK == local_txResponse)
			{
				char RESPDescription[60] = "Command was received correctly";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(0);
			}
			else if(RESPONSE_INVPAR == local_txResponse)
			{
				char RESPDescription[60] = "Unknown parameter of the received command";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVCHKSM == local_txResponse)
			{
				char RESPDescription[60] = "The checksum of the received package was incorrect";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVLOG == local_txResponse)
			{
				char RESPDescription[60] = "The requested log message does not exist";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVRATE == local_txResponse)
			{
				char RESPDescription[60] = "The requested rate is invalid";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVPORT == local_txResponse)
			{
				char RESPDescription[60] = "The requested port is invalid";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVCMD == local_txResponse)
			{
				char RESPDescription[60] = "The requested command does not exist";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVID == local_txResponse)
			{
				char RESPDescription[60] = "The received command/parameter is not valid for this IMS";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INVCH == local_txResponse)
			{
				char RESPDescription[60] = "The requested XCOM Channel ID is used by another client";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_VALOR == local_txResponse)
			{
				char RESPDescription[60] = "The received value is out of range";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_LOGEX == local_txResponse)
			{
				char RESPDescription[60] = "The requested XCOM log already exists for the used channel";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(0);
			}
			else if(RESPONSE_INVTR == local_txResponse)
			{
				char RESPDescription[60] = "The trigger is invalid for requested message";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else if(RESPONSE_INTERR == local_txResponse)
			{
				char RESPDescription[60] = "An internal error occurred";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
			else
			{

//				cout << "local_txResponse: " << local_txResponse << endl;

				char RESPDescription[60] = "Reserved for further use";
				for(int i=0; i<60; i++)
				{
					p_CmdResp[i] = RESPDescription[i];
				}
//				pthread_mutex_unlock(&m_mx_sentConf);
				return(-2);
			}
		}
    }
	else if(-10 == sentMsgRet)
    {
        /* case: no TCP connection */
    	char RESPDescription[60] = "No Response: No TCP connection";
		for(int i=0; i<60; i++)
		{
			p_CmdResp[i] = RESPDescription[i];
		}
//		pthread_mutex_unlock(&m_mx_sentConf);
    	return(-10);
    }

	/* case: sending failed (-1 == sentMsg) */
	char RESPDescription[60] = "No Response: Sending Failed";
	for(int i=0; i<60; i++)
	{
		p_CmdResp[i] = RESPDescription[i];
	}
//	pthread_mutex_unlock(&m_mx_sentConf);
	return(-2);
}



int insCom::createMsgCmdEKF(int cmd, int NumOfPar, float par[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->CMD_EKF_SendFrame.usCommand = (uint16_t) cmd;
	m_ixcomhandler.getIXComSendDataFrame()->CMD_EKF_SendFrame.usNumOfPar = (uint16_t) NumOfPar;
	for (int i=0; i<NumOfPar; i++)
	{
		m_ixcomhandler.getIXComSendDataFrame()->CMD_EKF_SendFrame.fPar[i] = par[i];
	}
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::CMD_EKF_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::waitAlignmentDone(uint32_t msTimeOut)
{
	uint16_t alignmentDone = 0;
//	timespec waitTimeOut;
	
	thread timerThread(&insCom::CountDown, this, msTimeOut, 1000, TMR_MTX_0);
	timerThread.detach();

	uint32_t currCountDownVal = 0;

	while(1) {

#ifdef __linux
		sleep(1);
#else
		Sleep(1000);
#endif

		lock_guard<mutex> lock1(m_mx_tmr_0);
		currCountDownVal = m_countDownVal_0;

//		cout << "CountDown: " << currCountDownVal << endl;

		if(currCountDownVal == 0)
		{
			printf(">%s Alignment Timeout\n",m_pcModuleID);
//			return(-1);
		}

		lock_guard<mutex> lock2(m_mx_globalStatus);
		alignmentDone = (m_globalStatus & ALIGNCOMPLTE);
		if(ALIGNCOMPLTE == alignmentDone)
		{
			m_goOnRunning_0 = 0;
			return(0);
		}
	}



//#ifdef __linux
//	itimerspec curTimerSpec;
//
//	if(0 == createOneShotTimer(msTimeOut))
//	{
//		while(1)
//		{
//
////			if(-1 == clock_gettime(CLOCK_REALTIME, &waitTimeOut))
////			{
////				perror(m_pcModuleID);
////				return(-1);
////			}
////
////			/*release semaphore every second*/
////			waitTimeOut.tv_sec += 1;
////
////			if(-1 == sem_timedwait(&m_sem_gStatus,&waitTimeOut))
////			{
////				if(ETIMEDOUT == errno)
////				{
////					/*check in case of semaphore time release alignment timeout*/
////					/* so this is not considered as an error*/
////				}
////				else
////				{
////					perror(m_pcModuleID);
////					timer_delete(m_aTimer);
////					return(-1);
////				}
////			}
//			if(0 == timer_gettime(m_aTimer,&curTimerSpec))
//			{
////				cout << curTimerSpec.it_value.tv_sec << "." << curTimerSpec.it_value.tv_nsec << endl;
//				if((curTimerSpec.it_value.tv_sec == 0) && (curTimerSpec.it_value.tv_nsec == 0))
//				{
//					printf(">%s Alignment Timeout\n",m_pcModuleID);
//					timer_delete(m_aTimer);
//					return(-1);
//				}
//			}
//			/*check response, update accuracyHighStatus*/
////			pthread_mutex_lock (&m_mx_globalStatus);
//			lock_guard<mutex> lock(m_mx_globalStatus);
//			alignmentDone = (m_globalStatus & ALIGNCOMPLTE);
////			pthread_mutex_unlock (&m_mx_globalStatus);
//			if(ALIGNCOMPLTE == alignmentDone)
//			{
//				timer_delete(m_aTimer);
//				return(0);
//			}
//		}
//	}
//	timer_delete(m_aTimer);
//	return (-1);
//
//#elif _WIN32
//
//
//	SYSTEMTIME sysTime;
//	time_t timeNow;
//	long time_ms;
//
//	timeNow = time(0);						// number of seconds since 01.01.1970
//	GetSystemTime(&sysTime);
//	time_ms = sysTime.wMilliseconds;		//	milliseconds of the current second
//
//	long long milliseconds_start = timeNow * 1000 + time_ms;
//	long long milliseconds_cur;
//
//
//
//	/*std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
//	auto duration = now.time_since_epoch();
//	long long milliseconds_start = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
//	long long milliseconds_cur;*/
//
//
//	while(1)
//	{
//
//		timeNow = time(0);
//		GetSystemTime(&sysTime);
//		time_ms = sysTime.wMilliseconds;
//		milliseconds_cur = timeNow * 1000 + time_ms;
//
//		waitTimeOut.tv_sec = timeNow;
//		waitTimeOut.tv_nsec = time_ms * 1000000;
//
//		/*std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
//		auto duration = now.time_since_epoch();
//		milliseconds_cur = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
//		auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration);
//		duration -= seconds;
//		auto nanoseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(duration);
//
//
//		waitTimeOut.tv_sec = seconds.count();
//		waitTimeOut.tv_nsec = nanoseconds.count();*/
//
//
//		//cout << "---   ---   time   ---   ---   " << waitTimeOut.tv_sec << " : " << waitTimeOut.tv_nsec << endl;
//
//
//
//		/*release semaphore every second*/
//		waitTimeOut.tv_sec += 1;
//
//		if(-1 == sem_timedwait(&m_sem_gStatus,&waitTimeOut))
//		{
//			if(ETIMEDOUT == errno)
//			{
//				/*check in case of semaphore time release alignment timeout*/
//				/* so this is not considered as an error*/
//			}
//			else
//			{
//				perror(m_pcModuleID);
//				return(-1);
//			}
//		}
//
//
//		if(milliseconds_cur > milliseconds_start + msTimeOut)
//		{
//			printf(">%s Alignment Timeout\n",m_pcModuleID);
//
//			return(-1);
//		}
//
//		/*check response, update accuracyHighStatus*/
////		pthread_mutex_lock (&m_mx_globalStatus);
//		lock_guard<mutex> lock(m_mx_globalStatus);
//		alignmentDone = (m_globalStatus & ALIGNCOMPLTE);
////		pthread_mutex_unlock (&m_mx_globalStatus);
//		if(ALIGNCOMPLTE == alignmentDone)
//		{
//			return(0);
//		}
//	}
//
//#else
//#error platform not supported
//#endif
}

int insCom::parseRxRunData(std::atomic_flag& continue_flag)
{
    char rxBuf[4096];
    int rxBytes = -1;
    int i = 0;

	while(continue_flag.test_and_set())
	{

		//printf("/// parseRxRunData /// \n");

		int socketCheck = 1;
		while(socketCheck) {

#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			lock_guard<mutex> lock(m_mx_socket);
			if(m_insSocket > 0)
				socketCheck = 0;
		}

//		if ((0 != m_insSocket) && (-1 != m_insSocket))
//		{
//			sem_post(&m_sem_socket);
//		}
//		if(-1 == sem_wait(&m_sem_socket))
//		{
////			printf("error sem_wait parseRxRunData \n");
//		}
		rxBytes = recv(m_insSocket, rxBuf, sizeof(rxBuf), 0);
	
		//printf("---rxBytes: %d \n", rxBytes);
		if (-1 != rxBytes)
		{
//			cout << "received tcp bytes" << endl;

				for (i = 0; i < rxBytes; i++)
				{
					iXComHandler::iXComReceiveDataReady recvReady = m_ixcomhandler.readReceivedXComByte(rxBuf[i]);
					switch (recvReady)
					{

					case (iXComHandler::iXComReceiveDataReady::PAR_FPGA_MCP23S08_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParFpgaMcp23s08, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_FPGA_MCP23S08), sizeof(t_XCOM_PAR_FPGA_MCP23S08));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParFpgaMcp23s08.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_OSVERSION_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysOsVersion, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_OSVERSION), sizeof(t_XCOM_PAR_XCOM_CHAR64));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysOsVersion.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_CONFIGCRC_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysConfigCrc, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_CONFIGCRC), sizeof(t_XCOM_PAR_SYS_CONFIGCRC));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysConfigCrc.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_FPGAVER_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysFpgaVer, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_FPGAVER), sizeof(t_XCOM_PAR_SYS_FPGAVER));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysFpgaVer.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_BOOTMODE_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysBootMode, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_BOOTMODE), sizeof(t_XCOM_PAR_SYS_BOOTMODE));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysBootMode.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_OPHOURCNT_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysOpHourCnt, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_OPHOURCNT), sizeof(t_XCOM_PAR_SYS_OPHOURCNT));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysOpHourCnt.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVPARSET_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysNavParSet, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVPARSET), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysNavParSet.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVNUM_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysNavNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysNavNum.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_EKFPARSET_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysEkfParSet, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_EKFPARSET), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysEkfParSet.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_EKFLIB_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysEkfLib, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_EKFLIB), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysEkfLib.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVLIB_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysNavLib, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVLIB), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysNavLib.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_FWVERSION_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysFWVersion, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_FWVERSION), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysFWVersion.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_CALDATE_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysCalDate, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_CALDATE), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysCalDate.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_MFG_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysMFG, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_MFG), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysMFG.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_SERIALNUM_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysSerialNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_SERIALNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysSerialNum.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PARTNUM_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysPartNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PARTNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysPartNum.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PRJNUM_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysPrjNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PRJNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysPrjNum.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PRESCALER_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysPrescaler, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PRESCALER), sizeof(t_XCOM_PAR_SYS_PRESCALER));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysPrescaler.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_MAINTIMING_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysMaintiming, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_MAINTIMING), sizeof(t_XCOM_PAR_SYS_MAINTIMING));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysMaintiming.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::PAR_SYS_UPTIME_Ready):
					{
//						pthread_mutex_lock (&m_mx_retParData);
						lock_guard<mutex> lock1(m_mx_retParData);
						memcpy(&m_retParData.xcomParSysUpTime, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_UPTIME), sizeof(t_XCOM_PAR_SYS_UPTIME));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_retParData.xcomParSysUpTime.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_retParData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_INSSOL_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcominsSol, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSSOL), sizeof(t_XCOM_MSG_INSSOL));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcominsSol.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_INSPOSECEF_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcominsPosECEF, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSPOSECEF), sizeof(t_XCOM_MSG_INSPOSECEF));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcominsPosECEF.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_INSDCM_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcominsDCM, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSDCM), sizeof(t_XCOM_MSG_INSDCM));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcominsDCM.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_INSPOSLLH_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcominsPosLLH, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSPOSLLH), sizeof(t_XCOM_MSG_INSPOSLLH));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcominsPosLLH.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_GNSSSOL_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomgnssSol, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_GNSSSOL), sizeof(t_XCOM_MSG_GNSSSOL));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomgnssSol.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_GNSSTIME_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomgnssTime, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_GNSSTIME), sizeof(t_XCOM_MSG_GNSSTIME));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomgnssTime.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_IMUCAL_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomimuCal, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_IMUCAL), sizeof(t_XCOM_MSG_IMUCAL));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomimuCal.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_IMUCOMP_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomimuComp, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_IMUCOMP), sizeof(t_XCOM_MSG_IMUCOMP));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomimuComp.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_IMUCORR_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomimuCorr, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_IMUCORR), sizeof(t_XCOM_MSG_IMUCORR));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomimuCorr.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_IMURAW_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomimuRaw, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_IMURAW), sizeof(t_XCOM_MSG_IMURAW));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomimuRaw.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_INSVELBODY_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcominsVelBODY, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSVELBODY), sizeof(t_XCOM_MSG_INSVELBODY));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcominsVelBODY.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_SYS_TEMP_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomTemp, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_SYS_TEMP), sizeof(t_XCOM_MSG_SYS_TEMP));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomTemp.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_EKFSENSORERR2_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomEkfError2, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_EKFSENSORERR2), sizeof(t_XCOM_MSG_EKFSENSORERR2));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomEkfError2.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::MSG_EKFSTDDEV2_Ready):
					{
//						pthread_mutex_lock (&m_mx_useData);
						lock_guard<mutex> lock1(m_mx_useData);
						memcpy(&m_useData.xcomEkfStdDev2, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_EKFSTDDEV2), sizeof(t_XCOM_MSG_EKFSTDDEV2));
//						pthread_mutex_lock (&m_mx_globalStatus);
						lock_guard<mutex> lock2(m_mx_globalStatus);
						m_globalStatus = m_useData.xcomEkfStdDev2.tBottom.gStatus;
//						pthread_mutex_unlock (&m_mx_globalStatus);
//						pthread_mutex_unlock (&m_mx_useData);
//						sem_post(&m_sem_gStatus);
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::RESPONSE_Ready):
					{
							if( (m_sendStruct.pData[2] == m_ixcomhandler.getIXComReceivedData()->RESPONSE->tHeader.ucFrameCnt)  )
							{
//								lock_guard<mutex> lock(m_mx_rx);
								unique_lock<mutex> lock(m_mx_rx);

								if( RESPONSE_OK == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_OK;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVPAR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVPAR;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVCHKSM == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVCHKSM;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVLOG == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVLOG;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVRATE == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVRATE;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVPORT == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVPORT;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVCMD == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVCMD;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVID == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVID;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVCH == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVCH;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_VALOR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_VALOR;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_LOGEX == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_LOGEX;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INVTR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INVTR;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else if( RESPONSE_INTERR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_INTERR;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
								else
								{
//									pthread_mutex_lock (&m_mx_rxResp );
									lock_guard<mutex> lock(m_mx_rxResp);
									m_txResponse = RESPONSE_RES;
//									pthread_mutex_unlock (&m_mx_rxResp );
								}
//								printf("/// sem_post /// \n");
//								sem_post(&m_sem_rx);

//								cout << "/// notify ///" << endl;
								cond_var_m_mx_rx.notify_one();
							}
							else
							{
							   /*response for other request*/
							   /* go on */
							}
					}
						break;

					case (iXComHandler::iXComReceiveDataReady::FRAMENOTCOMPLETE):
					{

					}
						break;

					default:
						break;
				}
			}
		}
	}
//	pthread_exit(NULL);
	return 0;
}

int insCom::parseRxRunUdpData(void)
{
    char rxBuf[4096];
    int rxBytes = -2;
    char p_sender[INET_ADDRSTRLEN];
    int i = 0;
    struct sockaddr sendAddr;
    struct sockaddr_in sendAddrin;
    memset(&sendAddr,0,sizeof(sockaddr));
    socklen_t sendAddrLen = INET_ADDRSTRLEN;


//	if(-1 == sem_wait(&m_sem_udpsocket))
//	{
////			printf("error sem_wait parseRxRunData");
//	}
	while(1)
	{

		int socketCheck = 1;
		while(socketCheck) {

#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			lock_guard<mutex> lock(m_mx_udpSocket);
			if(m_udpSocket > 0)
				socketCheck = 0;
		}

		rxBytes = recvfrom(m_udpSocket, rxBuf, sizeof(rxBuf), 0, (struct sockaddr*)&sendAddr, &sendAddrLen);
//		rxBytes = recvfrom(m_udpSocket, rxBuf, (sizeof(rxBuf)/sizeof(char)), 0, NULL, 0);	// new

		memcpy(&sendAddrin, &sendAddr,sizeof(sendAddrin));
		inet_ntop(AF_INET,(void *) &sendAddrin.sin_addr,&p_sender[0],INET_ADDRSTRLEN);
		
		/* iNat datagramm is feet in the parser */
//		if(sendAddrin.sin_addr.s_addr != m_inatIpAddr.sin_addr.s_addr )
		if((0 != m_inatIpAddr.sin_addr.s_addr) && (sendAddrin.sin_addr.s_addr != m_inatIpAddr.sin_addr.s_addr) )
			continue;
			
//		printf(">%s Rx Udp %d bytes from sender %s\n",m_pcModuleID,rxBytes,p_sender);

		if (-1 != rxBytes)
		{
//			cout << "received bytes" << endl;

			for (i = 0; i < rxBytes; i++)
			{
				iXComHandler::iXComReceiveDataReady recvReady = m_uixcomhandler.readReceivedXComByte(rxBuf[i]);



//				switch (recvReady)
//				{
//					case (iXComHandler::iXComReceiveDataReady::MSG_INSPOSLLH_Ready):
//					{
//						//printf(">%s Rx Udp Data MSG_INSPOSLLH_Ready\n",m_pcModuleID);
//						pthread_mutex_lock (&m_mx_useUdpData );
//						memcpy(&m_udpLog.xcominsPosLLH, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSPOSLLH), sizeof(t_XCOM_MSG_INSPOSLLH));
//						pthread_mutex_unlock (&m_mx_useUdpData );
//					}
//						break;
//					case (iXComHandler::iXComReceiveDataReady::MSG_INSSOL_Ready):
//					{
//						//printf(">%s Rx Udp Data MSG_INSSOL_Ready\n",m_pcModuleID);
//						pthread_mutex_lock (&m_mx_useUdpData);
//						memcpy(&m_udpLog.xcominsSol, (const void *)(m_ixcomhandler.getIXComReceivedData()->MSG_INSSOL), sizeof(t_XCOM_MSG_INSSOL));
//						pthread_mutex_unlock (&m_mx_useUdpData);
//					}
//						break;
//					case (iXComHandler::iXComReceiveDataReady::FRAMENOTCOMPLETE):
//					{
//
//					}
//						break;
//					default:
//						break;
//				}



				////////////////////////////////////////////////   N E W   ////////////////////////////////////////////////

				switch (recvReady)
				{

//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_OSVERSION_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysOsVersion, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_OSVERSION), sizeof(t_XCOM_PAR_XCOM_CHAR64));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysOsVersion.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_CONFIGCRC_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysConfigCrc, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_CONFIGCRC), sizeof(t_XCOM_PAR_SYS_CONFIGCRC));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysConfigCrc.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_FPGAVER_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysFpgaVer, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_FPGAVER), sizeof(t_XCOM_PAR_SYS_FPGAVER));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysFpgaVer.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_BOOTMODE_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysBootMode, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_BOOTMODE), sizeof(t_XCOM_PAR_SYS_BOOTMODE));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysBootMode.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_OPHOURCNT_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysOpHourCnt, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_OPHOURCNT), sizeof(t_XCOM_PAR_SYS_OPHOURCNT));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysOpHourCnt.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVPARSET_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysNavParSet, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVPARSET), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysNavParSet.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVNUM_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysNavNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysNavNum.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_EKFPARSET_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysEkfParSet, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_EKFPARSET), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysEkfParSet.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_EKFLIB_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysEkfLib, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_EKFLIB), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysEkfLib.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_NAVLIB_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysNavLib, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_NAVLIB), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysNavLib.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_FWVERSION_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysFWVersion, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_FWVERSION), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysFWVersion.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_CALDATE_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysCalDate, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_CALDATE), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysCalDate.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_MFGDATE_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysMFG, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_MFGDATE), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysMFG.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_SERIALNUM_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysSerialNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_SERIALNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysSerialNum.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PARTNUM_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysPartNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PARTNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysPartNum.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PRJNUM_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysPrjNum, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PRJNUM), sizeof(t_XCOM_PAR_XCOM_CHAR32));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysPrjNum.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_PRESCALER_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysPrescaler, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_PRESCALER), sizeof(t_XCOM_PAR_SYS_PRESCALER));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysPrescaler.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_MAINTIMING_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysMaintiming, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_MAINTIMING), sizeof(t_XCOM_PAR_SYS_MAINTIMING));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysMaintiming.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;
//
//				case (iXComHandler::iXComReceiveDataReady::PAR_SYS_UPTIME_Ready):
//				{
//					pthread_mutex_lock (&m_mx_retParData);
//					memcpy(&m_retParData.xcomParSysUpTime, (const void *)(m_ixcomhandler.getIXComReceivedData()->PAR_SYS_UPTIME), sizeof(t_XCOM_PAR_SYS_UPTIME));
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_retParData.xcomParSysUpTime.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_retParData);
//					sem_post(&m_sem_gStatus);
//				}
//					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_INSSOL_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcominsSol, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSSOL), sizeof(t_XCOM_MSG_INSSOL));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcominsSol.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcominsSol.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_INSPOSECEF_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcominsPosECEF, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSPOSECEF), sizeof(t_XCOM_MSG_INSPOSECEF));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcominsPosECEF.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcominsPosECEF.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_INSDCM_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcominsDCM, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSDCM), sizeof(t_XCOM_MSG_INSDCM));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcominsDCM.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcominsDCM.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_INSPOSLLH_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcominsPosLLH, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSPOSLLH), sizeof(t_XCOM_MSG_INSPOSLLH));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcominsPosLLH.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcominsPosLLH.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_GNSSSOL_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomgnssSol, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_GNSSSOL), sizeof(t_XCOM_MSG_GNSSSOL));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomgnssSol.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomgnssSol.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_GNSSTIME_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomgnssTime, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_GNSSTIME), sizeof(t_XCOM_MSG_GNSSTIME));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomgnssTime.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomgnssTime.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_IMUCAL_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomimuCal, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_IMUCAL), sizeof(t_XCOM_MSG_IMUCAL));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomimuCal.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomimuCal.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_IMUCOMP_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomimuComp, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_IMUCOMP), sizeof(t_XCOM_MSG_IMUCOMP));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomimuComp.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomimuComp.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_IMUCORR_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomimuCorr, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_IMUCORR), sizeof(t_XCOM_MSG_IMUCORR));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomimuCorr.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomimuCorr.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_IMURAW_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomimuRaw, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_IMURAW), sizeof(t_XCOM_MSG_IMURAW));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomimuRaw.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomimuRaw.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_INSVELBODY_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcominsVelBODY, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_INSVELBODY), sizeof(t_XCOM_MSG_INSVELBODY));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcominsVelBODY.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcominsVelBODY.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_SYS_TEMP_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomTemp, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_SYS_TEMP), sizeof(t_XCOM_MSG_SYS_TEMP));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomTemp.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomTemp.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_EKFSENSORERR2_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomEkfError2, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_EKFSENSORERR2), sizeof(t_XCOM_MSG_EKFSENSORERR2));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomEkfError2.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomTemp.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

				case (iXComHandler::iXComReceiveDataReady::MSG_EKFSTDDEV2_Ready):
				{
//					pthread_mutex_lock (&m_mx_useUdpData);
					lock_guard<mutex> lock1(m_mx_useUdpData);
					memcpy(&m_udpLog.xcomEkfStdDev2, (const void *)(m_uixcomhandler.getIXComReceivedData()->MSG_EKFSTDDEV2), sizeof(t_XCOM_MSG_EKFSTDDEV2));
					lock_guard<mutex> lock2(m_mx_globalStatus);
					m_globalStatus = m_udpLog.xcomEkfStdDev2.tBottom.gStatus;
//					pthread_mutex_lock (&m_mx_globalStatus);
//					m_globalStatus = m_useData.xcomTemp.tBottom.gStatus;
//					pthread_mutex_unlock (&m_mx_globalStatus);
//					pthread_mutex_unlock (&m_mx_useUdpData);
//					sem_post(&m_sem_gStatus);
				}
					break;

//				case (iXComHandler::iXComReceiveDataReady::RESPONSE_Ready):
//				{
//						if( (m_sendStruct.pData[2] == m_ixcomhandler.getIXComReceivedData()->RESPONSE->tHeader.ucFrameCnt)  )
//						{
//							if( RESPONSE_OK == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_OK;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVPAR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVPAR;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVCHKSM == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVCHKSM;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVLOG == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVLOG;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVRATE == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVRATE;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVPORT == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVPORT;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVCMD == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVCMD;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVID == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVID;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVCH == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVCH;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_VALOR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_VALOR;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_LOGEX == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_LOGEX;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INVTR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INVTR;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else if( RESPONSE_INTERR == m_ixcomhandler.getIXComReceivedData()->RESPONSE->RespID)
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_INTERR;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							else
//							{
//								pthread_mutex_lock (&m_mx_rxResp );
//								m_txResponse = RESPONSE_RES;
//								pthread_mutex_unlock (&m_mx_rxResp );
//							}
//							//printf("/// sem_post /// \n");
//							sem_post(&m_sem_rx);
//						}
//						else
//						{
//						   /*response for other request*/
//						   /* go on */
//						}
//				}
//					break;

				case (iXComHandler::iXComReceiveDataReady::FRAMENOTCOMPLETE):
				{

				}
					break;

				default:
					break;
			}

				///////////////////////////////////////////////////////////////////////////////////////////////////////////







			}
		}
		else
		{
			perror(m_pcModuleID);
		}
	}
//	pthread_exit(NULL);
	return 0;
}

//#ifdef __linux
void insCom::CountDown(uint32_t msTimeOut, uint32_t msStep, int reason)
{

	uint8_t timerIsRunning = 0;

	for(int tOut = msTimeOut; tOut >= 0; tOut-=msStep) {

		if(timerIsRunning)
//			usleep(1000 * msStep);
			this_thread::sleep_for(chrono::milliseconds(msStep));
		switch(reason) {

			case TMR_MTX_0: {
				lock_guard<mutex> lock0(m_mx_tmr_0);
				if(!m_goOnRunning_0)
					return;
				m_countDownVal_0 = tOut;
				break;
			}

//			case TMR_MTX_1: {
//				cout << "case TMR_MTX_1, " << "tOut: " << tOut << endl;
//				lock_guard<mutex> lock1(m_mx_tmr_1);
//				if(!m_goOnRunning_1)
//					return;
//				m_countDownVal_1 = tOut;
//				break;
//			}
		}

//		cout << "timer: " << tOut << endl;
//		cout << "m_countDownVal_0: " << m_countDownVal_0 << endl;
//		cout << "m_goOnRunning_0: " << unsigned(m_goOnRunning_0) << endl;

		timerIsRunning = 1;
	}


//	itimerspec aniTimerSpec;
//
//	double ms2ns = 1e6;
//
//	long int sPart  = (long int)   (msTimeOut / 1000);
//	long int nsPart = (long int) ((msTimeOut % 1000)*ms2ns);
//
//	aniTimerSpec.it_interval.tv_sec  = 0;
//	aniTimerSpec.it_interval.tv_nsec = 0;
//	aniTimerSpec.it_value.tv_sec     = sPart;
//	aniTimerSpec.it_value.tv_nsec    = nsPart;
//
//	sigevent sevp;
//	sevp.sigev_notify = SIGEV_NONE;
//
//#ifdef __CYGWIN__
//    /* CYGWIN BUG IT DOES NOT SUPPORT MONOTONIC CLOCK*/
//	if(! ( 0 == timer_create(CLOCK_REALTIME,&sevp,&m_aTimer)))
//#else
//	if(! ( 0 == timer_create(CLOCK_MONOTONIC,&sevp,&m_aTimer)))
//#endif
//	{
//		perror(m_pcModuleID);
//		return -1;
//	}
//	if(! ( 0 == timer_settime(m_aTimer, 0, &aniTimerSpec,NULL)))
//	{
//		perror(m_pcModuleID);
//		return -1;
//	}
//
//	return 0;
}
//#endif


int insCom::requestMsgPARSYS_PRJNUM()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_PRJNUM_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_PARTNUM()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_PARTNUM_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_SERIALNUM()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_SERIALNUM_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_MFGDATE()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_MFG_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_CALDATE()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_CALDATE_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_FWVERSION()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_FWVERSION_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_NAVLIB()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_NAVLIB_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_EKFLIB()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_EKFLIB_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_EKFPARSET()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_EKFPARSET_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_NAVNUM()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_NAVNUM_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_NAVPARSET()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_NAVPARSET_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::requestMsgPARSYS_MAINTIMING()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_MAINTIMING_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_PRESCALER()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_PRESCALER_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_UPTIME()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_UPTIME_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_OPHOURCOUNT()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_OPHOURCNT_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_BOOTMODE()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_BOOTMODE_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_FPGAVER()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_FPGAVER_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_CONFIGCRC()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_CONFIGCRC_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::requestMsgPARSYS_OSVERSION()
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_SYS_OSVERSION_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}





int insCom::createMsgPARFPGA_MCP23S08(uint8_t reg)
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();

	m_ixcomhandler.getIXComSendDataFrame()->PAR_FPGA_MCP23S08_SendFrame.ucGPIOreg = reg;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_FPGA_MCP23S08_SendData, CHANGEPAR);

//	pthread_mutex_unlock(&m_mx_txMsg);
		if((m_sendStruct.pData == NULL))
			return(-1);
		else
			return (0);
}

int insCom::requestMsgPARFPGA_MCP23S08()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();

	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_FPGA_MCP23S08_SendData, REQUESTPAR);

//	pthread_mutex_unlock(&m_mx_txMsg);
		if((m_sendStruct.pData == NULL))
			return(-1);
		else
			return (0);
}


int insCom::createMsgPARGNSS_ANTOFFSET(double pLeverArm[], uint8_t antenna)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.tParHeader.ucReserved = antenna;
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fLeverArm[0] = (float) pLeverArm[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fLeverArm[1] = (float) pLeverArm[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fLeverArm[2] = (float) pLeverArm[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fStdDev[0] = (float) pLeverArm[3];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fStdDev[1] = (float) pLeverArm[4];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_ANTOFFSET_SendFrame.fStdDev[2] = (float) pLeverArm[5];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_GNSS_ANTOFFSET_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_ALIGNMODE(uint32_t *pAlignMode)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ALIGNMODE_SendFrame.uiAlignMode = pAlignMode[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_ALIGNMODE_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_ALIGNTIME(uint32_t *pAlignTime)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ALIGNTIME_SendFrame.uiAlignTime = pAlignTime[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_ALIGNTIME_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_COARSETIME(uint32_t *pCoarseTime)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_COARSETIME_SendFrame.uiCoarseTime = pCoarseTime[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_COARSETIME_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_HDGPOSTHR(double pEkfAlignThrs[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_HDGPOSTHR_SendFrame.fThrHDG = (float) pEkfAlignThrs[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_HDGPOSTHR_SendFrame.fThrPosMed = (float) pEkfAlignThrs[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_HDGPOSTHR_SendFrame.fThrPosHigh = (float) pEkfAlignThrs[2];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_HDGPOSTHR_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_SMOOTH(uint32_t *pEkfSmooth)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_SMOOTH_SendFrame.uiSmooth = pEkfSmooth[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_SMOOTH_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	 if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_STARTUPV2(uint32_t p_intValues[], double p_doubleValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.dInitPosLon			= p_doubleValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.dInitPosLat			= p_doubleValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fInitPosAlt			= (float) p_doubleValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fStdDevInitPos[0]	= (float) p_doubleValues[3];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fStdDevInitPos[1]	= (float) p_doubleValues[4];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fStdDevInitPos[2]	= (float) p_doubleValues[5];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fInitHdg			= (float) p_doubleValues[6];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fStdDevInitHdg		= (float) p_doubleValues[7];

	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArm[0]		= (float) p_doubleValues[8];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArm[1]		= (float) p_doubleValues[9];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArm[2]		= (float) p_doubleValues[10];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArmStdDev[0]	= (float) p_doubleValues[11];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArmStdDev[1]	= (float) p_doubleValues[12];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.fLeverArmStdDev[2]	= (float) p_doubleValues[13];

	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucPosMode			= (uint8_t) p_intValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucHdgMode			= (uint8_t) p_intValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.usGnssTimeout		= (uint16_t) p_intValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucEnableAltMSL		= (uint8_t) p_intValues[3];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucReAlign			= (uint8_t) p_intValues[4];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucInMotion			= (uint8_t) p_intValues[5];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_STARTUPV2_SendFrame.ucAutoRestart		= (uint8_t) p_intValues[6];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_STARTUPV2_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}


int insCom::createMsgPARIMU_MISALIGN(double pImuMisalign[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_IMU_MISALIGN_SendFrame.frotx = (float) pImuMisalign[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_IMU_MISALIGN_SendFrame.froty = (float) pImuMisalign[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_IMU_MISALIGN_SendFrame.frotz = (float) pImuMisalign[2];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_IMU_MISALIGN_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARDAT_VEL(uint32_t val[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_DAT_VEL_SendFrame.uiVelocityoutputmode = val[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_DAT_VEL_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARDAT_POS(uint32_t val[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_DAT_POS_SendFrame.usPositionOutputMode = (uint16_t) val[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_DAT_POS_SendFrame.usAltitudeOutputMode = (uint16_t) val[1];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_DAT_POS_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARGNSS_DUALANTMODE(uint32_t mode)
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_DUALANTMODE_SendFrame.uiMode = mode;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_GNSS_DUALANTMODE_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARDAT_IMU(uint32_t val[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_DAT_IMU_SendFrame.uiInertialOutputMode = val[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_DAT_IMU_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}


int insCom::requestMsgPARDAT_IMU()
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_DAT_IMU_SendData, REQUESTPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}


int insCom::createMsgPAREKF_ZUPT(uint32_t intValues[],  double doubleValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.dAccThr = doubleValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.dOmgThr = doubleValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.dVelThr = doubleValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.fCutOffFreq = (float) doubleValues[3];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.fZuptRate = (float) doubleValues[4];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.fMinStdDevZUPT = (float) doubleValues[5];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.fWeightingFact = (float) doubleValues[6];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.fTimeConst = (float) doubleValues[7];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.usDelay = (uint16_t) intValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.ucMask = (uint8_t) intValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_ZUPTHR_SendFrame.ucAutoZUPT = (uint8_t) intValues[2];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_ZUPTHR_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPAREKF_VMEASPOINT(uint32_t intValues[],  double doubleValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_VMP_SendFrame.fDistance[0] = (float) doubleValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_VMP_SendFrame.fDistance[1] = (float) doubleValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_VMP_SendFrame.fDistance[2] = (float) doubleValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_VMP_SendFrame.usMask = (uint16_t) intValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_VMP_SendFrame.usCutOff = (uint16_t) intValues[1];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_VMP_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}


int insCom::createMsgPAREKF_DUALANTAID(uint32_t intValues[],  double doubleValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_DUALANTAID_SendFrame.fHdgStdDevThr = (float) doubleValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_DUALANTAID_SendFrame.fPitchStdDevThr = (float) doubleValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_DUALANTAID_SendFrame.fINSYawStdDevThr = (float) doubleValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_EKF_DUALANTAID_SendFrame.uiMode = intValues[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_EKF_DUALANTAID_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARARINC825_PORT(uint32_t intValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_PORT_SendFrame.uiPort = intValues[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_ARINC825_PORT_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARARINC825_BAUD(uint32_t intValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_BAUD_SendFrame.uiBaud = intValues[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_ARINC825_BAUD_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARARINC825_ENABLE(uint32_t intValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_ENABLE_SendFrame.usReserved = (uint16_t) intValues[0];						// usReserved: usRxEnable
	m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_ENABLE_SendFrame.usTxEnable = (uint16_t) intValues[1];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_ARINC825_ENABLE_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARARINC825_BUSRECOVERY(uint32_t intValues[])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_BUSRECOVERY_SendFrame.usBusRecovery = (uint16_t) intValues[0];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_ARINC825_BUSRECOVERY_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::getUseData(struct useLogData *p_useData)
{
//	pthread_mutex_lock (&m_mx_useData);
	lock_guard<mutex> lock(m_mx_useData);
	memcpy(p_useData,&m_useData,sizeof(useLogData));
//    pthread_mutex_unlock (&m_mx_useData);

    return(0);
}

int insCom::getUdpUseData(struct useUdpLogData *p_useUdpData)
{
//	pthread_mutex_lock (&m_mx_useUdpData);
	lock_guard<mutex> lock(m_mx_useUdpData);
	memcpy(p_useUdpData,&m_udpLog,sizeof(useUdpLogData));
//    pthread_mutex_unlock (&m_mx_useUdpData);

    return(0);
}

int insCom::getRetParData(struct retParData *p_retParData)
{

//	pthread_mutex_lock(&m_mx_retParData);
	lock_guard<mutex> lock(m_mx_retParData);
//	memcpy(p_retParData, &m_useData, sizeof(retParData));
	memcpy(p_retParData, &m_retParData, sizeof(retParData));
//	pthread_mutex_unlock(&m_mx_retParData);

	return(0);
}

int insCom::createMsgPARGNSS_NTRIP(uint32_t data[],char p_cStream[], char p_cServer[] ,char p_cUser[],char p_cPwd[])
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();

	if(strlen(p_cStream) < 128)
		strncpy(m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.cStream, p_cStream, 128);
	if(strlen(p_cServer) < 128)
		strncpy(m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.cServer, p_cServer, 128);
	if(strlen(p_cPwd) < 128)
		strncpy(m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.cPassword, p_cPwd, 128);
	if(strlen(p_cUser) < 128)
		strncpy(m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.cUser, p_cUser, 128);

	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.ucEnable = (uint8_t)data[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.ucSendPositionOnLogin = (uint8_t)data[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.usRemotePort =(uint16_t)data[2];



//	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.ucPort = (uint8_t) data[1];
//	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_NTRIP_SendFrame.uiBaud = (uint32_t) data[2];

	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_XCOM_NTRIP_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
		if((m_sendStruct.pData == NULL))
			return(-1);
		else
			return (0);

}


void insCom::reinitmARINC825_FL(void)
{
//	pthread_mutex_lock(&m_mx_ARINC825FL);
	lock_guard<mutex> lock(m_mx_ARINC825FL);
	
	//m_ARINC825_FL.uiDoc300 = {0u,0u,ARINC825_DOC_ACCRAW};  // 1
	m_ARINC825_FL.uiDoc300.usDivider = 0u;
	m_ARINC825_FL.uiDoc300.usReserved = 0u;
	m_ARINC825_FL.uiDoc300.uiDOC = ARINC825_DOC_ACCRAW;

	//m_ARINC825_FL.uiDoc301 = {0u,0u,ARINC825_DOC_ACCCOR};  // 2
	m_ARINC825_FL.uiDoc301.usDivider = 0u;
	m_ARINC825_FL.uiDoc301.usReserved = 0u;
	m_ARINC825_FL.uiDoc301.uiDOC = ARINC825_DOC_ACCCOR;

	//m_ARINC825_FL.uiDoc302 = {0u,0u,ARINC825_DOC_ACCCOMP};  // 3
	m_ARINC825_FL.uiDoc302.usDivider = 0u;
	m_ARINC825_FL.uiDoc302.usReserved = 0u;
	m_ARINC825_FL.uiDoc302.uiDOC = ARINC825_DOC_ACCCOMP;

	//m_ARINC825_FL.uiDoc303 = {0u,0u,ARINC825_DOC_OMGRAW};  // 4
	m_ARINC825_FL.uiDoc303.usDivider = 0u;
	m_ARINC825_FL.uiDoc303.usReserved = 0u;
	m_ARINC825_FL.uiDoc303.uiDOC = ARINC825_DOC_OMGRAW;

	//m_ARINC825_FL.uiDoc304 = {0u,0u,ARINC825_DOC_OMGCOR};  // 5
	m_ARINC825_FL.uiDoc304.usDivider = 0u;
	m_ARINC825_FL.uiDoc304.usReserved = 0u;
	m_ARINC825_FL.uiDoc304.uiDOC = ARINC825_DOC_OMGCOR;

	//m_ARINC825_FL.uiDoc305 = {0u,0u,ARINC825_DOC_OMGCOMP};  // 6
	m_ARINC825_FL.uiDoc305.usDivider = 0u;
	m_ARINC825_FL.uiDoc305.usReserved = 0u;
	m_ARINC825_FL.uiDoc305.uiDOC = ARINC825_DOC_OMGCOMP;

	//m_ARINC825_FL.uiDoc311 = {0u,0u,ARINC825_DOC_RPY};  // 7
	m_ARINC825_FL.uiDoc311.usDivider = 0u;
	m_ARINC825_FL.uiDoc311.usReserved = 0u;
	m_ARINC825_FL.uiDoc311.uiDOC = ARINC825_DOC_RPY;

	//m_ARINC825_FL.uiDoc337 = {0u,0u,ARINC825_DOC_VXYZ};  // 8
	m_ARINC825_FL.uiDoc337.usDivider = 0u;
	m_ARINC825_FL.uiDoc337.usReserved = 0u;
	m_ARINC825_FL.uiDoc337.uiDOC = ARINC825_DOC_VXYZ;

	//m_ARINC825_FL.uiDoc1130 = {0u,0u,ARINC825_DOC_VNED}; // 9
	m_ARINC825_FL.uiDoc1130.usDivider = 0u;
	m_ARINC825_FL.uiDoc1130.usReserved = 0u;
	m_ARINC825_FL.uiDoc1130.uiDOC = ARINC825_DOC_VNED;

	//m_ARINC825_FL.uiDoc1050 = {0u,0u,ARINC825_DOC_LON}; // 10
	m_ARINC825_FL.uiDoc1050.usDivider = 0u;
	m_ARINC825_FL.uiDoc1050.usReserved = 0u;
	m_ARINC825_FL.uiDoc1050.uiDOC = ARINC825_DOC_LON;

	//m_ARINC825_FL.uiDoc1049 = {0u,0u,ARINC825_DOC_LAT}; // 11
	m_ARINC825_FL.uiDoc1049.usDivider = 0u;
	m_ARINC825_FL.uiDoc1049.usReserved = 0u;
	m_ARINC825_FL.uiDoc1049.uiDOC = ARINC825_DOC_LAT;

	//m_ARINC825_FL.uiDoc1051 = {0u,0u,ARINC825_DOC_ALT}; // 12
	m_ARINC825_FL.uiDoc1051.usDivider = 0u;
	m_ARINC825_FL.uiDoc1051.usReserved = 0u;
	m_ARINC825_FL.uiDoc1051.uiDOC = ARINC825_DOC_ALT;

	//m_ARINC825_FL.uiDoc1069 = {0u,0u,ARINC825_DOC_TIME}; // 13
	m_ARINC825_FL.uiDoc1069.usDivider = 0u;
	m_ARINC825_FL.uiDoc1069.usReserved = 0u;
	m_ARINC825_FL.uiDoc1069.uiDOC = ARINC825_DOC_TIME;

	//m_ARINC825_FL.uiDoc1303 = {0u,0u,ARINC825_DOC_SYSSTAT}; // 14
	m_ARINC825_FL.uiDoc1303.usDivider = 0u;
	m_ARINC825_FL.uiDoc1303.usReserved = 0u;
	m_ARINC825_FL.uiDoc1303.uiDOC = ARINC825_DOC_SYSSTAT;

	//m_ARINC825_FL.uiDoc1304 = {0u,0u,ARINC825_DOC_EKF_LOW}; // 15
	m_ARINC825_FL.uiDoc1304.usDivider = 0u;
	m_ARINC825_FL.uiDoc1304.usReserved = 0u;
	m_ARINC825_FL.uiDoc1304.uiDOC = ARINC825_DOC_EKF_LOW;

	//m_ARINC825_FL.uiDoc1305 = {0u,0u,ARINC825_DOC_EKF_HI}; // 16
	m_ARINC825_FL.uiDoc1305.usDivider = 0u;
	m_ARINC825_FL.uiDoc1305.usReserved = 0u;
	m_ARINC825_FL.uiDoc1305.uiDOC = ARINC825_DOC_EKF_HI;

	//m_ARINC825_FL.uiDoc1310 = {0u,0u,ARINC825_DOC_LONSTDDEV}; // 17
	m_ARINC825_FL.uiDoc1310.usDivider = 0u;
	m_ARINC825_FL.uiDoc1310.usReserved = 0u;
	m_ARINC825_FL.uiDoc1310.uiDOC = ARINC825_DOC_LONSTDDEV;

	//m_ARINC825_FL.uiDoc1311 = {0u,0u,ARINC825_DOC_LATSTDDEV}; // 18
	m_ARINC825_FL.uiDoc1311.usDivider = 0u;
	m_ARINC825_FL.uiDoc1311.usReserved = 0u;
	m_ARINC825_FL.uiDoc1311.uiDOC = ARINC825_DOC_LATSTDDEV;

	//m_ARINC825_FL.uiDoc1312 = {0u,0u,ARINC825_DOC_VELSTDDEV}; // 19
	m_ARINC825_FL.uiDoc1312.usDivider = 0u;
	m_ARINC825_FL.uiDoc1312.usReserved = 0u;
	m_ARINC825_FL.uiDoc1312.uiDOC = ARINC825_DOC_VELSTDDEV;

	//m_ARINC825_FL.uiDoc1313 = {0u,0u,ARINC825_DOC_RPYSTDDEV}; // 20
	m_ARINC825_FL.uiDoc1313.usDivider = 0u;
	m_ARINC825_FL.uiDoc1313.usReserved = 0u;
	m_ARINC825_FL.uiDoc1313.uiDOC = ARINC825_DOC_RPYSTDDEV;

	//m_ARINC825_FL.uiDoc1314 = {0u,0u,ARINC825_DOC_ALTSTDDEV}; // 21
	m_ARINC825_FL.uiDoc1314.usDivider = 0u;
	m_ARINC825_FL.uiDoc1314.usReserved = 0u;
	m_ARINC825_FL.uiDoc1314.uiDOC = ARINC825_DOC_ALTSTDDEV;

	//m_ARINC825_FL.uiDoc1315 = {0u,0u,ARINC825_DOC_MAGICNUM}; // 22
	m_ARINC825_FL.uiDoc1315.usDivider = 0u;
	m_ARINC825_FL.uiDoc1315.usReserved = 0u;
	m_ARINC825_FL.uiDoc1315.uiDOC = ARINC825_DOC_MAGICNUM;

	// 23
	m_ARINC825_FL.uiDoc1037.usDivider = 0u;
	m_ARINC825_FL.uiDoc1037.usReserved = 0u;
	m_ARINC825_FL.uiDoc1037.uiDOC = ARINC825_DOC_GNSSLON;

	// 24
	m_ARINC825_FL.uiDoc1036.usDivider = 0u;
	m_ARINC825_FL.uiDoc1036.usReserved = 0u;
	m_ARINC825_FL.uiDoc1036.uiDOC = ARINC825_DOC_GNSSLAT;

	// 25
	m_ARINC825_FL.uiDoc1038.usDivider = 0u;
	m_ARINC825_FL.uiDoc1038.usReserved = 0u;
	m_ARINC825_FL.uiDoc1038.uiDOC = ARINC825_DOC_GNSSALT;

	// 26
	m_ARINC825_FL.uiDoc1608.usDivider = 0u;
	m_ARINC825_FL.uiDoc1608.usReserved = 0u;
	m_ARINC825_FL.uiDoc1608.uiDOC = ARINC825_DOC_GNSSVEL;

	// 27
	m_ARINC825_FL.uiDoc1201.usDivider = 0u;
	m_ARINC825_FL.uiDoc1201.usReserved = 0u;
	m_ARINC825_FL.uiDoc1201.uiDOC = ARINC825_DOC_GNSSINF;

	// 28
	m_ARINC825_FL.uiDoc1605.usDivider = 0u;
	m_ARINC825_FL.uiDoc1605.usReserved = 0u;
	m_ARINC825_FL.uiDoc1605.uiDOC = ARINC825_DOC_GNSSPOSSTDDEV;

	// 29
	m_ARINC825_FL.uiDoc1611.usDivider = 0u;
	m_ARINC825_FL.uiDoc1611.usReserved = 0u;
	m_ARINC825_FL.uiDoc1611.uiDOC = ARINC825_DOC_GNSSVELSTDDEV;

//	pthread_mutex_unlock(&m_mx_ARINC825FL);
};

int insCom::setmARINC825FLEntry(uint16_t usFrameId, uint16_t usDivider)
{
	int retValue = -1;
//	pthread_mutex_lock(&m_mx_ARINC825FL);
	lock_guard<mutex> lock(m_mx_ARINC825FL);
    switch(usFrameId)
	{
		case ARINC825_DOC_ACCRAW:
			m_ARINC825_FL.uiDoc300.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_ACCCOR:
			m_ARINC825_FL.uiDoc301.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_ACCCOMP:
			m_ARINC825_FL.uiDoc302.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_OMGRAW:
			m_ARINC825_FL.uiDoc303.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_OMGCOR:
			m_ARINC825_FL.uiDoc304.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_OMGCOMP:
			m_ARINC825_FL.uiDoc305.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_RPY:
			m_ARINC825_FL.uiDoc311.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_VXYZ:
			m_ARINC825_FL.uiDoc337.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_VNED:
			m_ARINC825_FL.uiDoc1130.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_LON:
			m_ARINC825_FL.uiDoc1050.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_LAT:
			m_ARINC825_FL.uiDoc1049.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_ALT:
			m_ARINC825_FL.uiDoc1051.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_TIME:
			m_ARINC825_FL.uiDoc1069.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_SYSSTAT:
			m_ARINC825_FL.uiDoc1303.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_EKF_LOW:
			m_ARINC825_FL.uiDoc1304.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_EKF_HI:
			m_ARINC825_FL.uiDoc1305.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_LONSTDDEV:
			m_ARINC825_FL.uiDoc1310.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_LATSTDDEV:
			m_ARINC825_FL.uiDoc1311.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_VELSTDDEV:
			m_ARINC825_FL.uiDoc1312.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_RPYSTDDEV:
			m_ARINC825_FL.uiDoc1313.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_ALTSTDDEV:
			m_ARINC825_FL.uiDoc1314.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_MAGICNUM:
			m_ARINC825_FL.uiDoc1315.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSLON:
			m_ARINC825_FL.uiDoc1037.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSLAT:
			m_ARINC825_FL.uiDoc1036.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSALT:
			m_ARINC825_FL.uiDoc1038.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSVEL:
			m_ARINC825_FL.uiDoc1608.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSINF:
			m_ARINC825_FL.uiDoc1201.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSPOSSTDDEV:
			m_ARINC825_FL.uiDoc1605.usDivider = usDivider;
			retValue = 0;
		break;
		case ARINC825_DOC_GNSSVELSTDDEV:
			m_ARINC825_FL.uiDoc1611.usDivider = usDivider;
			retValue = 0;
		break;
		default:
			retValue = -1;
		break;
	}
//    pthread_mutex_unlock(&m_mx_ARINC825FL);

	return(retValue);
}

int insCom::createMsgPARARINC825_FrameList(void)
{
	uint8_t numOfFrames = 29;

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock1(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
//	pthread_mutex_lock(&m_mx_ARINC825FL);
	lock_guard<mutex> lock2(m_mx_ARINC825FL);
	// Workaround: number of frames is set here into "reserved"
	memcpy(&(m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_FRAMELIST_SendFrame.tParHeader.ucReserved), &(numOfFrames), sizeof(uint8_t));
	memcpy(&(m_ixcomhandler.getIXComSendDataFrame()->PAR_ARINC825_FRAMELIST_SendFrame.cParArinc825FrameList), &m_ARINC825_FL, sizeof(t_ARINC825_FRAMEList));
//	pthread_mutex_unlock(&m_mx_ARINC825FL);
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_ARINC825_FRAMELIST_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);

	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}

int insCom::createMsgPARXCOM_UDPCONFIG(uint32_t intValues[],char p_srvAddr[])
{
//	in_addr_t srvAddr = 0;
//	srvAddr= inet_network(p_srvAddr);
	uint32_t srvAddr = 0;
	srvAddr = ntohl(inet_addr(p_srvAddr));
	
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_UDPCONFIG_SendFrame.ucChannel = (uint8_t) intValues[0];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_UDPCONFIG_SendFrame.ucEnable = (uint8_t) intValues[1];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_UDPCONFIG_SendFrame.uiPort = (uint32_t) intValues[2];
	m_ixcomhandler.getIXComSendDataFrame()->PAR_XCOM_UDPCONFIG_SendFrame.uiServerAddress =  (uint32_t) srvAddr;
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_XCOM_UDPCONFIG_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);

	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::createMsgPARGNSS_RTCMV3CONFIG(uint32_t intValues[])
{

//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_RTCMV3CONFIG_SendFrame.ucEnable = (uint8_t) intValues[0];
//	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_RTCMV3CONFIG_SendFrame.ucPort = (uint8_t) intValues[1];
//	m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_RTCMV3CONFIG_SendFrame.uiBaud = (uint16_t) intValues[2];
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_GNSS_RTCMV3CONFIG_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);

	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);

}

int insCom::createMsgPARGNSS_RTCMV3AIDING(char p_RTCMV3[64])
{
//	pthread_mutex_lock(&m_mx_txMsg);
	lock_guard<mutex> lock(m_mx_txMsg);
	m_ixcomhandler.initSendFrameZeros();
	for(int i = 0;i<64;i++)
	{
		m_ixcomhandler.getIXComSendDataFrame()->PAR_GNSS_RTCMV3AIDING_SendFrame.cPayload = (uint8_t) p_RTCMV3[i];
	}
	m_sendStruct = m_ixcomhandler.completeIXComSendFrame(iXComHandler::iXComSendData::PAR_GNSS_RTCMV3AIDING_SendData, CHANGEPAR);
//	pthread_mutex_unlock(&m_mx_txMsg);
	if((m_sendStruct.pData == NULL))
		return(-1);
	else
		return (0);
}


