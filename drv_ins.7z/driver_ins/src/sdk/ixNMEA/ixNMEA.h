#ifdef __cplusplus
extern "C" {
#endif

#ifndef NMEA_H_
#define NMEA_H_

#include "XCOMtypes.h"

#define NMEA_MAX_BUFFER_SIZE	2048
#define XCOM_GLOBALSTAT_GNSSINVALID			(1 << 6)
/*
 * EKF Status Hi
 */
#define EKF_STATUS_HI_RTKLLH_UPD			(1 << 0)
#define EKF_STATUS_HI_RTKLLH_LON_OUTLIER	(1 << 1)
#define EKF_STATUS_HI_RTKLLH_LAT_OUTLIER	(1 << 2)
#define EKF_STATUS_HI_RTKLLH_ALT_OUTLIER	(1 << 3)
#define EKF_STATUS_HI_BSLXYZ_UPDATE			(1 << 4)
#define EKF_STATUS_HI_BSLXYZ_OUTLIER		(1 << 5)
#define EKF_STATUS_HI_TDCP_UPDATE			(1 << 8)
#define EKF_STATUS_HI_TDCP_DD_UPDATE		(1 << 9)
#define EKF_STATUS_HI_ODO_ALONGTRK_UPDATE	(1 << 10)
#define EKF_STATUS_HI_ODO_ALONGTRK_OUTLIER	(1 << 11)
#define EKF_STATUS_HI_ODO_CONST_UPDATE		(1 << 12)
#define EKF_STATUS_HI_ODO_CONST_OUTLIER		(1 << 13)
#define EKF_STATUS_HI_GRAV_UPDATE			(1 << 14)
#define EKF_STATUS_HI_GRAV_OUTLIER			(1 << 15)
#define EKF_STATUS_HI_EXTPOS_UPD			(1 << 16)
#define EKF_STATUS_HI_EXTPOS_OUTLIER		(1 << 17)
#define EKF_STATUS_HI_EXTVEL_UPD			(1 << 18)
#define EKF_STATUS_HI_EXTVEL_OUTLIER		(1 << 19)
#define EKF_STATUS_HI_ZARU					(1 << 20)
#define EKF_STATUS_HI_WAHBA_UPDATE			(1 << 24)
#define EKF_STATUS_HI_WAHBA_FILTER			(1 << 25)
#define EKF_STATUS_HI_FILTERMODE_1			(1 << 26)
#define EKF_STATUS_HI_FILTERMODE_2			(1 << 27)
#define EKF_STATUS_HI_LEVELLING_COMPLETE	(1 << 29)
#define EKF_STATUS_HI_ALIGN_COMPLETE		(1 << 30)
#define EKF_STATUS_HI_INITPOS_SET			(1 << 31)


typedef enum
{
	NONE=0,
	FIXEDPOS=1,
	FIXEDHEIGHT=2,
	DOPPLER_VELOCITY=8,
	SINGLE=16,
	PSRDIFF=17,
	SBAS=18,
	PROPAGATED=19,
	OMNISTAR=20,
	L1_FLOAT=32,
	IONOFREE_FLOAT=33,
	NARROW_FLOAT=34,
	L1_INT=48,
	WIDE_INT=49,
	NARROW_INT=50,
	OMNISTAR_HP=64,
	OMNISTAR_XP=65
} t_Nov_PosVelType;

typedef enum
{
	SOL_COMPUTED=0,
	INSUFFICIENT_OBS=1,
	NO_CONVERGENCE=2,
	SINGULARITY=3,
	COV_TRACE=4,
	TEST_DIST=5,
	COLD_START=6,
	V_H_LIMIT=7,
	VARIANCE=8,
	RESIDUALS=9,
	DELTA_POS=10,
	NEGATIVE_VAR=11,
	Reserved=12,
	PENDING=13,
	INVALID_FIX=19,
	UNAUTHORIZED=20,
	ANTENNA_WARNING=21
} t_Nov_SolStatus;

typedef struct
{
	struct
	{
		double lon;
		int    lonDeg;
		double lonMin;
		char   lonDir;
	} Lon;
	struct
	{
		double lat;
		int    latDeg;
		double latMin;
		char   latDir;
	} Lat;
	char writeBuffer[NMEA_MAX_BUFFER_SIZE];
	int  fdCOM;
	int  sendTimer;
	struct
	{
		uint16_t     gps_week;
		double       gps_tow;
		uint16_t     utc_year;
		uint8_t      utc_month;
		uint8_t      utc_day;
		uint8_t      utc_hour;
		uint8_t      utc_minute;
		float        utc_seconds;
	} TIME;
	int delay;

} t_NmeaType;


void NMEA_processXCOMData(t_NmeaType *me, t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_GNSSTIME *gnsstime, t_XCOM_MSG_IMUCAL *imucal);
void NMEA_getXCOMGGA(t_NmeaType *me, t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_GNSSTIME *gnsstime,t_XCOM_MSG_IMUCAL *imucal);
uint8_t NMEA_getXCOMGpsQuality(t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_IMUCAL *imucal);
void NMEA_convertPosition(t_NmeaType *me);
int NMEA_calcCRC(char *pch);

#endif /* NMEA_H_ */


#ifdef __cplusplus
}
#endif
