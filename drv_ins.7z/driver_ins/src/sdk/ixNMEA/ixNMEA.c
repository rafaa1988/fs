
#include <stdio.h>
#include <stdlib.h>
//#include <unistd.h>
#include <string.h>
#include <math.h>
#include <fcntl.h>
#include <errno.h>
#include "ixNMEA.h"
#define RAD2DEG (180.f/3.14159f)

#ifdef __linux
#include <termios.h>
#endif
#include "XCOMtypes.h"

int NMEA_calcCRC(char *pch)
{
	unsigned char crc;

	if (*pch != '$')
		return 0;		// does not start with '$' - so can't CRC
	pch++;				// skip '$'
	crc = 0;

	/* scan between '$' and '*' (or until CR LF or EOL) */
	while ((*pch != '*') && (*pch != '\0') && (*pch != '\r') && (*pch != '\n'))
	{
		/* checksum calcualtion done over characters between '$' and '*' */
		crc ^= *pch;
		pch++;
	}

	/* add or re-write checksum */
	sprintf(pch,"*%02X\r\n",(unsigned int)crc);
	return 1;
}

void NMEA_convertPosition(t_NmeaType *me)
{
	/* Longitude */
	(me->Lon.lon >= 0) ? (me->Lon.lonDir = 'E') : (me->Lon.lonDir = 'W');
	me->Lon.lon    = me->Lon.lon*RAD2DEG;
	me->Lon.lon    = fabs(me->Lon.lon);
	me->Lon.lonDeg = (int)me->Lon.lon;
	me->Lon.lonMin = (me->Lon.lon - (double)me->Lon.lonDeg) * 60.0;

	/* Latitude */
	(me->Lat.lat >= 0) ? (me->Lat.latDir = 'N') : (me->Lat.latDir = 'S');
	me->Lat.lat    = me->Lat.lat*RAD2DEG;
	me->Lat.lat    = fabs(me->Lat.lat);
	me->Lat.latDeg = (int)me->Lat.lat;
	me->Lat.latMin = (me->Lat.lat - (double)me->Lat.latDeg) * 60.0;
}

void NMEA_processXCOMData(t_NmeaType *me, t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_GNSSTIME *gnsstime, t_XCOM_MSG_IMUCAL *imucal)
{
			me->Lat.lat = gnsssol->dLatitude;
			me->Lon.lon = gnsssol->dLongitude;
			NMEA_convertPosition(me);

			me->TIME.gps_tow  = (double) gnsssol->tHeader.uiGpsTime_sec+ 1e-6 * (double) gnsssol->tHeader.uiGpsTime_usec;
			me->TIME.gps_week = gnsssol->tHeader.usGpsWeek;

			me->TIME.utc_year = gnsstime->uiUTCyear;
			me->TIME.utc_month = gnsstime->ucUTCmonth;
			me->TIME.utc_day = gnsstime->ucUTCday;
			me->TIME.utc_hour = gnsstime->ucUTChour;
			me->TIME.utc_minute = gnsstime->ucUTCmin;
			me->TIME.utc_seconds = (float) gnsstime->uiUTCms * 1e-3;


			NMEA_getXCOMGGA(me, gnsssol, gnsstime, imucal);
			//printf("GGA:, %s",me->writeBuffer);
}


void NMEA_getXCOMGGA(t_NmeaType *me, t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_GNSSTIME *gnsstime,t_XCOM_MSG_IMUCAL *imucal)
{
	uint8_t gpsQuality = NMEA_getXCOMGpsQuality(gnsssol,imucal);
	uint8_t ucSatsTracked = gnsssol->ucSatsTracked;
	if(ucSatsTracked > 12)
		ucSatsTracked = 12;

	memset((void *)me->writeBuffer, 0, NMEA_MAX_BUFFER_SIZE);
	sprintf(me->writeBuffer, "$GPGGA,%02d%02d%05.2f,%02d%011.8f,%c,%03d%011.8f,%c,%1d,%02d,%.1f,%.3f,M,%.1f,M,,*",
			me->TIME.utc_hour, me->TIME.utc_minute, me->TIME.utc_seconds,
			me->Lat.latDeg, me->Lat.latMin, me->Lat.latDir,
			me->Lon.lonDeg, me->Lon.lonMin, me->Lon.lonDir,
			gpsQuality, ucSatsTracked, gnsssol->fPDOP, gnsssol->fAltitude,
			gnsssol->fUndulation);
	NMEA_calcCRC(me->writeBuffer);

}


uint8_t NMEA_getXCOMGpsQuality(t_XCOM_MSG_GNSSSOL *gnsssol, t_XCOM_MSG_IMUCAL *imucal)
{
    uint8_t ucGpsQualInd = 1;	// GPS Fix

    if( (imucal->uiEkfStatHi & EKF_STATUS_HI_LEVELLING_COMPLETE) && (imucal->uiEkfStatHi & EKF_STATUS_HI_INITPOS_SET) )
    {
		if( (gnsssol->usSolStatus == SOL_COMPUTED) && (gnsssol->usPosVelType == NARROW_FLOAT) )
			ucGpsQualInd = 5;		// Float RTK
		if( (gnsssol->usSolStatus == SOL_COMPUTED) && (gnsssol->usPosVelType > NARROW_FLOAT) )
			ucGpsQualInd = 4;		// RTK Fix
		if(gnsssol->tBottom.gStatus & XCOM_GLOBALSTAT_GNSSINVALID)
				ucGpsQualInd = 6;	// Estimated
    }
    else
    	ucGpsQualInd = 0;		// no Fix
    return ucGpsQualInd;
}
