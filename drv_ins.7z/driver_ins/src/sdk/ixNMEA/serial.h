/*
 * serial.h
 *
 *  Created on: 24.05.2016
 *      Author: Tobias
 */

#ifndef SERIAL_H_
#define SERIAL_H_

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include "insClass.h"
//#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>

int serial(int fd, char p_data[256]);
int setInterfaceAttributes(int fd, int baud, int parity);
int setInterfaceBlocking(int fd, int vmin);

#endif /* SERIAL_H_ */
