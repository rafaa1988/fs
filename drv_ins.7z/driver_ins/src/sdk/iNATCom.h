/*
 * iNATCom.h
 *
 *  Created on: 12.12.2016
 *      Author: zp
 */

#ifndef SRC_INATCOM_H_
#define SRC_INATCOM_H_

#include <thread>
#include <mutex>

#ifdef __linux
#include "serial.h"
#else
#include "Serial_w.h"
#endif
#include "ixNMEA.h"

#ifdef _WIN32
#define iNAT_STRUCT_ATTRIBUTES
#pragma pack(push)
#pragma pack(1)
#else
#define iNAT_STRUCT_ATTRIBUTES __attribute__ ((__packed__))
#endif

#define IMURAW 0
#define IMUCORR 1
#define IMUCOMP 2
uint32_t currImuMode = 0;
#define POSITION_WGS84 0
#define ALTITUDE_WGS84 0
#define PARDAT_VEL_BODY 3
#define DATACHANNEL 3
#define UDP_LOG_CHANNEL 2
#define UDP_DISABLE 0
#define UDP_ENABLE 1
//#define CH_SECOND_ACCESS 2
#define TIMEOUT 500  /*timeout in ms*/
#define CONF_TIMEOUT 20000	// save config timeout
#define M_PI 3.14159265358979323846

#define NUM_OF_PAR_EXTAID_FREEZE_ALT 3
#define NUM_OF_PAR_EXTAID_FREEZE_HDG 3
#define NUM_OF_PAR_EXTAID_FREEZE_VELBODY 7
#define NUM_OF_PAR_EXTAID_POS 12
#define NUM_OF_PAR_EXTAID_VEL 12
#define NUM_OF_PAR_EXTAID_HDG 2
#define NUM_OF_PAR_EXTAID_HGT 2

//#define iNAT_BRDCST_ADDR "192.168.6.255" // iNAT Broadcast Addr.
//#define iNAT_BRDCST_ADDR "192.168.1.255" // iNAT Broadcast Addr.
//#define iNAT_UDP_PORT 4710               // iNAT UDP Port

//#define iNAT_IP_ADDR "192.168.6.160"    // iNAT Addr.
//#define iNAT_TCP_PORT 3000               // iNAT TCP Port

//#define PC_IP_ADDR "192.168.6.158" // PC Addr.
//#define PC_IP_ADDR "192.168.1.155" // PC Addr.

struct {
	char	iNAT_ip[20];
	int		iNAT_tcp_port;
	char	iNAT_brdcst_addr[20];
	int		iNAT_udp_port;
	char	pc_ip[20];
#ifdef __linux
	char	serialPort[20];
#else
	int serialPort;
#endif
	int		log_freq;
	char	NTRIP_stream[128];
	char	NTRIP_server[128];
	int		NTRIP_remote_port;
	char	NTRIP_user[128];
	char	NTRIP_password[128];
}inputParams;


//#ifdef _WIN32
//#pragma pack(1)
//typedef struct
//#elif __linux
//typedef struct __attribute__ ((__packed__))
//#else
//#error platform not supported
//#endif
typedef struct iNAT_STRUCT_ATTRIBUTES
{
    int32_t fd;
    insCom *iNAT;

} t_FWDRTCMV3;

#ifdef _WIN32
#pragma pack(pop)
#endif

t_FWDRTCMV3 rtkThreadData;

//pthread_mutex_t mx_lock	= PTHREAD_MUTEX_INITIALIZER;
mutex mx_lock;
double tcp_uiGpsTime_sec = 0.0;
double tcp_uiGpsTime_usec = 0.0;
uint16_t tcp_gStatus = 0;
double udp_insPosLLH_uiGpsTime_sec = 0.0;
double udp_insPosLLH_uiGpsTime_usec = 0.0;
double udp_insSol_uiGpsTime_sec = 0.0;
double udp_insSol_uiGpsTime_usec = 0.0;
float temp[16] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

uint32_t confCmd = 0;

using namespace std;
void t_parseRxData(void *pArg);
void t_parseRxRunData(void *pArg);
void t_fwdRTCMV3Data(void *pArg);

int initINS(insCom *p_ins);
int createRTCMV3Thread(void);

int getSysInfo(insCom *p_ins);
int setConfig(insCom *p_ins, uint32_t action);
int setExtAid(insCom *p_ins, uint16_t action, int enable);
int setComChannel(insCom *p_ins, int numOfChannel, int action);
int requestLogs(insCom *p_ins);
int getParamsFromFile();
void calc_h_m_s(int *h, int *m, int *s);

static useLogData logData;
static useUdpLogData udpData;
static retParData parData;
static int logDivider_desired = 500;
static int logDivider_oneHz = 500;


char const *p_modName = "iNatModule";
char cmdResp[60];
char *p_cmdResp = &cmdResp[0];

//pthread_t insComThread;
//pthread_t udpComThread;
//pthread_t rtkComThread;
//thread insComThread;
//thread udpComThread;
//thread rtkComThread;

#ifdef _WIN32
CSerial serial;
int rxByteCnt = 0;
//int txByteCnt = 0;
char rxByte[1]="";
#endif

#endif /* SRC_INATCOM_H_ */
