#include "ixcomhandler.h"
#include <string.h>

iXComHandler::iXComHandler() : iXComParser()
{
}

iXComHandler::~iXComHandler()
{

}

iXComHandler::iXComSendFrame iXComHandler::completeIXComSendFrame(iXComSendData sendData, bool changeParameter)
{
    iXComSendFrame sendFrame;

    t_XCOM_Header * const header = (t_XCOM_Header *) &m_iXComSendDataFrame;
    header->ucSync = 0x7E;
    header->ucFrameCnt = m_sendFrameCounter++;

    if (CMD_XCOM_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_COMMAND;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_XCOMCMD_XCOM);
        m_iXComSendDataFrame.CMD_XCOM_SendFrame.tCmdHeader.usCmdID = XCOMCMD_XCOM;
        m_iXComSendDataFrame.CMD_XCOM_SendFrame.tCmdHeader.usSpecific = 0U;
    }
    else if (CMD_LOG_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_COMMAND;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_XCOMCMD_LOG);
        m_iXComSendDataFrame.CMD_LOG_SendFrame.tCmdHeader.usCmdID = XCOMCMD_LOG;
        m_iXComSendDataFrame.CMD_LOG_SendFrame.tCmdHeader.usSpecific = 0U;
    }
    else if (CMD_CONF_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_COMMAND;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_XCOMCMD_CONF);
        m_iXComSendDataFrame.CMD_CONF_SendFrame.tCmdHeader.usCmdID = XCOMCMD_CONF;
        m_iXComSendDataFrame.CMD_CONF_SendFrame.tCmdHeader.usSpecific = 0U;
    }
    else if (CMD_EKF_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_COMMAND;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_XCOMCMD_EKF) - sizeof(m_iXComSendDataFrame.CMD_EKF_SendFrame.fPar) + m_iXComSendDataFrame.CMD_EKF_SendFrame.usNumOfPar * sizeof(float);
        *(uint16_t *) &m_iXComSendDataFrame.CMD_EKF_SendFrame.fPar[m_iXComSendDataFrame.CMD_EKF_SendFrame.usNumOfPar] = m_iXComSendDataFrame.CMD_EKF_SendFrame.tBottom.gStatus;
        m_iXComSendDataFrame.CMD_EKF_SendFrame.tCmdHeader.usCmdID = XCOMCMD_EKF;
        m_iXComSendDataFrame.CMD_EKF_SendFrame.tCmdHeader.usSpecific = 0U;
    }
    else if (CMD_EXTAID_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_COMMAND;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_XCOMCMD_EXTAID) - sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar);
        uint8_t *pStatus = (uint8_t *) &m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar;
        if ((XCOMEXTAID_FREEZE_ALT == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID) || (XCOMEXTAID_FREEZE_HDG == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID))
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParFreezeAlt);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParFreezeAlt)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        else if (XCOMEXTAID_FREEZE_VELBODY == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID)
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParFreezeVelBody);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParFreezeVelBody)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        else if (XCOMEXTAID_POS == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID)
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.parExtAidPos);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.parExtAidPos)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        else if (XCOMEXTAID_VEL == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID)
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidVel);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidVel)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        else if (XCOMEXTAID_HDG == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID)
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidHdg);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidHdg)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        else if (XCOMEXTAID_HGT == m_iXComSendDataFrame.CMD_EXTAID_SendFrame.usCmdParID)
        {
            header->usMsgLen += sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidHdg);
            *(uint16_t *) (pStatus + sizeof(m_iXComSendDataFrame.CMD_EXTAID_SendFrame.cmdPar.dParExtAidHgt)) = m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tBottom.gStatus;
        }
        m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tCmdHeader.usCmdID = XCOMCMD_EXTAID;
        m_iXComSendDataFrame.CMD_EXTAID_SendFrame.tCmdHeader.usSpecific = 0U;
    }
    else if (PAR_SYS_PRJNUM_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_PRJNUM);
        m_iXComSendDataFrame.PAR_SYS_PRJNUM_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_PRJNUM;
        m_iXComSendDataFrame.PAR_SYS_PRJNUM_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_PARTNUM_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_PARTNUM);
        m_iXComSendDataFrame.PAR_SYS_PARTNUM_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_PARTNUM;
        m_iXComSendDataFrame.PAR_SYS_PARTNUM_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_SERIALNUM_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_SERIALNUM);
        m_iXComSendDataFrame.PAR_SYS_SERIALNUM_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_SERIALNUM;
        m_iXComSendDataFrame.PAR_SYS_SERIALNUM_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_MFG_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_MFG);
        m_iXComSendDataFrame.PAR_SYS_MFG_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_MFG;
        m_iXComSendDataFrame.PAR_SYS_MFG_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_CALDATE_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_CALDATE);
        m_iXComSendDataFrame.PAR_SYS_CALDATE_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_CALDATE;
        m_iXComSendDataFrame.PAR_SYS_CALDATE_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_FWVERSION_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_FWVERSION);
        m_iXComSendDataFrame.PAR_SYS_FWVERSION_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_FWVERSION;
        m_iXComSendDataFrame.PAR_SYS_FWVERSION_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_NAVLIB_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_NAVLIB);
        m_iXComSendDataFrame.PAR_SYS_NAVLIB_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_NAVLIB;
        m_iXComSendDataFrame.PAR_SYS_NAVLIB_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_EKFLIB_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_EKFLIB);
        m_iXComSendDataFrame.PAR_SYS_EKFLIB_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_EKFLIB;
        m_iXComSendDataFrame.PAR_SYS_EKFLIB_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_EKFPARSET_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_EKFPARSET);
        m_iXComSendDataFrame.PAR_SYS_EKFPARSET_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_EKFPARSET;
        m_iXComSendDataFrame.PAR_SYS_EKFPARSET_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_NAVNUM_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_NAVNUM);
        m_iXComSendDataFrame.PAR_SYS_NAVNUM_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_NAVNUM;
        m_iXComSendDataFrame.PAR_SYS_NAVNUM_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_NAVPARSET_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_NAVPARSET);
        m_iXComSendDataFrame.PAR_SYS_NAVPARSET_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_NAVPARSET;
        m_iXComSendDataFrame.PAR_SYS_NAVPARSET_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_MAINTIMING_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_MAINTIMING);
        m_iXComSendDataFrame.PAR_SYS_MAINTIMING_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_MAINTIMING;
        m_iXComSendDataFrame.PAR_SYS_MAINTIMING_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_PRESCALER_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_PRESCALER);
        m_iXComSendDataFrame.PAR_SYS_PRESCALER_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_PRESCALER;
        m_iXComSendDataFrame.PAR_SYS_PRESCALER_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_UPTIME_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_UPTIME);
        m_iXComSendDataFrame.PAR_SYS_UPTIME_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_UPTIME;
        m_iXComSendDataFrame.PAR_SYS_UPTIME_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_OPHOURCNT_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_OPHOURCNT);
        m_iXComSendDataFrame.PAR_SYS_OPHOURCNT_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_OPHOURCNT;
        m_iXComSendDataFrame.PAR_SYS_OPHOURCNT_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_BOOTMODE_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_BOOTMODE);
        m_iXComSendDataFrame.PAR_SYS_BOOTMODE_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_BOOTMODE;
        m_iXComSendDataFrame.PAR_SYS_BOOTMODE_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_FPGAVER_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_FPGAVER);
        m_iXComSendDataFrame.PAR_SYS_FPGAVER_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_FPGAVER;
        m_iXComSendDataFrame.PAR_SYS_FPGAVER_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_CONFIGCRC_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_CONFIGCRC);
        m_iXComSendDataFrame.PAR_SYS_CONFIGCRC_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_CONFIGCRC;
        m_iXComSendDataFrame.PAR_SYS_CONFIGCRC_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_SYS_OSVERSION_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_SYS_OSVERSION);
        m_iXComSendDataFrame.PAR_SYS_OSVERSION_SendFrame.tParHeader.usParID = XCOM_PAR_SYS_OSVERSION;
        m_iXComSendDataFrame.PAR_SYS_OSVERSION_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_IMU_MISALIGN_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_IMU_MISALIGN);
        m_iXComSendDataFrame.PAR_IMU_MISALIGN_SendFrame.tParHeader.usParID = XCOM_PAR_IMU_MISALIGN;
        m_iXComSendDataFrame.PAR_IMU_MISALIGN_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_GNSS_ANTOFFSET_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_GNSS_ANTOFFSET);
        m_iXComSendDataFrame.PAR_GNSS_ANTOFFSET_SendFrame.tParHeader.usParID = XCOM_PAR_GNSS_ANTOFFSET;
        m_iXComSendDataFrame.PAR_GNSS_ANTOFFSET_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_GNSS_RTCMV3AIDING_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_GNSS_RTCMV3AIDING);
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3AIDING_SendFrame.tParHeader.usParID = XCOM_PAR_GNSS_RTCMV3AIDING;
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3AIDING_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_GNSS_DUALANTMODE_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_GNSS_DUALANTMODE);
        m_iXComSendDataFrame.PAR_GNSS_DUALANTMODE_SendFrame.tParHeader.usParID = XCOM_PAR_GNSS_DUALANTMODE;
        m_iXComSendDataFrame.PAR_GNSS_DUALANTMODE_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_GNSS_RTCMV3CONFIG_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_GNSS_RTCMV3CONFIG);
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3CONFIG_SendFrame.tParHeader.usParID = XCOM_PAR_GNSS_RTCMV3CONFIG;
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3CONFIG_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_ALIGNMODE_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_ALIGNMODE);
        m_iXComSendDataFrame.PAR_EKF_ALIGNMODE_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_ALIGNMODE;
        m_iXComSendDataFrame.PAR_EKF_ALIGNMODE_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_ALIGNTIME_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_ALIGNTIME);
        m_iXComSendDataFrame.PAR_EKF_ALIGNTIME_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_ALIGNTIME;
        m_iXComSendDataFrame.PAR_EKF_ALIGNTIME_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_COARSETIME_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_COARSETIME);
        m_iXComSendDataFrame.PAR_EKF_COARSETIME_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_COARSETIME;
        m_iXComSendDataFrame.PAR_EKF_COARSETIME_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_VMP_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_VMP);
        m_iXComSendDataFrame.PAR_EKF_VMP_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_VMP;
        m_iXComSendDataFrame.PAR_EKF_VMP_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_STARTUP_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_STARTUP);
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_STARTUP;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_HDGPOSTHR_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_HDGPOSTHR);
        m_iXComSendDataFrame.PAR_EKF_HDGPOSTHR_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_HDGPOSTHR;
        m_iXComSendDataFrame.PAR_EKF_HDGPOSTHR_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_SMOOTH_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_SMOOTH);
        m_iXComSendDataFrame.PAR_EKF_SMOOTH_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_SMOOTH;
        m_iXComSendDataFrame.PAR_EKF_SMOOTH_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_ZUPTHR_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_ZUPTHR);
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_ZUPTHR;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_DUALANTAID_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_DUALANTAID);
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_DUALANTAID;
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_EKF_STARTUPV2_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_EKF_STARTUPV2);
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.tParHeader.usParID = XCOM_PAR_EKF_STARTUPV2;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_DAT_POS_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_DAT_POS);
        m_iXComSendDataFrame.PAR_DAT_POS_SendFrame.tParHeader.usParID = XCOM_PAR_DAT_POS;
        m_iXComSendDataFrame.PAR_DAT_POS_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_DAT_VEL_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_DAT_VEL);
        m_iXComSendDataFrame.PAR_DAT_VEL_SendFrame.tParHeader.usParID = XCOM_PAR_DAT_VEL;
        m_iXComSendDataFrame.PAR_DAT_VEL_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_DAT_IMU_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_DAT_IMU);
        m_iXComSendDataFrame.PAR_DAT_IMU_SendFrame.tParHeader.usParID = XCOM_PAR_DAT_IMU;
        m_iXComSendDataFrame.PAR_DAT_IMU_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_XCOM_NTRIP_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_XCOM_NTRIP);
        m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.tParHeader.usParID = XCOM_PAR_XCOM_NTRIP;
        m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_XCOM_UDPCONFIG_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_XCOM_UDPCONFIG);
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.tParHeader.usParID = XCOM_PAR_XCOM_UDPCONFIG;
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_FPGA_MCP23S08_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_FPGA_MCP23S08);
        m_iXComSendDataFrame.PAR_FPGA_MCP23S08_SendFrame.tParHeader.usParID = XCOM_PAR_FPGA_MCP23S08;
        m_iXComSendDataFrame.PAR_FPGA_MCP23S08_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_ARINC825_PORT_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_ARINC825_PORT);
        m_iXComSendDataFrame.PAR_ARINC825_PORT_SendFrame.tParHeader.usParID = XCOM_PAR_ARINC825_PORT;
        m_iXComSendDataFrame.PAR_ARINC825_PORT_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_ARINC825_BAUD_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_ARINC825_BAUD);
        m_iXComSendDataFrame.PAR_ARINC825_BAUD_SendFrame.tParHeader.usParID = XCOM_PAR_ARINC825_BAUD;
        m_iXComSendDataFrame.PAR_ARINC825_BAUD_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_ARINC825_ENABLE_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_ARINC825_ENABLE);
        m_iXComSendDataFrame.PAR_ARINC825_ENABLE_SendFrame.tParHeader.usParID = XCOM_PAR_ARINC825_ENABLE;
        m_iXComSendDataFrame.PAR_ARINC825_ENABLE_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_ARINC825_FRAMELIST_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_ARINC825_FRAMELIST);
        m_iXComSendDataFrame.PAR_ARINC825_FRAMELIST_SendFrame.tParHeader.usParID = XCOM_PAR_ARINC825_FRAMELIST;
        m_iXComSendDataFrame.PAR_ARINC825_FRAMELIST_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else if (PAR_ARINC825_BUSRECOVERY_SendData == sendData)
    {
        header->ucMsgID = XCOM_MSGID_PARAMETER;
        header->ucReserved = 0U;
        header->usMsgLen = sizeof(t_XCOM_PAR_ARINC825_BUSRECOVERY);
        m_iXComSendDataFrame.PAR_ARINC825_BUSRECOVERY_SendFrame.tParHeader.usParID = XCOM_PAR_ARINC825_BUSRECOVERY;
        m_iXComSendDataFrame.PAR_ARINC825_BUSRECOVERY_SendFrame.tParHeader.ucAction = changeParameter ? 0U : 1U;
    }
    else
    {
        return sendFrame;
    }

    *reinterpret_cast<uint16_t *> ((void *) (((char *) (&m_iXComSendDataFrame)) + header->usMsgLen - sizeof(uint16_t))) = Crc16((uint8_t *) &m_iXComSendDataFrame, header->usMsgLen - sizeof(uint16_t));

    sendFrame.pData = (uint8_t *) &m_iXComSendDataFrame;
    sendFrame.dataSizeByte = header->usMsgLen;
    return sendFrame;
}

iXComHandler::iXComReceiveDataReady iXComHandler::readReceivedXComByte(const char byte)
{
    t_XCOM_HeaderParser const *header = NULL;
    if (readReceivedByte(byte, &header) < 0)
    {
        m_iXComReceiveData.pData = NULL;
        return FRAMEERROR;
    }

    if (header)
    {
        m_iXComReceiveData.pData = (void *) &m_receiveMsgData;
        if (XCOM_MSGID_RESPONSE == header->ucMsgID)
        {
            return RESPONSE_Ready;
        }
        else if (XCOM_MSGID_MSG_IMURAW == header->ucMsgID)
        {
            return MSG_IMURAW_Ready;
        }
        else if (XCOM_MSGID_MSG_IMUCORR == header->ucMsgID)
        {
            return MSG_IMUCORR_Ready;
        }
        else if (XCOM_MSGID_MSG_IMUCOMP == header->ucMsgID)
        {
            return MSG_IMUCOMP_Ready;
        }
        else if (XCOM_MSGID_MSG_INSSOL == header->ucMsgID)
        {
            return MSG_INSSOL_Ready;
        }
        else if (XCOM_MSGID_MSG_INSRPY == header->ucMsgID)
        {
            return MSG_INSRPY_Ready;
        }
        else if (XCOM_MSGID_MSG_INSDCM == header->ucMsgID)
        {
            return MSG_INSDCM_Ready;
        }
        else if (XCOM_MSGID_MSG_INSQUAT == header->ucMsgID)
        {
            return MSG_INSQUAT_Ready;
        }
        else if (XCOM_MSGID_MSG_INSVELBODY == header->ucMsgID)
        {
            return MSG_INSVELBODY_Ready;
        }
        else if (XCOM_MSGID_MSG_INSPOSLLH == header->ucMsgID)
        {
            return MSG_INSPOSLLH_Ready;
        }
        else if (XCOM_MSGID_MSG_INSPOSECEF == header->ucMsgID)
        {
            return MSG_INSPOSECEF_Ready;
        }
        else if (XCOM_MSGID_MSG_INSPOSUTM == header->ucMsgID)
        {
            return MSG_INSPOSUTM_Ready;
        }
        else if (XCOM_MSGID_MSG_EKFSENSORERR == header->ucMsgID)
        {
            return MSG_EKFSENSORERR_Ready;
        }
        else if (XCOM_MSGID_MSG_EKFSENSORERR2 == header->ucMsgID)
        {
            return MSG_EKFSENSORERR2_Ready;
        }
        else if (XCOM_MSGID_MSG_EKFSTDDEV2 == header->ucMsgID)
        {
            return MSG_EKFSTDDEV2_Ready;
        }
        else if (XCOM_MSGID_MSG_GNSSSOL == header->ucMsgID)
        {
            return MSG_GNSSSOL_Ready;
        }
        else if (XCOM_MSGID_MSG_GNSSTIME == header->ucMsgID)
        {
            return MSG_GNSSTIME_Ready;
        }
        else if (XCOM_MSGID_MSG_GNSSHDG == header->ucMsgID)
        {
            return MSG_GNSSHDG_Ready;
        }
        else if (XCOM_MSGID_MSG_GNSSLEVERARM == header->ucMsgID)
        {
            return MSG_GNSSLEVERARM_Ready;
        }
        else if (XCOM_MSGID_MSG_WHEELDATA == header->ucMsgID)
        {
            return MSG_WHEELDATA_Ready;
        }
        else if (XCOM_MSGID_MSG_SYS_STAT == header->ucMsgID)
        {
            return MSG_SYS_STAT_Ready;
        }
        else if (XCOM_MSGID_MSG_STATFPGA == header->ucMsgID)
        {
            return MSG_STATFPGA_Ready;
        }
        else if (XCOM_MSGID_MSG_SYS_TEMP == header->ucMsgID)
        {
            return MSG_SYS_TEMP_Ready;
        }
        else if (XCOM_MSGID_MSG_IMUCAL == header->ucMsgID)
        {
            return MSG_IMUCAL_Ready;
        }
        else if (XCOM_MSGID_MSG_POSTPROC == header->ucMsgID)
        {
            return MSG_POSTPROC_Ready;
        }
        else if (XCOM_MSGID_MSG_EVENTTIME == header->ucMsgID)
        {
            return MSG_EVENTTIME_Ready;
        }
        else if (XCOM_MSGID_PARAMETER == header->ucMsgID)
        {
            if (XCOM_PAR_SYS_PRJNUM == m_iXComReceiveData.PAR_SYS_PRJNUM->tParHeader.usParID)
            {
                return PAR_SYS_PRJNUM_Ready;
            }
            else if (XCOM_PAR_SYS_PARTNUM == m_iXComReceiveData.PAR_SYS_PARTNUM->tParHeader.usParID)
            {
                return PAR_SYS_PARTNUM_Ready;
            }
            else if (XCOM_PAR_SYS_SERIALNUM == m_iXComReceiveData.PAR_SYS_SERIALNUM->tParHeader.usParID)
            {
                return PAR_SYS_SERIALNUM_Ready;
            }
            else if (XCOM_PAR_SYS_MFG == m_iXComReceiveData.PAR_SYS_MFG->tParHeader.usParID)
            {
                return PAR_SYS_MFG_Ready;
            }
            else if (XCOM_PAR_SYS_CALDATE == m_iXComReceiveData.PAR_SYS_CALDATE->tParHeader.usParID)
            {
                return PAR_SYS_CALDATE_Ready;
            }
            else if (XCOM_PAR_SYS_FWVERSION == m_iXComReceiveData.PAR_SYS_FWVERSION->tParHeader.usParID)
            {
                return PAR_SYS_FWVERSION_Ready;
            }
            else if (XCOM_PAR_SYS_NAVLIB == m_iXComReceiveData.PAR_SYS_NAVLIB->tParHeader.usParID)
            {
                return PAR_SYS_NAVLIB_Ready;
            }
            else if (XCOM_PAR_SYS_EKFLIB == m_iXComReceiveData.PAR_SYS_EKFLIB->tParHeader.usParID)
            {
                return PAR_SYS_EKFLIB_Ready;
            }
            else if (XCOM_PAR_SYS_EKFPARSET == m_iXComReceiveData.PAR_SYS_EKFPARSET->tParHeader.usParID)
            {
                return PAR_SYS_EKFPARSET_Ready;
            }
            else if (XCOM_PAR_SYS_NAVNUM == m_iXComReceiveData.PAR_SYS_NAVNUM->tParHeader.usParID)
            {
                return PAR_SYS_NAVNUM_Ready;
            }
            else if (XCOM_PAR_SYS_NAVPARSET == m_iXComReceiveData.PAR_SYS_NAVPARSET->tParHeader.usParID)
            {
                return PAR_SYS_NAVPARSET_Ready;
            }
            else if (XCOM_PAR_SYS_MAINTIMING == m_iXComReceiveData.PAR_SYS_MAINTIMING->tParHeader.usParID)
            {
                return PAR_SYS_MAINTIMING_Ready;
            }
            else if (XCOM_PAR_SYS_PRESCALER == m_iXComReceiveData.PAR_SYS_PRESCALER->tParHeader.usParID)
            {
                return PAR_SYS_PRESCALER_Ready;
            }
            else if (XCOM_PAR_SYS_UPTIME == m_iXComReceiveData.PAR_SYS_UPTIME->tParHeader.usParID)
            {
                return PAR_SYS_UPTIME_Ready;
            }
            else if (XCOM_PAR_SYS_OPHOURCNT == m_iXComReceiveData.PAR_SYS_OPHOURCNT->tParHeader.usParID)
            {
                return PAR_SYS_OPHOURCNT_Ready;
            }
            else if (XCOM_PAR_SYS_BOOTMODE == m_iXComReceiveData.PAR_SYS_BOOTMODE->tParHeader.usParID)
            {
                return PAR_SYS_BOOTMODE_Ready;
            }
            else if (XCOM_PAR_SYS_FPGAVER == m_iXComReceiveData.PAR_SYS_FPGAVER->tParHeader.usParID)
            {
                return PAR_SYS_FPGAVER_Ready;
            }
            else if (XCOM_PAR_SYS_CONFIGCRC == m_iXComReceiveData.PAR_SYS_CONFIGCRC->tParHeader.usParID)
            {
                return PAR_SYS_CONFIGCRC_Ready;
            }
            else if (XCOM_PAR_SYS_OSVERSION == m_iXComReceiveData.PAR_SYS_OSVERSION->tParHeader.usParID)
            {
                return PAR_SYS_OSVERSION_Ready;
            }
            else if (XCOM_PAR_IMU_MISALIGN == m_iXComReceiveData.PAR_IMU_MISALIGN->tParHeader.usParID)
            {
                return PAR_IMU_MISALIGN_Ready;
            }
            else if (XCOM_PAR_GNSS_ANTOFFSET == m_iXComReceiveData.PAR_GNSS_ANTOFFSET->tParHeader.usParID)
            {
                return PAR_GNSS_ANTOFFSET_Ready;
            }
            else if (XCOM_PAR_GNSS_RTCMV3AIDING == m_iXComReceiveData.PAR_GNSS_RTCMV3AIDING->tParHeader.usParID)
            {
                return PAR_GNSS_RTCMV3AIDING_Ready;
            }
            else if (XCOM_PAR_GNSS_DUALANTMODE == m_iXComReceiveData.PAR_GNSS_DUALANTMODE->tParHeader.usParID)
            {
                return PAR_GNSS_DUALANTMODE_Ready;
            }
            else if (XCOM_PAR_GNSS_RTCMV3CONFIG == m_iXComReceiveData.PAR_GNSS_RTCMV3CONFIG->tParHeader.usParID)
            {
                return PAR_GNSS_RTCMV3CONFIG_Ready;
            }
            else if (XCOM_PAR_EKF_ALIGNMODE == m_iXComReceiveData.PAR_EKF_ALIGNMODE->tParHeader.usParID)
            {
                return PAR_EKF_ALIGNMODE_Ready;
            }
            else if (XCOM_PAR_EKF_ALIGNTIME == m_iXComReceiveData.PAR_EKF_ALIGNTIME->tParHeader.usParID)
            {
                return PAR_EKF_ALIGNTIME_Ready;
            }
            else if (XCOM_PAR_EKF_COARSETIME == m_iXComReceiveData.PAR_EKF_COARSETIME->tParHeader.usParID)
            {
                return PAR_EKF_COARSETIME_Ready;
            }
            else if (XCOM_PAR_EKF_VMP == m_iXComReceiveData.PAR_EKF_VMP->tParHeader.usParID)
            {
                return PAR_EKF_VMP_Ready;
            }
            else if (XCOM_PAR_EKF_STARTUP == m_iXComReceiveData.PAR_EKF_STARTUP->tParHeader.usParID)
            {
                return PAR_EKF_STARTUP_Ready;
            }
            else if (XCOM_PAR_EKF_HDGPOSTHR == m_iXComReceiveData.PAR_EKF_HDGPOSTHR->tParHeader.usParID)
            {
                return PAR_EKF_HDGPOSTHR_Ready;
            }
            else if (XCOM_PAR_EKF_SMOOTH == m_iXComReceiveData.PAR_EKF_SMOOTH->tParHeader.usParID)
            {
                return PAR_EKF_SMOOTH_Ready;
            }
            else if (XCOM_PAR_EKF_ZUPTHR == m_iXComReceiveData.PAR_EKF_ZUPTHR->tParHeader.usParID)
            {
                return PAR_EKF_ZUPTHR_Ready;
            }
            else if (XCOM_PAR_EKF_DUALANTAID == m_iXComReceiveData.PAR_EKF_DUALANTAID->tParHeader.usParID)
            {
                return PAR_EKF_DUALANTAID_Ready;
            }
            else if (XCOM_PAR_EKF_STARTUPV2 == m_iXComReceiveData.PAR_EKF_STARTUPV2->tParHeader.usParID)
            {
                return PAR_EKF_STARTUPV2_Ready;
            }
            else if (XCOM_PAR_DAT_POS == m_iXComReceiveData.PAR_DAT_POS->tParHeader.usParID)
            {
                return PAR_DAT_POS_Ready;
            }
            else if (XCOM_PAR_DAT_VEL == m_iXComReceiveData.PAR_DAT_VEL->tParHeader.usParID)
            {
                return PAR_DAT_VEL_Ready;
            }
            else if (XCOM_PAR_DAT_IMU == m_iXComReceiveData.PAR_DAT_IMU->tParHeader.usParID)
            {
                return PAR_DAT_IMU_Ready;
            }
            else if (XCOM_PAR_XCOM_NTRIP == m_iXComReceiveData.PAR_XCOM_NTRIP->tParHeader.usParID)
            {
                return PAR_XCOM_NTRIP_Ready;
            }
            else if (XCOM_PAR_XCOM_UDPCONFIG == m_iXComReceiveData.PAR_XCOM_UDPCONFIG->tParHeader.usParID)
            {
                return PAR_XCOM_UDPCONFIG_Ready;
            }
            else if (XCOM_PAR_FPGA_MCP23S08 == m_iXComReceiveData.PAR_FPGA_MCP23S08->tParHeader.usParID)
            {
                return PAR_FPGA_MCP23S08_Ready;
            }
            else if (XCOM_PAR_ARINC825_PORT == m_iXComReceiveData.PAR_ARINC825_PORT->tParHeader.usParID)
            {
                return PAR_ARINC825_PORT_Ready;
            }
            else if (XCOM_PAR_ARINC825_BAUD == m_iXComReceiveData.PAR_ARINC825_BAUD->tParHeader.usParID)
            {
                return PAR_ARINC825_BAUD_Ready;
            }
            else if (XCOM_PAR_ARINC825_ENABLE == m_iXComReceiveData.PAR_ARINC825_ENABLE->tParHeader.usParID)
            {
                return PAR_ARINC825_ENABLE_Ready;
            }
            else if (XCOM_PAR_ARINC825_FRAMELIST == m_iXComReceiveData.PAR_ARINC825_FRAMELIST->tParHeader.usParID)
            {
                return PAR_ARINC825_FRAMELIST_Ready;
            }
            else if (XCOM_PAR_ARINC825_BUSRECOVERY == m_iXComReceiveData.PAR_ARINC825_BUSRECOVERY->tParHeader.usParID)
            {
                return PAR_ARINC825_BUSRECOVERY_Ready;
            }
        }
    }
    m_iXComReceiveData.pData = NULL;
    return FRAMENOTCOMPLETE;
}

iXComHandler::iXComSendDataFrame *iXComHandler::getIXComSendDataFrame()
{
    return &m_iXComSendDataFrame;
}

iXComHandler::iXComReceiveData const *iXComHandler::getIXComReceivedData()
{
    return &m_iXComReceiveData;
}

void iXComHandler::initSendFrameZeros()
{
    memset((void *) &m_iXComSendDataFrame, 0U, sizeof(iXComSendDataFrame));
}

void iXComHandler::initSendFrame(iXComReceiveData initFrame, uint16_t initFrameSize)
{
    uint16_t copiedBytes;
    if ((initFrame.pData) && (initFrameSize > 0U))
    {
        copiedBytes = initFrameSize < sizeof(iXComSendDataFrame) ? initFrameSize : sizeof(iXComSendDataFrame);
        memcpy((void *) &m_iXComSendDataFrame, (void *) initFrame.pData, copiedBytes);
    }
    else
    {
        copiedBytes = 0U;
    }
    memset((void *) ((char *) &m_iXComSendDataFrame + copiedBytes), 0U, sizeof(iXComSendDataFrame) - copiedBytes);
}

iXComHandler::iXComSendFrame iXComHandler::completeIXComSendFrameWithFrameSize(iXComSendData sendData, uint16_t frameSize, bool changeParameter)
{
    iXComSendFrame sendFrame = completeIXComSendFrame(sendData, changeParameter);

    t_XCOM_Header * const header = (t_XCOM_Header *) sendFrame.pData;

    header->usMsgLen = frameSize;

    *reinterpret_cast<uint16_t *> ((void *) (((char *) (&m_iXComSendDataFrame)) + header->usMsgLen - sizeof(uint16_t))) = Crc16((uint8_t *) &m_iXComSendDataFrame, header->usMsgLen - sizeof(uint16_t));

    sendFrame.dataSizeByte = header->usMsgLen;
    return sendFrame;
}
