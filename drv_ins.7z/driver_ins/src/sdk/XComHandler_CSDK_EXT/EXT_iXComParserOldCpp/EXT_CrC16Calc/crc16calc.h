#ifndef CRC16CALC_H
#define CRC16CALC_H

#include <stdint.h>

class CrC16Calc
{
public:
    CrC16Calc();
    ~CrC16Calc();

protected:
    uint16_t Crc16(const unsigned char *pByte, unsigned int Size);

private:
    static unsigned short CrcByte(unsigned short const Crc, unsigned char const Byte);
};

#endif // CRC16CALC_H
