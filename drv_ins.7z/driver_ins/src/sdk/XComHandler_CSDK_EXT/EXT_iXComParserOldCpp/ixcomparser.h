#ifndef IXCOMPARSER_H
#define IXCOMPARSER_H

#include <stdint.h>
#include <stddef.h>
#include "EXT_CrC16Calc/crc16calc.h"

#ifdef _WIN32
#define XCOM_STRUCTATTRIBUTES
#pragma pack(push)
#pragma pack(1)
#else
#define XCOM_STRUCTATTRIBUTES __attribute__ ((__packed__))
#endif

#ifndef MAXXCOMDATABYTES
#define MAXXCOMDATABYTES 512//4096
#endif

#define ERRBIT_IXCOMPARSER_SYNCEXPECTED 0x01
#define ERRBIT_IXCOMPARSER_BUFFERLIMIT 0x02
#define ERRBIT_IXCOMPARSER_CRC 0x03

class iXComParser : protected CrC16Calc
{
public:
    iXComParser();
    ~iXComParser();

protected:
    typedef struct XCOM_STRUCTATTRIBUTES
    {
        // Header
        uint8_t 	ucSync;
        uint8_t 	ucMsgID;
        uint8_t		ucFrameCnt;
        uint8_t 	ucReserved;
        uint16_t	usMsgLen;
        uint16_t	usGpsWeek;
        uint32_t	uiGpsTime_sec;
        uint32_t	uiGpsTime_usec;
    } t_XCOM_HeaderParser;

private:
    uint16_t m_msgByteCount;
    uint16_t m_msgSize;
    bool m_expectNewMsg;

protected:
    uint8_t m_receiveMsgData[MAXXCOMDATABYTES];
    bool m_skipCrcCheck;
    uint8_t m_errByte;
    uint8_t *m_pErrByte;

protected:
    int8_t readReceivedByte(const char byte, const t_XCOM_HeaderParser **headerOut);

public:
    void setErrAddr(uint8_t *errByteAddr);
};

#ifdef _WIN32
#pragma pack(pop)
#endif


#endif // IXCOMPARSER_H
