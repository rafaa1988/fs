#ifndef IXCOMHANDLER_H
#define IXCOMHANDLER_H

#include "ixcomparser.h"
#include "XCOMtypes.h"
#include <string.h>

class iXComHandler : iXComParser
{
public:
    iXComHandler();
    ~iXComHandler();

    struct iXComSendFrame
    {
        uint8_t *pData;
        uint16_t dataSizeByte;
    };

    enum iXComSendData
    {
        CMD_XCOM_SendData = 0,
        CMD_LOG_SendData,
        CMD_CONF_SendData,
        CMD_EKF_SendData,
        CMD_EXTAID_SendData,
        PAR_SYS_PRJNUM_SendData,
        PAR_SYS_PARTNUM_SendData,
        PAR_SYS_SERIALNUM_SendData,
        PAR_SYS_MFG_SendData,
        PAR_SYS_CALDATE_SendData,
        PAR_SYS_FWVERSION_SendData,
        PAR_SYS_NAVLIB_SendData,
        PAR_SYS_EKFLIB_SendData,
        PAR_SYS_EKFPARSET_SendData,
        PAR_SYS_NAVNUM_SendData,
        PAR_SYS_NAVPARSET_SendData,
        PAR_SYS_MAINTIMING_SendData,
        PAR_SYS_PRESCALER_SendData,
        PAR_SYS_UPTIME_SendData,
        PAR_SYS_OPHOURCNT_SendData,
        PAR_SYS_BOOTMODE_SendData,
        PAR_SYS_FPGAVER_SendData,
        PAR_SYS_CONFIGCRC_SendData,
        PAR_SYS_OSVERSION_SendData,
        PAR_IMU_MISALIGN_SendData,
        PAR_GNSS_ANTOFFSET_SendData,
        PAR_GNSS_RTCMV3AIDING_SendData,
        PAR_GNSS_DUALANTMODE_SendData,
        PAR_GNSS_RTCMV3CONFIG_SendData,
        PAR_EKF_ALIGNMODE_SendData,
        PAR_EKF_ALIGNTIME_SendData,
        PAR_EKF_COARSETIME_SendData,
        PAR_EKF_VMP_SendData,
        PAR_EKF_STARTUP_SendData,
        PAR_EKF_HDGPOSTHR_SendData,
        PAR_EKF_SMOOTH_SendData,
        PAR_EKF_ZUPTHR_SendData,
        PAR_EKF_DUALANTAID_SendData,
        PAR_EKF_STARTUPV2_SendData,
        PAR_DAT_POS_SendData,
        PAR_DAT_VEL_SendData,
        PAR_DAT_IMU_SendData,
        PAR_XCOM_NTRIP_SendData,
        PAR_XCOM_UDPCONFIG_SendData,
        PAR_FPGA_MCP23S08_SendData,
        PAR_ARINC825_PORT_SendData,
        PAR_ARINC825_BAUD_SendData,
        PAR_ARINC825_ENABLE_SendData,
        PAR_ARINC825_FRAMELIST_SendData,
        PAR_ARINC825_BUSRECOVERY_SendData,
    };

    enum iXComReceiveDataReady
    {
        FRAMEERROR = -1,
        FRAMENOTCOMPLETE,
        RESPONSE_Ready,
        MSG_IMURAW_Ready,
        MSG_IMUCORR_Ready,
        MSG_IMUCOMP_Ready,
        MSG_INSSOL_Ready,
        MSG_INSRPY_Ready,
        MSG_INSDCM_Ready,
        MSG_INSQUAT_Ready,
        MSG_INSVELBODY_Ready,
        MSG_INSPOSLLH_Ready,
        MSG_INSPOSECEF_Ready,
        MSG_INSPOSUTM_Ready,
        MSG_EKFSENSORERR_Ready,
        MSG_EKFSENSORERR2_Ready,
        MSG_EKFSTDDEV2_Ready,
        MSG_GNSSSOL_Ready,
        MSG_GNSSTIME_Ready,
        MSG_GNSSHDG_Ready,
        MSG_GNSSLEVERARM_Ready,
        MSG_WHEELDATA_Ready,
        MSG_SYS_STAT_Ready,
        MSG_STATFPGA_Ready,
        MSG_SYS_TEMP_Ready,
        MSG_IMUCAL_Ready,
        MSG_POSTPROC_Ready,
        MSG_EVENTTIME_Ready,
        PAR_SYS_PRJNUM_Ready,
        PAR_SYS_PARTNUM_Ready,
        PAR_SYS_SERIALNUM_Ready,
        PAR_SYS_MFG_Ready,
        PAR_SYS_CALDATE_Ready,
        PAR_SYS_FWVERSION_Ready,
        PAR_SYS_NAVLIB_Ready,
        PAR_SYS_EKFLIB_Ready,
        PAR_SYS_EKFPARSET_Ready,
        PAR_SYS_NAVNUM_Ready,
        PAR_SYS_NAVPARSET_Ready,
        PAR_SYS_MAINTIMING_Ready,
        PAR_SYS_PRESCALER_Ready,
        PAR_SYS_UPTIME_Ready,
        PAR_SYS_OPHOURCNT_Ready,
        PAR_SYS_BOOTMODE_Ready,
        PAR_SYS_FPGAVER_Ready,
        PAR_SYS_CONFIGCRC_Ready,
        PAR_SYS_OSVERSION_Ready,
        PAR_IMU_MISALIGN_Ready,
        PAR_GNSS_ANTOFFSET_Ready,
        PAR_GNSS_RTCMV3AIDING_Ready,
        PAR_GNSS_DUALANTMODE_Ready,
        PAR_GNSS_RTCMV3CONFIG_Ready,
        PAR_EKF_ALIGNMODE_Ready,
        PAR_EKF_ALIGNTIME_Ready,
        PAR_EKF_COARSETIME_Ready,
        PAR_EKF_VMP_Ready,
        PAR_EKF_STARTUP_Ready,
        PAR_EKF_HDGPOSTHR_Ready,
        PAR_EKF_SMOOTH_Ready,
        PAR_EKF_ZUPTHR_Ready,
        PAR_EKF_DUALANTAID_Ready,
        PAR_EKF_STARTUPV2_Ready,
        PAR_DAT_POS_Ready,
        PAR_DAT_VEL_Ready,
        PAR_DAT_IMU_Ready,
        PAR_XCOM_NTRIP_Ready,
        PAR_XCOM_UDPCONFIG_Ready,
        PAR_FPGA_MCP23S08_Ready,
        PAR_ARINC825_PORT_Ready,
        PAR_ARINC825_BAUD_Ready,
        PAR_ARINC825_ENABLE_Ready,
        PAR_ARINC825_FRAMELIST_Ready,
        PAR_ARINC825_BUSRECOVERY_Ready,
    };

    union iXComSendDataFrame
    {
        t_XCOM_XCOMCMD_XCOM CMD_XCOM_SendFrame;
        t_XCOM_XCOMCMD_LOG CMD_LOG_SendFrame;
        t_XCOM_XCOMCMD_CONF CMD_CONF_SendFrame;
        t_XCOM_XCOMCMD_EKF CMD_EKF_SendFrame;
        t_XCOM_XCOMCMD_EXTAID CMD_EXTAID_SendFrame;
        t_XCOM_PAR_SYS_PRJNUM PAR_SYS_PRJNUM_SendFrame;
        t_XCOM_PAR_SYS_PARTNUM PAR_SYS_PARTNUM_SendFrame;
        t_XCOM_PAR_SYS_SERIALNUM PAR_SYS_SERIALNUM_SendFrame;
        t_XCOM_PAR_SYS_MFG PAR_SYS_MFG_SendFrame;
        t_XCOM_PAR_SYS_CALDATE PAR_SYS_CALDATE_SendFrame;
        t_XCOM_PAR_SYS_FWVERSION PAR_SYS_FWVERSION_SendFrame;
        t_XCOM_PAR_SYS_NAVLIB PAR_SYS_NAVLIB_SendFrame;
        t_XCOM_PAR_SYS_EKFLIB PAR_SYS_EKFLIB_SendFrame;
        t_XCOM_PAR_SYS_EKFPARSET PAR_SYS_EKFPARSET_SendFrame;
        t_XCOM_PAR_SYS_NAVNUM PAR_SYS_NAVNUM_SendFrame;
        t_XCOM_PAR_SYS_NAVPARSET PAR_SYS_NAVPARSET_SendFrame;
        t_XCOM_PAR_SYS_MAINTIMING PAR_SYS_MAINTIMING_SendFrame;
        t_XCOM_PAR_SYS_PRESCALER PAR_SYS_PRESCALER_SendFrame;
        t_XCOM_PAR_SYS_UPTIME PAR_SYS_UPTIME_SendFrame;
        t_XCOM_PAR_SYS_OPHOURCNT PAR_SYS_OPHOURCNT_SendFrame;
        t_XCOM_PAR_SYS_BOOTMODE PAR_SYS_BOOTMODE_SendFrame;
        t_XCOM_PAR_SYS_FPGAVER PAR_SYS_FPGAVER_SendFrame;
        t_XCOM_PAR_SYS_CONFIGCRC PAR_SYS_CONFIGCRC_SendFrame;
        t_XCOM_PAR_SYS_OSVERSION PAR_SYS_OSVERSION_SendFrame;
        t_XCOM_PAR_IMU_MISALIGN PAR_IMU_MISALIGN_SendFrame;
        t_XCOM_PAR_GNSS_ANTOFFSET PAR_GNSS_ANTOFFSET_SendFrame;
        t_XCOM_PAR_GNSS_RTCMV3AIDING PAR_GNSS_RTCMV3AIDING_SendFrame;
        t_XCOM_PAR_GNSS_DUALANTMODE PAR_GNSS_DUALANTMODE_SendFrame;
        t_XCOM_PAR_GNSS_RTCMV3CONFIG PAR_GNSS_RTCMV3CONFIG_SendFrame;
        t_XCOM_PAR_EKF_ALIGNMODE PAR_EKF_ALIGNMODE_SendFrame;
        t_XCOM_PAR_EKF_ALIGNTIME PAR_EKF_ALIGNTIME_SendFrame;
        t_XCOM_PAR_EKF_COARSETIME PAR_EKF_COARSETIME_SendFrame;
        t_XCOM_PAR_EKF_VMP PAR_EKF_VMP_SendFrame;
        t_XCOM_PAR_EKF_STARTUP PAR_EKF_STARTUP_SendFrame;
        t_XCOM_PAR_EKF_HDGPOSTHR PAR_EKF_HDGPOSTHR_SendFrame;
        t_XCOM_PAR_EKF_SMOOTH PAR_EKF_SMOOTH_SendFrame;
        t_XCOM_PAR_EKF_ZUPTHR PAR_EKF_ZUPTHR_SendFrame;
        t_XCOM_PAR_EKF_DUALANTAID PAR_EKF_DUALANTAID_SendFrame;
        t_XCOM_PAR_EKF_STARTUPV2 PAR_EKF_STARTUPV2_SendFrame;
        t_XCOM_PAR_DAT_POS PAR_DAT_POS_SendFrame;
        t_XCOM_PAR_DAT_VEL PAR_DAT_VEL_SendFrame;
        t_XCOM_PAR_DAT_IMU PAR_DAT_IMU_SendFrame;
        t_XCOM_PAR_XCOM_NTRIP PAR_XCOM_NTRIP_SendFrame;
        t_XCOM_PAR_XCOM_UDPCONFIG PAR_XCOM_UDPCONFIG_SendFrame;
        t_XCOM_PAR_FPGA_MCP23S08 PAR_FPGA_MCP23S08_SendFrame;
        t_XCOM_PAR_ARINC825_PORT PAR_ARINC825_PORT_SendFrame;
        t_XCOM_PAR_ARINC825_BAUD PAR_ARINC825_BAUD_SendFrame;
        t_XCOM_PAR_ARINC825_ENABLE PAR_ARINC825_ENABLE_SendFrame;
        t_XCOM_PAR_ARINC825_FRAMELIST PAR_ARINC825_FRAMELIST_SendFrame;
        t_XCOM_PAR_ARINC825_BUSRECOVERY PAR_ARINC825_BUSRECOVERY_SendFrame;
    };

    union iXComReceiveData
    {
        t_XCOM_XCOM_RESPONSE *RESPONSE;
        t_XCOM_MSG_IMURAW *MSG_IMURAW;
        t_XCOM_MSG_IMUCORR *MSG_IMUCORR;
        t_XCOM_MSG_IMUCOMP *MSG_IMUCOMP;
        t_XCOM_MSG_INSSOL *MSG_INSSOL;
        t_XCOM_MSG_INSRPY *MSG_INSRPY;
        t_XCOM_MSG_INSDCM *MSG_INSDCM;
        t_XCOM_MSG_INSQUAT *MSG_INSQUAT;
        t_XCOM_MSG_INSVELBODY *MSG_INSVELBODY;
        t_XCOM_MSG_INSPOSLLH *MSG_INSPOSLLH;
        t_XCOM_MSG_INSPOSECEF *MSG_INSPOSECEF;
        t_XCOM_MSG_INSPOSUTM *MSG_INSPOSUTM;
        t_XCOM_MSG_EKFSENSORERR *MSG_EKFSENSORERR;
        t_XCOM_MSG_EKFSENSORERR2 *MSG_EKFSENSORERR2;
        t_XCOM_MSG_EKFSTDDEV2 *MSG_EKFSTDDEV2;
        t_XCOM_MSG_GNSSSOL *MSG_GNSSSOL;
        t_XCOM_MSG_GNSSTIME *MSG_GNSSTIME;
        t_XCOM_MSG_GNSSHDG *MSG_GNSSHDG;
        t_XCOM_MSG_GNSSLEVERARM *MSG_GNSSLEVERARM;
        t_XCOM_MSG_WHEELDATA *MSG_WHEELDATA;
        t_XCOM_MSG_SYS_STAT *MSG_SYS_STAT;
        t_XCOM_MSG_STATFPGA *MSG_STATFPGA;
        t_XCOM_MSG_SYS_TEMP *MSG_SYS_TEMP;
        t_XCOM_MSG_IMUCAL *MSG_IMUCAL;
        t_XCOM_MSG_POSTPROC *MSG_POSTPROC;
        t_XCOM_MSG_EVENTTIME *MSG_EVENTTIME;
        t_XCOM_PAR_SYS_PRJNUM *PAR_SYS_PRJNUM;
        t_XCOM_PAR_SYS_PARTNUM *PAR_SYS_PARTNUM;
        t_XCOM_PAR_SYS_SERIALNUM *PAR_SYS_SERIALNUM;
        t_XCOM_PAR_SYS_MFG *PAR_SYS_MFG;
        t_XCOM_PAR_SYS_CALDATE *PAR_SYS_CALDATE;
        t_XCOM_PAR_SYS_FWVERSION *PAR_SYS_FWVERSION;
        t_XCOM_PAR_SYS_NAVLIB *PAR_SYS_NAVLIB;
        t_XCOM_PAR_SYS_EKFLIB *PAR_SYS_EKFLIB;
        t_XCOM_PAR_SYS_EKFPARSET *PAR_SYS_EKFPARSET;
        t_XCOM_PAR_SYS_NAVNUM *PAR_SYS_NAVNUM;
        t_XCOM_PAR_SYS_NAVPARSET *PAR_SYS_NAVPARSET;
        t_XCOM_PAR_SYS_MAINTIMING *PAR_SYS_MAINTIMING;
        t_XCOM_PAR_SYS_PRESCALER *PAR_SYS_PRESCALER;
        t_XCOM_PAR_SYS_UPTIME *PAR_SYS_UPTIME;
        t_XCOM_PAR_SYS_OPHOURCNT *PAR_SYS_OPHOURCNT;
        t_XCOM_PAR_SYS_BOOTMODE *PAR_SYS_BOOTMODE;
        t_XCOM_PAR_SYS_FPGAVER *PAR_SYS_FPGAVER;
        t_XCOM_PAR_SYS_CONFIGCRC *PAR_SYS_CONFIGCRC;
        t_XCOM_PAR_SYS_OSVERSION *PAR_SYS_OSVERSION;
        t_XCOM_PAR_IMU_MISALIGN *PAR_IMU_MISALIGN;
        t_XCOM_PAR_GNSS_ANTOFFSET *PAR_GNSS_ANTOFFSET;
        t_XCOM_PAR_GNSS_RTCMV3AIDING *PAR_GNSS_RTCMV3AIDING;
        t_XCOM_PAR_GNSS_DUALANTMODE *PAR_GNSS_DUALANTMODE;
        t_XCOM_PAR_GNSS_RTCMV3CONFIG *PAR_GNSS_RTCMV3CONFIG;
        t_XCOM_PAR_EKF_ALIGNMODE *PAR_EKF_ALIGNMODE;
        t_XCOM_PAR_EKF_ALIGNTIME *PAR_EKF_ALIGNTIME;
        t_XCOM_PAR_EKF_COARSETIME *PAR_EKF_COARSETIME;
        t_XCOM_PAR_EKF_VMP *PAR_EKF_VMP;
        t_XCOM_PAR_EKF_STARTUP *PAR_EKF_STARTUP;
        t_XCOM_PAR_EKF_HDGPOSTHR *PAR_EKF_HDGPOSTHR;
        t_XCOM_PAR_EKF_SMOOTH *PAR_EKF_SMOOTH;
        t_XCOM_PAR_EKF_ZUPTHR *PAR_EKF_ZUPTHR;
        t_XCOM_PAR_EKF_DUALANTAID *PAR_EKF_DUALANTAID;
        t_XCOM_PAR_EKF_STARTUPV2 *PAR_EKF_STARTUPV2;
        t_XCOM_PAR_DAT_POS *PAR_DAT_POS;
        t_XCOM_PAR_DAT_VEL *PAR_DAT_VEL;
        t_XCOM_PAR_DAT_IMU *PAR_DAT_IMU;
        t_XCOM_PAR_XCOM_NTRIP *PAR_XCOM_NTRIP;
        t_XCOM_PAR_XCOM_UDPCONFIG *PAR_XCOM_UDPCONFIG;
        t_XCOM_PAR_FPGA_MCP23S08 *PAR_FPGA_MCP23S08;
        t_XCOM_PAR_ARINC825_PORT *PAR_ARINC825_PORT;
        t_XCOM_PAR_ARINC825_BAUD *PAR_ARINC825_BAUD;
        t_XCOM_PAR_ARINC825_ENABLE *PAR_ARINC825_ENABLE;
        t_XCOM_PAR_ARINC825_FRAMELIST *PAR_ARINC825_FRAMELIST;
        t_XCOM_PAR_ARINC825_BUSRECOVERY *PAR_ARINC825_BUSRECOVERY;
        void *pData;
    };

private:
    iXComSendDataFrame m_iXComSendDataFrame;
    uint8_t m_sendFrameCounter;
    iXComReceiveData m_iXComReceiveData;

public:
    void initSendFrame(iXComReceiveData initFrame, uint16_t intFrameSize);
    void initSendFrameZeros();
    iXComSendDataFrame *getIXComSendDataFrame();
    iXComSendFrame completeIXComSendFrame(iXComSendData sendData, bool changeParameter = false);
    iXComSendFrame completeIXComSendFrameWithFrameSize(iXComSendData sendData, uint16_t frameSize, bool changeParameter = false);

    iXComReceiveDataReady readReceivedXComByte(const char byte);
    iXComReceiveData const *getIXComReceivedData();

    iXComSendFrame getSendFrame_CMD_XCOM(uint16_t State, uint16_t Channel)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.CMD_XCOM_SendFrame.usState = State;
        m_iXComSendDataFrame.CMD_XCOM_SendFrame.usChannel = Channel;
        return completeIXComSendFrame(iXComSendData::CMD_XCOM_SendData);
    }

    iXComSendFrame getSendFrame_CMD_LOG(uint8_t msgID, uint16_t par, uint8_t trigger, uint16_t divider)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.CMD_LOG_SendFrame.ucMsgID = msgID;
        m_iXComSendDataFrame.CMD_LOG_SendFrame.usPAR = par;
        m_iXComSendDataFrame.CMD_LOG_SendFrame.ucTrigger = trigger;
        m_iXComSendDataFrame.CMD_LOG_SendFrame.usDivider = divider;
        return completeIXComSendFrame(iXComSendData::CMD_LOG_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_PRJNUM(char ProjectNumber[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_PRJNUM_SendFrame.cProjectNumber, ProjectNumber, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PRJNUM_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_PRJNUM()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PRJNUM_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_PARTNUM(char Partnumber[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_PARTNUM_SendFrame.cPartnumber, Partnumber, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PARTNUM_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_PARTNUM()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PARTNUM_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_SERIALNUM(char SerialNumber[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_SERIALNUM_SendFrame.cSerialNumber, SerialNumber, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_SERIALNUM_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_SERIALNUM()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_SERIALNUM_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_MFG(char ManufacturingDate[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_MFG_SendFrame.cManufacturingDate, ManufacturingDate, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_MFG_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_MFG()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_MFG_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_CALDATE(uint16_t Password, char CalibrationDate[32])
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_CALDATE_SendFrame.usPassword = Password;
        memcpy(m_iXComSendDataFrame.PAR_SYS_CALDATE_SendFrame.cCalibrationDate, CalibrationDate, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_CALDATE_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_CALDATE()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_CALDATE_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_FWVERSION(char FirmwareVersion[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_FWVERSION_SendFrame.cFirmwareVersion, FirmwareVersion, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_FWVERSION_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_FWVERSION()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_FWVERSION_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_NAVLIB(char NavLibVersion[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_NAVLIB_SendFrame.cNavLibVersion, NavLibVersion, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVLIB_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_NAVLIB()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVLIB_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_EKFLIB(char EKFversion[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_EKFLIB_SendFrame.cEKFversion, EKFversion, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_EKFLIB_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_EKFLIB()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_EKFLIB_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_EKFPARSET(char EKFParameterSet[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_EKFPARSET_SendFrame.cEKFParameterSet, EKFParameterSet, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_EKFPARSET_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_EKFPARSET()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_EKFPARSET_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_NAVNUM(char NavigatorVersion[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_NAVNUM_SendFrame.cNavigatorVersion, NavigatorVersion, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVNUM_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_NAVNUM()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVNUM_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_NAVPARSET(char NavigatorParSet[32])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_NAVPARSET_SendFrame.cNavigatorParSet, NavigatorParSet, 32 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVPARSET_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_NAVPARSET()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_NAVPARSET_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_MAINTIMING(uint16_t Maintiming, uint16_t Password)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_MAINTIMING_SendFrame.usMaintiming = Maintiming;
        m_iXComSendDataFrame.PAR_SYS_MAINTIMING_SendFrame.usPassword = Password;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_MAINTIMING_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_MAINTIMING()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_MAINTIMING_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_PRESCALER(uint16_t Prescaler, uint16_t Password)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_PRESCALER_SendFrame.usPrescaler = Prescaler;
        m_iXComSendDataFrame.PAR_SYS_PRESCALER_SendFrame.usPassword = Password;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PRESCALER_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_PRESCALER()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_PRESCALER_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_UPTIME(float Uptime)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_UPTIME_SendFrame.fUptime = Uptime;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_UPTIME_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_UPTIME()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_UPTIME_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_OPHOURCNT(uint32_t OperationalHourCounter)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_OPHOURCNT_SendFrame.uiOperationalHourCounter = OperationalHourCounter;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_OPHOURCNT_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_OPHOURCNT()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_OPHOURCNT_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_BOOTMODE(uint32_t Bootmode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_BOOTMODE_SendFrame.uiBootmode = Bootmode;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_BOOTMODE_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_BOOTMODE()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_BOOTMODE_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_FPGAVER(uint8_t Major, uint8_t Minor)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_FPGAVER_SendFrame.ucMajor = Major;
        m_iXComSendDataFrame.PAR_SYS_FPGAVER_SendFrame.ucMinor = Minor;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_FPGAVER_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_FPGAVER()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_FPGAVER_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_CONFIGCRC(uint16_t ROMCRC, uint16_t RAMCRC)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_SYS_CONFIGCRC_SendFrame.usROMCRC = ROMCRC;
        m_iXComSendDataFrame.PAR_SYS_CONFIGCRC_SendFrame.usRAMCRC = RAMCRC;
        return completeIXComSendFrame(iXComSendData::PAR_SYS_CONFIGCRC_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_CONFIGCRC()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_CONFIGCRC_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_SYS_OSVERSION(char OSversion[64])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_SYS_OSVERSION_SendFrame.cOSversion, OSversion, 64 * sizeof(char));
        return completeIXComSendFrame(iXComSendData::PAR_SYS_OSVERSION_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_SYS_OSVERSION()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_SYS_OSVERSION_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_IMU_MISALIGN(float rotx, float roty, float rotz)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_IMU_MISALIGN_SendFrame.frotx = rotx;
        m_iXComSendDataFrame.PAR_IMU_MISALIGN_SendFrame.froty = roty;
        m_iXComSendDataFrame.PAR_IMU_MISALIGN_SendFrame.frotz = rotz;
        return completeIXComSendFrame(iXComSendData::PAR_IMU_MISALIGN_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_IMU_MISALIGN()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_IMU_MISALIGN_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_GNSS_ANTOFFSET(float LeverArm[3], float StdDev[3])
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_GNSS_ANTOFFSET_SendFrame.fLeverArm, LeverArm, 3 * sizeof(float));
        memcpy(m_iXComSendDataFrame.PAR_GNSS_ANTOFFSET_SendFrame.fStdDev, StdDev, 3 * sizeof(float));
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_ANTOFFSET_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_GNSS_ANTOFFSET()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_ANTOFFSET_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_GNSS_RTCMV3AIDING(char Payload)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3AIDING_SendFrame.cPayload = Payload;
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_RTCMV3AIDING_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_GNSS_RTCMV3AIDING()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_RTCMV3AIDING_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_GNSS_DUALANTMODE(uint32_t Mode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_GNSS_DUALANTMODE_SendFrame.uiMode = Mode;
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_DUALANTMODE_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_GNSS_DUALANTMODE()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_DUALANTMODE_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_GNSS_RTCMV3CONFIG(uint8_t Enable)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_GNSS_RTCMV3CONFIG_SendFrame.ucEnable = Enable;
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_RTCMV3CONFIG_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_GNSS_RTCMV3CONFIG()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_GNSS_RTCMV3CONFIG_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_ALIGNMODE(uint32_t AlignMode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_ALIGNMODE_SendFrame.uiAlignMode = AlignMode;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ALIGNMODE_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_ALIGNMODE()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ALIGNMODE_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_ALIGNTIME(uint32_t AlignTime)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_ALIGNTIME_SendFrame.uiAlignTime = AlignTime;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ALIGNTIME_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_ALIGNTIME()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ALIGNTIME_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_COARSETIME(uint32_t CoarseTime)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_COARSETIME_SendFrame.uiCoarseTime = CoarseTime;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_COARSETIME_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_COARSETIME()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_COARSETIME_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_VMP(float Distance[3], uint16_t Mask, uint16_t CutOff)
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_EKF_VMP_SendFrame.fDistance, Distance, 3 * sizeof(float));
        m_iXComSendDataFrame.PAR_EKF_VMP_SendFrame.usMask = Mask;
        m_iXComSendDataFrame.PAR_EKF_VMP_SendFrame.usCutOff = CutOff;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_VMP_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_VMP()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_VMP_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_STARTUP(double InitPosLon, double InitPosLat, float InitPosAlt, float StdDevInitPos[3], float InitHdg, float StdDevInitHdg, uint8_t PosMode, uint8_t HdgMode, uint16_t GnssTimeout, uint8_t ReAlign, uint8_t InMotion, uint8_t AutoRestart)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.dInitPosLon = InitPosLon;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.dInitPosLat = InitPosLat;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.fInitPosAlt = InitPosAlt;
        memcpy(m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.fStdDevInitPos, StdDevInitPos, 3 * sizeof(float));
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.fInitHdg = InitHdg;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.fStdDevInitHdg = StdDevInitHdg;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.ucPosMode = PosMode;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.ucHdgMode = HdgMode;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.usGnssTimeout = GnssTimeout;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.ucReAlign = ReAlign;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.ucInMotion = InMotion;
        m_iXComSendDataFrame.PAR_EKF_STARTUP_SendFrame.ucAutoRestart = AutoRestart;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_STARTUP_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_STARTUP()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_STARTUP_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_HDGPOSTHR(float ThrHDG, float ThrPosMed, float ThrPosHigh)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_HDGPOSTHR_SendFrame.fThrHDG = ThrHDG;
        m_iXComSendDataFrame.PAR_EKF_HDGPOSTHR_SendFrame.fThrPosMed = ThrPosMed;
        m_iXComSendDataFrame.PAR_EKF_HDGPOSTHR_SendFrame.fThrPosHigh = ThrPosHigh;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_HDGPOSTHR_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_HDGPOSTHR()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_HDGPOSTHR_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_SMOOTH(uint32_t Smooth)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_SMOOTH_SendFrame.uiSmooth = Smooth;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_SMOOTH_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_SMOOTH()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_SMOOTH_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_ZUPTHR(double AccThr, double OmgThr, double VelThr, float CutOffFreq, float ZuptRate, float MinStdDevZUPT, float WeightingFact, float TimeConst, uint16_t Delay, uint8_t Mask, uint8_t AutoZUPT)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.dAccThr = AccThr;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.dOmgThr = OmgThr;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.dVelThr = VelThr;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.fCutOffFreq = CutOffFreq;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.fZuptRate = ZuptRate;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.fMinStdDevZUPT = MinStdDevZUPT;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.fWeightingFact = WeightingFact;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.fTimeConst = TimeConst;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.usDelay = Delay;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.ucMask = Mask;
        m_iXComSendDataFrame.PAR_EKF_ZUPTHR_SendFrame.ucAutoZUPT = AutoZUPT;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ZUPTHR_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_ZUPTHR()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_ZUPTHR_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_DUALANTAID(float HdgStdDevThr, float PitchStdDevThr, float INSYawStdDevThr, uint32_t Mode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.fHdgStdDevThr = HdgStdDevThr;
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.fPitchStdDevThr = PitchStdDevThr;
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.fINSYawStdDevThr = INSYawStdDevThr;
        m_iXComSendDataFrame.PAR_EKF_DUALANTAID_SendFrame.uiMode = Mode;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_DUALANTAID_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_DUALANTAID()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_DUALANTAID_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_EKF_STARTUPV2(double InitPosLon, double InitPosLat, float InitPosAlt, float StdDevInitPos[3], float InitHdg, float StdDevInitHdg, float LeverArm[3], float LeverArmStdDev[3], uint8_t PosMode, uint8_t HdgMode, uint16_t GnssTimeout, uint8_t EnableAltMSL, uint8_t ReAlign, uint8_t InMotion, uint8_t AutoRestart)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.dInitPosLon = InitPosLon;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.dInitPosLat = InitPosLat;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fInitPosAlt = InitPosAlt;
        memcpy(m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fStdDevInitPos, StdDevInitPos, 3 * sizeof(float));
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fInitHdg = InitHdg;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fStdDevInitHdg = StdDevInitHdg;
        memcpy(m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fLeverArm, LeverArm, 3 * sizeof(float));
        memcpy(m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.fLeverArmStdDev, LeverArmStdDev, 3 * sizeof(float));
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucPosMode = PosMode;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucHdgMode = HdgMode;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.usGnssTimeout = GnssTimeout;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucEnableAltMSL = EnableAltMSL;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucReAlign = ReAlign;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucInMotion = InMotion;
        m_iXComSendDataFrame.PAR_EKF_STARTUPV2_SendFrame.ucAutoRestart = AutoRestart;
        return completeIXComSendFrame(iXComSendData::PAR_EKF_STARTUPV2_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_EKF_STARTUPV2()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_EKF_STARTUPV2_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_DAT_POS(uint16_t PositionOutputMode, uint16_t AltitudeOutputMode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_DAT_POS_SendFrame.usPositionOutputMode = PositionOutputMode;
        m_iXComSendDataFrame.PAR_DAT_POS_SendFrame.usAltitudeOutputMode = AltitudeOutputMode;
        return completeIXComSendFrame(iXComSendData::PAR_DAT_POS_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_DAT_POS()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_DAT_POS_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_DAT_VEL(uint32_t Velocityoutputmode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_DAT_VEL_SendFrame.uiVelocityoutputmode = Velocityoutputmode;
        return completeIXComSendFrame(iXComSendData::PAR_DAT_VEL_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_DAT_VEL()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_DAT_VEL_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_DAT_IMU(uint32_t InertialOutputMode)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_DAT_IMU_SendFrame.uiInertialOutputMode = InertialOutputMode;
        return completeIXComSendFrame(iXComSendData::PAR_DAT_IMU_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_DAT_IMU()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_DAT_IMU_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_XCOM_NTRIP(char Stream[128], char User[128], char Password[128], char Server[128], uint8_t SendPositionOnLogin, uint8_t Enable, uint16_t RemotePort)
    {
        initSendFrameZeros();
        memcpy(m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.cStream, Stream, 128 * sizeof(char));
        memcpy(m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.cUser, User, 128 * sizeof(char));
        memcpy(m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.cPassword, Password, 128 * sizeof(char));
        memcpy(m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.cServer, Server, 128 * sizeof(char));
        m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.ucSendPositionOnLogin = SendPositionOnLogin;
        m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.ucEnable = Enable;
        m_iXComSendDataFrame.PAR_XCOM_NTRIP_SendFrame.usRemotePort = RemotePort;
        return completeIXComSendFrame(iXComSendData::PAR_XCOM_NTRIP_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_XCOM_NTRIP()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_XCOM_NTRIP_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_XCOM_UDPCONFIG(uint32_t ServerAddress, uint32_t Port, uint8_t Enable, uint8_t Channel, uint8_t EnableABD)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.uiServerAddress = ServerAddress;
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.uiPort = Port;
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.ucEnable = Enable;
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.ucChannel = Channel;
        m_iXComSendDataFrame.PAR_XCOM_UDPCONFIG_SendFrame.ucEnableABD = EnableABD;
        return completeIXComSendFrame(iXComSendData::PAR_XCOM_UDPCONFIG_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_XCOM_UDPCONFIG()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_XCOM_UDPCONFIG_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_FPGA_MCP23S08(uint8_t GPIOreg, uint8_t Res[3])
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_FPGA_MCP23S08_SendFrame.ucGPIOreg = GPIOreg;
        memcpy(m_iXComSendDataFrame.PAR_FPGA_MCP23S08_SendFrame.ucRes, Res, 3 * sizeof(uint8_t));
        return completeIXComSendFrame(iXComSendData::PAR_FPGA_MCP23S08_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_FPGA_MCP23S08()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_FPGA_MCP23S08_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_ARINC825_PORT(uint32_t Port)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_ARINC825_PORT_SendFrame.uiPort = Port;
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_PORT_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_ARINC825_PORT()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_PORT_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_ARINC825_BAUD(uint32_t Baud)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_ARINC825_BAUD_SendFrame.uiBaud = Baud;
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_BAUD_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_ARINC825_BAUD()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_BAUD_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_ARINC825_ENABLE(uint16_t TxEnable)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_ARINC825_ENABLE_SendFrame.usTxEnable = TxEnable;
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_ENABLE_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_ARINC825_ENABLE()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_ENABLE_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_ARINC825_FRAMELIST(char ParArinc825FrameList)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_ARINC825_FRAMELIST_SendFrame.cParArinc825FrameList = ParArinc825FrameList;
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_FRAMELIST_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_ARINC825_FRAMELIST()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_FRAMELIST_SendData);
    }

    iXComSendFrame getSendFrameChange_PAR_ARINC825_BUSRECOVERY(uint16_t BusRecovery)
    {
        initSendFrameZeros();
        m_iXComSendDataFrame.PAR_ARINC825_BUSRECOVERY_SendFrame.usBusRecovery = BusRecovery;
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_BUSRECOVERY_SendData, true);
    }

    iXComSendFrame getSendFrameRead_PAR_ARINC825_BUSRECOVERY()
    {
        initSendFrameZeros();
        return completeIXComSendFrame(iXComSendData::PAR_ARINC825_BUSRECOVERY_SendData);
    }
};

#endif // IXCOMHANDLER_H

