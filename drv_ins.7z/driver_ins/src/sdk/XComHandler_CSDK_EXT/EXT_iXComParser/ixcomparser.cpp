#include "ixcomparser.h"

iXComParser::iXComParser() : CrC16Calc()
{

}

iXComParser::~iXComParser()
{

}

int8_t iXComParser::readReceivedByte(const char byte, t_XCOM_HeaderParser const **headerOut)
{   
    if (m_expectNewMsg && (0x7E == byte))
    {
        m_msgByteCount = 0;
        m_msgSize = 0;
        m_expectNewMsg = false;
    }
    else if (m_expectNewMsg)
    {
        *headerOut = NULL;
        *m_pErrByte |= ERRBIT_IXCOMPARSER_SYNCEXPECTED;
        return -1;
    }
    else
    {
        m_msgByteCount++;
    }

    if (m_msgByteCount < MAXXCOMDATABYTES)
    {
        m_receiveMsgData[m_msgByteCount] = byte;
    }
    else
    {
        m_expectNewMsg = true;
        *headerOut = NULL;
        *m_pErrByte |= ERRBIT_IXCOMPARSER_BUFFERLIMIT;
        return -1;
    }

    t_XCOM_HeaderParser *header = NULL;
    if (m_msgByteCount < sizeof(t_XCOM_HeaderParser) - 1)
    {
        *headerOut = NULL;
        return 0;
    }
    else if (0 == m_msgSize)
    {
        header = (t_XCOM_HeaderParser *) &m_receiveMsgData;
        m_msgSize = header->usMsgLen;
        *headerOut = NULL;
        return 0;
    }
    else if (m_msgByteCount < m_msgSize - 1)
    {
        *headerOut = NULL;
        return 0;
    }
    else
    {
        header = (t_XCOM_HeaderParser *) &m_receiveMsgData;
        m_expectNewMsg = true;

        if (m_skipCrcCheck)
        {
            *headerOut = (t_XCOM_HeaderParser *) &m_receiveMsgData;
            return 0;
        }

        uint16_t const crcVal = Crc16((const unsigned char *)&m_receiveMsgData, header->usMsgLen - sizeof(uint16_t));
        uint16_t const *crcValMsg = (uint16_t *) &m_receiveMsgData[header->usMsgLen - sizeof(uint16_t)];

        if (crcVal == *crcValMsg)
        {
            *headerOut = (t_XCOM_HeaderParser *) &m_receiveMsgData;
            return 0;
        }
        else
        {
            *headerOut = NULL;
            *m_pErrByte |= ERRBIT_IXCOMPARSER_CRC;
            return -1;
        }
    }
}

void iXComParser::setErrAddr(uint8_t *errByteAddr)
{
    if (errByteAddr)
    {
        m_pErrByte = errByteAddr;
    }
}
