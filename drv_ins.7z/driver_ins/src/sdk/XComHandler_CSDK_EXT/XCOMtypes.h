#ifndef XCOMTYPES_H
#define XCOMTYPES_H

// XCOMtypes.h for CSDK

#include <stdint.h>

#ifdef _WIN32
#define XCOM_STRUCTATTRIBUTES
#pragma pack(push)
#pragma pack(1)
#else
#define XCOM_STRUCTATTRIBUTES __attribute__ ((__packed__))
#endif

#ifndef MAXXCOMDATABYTES
#define MAXXCOMDATABYTES 4096
#endif
#define MAXXCOMDATA4BYTES (MAXXCOMDATABYTES / 4U)
#define MAXXCOMDATA8BYTES (MAXXCOMDATABYTES / 8U)

/* Message IDs */
#define XCOM_MSGID_MSG_IMURAW 0x00
#define XCOM_MSGID_MSG_IMUCORR 0x01
#define XCOM_MSGID_MSG_IMUCOMP 0x02
#define XCOM_MSGID_MSG_INSSOL 0x03
#define XCOM_MSGID_MSG_INSRPY 0x04
#define XCOM_MSGID_MSG_INSDCM 0x05
#define XCOM_MSGID_MSG_INSQUAT 0x06
#define XCOM_MSGID_MSG_INSVELBODY 0x09
#define XCOM_MSGID_MSG_INSPOSLLH 0x0A
#define XCOM_MSGID_MSG_INSPOSECEF 0x0B
#define XCOM_MSGID_MSG_INSPOSUTM 0x0C
#define XCOM_MSGID_MSG_EKFSENSORERR 0x10
#define XCOM_MSGID_MSG_EKFSENSORERR2 0x27
#define XCOM_MSGID_MSG_EKFSTDDEV2 0x28
#define XCOM_MSGID_MSG_GNSSSOL 0x12
#define XCOM_MSGID_MSG_GNSSTIME 0x14
#define XCOM_MSGID_MSG_GNSSHDG 0x33
#define XCOM_MSGID_MSG_GNSSLEVERARM 0x1B
#define XCOM_MSGID_MSG_WHEELDATA 0x16
#define XCOM_MSGID_MSG_SYS_STAT 0x19
#define XCOM_MSGID_MSG_STATFPGA 0x20
#define XCOM_MSGID_MSG_SYS_TEMP 0x22
#define XCOM_MSGID_MSG_IMUCAL 0x31
#define XCOM_MSGID_MSG_POSTPROC 0x40
#define XCOM_MSGID_MSG_EVENTTIME 0x34

#define XCOM_MSGID_COMMAND 0xFD
#define XCOM_MSGID_RESPONSE 0xFE
#define XCOM_MSGID_PARAMETER 0xFF

/* XCOM COMMAND IDs */
#define XCOMCMD_LOG 0x0000
#define XCOMCMD_CONF 0x0003
#define XCOMCMD_EKF 0x0004
#define XCOMCMD_XCOM 0x0005
#define XCOMCMD_EXTAID 0x0007

#define XCOM_CMD_XCOM_CLOSE 0U
#define XCOM_CMD_XCOM_OPEN 1U
#define XCOM_CMD_XCOM_COLDRESET 2U
#define XCOM_CMD_XCOM_WARMRESET 3U
#define XCOM_CMD_XCOM_RESETOMGINT 4U
#define XCOM_CMD_XCOM_RESETTIMEBIAS 6U

// defines for the global status in each message
#define XCOM_GSTATUSBIT_HARDWAREERR 0x0001
#define XCOM_GSTATUSBIT_COMMERR 0x0002
#define XCOM_GSTATUSBIT_NAVERR 0x0004
#define XCOM_GSTATUSBIT_CALERR 0x0008
#define XCOM_GSTATUSBIT_GYROVERR 0x0010
#define XCOM_GSTATUSBIT_ACCOVERR 0x0020
#define XCOM_GSTATUSBIT_GNSSINVALID 0x0040
#define XCOM_GSTATUSBIT_STANDBY 0x0080
#define XCOM_GSTATUSBIT_DYNAMICALIGN 0x0100
#define XCOM_GSTATUSBIT_TIMEINVALID 0x0200
#define XCOM_GSTATUSBIT_NAVMODE 0x0400
#define XCOM_GSTATUSBIT_RESERVED 0x0800
#define XCOM_GSTATUSBIT_ALIGNSTATUS 0x3000
#define XCOM_GSTATUSBIT_POSACCURACY 0xC000
#define XCOM_GSTATUSGET_ALIGNSTATUS(gStatus) ((gStatus & XCOM_GSTATUSBIT_ALIGNSTATUS) >> 12)
#define XCOM_GSTATUSGET_POSACCURACY(gStatus) ((gStatus & XCOM_GSTATUSBIT_POSACCURACY) >> 14)

/* XCOM LOG COMMAND */
#define XCOMLOG_ACTION_ADD      0x0000
#define XCOMLOG_ACTION_STOP     0x0001
#define XCOMLOG_ACTION_START    0x0002
#define XCOMLOG_ACTION_CLEAR    0x0003
#define XCOMLOG_ACTION_CLEARALL	0x0004
#define XCOMLOG_ACTION_STOPALL  0x0005
#define XCOMLOG_ACTION_STARTALL 0x0006

#define XCOMLOG_TRIGGER_SYNC    0x00
#define XCOMLOG_TRIGGER_EVENT   0x01
#define XCOMLOG_TRIGGER_POLLED  0x02

/* XCOM CONF COMMAND */
#define XCOMCONF_SAVE    0
#define XCOMCONF_LOAD    1
#define XCOMCONF_FACTORY 2

/* XCOM EKF COMMAND */
#define XCOMEKF_ALIGN         0
#define XCOMEKF_SAVEPOS       1
#define XCOMEKF_SAVEHDG       2
#define XCOMEKF_SAVEANTOFFSET 3
#define XCOMEKF_ZUPT          4
#define XCOMEKF_ALIGNCOMPLETE 5
#define XCOMEKF_COPYODOSCF    6

/* XCOM EXTAID COMMAND */
#define XCOMEXTAID_FREEZE_ALT 0
#define XCOMEXTAID_FREEZE_HDG 1
#define XCOMEXTAID_FREEZE_VELBODY 2
#define XCOMEXTAID_POS        3
#define XCOMEXTAID_VEL        4
#define XCOMEXTAID_HDG        5
#define XCOMEXTAID_HGT        6

/* parameter numbers */
#define XCOM_PAR_SYS_PRJNUM 0
#define XCOM_PAR_SYS_PARTNUM 1
#define XCOM_PAR_SYS_SERIALNUM 2
#define XCOM_PAR_SYS_MFG 3
#define XCOM_PAR_SYS_CALDATE 4
#define XCOM_PAR_SYS_FWVERSION 5
#define XCOM_PAR_SYS_NAVLIB 6
#define XCOM_PAR_SYS_EKFLIB 7
#define XCOM_PAR_SYS_EKFPARSET 8
#define XCOM_PAR_SYS_NAVNUM 9
#define XCOM_PAR_SYS_NAVPARSET 10
#define XCOM_PAR_SYS_MAINTIMING 11
#define XCOM_PAR_SYS_PRESCALER 12
#define XCOM_PAR_SYS_UPTIME 13
#define XCOM_PAR_SYS_OPHOURCNT 14
#define XCOM_PAR_SYS_BOOTMODE 15
#define XCOM_PAR_SYS_FPGAVER 16
#define XCOM_PAR_SYS_CONFIGCRC 17
#define XCOM_PAR_SYS_OSVERSION 18
#define XCOM_PAR_IMU_MISALIGN 105
#define XCOM_PAR_GNSS_ANTOFFSET 204
#define XCOM_PAR_GNSS_RTCMV3AIDING 210
#define XCOM_PAR_GNSS_DUALANTMODE 211
#define XCOM_PAR_GNSS_RTCMV3CONFIG 213
#define XCOM_PAR_EKF_ALIGNMODE 700
#define XCOM_PAR_EKF_ALIGNTIME 701
#define XCOM_PAR_EKF_COARSETIME 702
#define XCOM_PAR_EKF_VMP 703
#define XCOM_PAR_EKF_STARTUP 707
#define XCOM_PAR_EKF_HDGPOSTHR 708
#define XCOM_PAR_EKF_SMOOTH 709
#define XCOM_PAR_EKF_ZUPTHR 712
#define XCOM_PAR_EKF_DUALANTAID 730
#define XCOM_PAR_EKF_STARTUPV2 731
#define XCOM_PAR_DAT_POS 800
#define XCOM_PAR_DAT_VEL 801
#define XCOM_PAR_DAT_IMU 802
#define XCOM_PAR_XCOM_NTRIP 907
#define XCOM_PAR_XCOM_UDPCONFIG 910
#define XCOM_PAR_FPGA_MCP23S08 1015
#define XCOM_PAR_ARINC825_PORT 1200
#define XCOM_PAR_ARINC825_BAUD 1201
#define XCOM_PAR_ARINC825_ENABLE 1202
#define XCOM_PAR_ARINC825_FRAMELIST 1204
#define XCOM_PAR_ARINC825_BUSRECOVERY 1205

typedef enum
{
    XCOMRESP_OK,
    XCOMRESP_INVALIDPAR,
    XCOMRESP_INVALIDCRC,
    XCOMRESP_INVALIDLOG,
    XCOMRESP_INVALIDRATE,
    XCOMRESP_INVALIDPORT,
    XCOMRESP_INVALIDCMD,
    XCOMRESP_INVALIDID,
    XCOMRESP_INVALIDCHANNEL,
    XCOMRESP_PAROUTOFRANGE,
    XCOMRESP_LOGEXISTS,
    XCOMRESP_INVALIDTRIGGER,
    XCOMRESP_INTERNALERROR
} t_eXCOM_XCOMRESPONSE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    uint8_t ucSync;
    uint8_t ucMsgID;
    uint8_t ucFrameCnt;
    uint8_t ucReserved;
    uint16_t usMsgLen;
    uint16_t usGpsWeek;
    uint32_t uiGpsTime_sec;
    uint32_t uiGpsTime_usec;
} t_XCOM_Header;

typedef struct XCOM_STRUCTATTRIBUTES
{
    uint16_t gStatus;
    uint16_t CRC16;
} t_XCOM_Bottom;

typedef struct XCOM_STRUCTATTRIBUTES
{
    uint16_t usCmdID;
    uint16_t usSpecific;
} t_XCOM_CmdHeader;

typedef struct XCOM_STRUCTATTRIBUTES
{
    uint16_t usParID;
    uint8_t ucReserved;
    uint8_t ucAction;
} t_XCOM_ParHeader;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    uint16_t RespID;
    uint16_t MsgSize;
    uint8_t errMsg[MAXXCOMDATABYTES - sizeof(t_XCOM_Header) - sizeof(t_XCOM_Bottom) - 2U * sizeof(uint16_t)];
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOM_RESPONSE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_CmdHeader tCmdHeader;
    uint8_t ucMsgID;
    uint8_t ucTrigger;
    uint16_t usPAR;
    uint16_t usDivider;
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOMCMD_LOG;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_CmdHeader tCmdHeader;
    uint32_t uiConfCmdPar;
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOMCMD_CONF;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_CmdHeader tCmdHeader;
    uint16_t usCommand;
    uint16_t usNumOfPar;
    float fPar[MAXXCOMDATA4BYTES - 8];
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOMCMD_EKF;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_CmdHeader tCmdHeader;
    uint16_t usState;
    uint16_t usChannel;
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOMCMD_XCOM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_CmdHeader tCmdHeader;
    double dTimeValue;
    uint16_t usTimeMode;
    uint16_t usCmdParID;
    union
    {
        double dParFreezeAlt[3];
        double dParFreezeHdg[3];
        double dParFreezeVelBody[7];
        struct XCOM_STRUCTATTRIBUTES
        {
            double dPar[12];
            uint32_t uiAltMS;
        } parExtAidPos;
        double dParExtAidVel[12];
        double dParExtAidHdg[2];
        double dParExtAidHgt[2];
    } cmdPar;
    t_XCOM_Bottom tBottom;
} t_XCOM_XCOMCMD_EXTAID;


typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint8_t ucPayload[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_CHAR32;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint8_t ucPayload[64];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_CHAR64;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usParUINT16;
    uint16_t usReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_UINT16;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiParUINT32;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_UINT32;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAcc[3];
    float fOmg[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_IMURAW;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAcc[3];
    float fOmg[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_IMUCORR;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAcc[3];
    float fOmg[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_IMUCOMP;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAcc[3];
    float fOmg[3];
    float fRPY[3];
    float fVel[3];
    double dPos[2];
    float fAlt;
    int16_t sUndulation;
    uint16_t usDATSEL;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSSOL;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fRPY[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSRPY;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fC11;
    float fC21;
    float fC31;
    float fC12;
    float fC22;
    float fC32;
    float fC13;
    float fC23;
    float fC33;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSDCM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fq[4];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSQUAT;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fVx;
    float fVy;
    float fVz;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSVELBODY;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    double dLongitude;
    double dLatitude;
    float fHeight;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSPOSLLH;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    double dECEF[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSPOSECEF;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    int32_t iUTMZone;
    double dUTMEasting;
    double dUTMNorthing;
    float fHeight;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_INSPOSUTM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fBiasAcc[3];
    float fBiasOmg[3];
    float fScfAcc[3];
    float fScfOmg[3];
    float fScfOdo;
    float fOdometerMisalignment[2];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_EKFSENSORERR;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fBiasAcc[3];
    float fBiasOmg[3];
    float fMaAcc[9];
    float fMaOmg[9];
    float fScfOdo;
    float fOdometerMisalignment[2];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_EKFSENSORERR2;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fPos[3];
    float fVel[3];
    float fRpy[3];
    float fBiasAcc[3];
    float fBiasOmg[3];
    float fMaAcc[9];
    float fMaOmg[9];
    float fScfOdo;
    float fMaOdo[2];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_EKFSTDDEV2;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    double dLongitude;
    double dLatitude;
    float fAltitude;
    float fUndulation;
    float fVned[3];
    float fStdDevLon;
    float fStdDevLat;
    float fStdDevAlt;
    float fStdDevVned[3];
    uint16_t usSolStatus;
    uint16_t usPosVelType;
    float fPDOP;
    uint8_t ucSatsUsed;
    uint8_t ucSatsTracked;
    uint16_t usStation;
    float fDiffAge;
    float fSolAge;
    uint32_t uiGNSSStatus;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_GNSSSOL;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    double dUTCoffset;
    double dOffset;
    uint32_t uiUTCyear;
    uint8_t ucUTCmonth;
    uint8_t ucUTCday;
    uint8_t ucUTChour;
    uint8_t ucUTCmin;
    uint32_t uiUTCms;
    uint32_t uiUTCstatus;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_GNSSTIME;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fHeading;
    float fHeadingStdDev;
    float fPitch;
    float fPitchStdDev;
    uint16_t usSolStatus;
    uint16_t usPosVelType;
    uint16_t usReserved;
    uint8_t ucSatsUsed;
    uint8_t ucSatsTracked;
    uint32_t uiGnssStatus;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_GNSSHDG;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fPrimaryAntennaOffset[3];
    float fPrimaryAntennaOffsetStdDev[3];
    float fSecondaryAntennaOffset[3];
    float fSecondaryAntennaOffsetStdDev[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_GNSSLEVERARM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fOdoSpeed;
    int32_t iOdoTicks;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_WHEELDATA;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    uint32_t uiMode;
    uint32_t uiSYSStatus;
    char c;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_SYS_STAT;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    uint16_t usMessageID;
    uint8_t ucReserved;
    uint8_t ucAction;
    uint32_t uiPowerStatusLow;
    uint32_t uiPowerStatusHigh;
    uint16_t usFPGAStatus;
    uint16_t usSupervisorStatus;
    uint8_t ucIMUStatus;
    uint8_t ucTemperatureStatus;
    uint16_t usReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_STATFPGA;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fTemp[16];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_SYS_TEMP;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAccLSB[3];
    float fOmgLSB[3];
    double dAccCal[3];
    double dOmgCal[3];
    double dAvgdurationIMU;
    double dQ_nb[4];
    double dPos[3];
    double dVel_ned[3];
    float fTemperature[16];
    uint32_t uiSysStat;
    uint32_t uiEkfStatLow;
    uint32_t uiEkfStatHi;
    uint32_t uiImuStat[6];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_IMUCAL;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    float fAcc[3];
    float fOmg[3];
    float fDeltaTheta[12];
    float fDeltaV[12];
    double dQ_nb[4];
    double dPos[3];
    double dVel_ned[3];
    uint32_t uiExtendedSystemStatus;
    uint32_t uiEKFStatusLow;
    uint32_t uiEKFStatusHigh;
    float fDataSpeed;
    int32_t iDataTicks;
    uint32_t uiDataInterval;
    uint32_t uiDataTrigEvent;
    uint32_t uiDataTrigNextEvent;
    char cvarPayload[100];
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_POSTPROC;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    double dEVENTTIME0;
    double dEVENTTIME1;
    t_XCOM_Bottom tBottom;
} t_XCOM_MSG_EVENTTIME;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cProjectNumber[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_PRJNUM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cPartnumber[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_PARTNUM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cSerialNumber[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_SERIALNUM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cManufacturingDate[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_MFG;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usPassword;
    uint16_t usReserved;
    char cCalibrationDate[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_CALDATE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cFirmwareVersion[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_FWVERSION;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cNavLibVersion[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_NAVLIB;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cEKFversion[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_EKFLIB;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cEKFParameterSet[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_EKFPARSET;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cNavigatorVersion[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_NAVNUM;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cNavigatorParSet[32];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_NAVPARSET;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usMaintiming;
    uint16_t usPassword;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_MAINTIMING;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usPrescaler;
    uint16_t usPassword;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_PRESCALER;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float fUptime;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_UPTIME;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiOperationalHourCounter;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_OPHOURCNT;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiBootmode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_BOOTMODE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint8_t ucMajor;
    uint8_t ucMinor;
    uint16_t usReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_FPGAVER;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usROMCRC;
    uint16_t usRAMCRC;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_CONFIGCRC;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cOSversion[64];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_SYS_OSVERSION;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float frotx;
    float froty;
    float frotz;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_IMU_MISALIGN;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float fLeverArm[3];
    float fStdDev[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_GNSS_ANTOFFSET;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cPayload;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_GNSS_RTCMV3AIDING;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiMode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_GNSS_DUALANTMODE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint8_t ucReserved;
    uint8_t ucEnable;
    uint16_t usReserved;
    uint32_t uiReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_GNSS_RTCMV3CONFIG;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiAlignMode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_ALIGNMODE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiAlignTime;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_ALIGNTIME;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiCoarseTime;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_COARSETIME;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float fDistance[3];
    uint16_t usMask;
    uint16_t usCutOff;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_VMP;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    double dInitPosLon;
    double dInitPosLat;
    float fInitPosAlt;
    float fStdDevInitPos[3];
    float fInitHdg;
    float fStdDevInitHdg;
    uint8_t ucPosMode;
    uint8_t ucHdgMode;
    uint16_t usGnssTimeout;
    uint8_t ucReserved;
    uint8_t ucReAlign;
    uint8_t ucInMotion;
    uint8_t ucAutoRestart;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_STARTUP;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float fThrHDG;
    float fThrPosMed;
    float fThrPosHigh;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_HDGPOSTHR;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiSmooth;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_SMOOTH;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    double dAccThr;
    double dOmgThr;
    double dVelThr;
    float fCutOffFreq;
    float fZuptRate;
    float fMinStdDevZUPT;
    float fWeightingFact;
    float fTimeConst;
    uint16_t usDelay;
    uint8_t ucMask;
    uint8_t ucAutoZUPT;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_ZUPTHR;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    float fHdgStdDevThr;
    float fPitchStdDevThr;
    float fINSYawStdDevThr;
    uint32_t uiMode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_DUALANTAID;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    double dInitPosLon;
    double dInitPosLat;
    float fInitPosAlt;
    float fStdDevInitPos[3];
    float fInitHdg;
    float fStdDevInitHdg;
    float fLeverArm[3];
    float fLeverArmStdDev[3];
    uint8_t ucPosMode;
    uint8_t ucHdgMode;
    uint16_t usGnssTimeout;
    uint8_t ucEnableAltMSL;
    uint8_t ucReAlign;
    uint8_t ucInMotion;
    uint8_t ucAutoRestart;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_EKF_STARTUPV2;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usPositionOutputMode;
    uint16_t usAltitudeOutputMode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_DAT_POS;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiVelocityoutputmode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_DAT_VEL;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiInertialOutputMode;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_DAT_IMU;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cStream[128];
    char cUser[128];
    char cPassword[128];
    char cServer[128];
    uint8_t ucSendPositionOnLogin;
    uint8_t ucEnable;
    uint16_t usRemotePort;
    uint32_t uiReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_NTRIP;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiServerAddress;
    uint32_t uiPort;
    uint8_t ucEnable;
    uint8_t ucChannel;
    uint8_t ucEnableABD;
    uint8_t ucReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_XCOM_UDPCONFIG;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint8_t ucGPIOreg;
    uint8_t ucRes[3];
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_FPGA_MCP23S08;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiPort;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_ARINC825_PORT;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint32_t uiBaud;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_ARINC825_BAUD;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usReserved;
    uint16_t usTxEnable;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_ARINC825_ENABLE;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    char cParArinc825FrameList;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_ARINC825_FRAMELIST;

typedef struct XCOM_STRUCTATTRIBUTES
{
    t_XCOM_Header tHeader;
    t_XCOM_ParHeader tParHeader;
    uint16_t usBusRecovery;
    uint16_t usReserved;
    t_XCOM_Bottom tBottom;
} t_XCOM_PAR_ARINC825_BUSRECOVERY;

#ifdef _WIN32
#pragma pack(pop)
#endif

#endif // XCOMTYPES_H
