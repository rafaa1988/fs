


#ifdef _WIN32
#pragma comment(lib, "ws2_32.lib")
#endif

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include "insClass.h"
#include <time.h>
#include <signal.h>
//#include <pthread.h>
#include <thread>
#include <mutex>
#include "iNATCom.h"
#include "csdk_welcome.h"


int main(int argc, char* argv[])
{

	int serialAvailable = 1;

	printWelcome();

	if(getParamsFromFile() == -1)
	{
		printf("%s", "read config file failed \n");

		if(argc != 13) {
//			printf("%s", "usage: iXCOM_CSDK iNAT-ip iNAT-port iNAT-broadcast-ip iNAT-udp-port pc-ip serial-port log-freqency \n");
			printf("%s", "usage: iXCOM_CSDK <param_1 param_2 ...> \n");
			printf("%s", "param list: \n"
					"     iXCOM_CSDK \n"
					"     iNAT-ip \n"
					"     iNAT-port \n"
					"     iNAT-broadcast-ip \n"
					"     iNAT-udp-port \n"
					"     pc-ip \n"
					"     serial-port \n"
					"     log-freqency \n"
					"     NTRIP-stream \n"
					"     NTRIP-server \n"
					"     NTRIP-remote-port \n"
					"     NTRIP-user \n"
					"     NTRIP-password \n");
			exit(EXIT_FAILURE);
		} else {

			memcpy(inputParams.iNAT_ip, argv[1], sizeof(inputParams.iNAT_ip));							// iNAT-IP-Address
			inputParams.iNAT_tcp_port = atoi(argv[2]);													// iNAT-TCP-Port
			memcpy(inputParams.iNAT_brdcst_addr, argv[3], sizeof(inputParams.iNAT_brdcst_addr));		// iNAT-Broadcast-Address
			inputParams.iNAT_udp_port = atoi(argv[4]);													// iNAT-UDP-Port
			memcpy(inputParams.pc_ip, argv[5], sizeof(inputParams.pc_ip));								// PC-IP-Address
#ifdef __linux
			memcpy(inputParams.serialPort, argv[6], sizeof(inputParams.serialPort));					// serial interface
#else
			inputParams.serialPort = atoi(argv[6]);
#endif
			inputParams.log_freq = atoi(argv[7]);
			memcpy(inputParams.NTRIP_stream, argv[8], sizeof(inputParams.NTRIP_stream));
			memcpy(inputParams.NTRIP_server, argv[9], sizeof(inputParams.NTRIP_server));
			inputParams.NTRIP_remote_port = atoi(argv[10]);
			memcpy(inputParams.NTRIP_user, argv[11], sizeof(inputParams.NTRIP_user));
			memcpy(inputParams.NTRIP_password, argv[12], sizeof(inputParams.NTRIP_password));
		}
	}
	else
	{
		printf(">%s read parameters: \n", p_modName);
		printf("\t iNAT ip address:............................. %s \n", inputParams.iNAT_ip);
		printf("\t iNAT tcp port:............................... %d \n", inputParams.iNAT_tcp_port);
		printf("\t iNAT broadcast address:...................... %s \n", inputParams.iNAT_brdcst_addr);
		printf("\t iNAT udp port:............................... %d \n", inputParams.iNAT_udp_port);
		printf("\t PC ip address:............................... %s \n", inputParams.pc_ip);
#ifdef __linux
		printf("\t serial interface:............................ %s \n", inputParams.serialPort);
#else
		printf("\t serial interface:............................ %d \n", inputParams.serialPort);
#endif
		printf("\t log frequency:............................... %d \n", inputParams.log_freq);
		printf("\t NTRIP stream:................................ %s \n", inputParams.NTRIP_stream);
		printf("\t NTRIP server:................................ %s \n", inputParams.NTRIP_server);
		printf("\t NTRIP remote port:........................... %d \n", inputParams.NTRIP_remote_port);
		printf("\t NTRIP user:.................................. %s \n", inputParams.NTRIP_user);
//		printf("\t NTRIP password:.............................. %s \n", inputParams.NTRIP_password);
	}

	int mainLoopCnt = 0;
//	static useLogData logData;
//	static useUdpLogData udpData;
//	static retParData parData;
	memset(&logData,0,sizeof(useLogData));
	memset(&udpData, 0, sizeof(useUdpLogData));
	memset(&parData, 0, sizeof(retParData));
	insCom* iNAT = new insCom(p_modName);

	/* init fwd correction data ... */							// set read/write capability (linux: sudo chmod o+rw /dev/ttyUSB0 (e.g.)) on your serial port
#ifdef __linux
	//int rtcmv3Stream = open("/dev/ttyS8",O_RDWR| O_SYNC);
	//int rtcmv3Stream = open("/dev/ttyUSB0",O_RDWR| O_SYNC);
	int rtcmv3Stream = open(inputParams.serialPort,O_RDWR| O_SYNC);
	if (-1 == rtcmv3Stream)

#else
	int rtcmv3Stream = serial.Open(inputParams.serialPort, 19200);
	if (0 == rtcmv3Stream)
#endif
	{
		char u_in[1024];
		do
		{
			printf(">%s could not open serial interface: continue anyway? (y/n) ", p_modName);
			cin >> u_in;
		}while((tolower(u_in[0]) != 'y') && (tolower(u_in[0]) != 'n'));
		if(tolower(u_in[0]) == 'n')
		{
			printf(">%s aborted \n", p_modName);
			return -1;
		}
		else
		{
			serialAvailable = 0;
		}
	}
#ifdef __linux
	if(serialAvailable)
	{
		if(-1 == setInterfaceAttributes(rtcmv3Stream, B19200, 0))
			printf(">%s could not set serial interface: baudrate \n",p_modName);

		if(-1 == setInterfaceBlocking(rtcmv3Stream, 64))
			printf(">%s could not set serial interface: blocking \n",p_modName);
	}
#endif

	/* update rtkThread data */
	rtkThreadData.fd = rtcmv3Stream;
	rtkThreadData.iNAT = iNAT;

	/*init iNAT*/
	if( 0 == initINS(iNAT))
	{

		/*init rtcmv3 thread*/
		if(serialAvailable)
			if(0 == createRTCMV3Thread())
				printf(">%s rtk thread created\n",p_modName);

		/*getData*/
		while(mainLoopCnt < 100)
		{
			// TCP DATA
			if( 0 == iNAT->getUseData(&logData) )
			{

				printf("\n>%s T C P   D A T A: \n", p_modName);

//				pthread_mutex_lock(&mx_lock);
				lock_guard<mutex> lock(mx_lock);
				tcp_uiGpsTime_sec		= (double)logData.xcominsSol.tHeader.uiGpsTime_sec;
				tcp_uiGpsTime_usec		= (double)logData.xcominsSol.tHeader.uiGpsTime_usec * 1e-6;
				tcp_gStatus				= logData.xcominsSol.tBottom.gStatus;
				//for(int i = 0; i < 16; i++)
				for(int i = 0; i < (sizeof(temp)/sizeof(float)); i++)
				{
					temp[i]				= 0.0;
					temp[i]				= logData.xcomTemp.fTemp[i];
				}
//				pthread_mutex_unlock(&mx_lock);
				
//				printf(">%s alignment status: %d\n", p_modName, ALIGNCOMPLTE == (tcp_gStatus & ALIGNCOMPLTE ));
				printf(">%s alignment status: %s\n", p_modName,    (ALIGNCOMPLTE == (tcp_gStatus & ALIGNCOMPLTE )) ? "C O M P L E T E" : "PENDING..."   );
				printf(">%s last valid time insSol: %f\n", p_modName, tcp_uiGpsTime_sec + tcp_uiGpsTime_usec);

				printf(">%s temperature data [deg C]: %.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f \n",
													p_modName,
													temp[0], temp[1], temp[2], temp[3],
													temp[4], temp[5], temp[6], temp[7],
													temp[8], temp[9], temp[10], temp[11],
													temp[12], temp[13], temp[14], temp[15]);

				//printf(">%s tcp data, alignment status: %d\n",p_modName,ALIGNCOMPLTE == (logData.xcominsSol.tBottom.gStatus & ALIGNCOMPLTE ));
				//printf(">%s tcp data, last valid time insSol: %f\n",p_modName,(double)logData.xcominsSol.tHeader.uiGpsTime_sec + ((double) logData.xcominsSol.tHeader.uiGpsTime_usec)*(1e-6));
			}
			
			// UDP DATA
			if( 0 == iNAT->getUdpUseData(&udpData) )
			{

				printf("\n>%s U D P   D A T A: \n", p_modName);

//				pthread_mutex_lock(&mx_lock);
				lock_guard<mutex> lock(mx_lock);
				udp_insPosLLH_uiGpsTime_sec		= (double)udpData.xcominsPosLLH.tHeader.uiGpsTime_sec;
				udp_insPosLLH_uiGpsTime_usec	= (double)udpData.xcominsPosLLH.tHeader.uiGpsTime_usec * 1e-6;
				udp_insSol_uiGpsTime_sec		= (double)udpData.xcominsSol.tHeader.uiGpsTime_sec;
				udp_insSol_uiGpsTime_usec		= (double)udpData.xcominsSol.tHeader.uiGpsTime_usec * 1e-6;
//				for(int i = 0; i < 16; i++)
				for(int i = 0; i < (sizeof(temp)/sizeof(float)); i++)
				{
					temp[i]						= 0.0;
					temp[i]						= udpData.xcomTemp.fTemp[i];
				}
//				pthread_mutex_unlock(&mx_lock);

				printf(">%s last valid time: %f\n", p_modName, udp_insPosLLH_uiGpsTime_sec + udp_insPosLLH_uiGpsTime_usec);
				printf(">%s last valid time insSol: %f\n", p_modName, udp_insSol_uiGpsTime_sec + udp_insSol_uiGpsTime_usec);
				
				printf(">%s temperature data [deg C]: %.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f / "
													"%.1f / %.1f / %.1f / %.1f \n",
													p_modName,
													temp[0], temp[1], temp[2], temp[3],
													temp[4], temp[5], temp[6], temp[7],
													temp[8], temp[9], temp[10], temp[11],
													temp[12], temp[13], temp[14], temp[15]);

				//printf(">%s udp data, last valid time: %f\n",p_modName,(double) udpData.xcominsPosLLH.tHeader.uiGpsTime_sec + ((double) udpData.xcominsPosLLH.tHeader.uiGpsTime_usec)*(1e-6));
				//printf(">%s udp data, last valid time insSol: %f\n",p_modName,(double) udpData.xcominsSol.tHeader.uiGpsTime_sec + ((double) udpData.xcominsSol.tHeader.uiGpsTime_usec)*(1e-6));
			}
#ifdef __linux__
			sleep(1);
#elif _WIN32
			Sleep(1000);
#else
#error platform not supported
#endif
			mainLoopCnt++;
		}
	}
	else
	{
		printf(">%s Exit Error\n",p_modName);
		exit(EXIT_FAILURE);
	}
	
	/********************/
	/*  cancel threads  */
	/********************/
//	int c = pthread_cancel(rtkComThread);
//	if(!(0 == pthread_cancel(rtkComThread)))
//	{
//		perror(p_modName);
//	}
//	printf(">%s rtk thread canceled\n",p_modName);
//	if(!(0 == pthread_cancel(insComThread)))
//	{
//		perror(p_modName);
//	}
//	printf(">%s tcp thread canceled\n",p_modName);
//	if(!(0 == pthread_cancel(udpComThread)))
//	{
//		perror(p_modName);
//	}
//	printf(">%s udp thread canceled\n",p_modName);


	/***********************/
	/*    Close Channel    */
	/***********************/
	setComChannel(iNAT, UDP_LOG_CHANNEL, CLOSE_CHANNEL);
	setComChannel(iNAT, DATACHANNEL, CLOSE_CHANNEL);



	/******************/
	/*  Close Socket  */
	/******************/
	if(-1 == iNAT->closeSocket())
	{
		printf(">%s could not close socket\n",p_modName);
	}
	if(-1 == iNAT->closeUdpSocket())
	{
		printf(">%s could not close socket\n",p_modName);
	}

	/******************/
	/*  Close Stream  */
	/******************/
#ifdef __linux
	//sleep(3);
	if(serialAvailable)
		if(-1 == close(rtcmv3Stream))
#else
	//Sleep(3000);
	if(serialAvailable)
		if(0 == serial.Close())
#endif
	{
		printf(">%s could not close rtcmv3Stream\n",p_modName);
		perror(p_modName);
	}

	exit(EXIT_SUCCESS);
}

int initINS(insCom *p_ins)
{
	/**************************************/
    /* Open TCP Sockect and connect to i t*/
	/**************************************/
	if( -1 == p_ins->openNConnectSocket(inputParams.iNAT_ip,inputParams.iNAT_tcp_port))
		return -1;


	/**********************/
	/* Create "Rx" Thread */
	/**********************/

//	cout << "+++ creating insComThread" << endl;
	thread insComThread(t_parseRxData, p_ins);
//	cout << "+++ creating insComThread DONE" << endl;
	insComThread.detach();

//	int rxState = 0;
//	pthread_attr_t rxpthread_attributes;
//	sched_param rxPrio;
//	rxPrio.sched_priority = 0;
//	if(!( 0 == pthread_attr_init(&rxpthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_setschedparam(&rxpthread_attributes, &rxPrio)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_create(&insComThread, &rxpthread_attributes, t_parseRxData, p_ins)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
////	std::thread t1(t_parseRxData(p_ins));
//	if(!(0 == pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &rxState)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_detach(insComThread)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_destroy(&rxpthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}


	/**************************************/
	/* Open UDP Sockect and connect to it */
	/**************************************/
	if( -1 == p_ins->ConnectUDPSocket(inputParams.pc_ip, inputParams.iNAT_udp_port))
			return -1;


	/******************************/
	/* Create UDP Rx Thread       */
	/******************************/

//	cout << "+++ creating udpComThread" << endl;
	thread udpComThread(t_parseRxRunData, p_ins);
//	cout << "+++ creating udpComThread DONE" << endl;
	udpComThread.detach();

//	int udpState = 0;
//	pthread_attr_t udppthread_attributes;
//	sched_param udpPrio;
//    udpPrio.sched_priority = 0;
//	if(!( 0 == pthread_attr_init(&udppthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_setschedparam(&udppthread_attributes, &udpPrio)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_create(&udpComThread, &udppthread_attributes, t_parseRxRunData, p_ins)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &udpState)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_detach(udpComThread)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_destroy(&udppthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}


	/****************************************************************************/
	/* connect to a free channel to get system information and disable UDP LOG 	*/
	/****************************************************************************/
	printf(">%s look for a free channel to get system information and disable udp log \n", p_modName);
	for(int i = 0; i < 32; i++)
	{

		if(i == 1) continue;		// recording channel excluded

		printf(">%s CHANNEL %d... \n", p_modName, i);

		if(setComChannel(p_ins, i, OPEN_CHANNEL) == -1)
		{
			continue;
		}
		else
		{

			/****************************************************/
			/* 				get system information			 	*/
			/****************************************************/
			if(getSysInfo(p_ins) != 0)
			{
				printf(">%s could not get system information \n", p_modName);

				return(-1);
			}


			/********************************/
			/*         disable udp log      */
			/********************************/
			uint32_t udpConfig[3] = {  UDP_LOG_CHANNEL,						//ucChannel
//			uint32_t udpConfig[3] = {  i + 1,						//ucChannel
									   (uint32_t)UDP_DISABLE,				//ucEnable
									   (uint32_t)inputParams.iNAT_udp_port 	//uiPort
									};
			char *srvAddr = inputParams.iNAT_brdcst_addr;

			if(0 != p_ins->createMsgPARXCOM_UDPCONFIG(udpConfig,srvAddr))
					return(-1);
			if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
			{
				printf(">%s PARXCOM_UDPCONFIG disable: %s\n",p_modName,p_cmdResp);
				return (-1);
			}
			printf(">%s PARXCOM_UDPCONFIG disable: %s\n",p_modName,p_cmdResp);



			/********************************************************/
			/*      SYSTEM CONFIGURATION: SAVE/LOAD/FACTORY         */
			/********************************************************/
			if(setConfig(p_ins, XCOMCONF_SAVE) == -1)
				return -1;

			/***********************/
			/*    Close Channel    */
			/***********************/
			setComChannel(p_ins, i, CLOSE_CHANNEL);

			break;

		}

	}
	/*******************************************************************************************/
	/*  re-open TCP Sockect and connect to it (required to open another channel after closing)  */
	/*******************************************************************************************/
	if( -1 == p_ins->openNConnectSocket(inputParams.iNAT_ip,inputParams.iNAT_tcp_port))
		return -1;


	/******************************/
	/*    open udp log channel    */
	/******************************/
	if(setComChannel(p_ins, UDP_LOG_CHANNEL, OPEN_CHANNEL) == -1)
		return -1;

	/************************************************************/
	/*           Request Data Logs (UDP LOG CHANNEL)            */
	/************************************************************/
	if(requestLogs(p_ins) == -1)
		return -1;


	/********************************************************/
	/*      SYSTEM CONFIGURATION: SAVE/LOAD/FACTORY         */
	/********************************************************/
	if(setConfig(p_ins, XCOMCONF_SAVE) == -1)
		return -1;


	/*********************/
	/*   Close Channel   */
	/*********************/
	setComChannel(p_ins, UDP_LOG_CHANNEL, CLOSE_CHANNEL);


	/*******************************************************************************************/
	/*  re-open TCP Sockect and connect to it (required to open another channel after closing)  */
	/*******************************************************************************************/
	if( -1 == p_ins->openNConnectSocket(inputParams.iNAT_ip,inputParams.iNAT_tcp_port))
		return -1;


    /******************************/
	/* open communication channel */
	/******************************/
	if(setComChannel(p_ins, DATACHANNEL, OPEN_CHANNEL) == -1)
		return -1;


	/********************************/
	/*         set params           */
	/********************************/

//	/* FPGA MCP23S08 */
//	uint8_t reg = 1;
//	if( -1 == p_ins->createMsgPARFPGA_MCP23S08(reg))
//		return(-1);
//	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
//	{
//		printf(">%s PARFPGA_MCP23S08: %s\n",p_modName,p_cmdResp);
//		return (-1);
//	}
//	printf(">%s PARFPGA_MCP23S08: %s\n",p_modName,p_cmdResp);

	/* Missalign */
	double drpy[3] = {0.f,0.f,0.f};
	if( -1 == p_ins->createMsgPARIMU_MISALIGN(drpy))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_MISALIGN: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_MISALIGN: %s\n",p_modName,p_cmdResp);

	/* DualAntMode */
	uint32_t dualAntMode = 0;
	if( -1 == p_ins->createMsgPARGNSS_DUALANTMODE(dualAntMode))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARGNSS_DUALANTMODE: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARGNSS_DUALANTMODE: %s\n",p_modName,p_cmdResp);

	/* LeverArms2Gnss */
	double ins2gnss1[6] = {0.f,0.f,0.f,0.02f,0.02f,0.02f};
	double ins2gnss2[6] = {10.f,0.f,0.f,0.02f,0.02f,0.02f};
	if( -1 == p_ins->createMsgPARGNSS_ANTOFFSET(ins2gnss1,0))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_ANTOFFSET 1: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_ANTOFFSET 1: %s\n",p_modName,p_cmdResp);

    /*LeverArm2Gnss2*/
	if( -1 == p_ins->createMsgPARGNSS_ANTOFFSET(ins2gnss2,1))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_ANTOFFSET 2: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_ANTOFFSET 2: %s\n",p_modName,p_cmdResp);

	/* Alignmode */
	uint32_t alignMode[1] = {4};
	if( -1 == p_ins->createMsgPAREKF_ALIGNMODE(alignMode))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_ALIGNMODE: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_ALIGNMODE: %s\n",p_modName,p_cmdResp);

	/* Alignmnet */
	uint32_t alignTime[1] = {30};
	if( -1 == p_ins->createMsgPAREKF_ALIGNTIME(alignTime))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_ALIGNTIME: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_ALIGNTIME: %s\n",p_modName,p_cmdResp);

	uint32_t coarseTime[1] = {5};
	if( -1 == p_ins->createMsgPAREKF_COARSETIME(coarseTime))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_COARSETIME: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_COARSETIME: %s\n",p_modName,p_cmdResp);

	/* thresholds */
	double alHeThrs[3] = {1.f,0.5f,0.05f};
	if( -1 == p_ins->createMsgPAREKF_HDGPOSTHR(alHeThrs))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_HDGPOSTHR: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_HDGPOSTHR: %s\n",p_modName,p_cmdResp);

	/* DualAntAid */
	uint32_t DualAntAid_Mode[1] = {2};
	double DualAntAid_StdDevThr[3] = {1.f/180*M_PI, 3.f/180*M_PI, 2.f/180*M_PI};
	if(-1 == p_ins->createMsgPAREKF_DUALANTAID(DualAntAid_Mode, DualAntAid_StdDevThr))
	{
		return(-1);
	}
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_DUALANTAID: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_DUALANTAID: %s\n",p_modName,p_cmdResp);

	/* EKF ZUPT THRESH	*/
	uint32_t dlyAct[3] =
	{
		1000,	/*samples dly*/
		3,		/*activation mask bit 0 acc bit 1 omg bit 2 vel*/
		1		/* auto zupt enable*/
	};
	double thrs[8] =
	{
		1.0,       			/* thrs acc */
		2.0/180.0*M_PI,		/* thrs omg */
		0.1,				/* thrs odoVel */
		1.0,				/* acc&omg LpHz */
		1.0,				/* zupt interval */
		0.05,				/* zupt final stdDev */
		1.0,				/* wheight fact.*/
		0.5					/* timeconstant */
	};
	if( -1 == p_ins->createMsgPAREKF_ZUPT(dlyAct,thrs))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_ZUPT: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_ZUPT: %s\n",p_modName,p_cmdResp);

	/* StartUpMASK */
	double initPosLon = 7.0/180.0*M_PI;
	double initPosLat = 42.0/180.0*M_PI;
	double initPosAlt = 0.0;
	double initStdLon = 100.0;
	double initStdLat = 100.0;
	double initStdAlt = 100.0;
	double initHead = 0.0;
	double initHeadStd = M_PI;

	double initLeverArmX = 0.65;
	double initLeverArmY = 0.36;
	double initLeverArmZ = 0.77;
	double initLeverArmStdDevX = 0.01;
	double initLeverArmStdDevY = 0.01;
	double initLeverArmStdDevZ = 0.01;

	uint32_t posMask = 0;
	uint32_t headMask = 0; /* 4 is DUALANTENNA*/
	uint32_t gnssTimeout = 60;
	uint32_t zuptEnable = 1;
	uint32_t reAlign = 0;
	uint32_t reStart = 0;
	uint32_t inMotion = 0;

	double dblValues[14] =
	{
		initPosLon,
		initPosLat,
		initPosAlt,
		initStdLon,
		initStdLat,
		initStdAlt,
		initHead,
		initHeadStd,

		initLeverArmX,
		initLeverArmY,
		initLeverArmZ,
		initLeverArmStdDevX,
		initLeverArmStdDevY,
		initLeverArmStdDevZ
	};

	uint32_t intValues[7] =
	{
			posMask,
			headMask,
			gnssTimeout,
			zuptEnable,
			reAlign,
			inMotion,
			reStart
	};

	if( -1 == p_ins->createMsgPAREKF_STARTUPV2(intValues,dblValues))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_STARTUP: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_STARTUP: %s\n",p_modName,p_cmdResp);

	uint32_t smoothSamples[1] = {10};
	if( -1 == p_ins->createMsgPAREKF_SMOOTH(smoothSamples))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PAREKF_SMOOTH: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PAREKF_SMOOTH: %s\n",p_modName,p_cmdResp);

	/* IMU CORR */
	currImuMode = IMURAW;		// IMURAW / IMUCORR / IMUCOMP
	uint32_t imuData[1] = {currImuMode};
	if( -1 == p_ins->createMsgPARDAT_IMU(imuData))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_IMU: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_IMU: %s\n",p_modName,p_cmdResp);

	/* VEL BODY */
	uint32_t velBdy[1] = {PARDAT_VEL_BODY};
	if( -1 == p_ins->createMsgPARDAT_VEL(velBdy))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_VEL: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_VEL: %s\n",p_modName,p_cmdResp);

	/* POS WGS84 */
	uint32_t wgs84[2] = {POSITION_WGS84, ALTITUDE_WGS84};
	if( -1 == p_ins->createMsgPARDAT_POS(wgs84))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARDAT_POS: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARDAT_POS: %s\n",p_modName,p_cmdResp);


	/* CAN Port */
	uint32_t canPort[1] = {0}; /* 0 => CAN0, 1 => CAN1 */
	if(0!= p_ins->createMsgPARARINC825_PORT(canPort))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARARINC825_PORT: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARARINC825_PORT: %s\n",p_modName,p_cmdResp);


	uint32_t canBusRec[1] = {0}; /* 0 => Disable Bus Recovery, 1 => Enable Bus Recovery */
	//  ALWAYS DISABLE IF NO CAN DEVICE CONNECTED
	if(0 != p_ins->createMsgPARARINC825_BUSRECOVERY(canBusRec))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARARINC825_BUSRECOVERY: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARARINC825_BUSRECOVERY: %s\n",p_modName,p_cmdResp);

#ifdef __POWERCYCLE__
	uint32_t canBaud[1] = {500000};  /* => 125000,
	                                    => 250000,
	                              	    => 500000,
	                                    => 1000000    */
	if(0 != p_ins->createMsgPARARINC825_BAUD(canBaud))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARARINC825_BAUD: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARARINC825_BAUD: %s\n",p_modName,p_cmdResp);
	printf(">%s ==> POWER CYCLE IS REQUIRED TO CHANGE PARARINC825_BaudRate: %s\n",p_modName);
#endif

	uint32_t canEnable[2] = {1,1}; /*Rx, Tx*/
	if (0 != p_ins->createMsgPARARINC825_ENABLE(canEnable))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARARINC825_ENABLE: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARARINC825_ENABLE: %s\n",p_modName,p_cmdResp);


////	/* CAN ARINC825 FrameList*/												// Momentan Unstimmigkeiten in der Framelist. Wird bald von Tim komplett überarbeitet und wird frei konfigurierbar.
//	p_ins->reinitmARINC825_FL(); /* unlog all can frames*/
//	uint16_t divider = 500;    /* can base frq. is 500Hz, so a divider of 5 => 100Hz data*/
//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_TIME, divider);
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_ACCRAW, divider);	//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_ACCCOR, divider);
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_ACCCOMP, divider);	//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_OMGRAW, divider);	//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_OMGCOR, divider);
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_OMGCOMP, divider);	//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_RPY, divider);
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_VNED, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_VXYZ, divider);
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_LON, divider);
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_LAT, divider);
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_ALT, divider);
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_SYSSTAT, divider);
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_EKF_LOW, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_EKF_HI, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_LONSTDDEV, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_LATSTDDEV, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_ALTSTDDEV, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_VELSTDDEV, divider);	//
//	p_ins->setmARINC825FLEntry(ARINC825_DOC_RPYSTDDEV, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_MAGICNUM, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSLON, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSLAT, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSALT, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSVEL, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSINF, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSPOSSTDDEV, divider);	//
//    p_ins->setmARINC825FLEntry(ARINC825_DOC_GNSSVELSTDDEV, divider);	//
//
//	p_ins->createMsgPARARINC825_FrameList();
//	if(0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
//	{
//		printf(">%s PARARINC825_FrameList: %s\n",p_modName,p_cmdResp);
//		return (-1);
//	}
//	printf(">%s PARARINC825_FrameList: %s\n",p_modName,p_cmdResp);

//#define __USE_iNAT_NTRIPCLIENT__
#ifdef __USE_iNAT_NTRIPCLIENT__
	/* NTRIP */
//	char c_aStream[128]="";
//	char c_aServer[128]="";
//	char c_aUser[128]="";
//	char c_aPwd[128]="";

	uint32_t data[3] = {
						1,   	// Enable
			            1,   	// SendPositionOnLogin
//			            2101 	// Remote Port
						inputParams.NTRIP_remote_port
					};

	//if (0 != p_ins->createMsgPARGNSS_NTRIP(data, c_aStream, c_aServer, c_aUser, c_aPwd))
	if (0 != p_ins->createMsgPARGNSS_NTRIP(data, inputParams.NTRIP_stream, inputParams.NTRIP_server, inputParams.NTRIP_user, inputParams.NTRIP_password))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARGNSS_NTRIP: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARGNSS_NTRIP: %s\n",p_modName,p_cmdResp);
#endif

//#define __USE_RTCMV3_IXCOM__
#ifdef __USE_RTCMV3_IXCOM__
	/* RTCMV3 while sending RTCMV3 via PAR_GNSS_RTCMV3AIDING instead of using NTRIP Client*/
	uint32_t rtcmv3[3] = {1, 	//ucEnable
					      1, 	//ucPort 1 => Com1
				          19200 // BaudRate
						};
	if( 0 != p_ins->createMsgPARGNSS_RTCMV3CONFIG(rtcmv3))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARGNSS_RTCMV3CONFIG: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARGNSS_RTCMV3CONFIG: %s\n",p_modName,p_cmdResp);
#endif


	/********************************************************/
	/*           Request Data Logs (TCP CHANNEL)            */
	/********************************************************/
	if(requestLogs(p_ins) == -1)
		return -1;


	/********************************/
	/*         enable udp log       */
	/********************************/
	uint32_t udpConfig[3] = {  UDP_LOG_CHANNEL,						//ucChannel
			                   (uint32_t)UDP_ENABLE,				//ucEnable
							   (uint32_t)inputParams.iNAT_udp_port 	//uiPort
							};
	char *srvAddr = inputParams.iNAT_brdcst_addr;

	if(0 != p_ins->createMsgPARXCOM_UDPCONFIG(udpConfig,srvAddr))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s PARXCOM_UDPCONFIG enable: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s PARXCOM_UDPCONFIG enable: %s\n",p_modName,p_cmdResp);


	/********************************************************/
	/*      SYSTEM CONFIGURATION: SAVE/LOAD/FACTORY         */
	/********************************************************/
	if(setConfig(p_ins, XCOMCONF_SAVE) == -1)
		return -1;


	/********************************************************/
	/*				EXTAID Commands							*/
	/********************************************************/
//	if(setExtAid(p_ins, XCOMEXTAID_HGT, 0) == -1)
//		return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_POS, 0) == -1)
//		return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_VEL, 0) == -1)
//		return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_FREEZE_ALT, 0) == -1)
//				return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_FREEZE_HDG, 0) == -1)
//				return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_FREEZE_VELBODY, 0) == -1)
//				return -1;

//	if(setExtAid(p_ins, XCOMEXTAID_HDG, 0) == -1)
//				return -1;

//		setExtAid(p_ins, XCOMEXTAID_VEL, 0);
//		setExtAid(p_ins, XCOMEXTAID_FREEZE_ALT, 0);
//		setExtAid(p_ins, XCOMEXTAID_FREEZE_HDG, 0);
//		setExtAid(p_ins, XCOMEXTAID_FREEZE_VELBODY, 0);
//		setExtAid(p_ins, XCOMEXTAID_HDG, 0);


	/********************************************************/
	/*		Request Alignment								*/
	/********************************************************/
	if( -1 == p_ins->createMsgCmdEKF(XCOMEKF_ALIGNCOMPLETE, 0, NULL))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s XCOMEKF_ALIGNCOMPLETE: %s\n",p_modName,p_cmdResp);
		return (-1);
	}

	printf(">%s XCOMEKF_ALIGNCOMPLETE: %s\n",p_modName,p_cmdResp);

	if( -1 == p_ins->createMsgCmdEKF(XCOMEKF_ALIGN, 0, NULL))
		return(-1);
	if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
	{
		printf(">%s XCOMEKF_ALIGN: %s\n",p_modName,p_cmdResp);
		return (-1);
	}
	printf(">%s XCOMEKF_ALIGN: %s\n",p_modName,p_cmdResp);
	printf(">%s Alignment Started\n",p_modName);

#ifdef __linux
	sleep(1);
#elif _WIN32
	Sleep(1000);
#else
#error platform not supported
#endif

	if( -1 == p_ins->waitAlignmentDone(100000)) /*TimeOut in ms*/
		return(-1);
	printf(">%s Alignment Done\n",p_modName);


 return(0);

}

void t_parseRxData(void *pData)
{
	if(!(pData==NULL))
	{
		insCom *instance = (insCom *) pData;
		instance->parseRxRunData();
	}
//	pthread_exit(NULL);

//#ifdef _WIN32
//	return NULL;
//#endif
}

void t_parseRxRunData(void *pData)
{
	if(!(pData==NULL))
	{
		insCom *instance = (insCom *) pData;
		instance->parseRxRunUdpData();
	}
//	pthread_exit(NULL);

//#ifdef _WIN32
//	return NULL;
//#endif
}

void t_fwdRTCMV3Data(void *pData)
{

	t_FWDRTCMV3 *myThreadData = (t_FWDRTCMV3*) pData;

	/* fwd correction data ... */
	char rtcmv3OutData[64]="";
	char rtcmv3InData[512]="";
	int rxBytes = 0;
	int txBytes = 0;
	static unsigned int byteCnt = 0;
	static t_NmeaType nmea;
	static useLogData logData;

	while(1)
	{
		// Send GGA via serial

//      const char *ggaStr = "$GPGGA,103203.00,4916.4303,N,00709.5259,E,1,16,0.6,270.32,M,48.60,M,,*6B\r\n";
//		txBytes = write(myThreadData->fd,(void *) ggaStr,strlen(ggaStr));
		if( 0 == myThreadData->iNAT->getUseData(&logData))
		{
			NMEA_processXCOMData(&nmea, &logData.xcomgnssSol, &logData.xcomgnssTime, &logData.xcomimuCal);
#ifdef __linux
			txBytes = write(myThreadData->fd,(void *) nmea.writeBuffer,strlen(nmea.writeBuffer));
#else

			txBytes = serial.SendData(nmea.writeBuffer, strlen(nmea.writeBuffer));
//			txBytes = serial.SendData(ggaStr, strlen(ggaStr));

#endif
		}
		
		//cout << "--------------- txBytes: " << txBytes << endl;
		
		if (-1 == txBytes)
		{
			perror(p_modName);
		}


		//RTCMV3 via TCP
#ifdef __linux
		rxBytes = read(myThreadData->fd, (void *) rtcmv3InData, sizeof(rtcmv3InData));
		cout << "+++++++++++++++ received data: " <<  rtcmv3InData << endl;
		cout << "+++++++++++++++ received data: " <<  rxBytes << endl;
#else

		while(rxByteCnt < sizeof(rtcmv3InData)) {
			rxByteCnt += rxBytes;
			if(rxByteCnt >= sizeof(rtcmv3InData)) break;

			//rxBytes = serial.ReadData((void *) rtcmv3InData, sizeof(rtcmv3InData));
			rxBytes = serial.ReadData((void *) rxByte, sizeof(rxByte));

			if (-1 == rxBytes)
			{
				perror(p_modName);
			}
			else
			{
				if(rxBytes > 0)
				{
					rtcmv3InData[rxByteCnt] = rxByte[0];
					
					//cout << "+++++++++++++++ received data: " <<  rtcmv3InData << endl;
					//cout << "+++++++++++++++ received data: " <<  rxByteCnt << endl;
				}
			}
		}

		rxBytes = rxByteCnt;
		rxByteCnt = 0;

#endif

		//cout << "--------------- rxBytes: " << rxBytes << endl;

		if (-1 == rxBytes)
		{
			perror(p_modName);
		}

		/* max. send buffer is 64bytes only...*/
		for(int j = 0; j < ((int) rxBytes); j++)
		{
			byteCnt++;
			rtcmv3OutData[byteCnt-1] = rtcmv3InData[j];
			if( 64 == byteCnt )
			{
				//printf(">>>>>>>>>>>>>>>>>>>> received data: %d \n", byteCnt);

				byteCnt = 0;
				if( -1 == myThreadData->iNAT->createMsgPARGNSS_RTCMV3AIDING(rtcmv3OutData))
				{
					printf(">%s could not create PAR_GNSS_RTCMV3AIDING message\n",p_modName);
				}
				else
				{
					if( 0 != myThreadData->iNAT->sentNConfirmMsg(TIMEOUT,p_cmdResp))
					{
						printf(">%s PAR_GNSS_RTCMV3AIDING: %s\n",p_modName,p_cmdResp);
					}
					//printf(">%s -------%d-------- PAR_GNSS_RTCMV3AIDING: %s\n", p_modName, j, p_cmdResp);
				}
			}

		}
	}
//	pthread_exit(NULL);
}


/***********************************/
/* Create RTCMV3 FWD Thread       */
/**********************************/
int createRTCMV3Thread(void)
{
//	cout << "+++ creating rtkComThread" << endl;
	thread rtkComThread(t_fwdRTCMV3Data, (void*) &rtkThreadData);
//	cout << "+++ creating rtkComThread DONE" << endl;
	rtkComThread.detach();

//	int rtkState = 0;
//	pthread_attr_t rtkpthread_attributes;
//	sched_param rtkPrio;
//    rtkPrio.sched_priority = 0;
//	if(!( 0 == pthread_attr_init(&rtkpthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_setschedparam(&rtkpthread_attributes, &rtkPrio)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_create(&rtkComThread, &rtkpthread_attributes, t_fwdRTCMV3Data, (void*) &rtkThreadData)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &rtkState)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_detach(rtkComThread)))
//	{
//		perror(p_modName);
//		return (-1);
//	}
//	if(!(0 == pthread_attr_destroy(&rtkpthread_attributes)))
//	{
//		perror(p_modName);
//		return (-1);
//	}

	return(0);

}


/****************************************************/
/* 				get system information			 	*/
/****************************************************/
int getSysInfo(insCom *p_ins)
{

	int ret = 0;
	uint8_t c_out_32[32];
	uint8_t c_out_64[64];

	printf(">%s Get system information... \n", p_modName);

	/****************************************************/
	/*					project number					*/
	/****************************************************/
	if(-1 == p_ins->requestMsgPARSYS_PRJNUM())
		{
			printf("\t requestMsgPARSYS_PRJNUM failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t PRJNUM sentNConfirmMsg failed \n");
				ret = -1;
			}
		}
#ifdef __linux
			usleep(100000);
#else
			Sleep(100);
#endif
		while ((XCOM_PAR_SYS_PRJNUM != parData.xcomParSysPrjNum.tParHeader.usParID) || (parData.xcomParSysPrjNum.tBottom.CRC16 == 0))
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysPrjNum.ucPayload[i];
		}

		printf("\t project number:.............................. %s \n", c_out_32);


		/****************************************************/
		/*					part number						*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_PARTNUM())
		{
			printf("\t requestMsgPARSYS_PARTNUM failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t PARTNUM sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_PARTNUM != parData.xcomParSysPartNum.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysPartNum.ucPayload[i];
		}

		printf("\t part number:................................. %s \n", c_out_32);


		/****************************************************/
		/*					serial number					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_SERIALNUM())
		{
			printf("\t requestMsgPARSYS_SERIALNUM failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t SERIALNUM sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_SERIALNUM != parData.xcomParSysSerialNum.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysSerialNum.ucPayload[i];
		}

		printf("\t serial number:............................... %s \n", c_out_32);


		/****************************************************/
		/*				manufacturing date					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_MFGDATE())
		{
			printf("\t requestMsgPARSYS_MFGDATE failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t MFGDATE sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_MFG != parData.xcomParSysMFG.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysMFG.ucPayload[i];
		}

		printf("\t manufacturing date:.......................... %s \n", c_out_32);

		/****************************************************/
		/*				calibration date					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_CALDATE())
		{
			printf("\t requestMsgPARSYS_CALDATE failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t CALDATE sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_CALDATE != parData.xcomParSysCalDate.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysCalDate.ucPayload[i];
		}

		printf("\t calibration date:............................ %s \n", c_out_32);


		/****************************************************/
		/*				firmware version					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_FWVERSION())
		{
			printf("\t requestMsgPARSYS_FWVERSION failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t FWVERSION sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_FWVERSION != parData.xcomParSysFWVersion.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysFWVersion.ucPayload[i];
		}

		printf("\t firmware version:............................ %s \n", c_out_32);


		/****************************************************/
		/*					navlib version					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_NAVLIB())
		{
			printf("\t requestMsgPARSYS_NAVLIB failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t NAVLIB sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_NAVLIB != parData.xcomParSysNavLib.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysNavLib.ucPayload[i];
		}

		printf("\t navlib version:.............................. %s \n", c_out_32);


		/****************************************************/
		/*					EKF lib version					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_EKFLIB())
		{
			printf("\t requestMsgPARSYS_EKFLIB failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t EKFLIB sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_EKFLIB != parData.xcomParSysEkfLib.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysEkfLib.ucPayload[i];
		}

		printf("\t EKF lib version:............................. %s \n", c_out_32);


		/****************************************************/
		/*					EKF parameter set				*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_EKFPARSET())
		{
			printf("\t requestMsgPARSYS_EKFPARSET failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t EKFPARSET sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_EKFPARSET != parData.xcomParSysEkfParSet.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysEkfParSet.ucPayload[i];
		}

		printf("\t EKF parameter set:........................... %s \n", c_out_32);


		/****************************************************/
		/*					navigator version				*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_NAVNUM())
		{
			printf("\t requestMsgPARSYS_NAVNUM failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t NAVNUM sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_NAVNUM != parData.xcomParSysNavNum.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysNavNum.ucPayload[i];
		}

		printf("\t navigator version:........................... %s \n", c_out_32);


		/****************************************************/
		/*				navigator parameter set				*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_NAVPARSET())
		{
			printf("\t requestMsgPARSYS_NAVPARSET failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t NAVPARSET sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_NAVPARSET != parData.xcomParSysNavParSet.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 32; i++)
		{
			c_out_32[i] = parData.xcomParSysNavParSet.ucPayload[i];
		}

		printf("\t navigator parameter set:..................... %s \n", c_out_32);


		/****************************************************/
		/*		maintiming (internal frequency in Hz)		*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_MAINTIMING())
		{
			printf("\t requestMsgPARSYS_MAINTIMING failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t MAINTIMING sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_MAINTIMING != parData.xcomParSysMaintiming.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		printf("\t maintiming (internal system frequency):...... %d Hz \n", parData.xcomParSysMaintiming.usMaintiming);

		logDivider_desired = parData.xcomParSysMaintiming.usMaintiming / inputParams.log_freq;
		logDivider_oneHz = parData.xcomParSysMaintiming.usMaintiming;

	//	cout << ">>>>> sysInfo: " << "logDivider_desired: " << logDivider_desired << ", logDivider_oneHz: " << logDivider_oneHz << endl;


		/****************************************************/
		/*			prescaler (coning correction)			*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_PRESCALER())
		{
			printf("\t requestMsgPARSYS_PRESCALER failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t PRESCALER sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_PRESCALER != parData.xcomParSysPrescaler.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		printf("\t prescaler (coning correction):............... %d \n", parData.xcomParSysPrescaler.usPrescaler);


		/****************************************************/
		/*					system uptime					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_UPTIME())
		{
			printf("\t requestMsgPARSYS_UPTIME failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t UPTIME sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_UPTIME != parData.xcomParSysUpTime.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		int tm_s = parData.xcomParSysUpTime.fUptime;
		int tm_m = 0;
		int tm_h = 0;
		calc_h_m_s(&tm_h, &tm_m, &tm_s);

//		printf("\t system uptime:............................... %.0f s \n", parData.xcomParSysUpTime.fUptime);
		printf("\t system uptime:............................... %d h %d m %d s \n", tm_h, tm_m, tm_s);

		/****************************************************/
		/*						op time						*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_OPHOURCOUNT())
		{
			printf("\t requestMsgPARSYS_OPHOURCOUNT failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t OPHOURCOUNT sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_OPHOURCNT != parData.xcomParSysOpHourCnt.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		tm_s = parData.xcomParSysOpHourCnt.uiOperationalHourCounter;
		tm_m = 0;
		tm_h = 0;
		calc_h_m_s(&tm_h, &tm_m, &tm_s);

//		printf("\t op time:..................................... %d s \n", parData.xcomParSysOpHourCnt.uiOpHour);
		printf("\t op uptime:................................... %d h %d m %d s \n", tm_h, tm_m, tm_s);

		/****************************************************/
		/*					boot mode						*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_BOOTMODE())
		{
			printf("\t requestMsgPARSYS_BOOTMODE failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t BOOTMODE sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_BOOTMODE != parData.xcomParSysBootMode.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		printf("\t boot mode:................................... %d \n", parData.xcomParSysBootMode.uiBootmode);

		/****************************************************/
		/*					FPGA version					*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_FPGAVER())
		{
			printf("\t requestMsgPARSYS_FPGAVER failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t FPGAVER sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_FPGAVER != parData.xcomParSysFpgaVer.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		printf("\t FPGA version:................................ %d.%d \n", parData.xcomParSysFpgaVer.ucMajor, parData.xcomParSysFpgaVer.ucMinor);

//		/****************************************************/
//		/*			current FPGA_MCP23S08 settings			*/
//		/****************************************************/
//		if(-1 == p_ins->requestMsgPARFPGA_MCP23S08())
//		{
//			printf("\t requestMsgPARFPGA_MCP23S08 failed \n");
//			ret = -1;
//		}
//		else
//		{
//			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
//			{
//				printf("\t FPGA_MCP23S08 sentNConfirmMsg failed \n");
//				ret = -1;
//			}
//		}
//
////		while (XCOM_PAR_SYS_FPGAVER != parData.xcomParSysFpgaVer.tParHeader.usParID)
//		while(XCOM_PAR_FPGA_MCP23S08 != parData.xcomParFpgaMcp23s08.tParHeader.usParID)
//		{
//#ifdef __linux
//			usleep(10000);
//#else
//			Sleep(10);
//#endif
//			p_ins->getRetParData(&parData);
//		}
//
////		printf("\t FPGA version:................................ %d.%d \n", parData.xcomParSysFpgaVer.ucMajor, parData.xcomParSysFpgaVer.ucMinor);
//		printf("\t FPGA MCP23S08 current settings:.............. %d \n", parData.xcomParFpgaMcp23s08.ucGPIOreg);

		/****************************************************/
		/*					config CRC						*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_CONFIGCRC())
		{
			printf("\t requestMsgPARSYS_CONFIGCRC failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t CONFIGCRC sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_CONFIGCRC != parData.xcomParSysConfigCrc.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		printf("\t config CRC (ROM / RAM):...................... %d / %d \n", parData.xcomParSysConfigCrc.usROMCRC, parData.xcomParSysConfigCrc.usRAMCRC);

		/****************************************************/
		/*					OS version						*/
		/****************************************************/
		if(-1 == p_ins->requestMsgPARSYS_OSVERSION())
		{
			printf("\t requestMsgPARSYS_OSVERSION failed \n");
			ret = -1;
		}
		else
		{
			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
			{
				printf("\t OSVERSION sentNConfirmMsg failed \n");
				ret = -1;
			}
		}

		while (XCOM_PAR_SYS_OSVERSION != parData.xcomParSysOsVersion.tParHeader.usParID)
		{
#ifdef __linux
			usleep(10000);
#else
			Sleep(10);
#endif
			p_ins->getRetParData(&parData);
		}

		for(int i = 0; i < 64; i++)
		{
			c_out_64[i] = parData.xcomParSysOsVersion.ucPayload[i];
		}

		printf("\t OS version:.................................. %s \n", c_out_64);


	return ret;
}

/********************************************************/
/*				EXTAID Command Handler					*/
/********************************************************/
int setExtAid(insCom *p_ins, uint16_t action, int onOff)
{
	int numOfParams;
	int ret = 0;
	char s[180];
	char *cAction = (char*)"";
	double *params;
	double dTimeValue = 206620.498962;
	uint16_t usTimeMode = 0;

	switch(action)
	{
	case XCOMEXTAID_FREEZE_ALT:		//	Forced altitude aiding
		cAction = (char*)"EXTAID FREEZE ALT";
		params = new double[NUM_OF_PAR_EXTAID_FREEZE_ALT];
		numOfParams = NUM_OF_PAR_EXTAID_FREEZE_ALT;
		params[0] = 314.0;		//	Altitude in m
		params[1] = onOff;		//	Aiding Switch: 0 disable forced aiding, 1 enable forced aiding
		params[2] = 0.5;		//	Standard deviation of altitude in m
		break;

	case XCOMEXTAID_FREEZE_HDG:		//	Forced heading aiding
		cAction = (char*)"EXTAID FREEZE HDG";
		params = new double[NUM_OF_PAR_EXTAID_FREEZE_HDG];
		numOfParams = NUM_OF_PAR_EXTAID_FREEZE_HDG;
		params[0] = 0.785;		//	Heading in rad
		params[1] = onOff;		//	Aiding Switch: 0 disable forced aiding, 1 enable forced aiding
		params[2] = 0.005;		//	Standard deviationof heading in rad
		break;

	case XCOMEXTAID_FREEZE_VELBODY:	//	Forced body velocity (x, y, z) aiding
		cAction = (char*)"EXTAID FREEZE VELBODY";
		params = new double[NUM_OF_PAR_EXTAID_FREEZE_VELBODY];
		numOfParams = NUM_OF_PAR_EXTAID_FREEZE_VELBODY;
		params[0] = 8.75;		//	Velocity along body x-axis in m/s
		params[1] = 0.32;		//	Velocity along body y-axis in m/s
		params[2] = 0.15;		//	Velocity along body z-axis in m/s
		params[3] = 0.012;		//	Standard deviation of x-component in m/s
		params[4] = 0.012;		//	Standard deviation of y-component in m/s
		params[5] = 0.012;		//	Standard deviation of z-component in m/s
		params[6] = onOff;		//	Aiding Switch: 0 disable forced aiding, 1 enable forced aiding
		break;

	case XCOMEXTAID_POS:			//	Forced position aiding in WGS84
		cAction = (char*)"EXTAID POS";
		params = new double[NUM_OF_PAR_EXTAID_POS];
		numOfParams = NUM_OF_PAR_EXTAID_POS;
		params[0] = 0.125;		//	Longitude in rad
		params[1] = 0.86;		//	Latitude in rad
		params[2] = 314.0;		//	Altitude in m
		params[3] = 0.05;		//	Standard deviation of Longitude in m
		params[4] = 0.05;		//	Standard deviation of Latitude in m
		params[5] = 0.5;		//	Standard deviation of Altitude in m
		params[6] = 1.2;		//	Lever arm in x-direction in m
		params[7] = 0.0;		//	Lever arm in y-direction in m
		params[8] = -0.7;		//	Lever arm in z-direction in m
		params[9] = 0.05;		//	Standard deviation of lever arm in x-direction in m
		params[10] = 0.05;		//	Standard deviation of lever arm in y-direction in m
		params[11] = 0.05;		//	Standard deviation of lever arm in z-direction in m
		break;

	case XCOMEXTAID_VEL:			//	Forced velocity aiding in NED frame
		cAction = (char*)"EXTAID VEL";
		params = new double[NUM_OF_PAR_EXTAID_VEL];
		numOfParams = NUM_OF_PAR_EXTAID_VEL;
		params[0] = 0.0;		//	V_north direction in m/s
		params[1] = 0.0;		//	V_east direction in m/s
		params[2] = 0.0;		//	V_down in m/s
		params[3] = 0.02;		//	Standard deviation of V_north in m/s
		params[4] = 0.02;		//	Standard deviation of V_east in m/s
		params[5] = 0.02;		//	Standard deviation of V_down in m/s
		params[6] = 1.2;		//	Lever arm in x-direction in m
		params[7] = 0.0;		//	Lever arm in y-direction in m
		params[8] = -0.7;		//	Lever arm in z-direction in m
		params[9] = 0.05;		//	Standard deviation of lever arm in x-direction in m
		params[10] = 0.05;		//	Standard deviation of lever arm in y-direction in m
		params[11] = 0.05;		//	Standard deviation of lever arm in z-direction in m
		break;

	case XCOMEXTAID_HDG:			//	External heading aiding
		cAction = (char*)"EXTAID HDG";
		params = new double[NUM_OF_PAR_EXTAID_HDG];
		numOfParams = NUM_OF_PAR_EXTAID_HDG;
		params[0] = 0.785;		//	Heading in rad
		params[1] = 0.005;		//	Standard deviation of heading in rad;
		break;

	case XCOMEXTAID_HGT:
		cAction = (char*)"EXTAID HGT";
		params = new double[NUM_OF_PAR_EXTAID_HGT];
		numOfParams = NUM_OF_PAR_EXTAID_HGT;
		params[0] = 314.0;		//	Height in m
		params[1] = 0.5;		//	Standard deviation of height in m
		break;

	default:
		break;
	}

	/* EXTAID COMMAND */
	if(-1 == p_ins->createMsgCmdEXTAID(action, dTimeValue, usTimeMode, numOfParams, params))
	{
		sprintf(s, ">%s XCOMCMD_EXTAID (%s): create msg failed \n", p_modName, cAction);
		ret = -1;
	}
	else
	{
		if( 0 != p_ins->sentNConfirmMsg(CONF_TIMEOUT, p_cmdResp))
		{
			sprintf(s, ">%s XCOMCMD_EXTAID (%s): %s\n", p_modName, cAction, p_cmdResp);
			ret = -1;
		}
		else
		{
			sprintf(s, ">%s XCOMCMD_EXTAID (%s): %s\n", p_modName, cAction, p_cmdResp);
		}
	}

	printf("%s", s);
	return ret;

}


int setConfig(insCom *p_ins, uint32_t action)
{
	/********************************************************/
	/*      SYSTEM CONFIGURATION: SAVE/LOAD/FACTORY         */
	/********************************************************/


#define __DISABLE_SAVECONFIG__
#ifdef __DISABLE_SAVECONFIG__
	return 0;
#endif


	int ret = 0;
	char s[180];
	char *cAction = (char*)"";

	switch(action)
	{

	case XCOMCONF_SAVE:
		cAction = (char*)"SAVE CONFIG";
		break;

	case XCOMCONF_LOAD:
		cAction = (char*)"LOAD CONFIG";
		break;

	case XCOMCONF_FACTORY:
		cAction = (char*)"FACTORY SETTINGS";
		break;

	default:
		break;
	}

	/* XCOM COMMAND: XCOMCONF_SAVE = 0, XCOMCONF_LOAD = 1, XCOMCONF_FACTORY = 2 */
	if( -1 == p_ins->createMsgCmdCONF(action))
	{
		sprintf(s, ">%s XCOMCMD_CONF (%s): create msg failed \n", p_modName, cAction);
		ret = -1;
	}
	else
	{
		if( 0 != p_ins->sentNConfirmMsg(CONF_TIMEOUT, p_cmdResp))
		{
			sprintf(s, ">%s XCOMCMD_CONF (%s): %s\n", p_modName, cAction, p_cmdResp);
			ret = -1;
		}
		else
		{
			sprintf(s, ">%s XCOMCMD_CONF (%s): %s\n", p_modName, cAction, p_cmdResp);
		}
	}

	printf("%s", s);
	return ret;
}

int setComChannel(insCom *p_ins, int numOfChannel, int action)
{
	/**************************************************/
	/*      open / close communication channel        */
	/*              OPEN_CHANNEL: 1                   */
	/*              CLOSE_CHANNEL: 0                  */
	/**************************************************/

	int ret = 0;
	char s[180];
	char *cAction = (char*)"";

	switch(action)
	{
		case OPEN_CHANNEL:
			cAction = (char*)"OPEN";
			if( -1 == p_ins->createMsgOpenChannel(numOfChannel))
			{
				sprintf(s, ">%s Could not create open channel msg\n", p_modName);
				ret = -1;
			}
			break;

		case CLOSE_CHANNEL:
			cAction = (char*)"CLOSE";
			if(-1 == p_ins->createMsgCloseChannel(numOfChannel))
			{
				sprintf(s, ">%s Could not create close channel msg\n", p_modName);
				ret = -1;
			}
			break;

		default:
			break;
	}

	if(ret != -1)
	{
		if(0 != p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp)) {
			sprintf(s, ">%s %s channel: %s\n", p_modName, cAction, p_cmdResp);
//			if(action == OPEN_CHANNEL)
				ret = -1;
		}
		else
		{
			sprintf(s, ">%s %s channel: %s\n", p_modName, cAction, p_cmdResp);
		}
	}

//	if(action == CLOSE_CHANNEL) ret = 0;

	printf("%s", s);
	return ret;
}


int requestLogs(insCom *p_ins)
{
	/********************************************************/
	/*           Request Data Logs				            */
	/********************************************************/

	/*Use ICD_iXCOM_Library: CLEAR ALL LOG*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSSOL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_CLEARALL, 10))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s Clear all Logs: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s Clear all Logs: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG INSSOL*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSSOL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSSOL: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSSOL: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG INSPOSLLH*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSPOSLLH, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSPOSLLH: %s\n",p_modName,p_cmdResp);
			return(-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSPOSLLH: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG INSDCM*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSDCM, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSDCM: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSDCM: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG INSPOSECEF*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSPOSECEF, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSPOSECEF: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSPOSECEF: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG INSPOSUTM*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSPOSUTM, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSPOSUTM: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSPOSUTM: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_GNSSSOL*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_GNSSSOL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_oneHz))	// always 1 Hz
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_GNSSSOL: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_GNSSSOL: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_GNSSTIME*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_GNSSTIME, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_oneHz))	// always 1 Hz
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_GNSSTIME: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_GNSSTIME: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_IMUCAL*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_IMUCAL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_IMUCAL: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_IMUCAL: %s\n",p_modName,p_cmdResp);



//		if(-1 == p_ins->requestMsgPARDAT_IMU())
//		{
//			printf("\t requestMsgPARDAT_IMU failed \n");
//		}
//		else
//		{
//			if(-1 == p_ins->sentNConfirmMsg(TIMEOUT, p_cmdResp))
//			{
//				printf("\t PARDAT_IMU sentNConfirmMsg failed \n");
//			}
//		}
//
//		while (XCOM_PAR_DAT_IMU != parData.xcomParDatImu.tParHeader.usParID)
//		{
//		#ifdef __linux
//			usleep(10000);
//		#else
//			Sleep(10);
//		#endif
//			p_ins->getRetParData(&parData);
//		}
//
//		printf("\t current imu mode:............................ %d \n", parData.xcomParDatImu.uiMode);


		switch(currImuMode)
		{
		case IMURAW:

			/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_IMURAW*/
			if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_IMURAW, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
				return(-1);
			if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
			{
				printf(">%s add XCOM_MSGID_MSG_IMURAW: %s\n",p_modName,p_cmdResp);
				return (-1);
			}
			printf(">%s add XCOM_MSGID_MSG_IMURAW: %s\n",p_modName,p_cmdResp);

			break;

		case IMUCORR:

			/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_IMUCORR*/
			if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_IMUCORR, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
				return(-1);
			if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
			{
				printf(">%s add XCOM_MSGID_MSG_IMUCORR: %s\n",p_modName,p_cmdResp);
				return (-1);
			}
			printf(">%s add XCOM_MSGID_MSG_IMUCORR: %s\n",p_modName,p_cmdResp);

			break;

		case IMUCOMP:

			/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_IMUCOMP*/
			if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_IMUCOMP, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
				return(-1);
			if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
			{
				printf(">%s add XCOM_MSGID_MSG_IMUCOMP: %s\n",p_modName,p_cmdResp);
				return (-1);
			}
			printf(">%s add XCOM_MSGID_MSG_IMUCOMP: %s\n",p_modName,p_cmdResp);

			break;
		}


		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_INSVELBODY*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_INSVELBODY, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_INSVELBODY: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_INSVELBODY: %s\n",p_modName,p_cmdResp);


		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_TEMP*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_SYS_TEMP, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_oneHz))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_TEMP: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_TEMP: %s\n",p_modName,p_cmdResp);


		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_SYSSTAT*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_SYS_STAT, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_desired))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_SYSSTAT: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_SYSSTAT: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_EKFERROR2*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_EKFSENSORERR2, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_oneHz))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_EKFSENSORERR2: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_EKFSENSORERR2: %s\n",p_modName,p_cmdResp);

		/*Use ICD_iXCOM_Library: ADD LOG XCOM_MSGID_MSG_EKFSTDDEV2*/
		if( -1 == p_ins->createMsgCmdLOG(XCOM_MSGID_MSG_EKFSTDDEV2, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, logDivider_oneHz))
			return(-1);
		if( 0 != p_ins->sentNConfirmMsg(TIMEOUT,p_cmdResp))
		{
			printf(">%s add XCOM_MSGID_MSG_EKFSTDDEV2: %s\n",p_modName,p_cmdResp);
			return (-1);
		}
		printf(">%s add XCOM_MSGID_MSG_EKFSTDDEV2: %s\n",p_modName,p_cmdResp);



        printf(">%s Logs Requested\n",p_modName);

		return 0;

}

//#ifdef _WIN32
//#endif

int getParamsFromFile()
{

	const int pathMax = 300;
	char result[pathMax];
#ifdef __linux
	if(readlink("/proc/self/exe", result, pathMax) == -1)
#else

#ifdef __MINGW32__
    LPWSTR lpwstr_res = new TCHAR[pathMax];
    int fileNameLength = GetModuleFileName(0, lpwstr_res, pathMax);     // QT_ch
    wcstombs(result, lpwstr_res, pathMax);
#else
	int fileNameLength = GetModuleFileName(0, result, pathMax);
#endif

	if((fileNameLength == 0) || ((fileNameLength > 0) && (GetLastError() > 0)))
#endif
	{
		printf(">%s could not determine config file path \n", p_modName);
		return -1;
	}
	
	char fileName[pathMax + 4];
#ifdef _WIN32
	result[fileNameLength - 4] = '\0';
#endif
	strcpy(fileName, result);
	strcat(fileName, ".conf");

#ifdef __linux
	strcpy(fileName, "/home/zp/files/svn_loc/iep_264_01_iXCOM-CSDK/30_IMPL/20_Binaries/projects/LINUX/iXCOM_CSDK/Debug/iXCOM_CSDK.conf");
#endif

	char inputArray[1000];
	int arLen = (sizeof(inputArray) / sizeof(char));
	char c;
	FILE *f;

	if(0 == (f = fopen(fileName, "r")))
	{
		printf(">%s could not open config file: %s \n", p_modName, fileName);
		return -1;
	}

	for(int i = 0; i < arLen; i++)
	{
		if(EOF == (c = fgetc(f)))
			break;
		inputArray[i] = c;
	}
	fclose(f);


	char param[128];
	memset(param, 0, sizeof(param));
	int paramNr = 0;
	int numOfParams = 12;
	int lastFound = 0;
	int firstPos = 0;
	int lastPos = 0;
	for(int i = 0; i < arLen; i++)
	{
		if(inputArray[i] == '=')
		{
			paramNr++;
			firstPos = i + 2;
			i = firstPos;
		}

		if(inputArray[i] == '"')
		{
			lastFound = 1;
			lastPos = i;
		}

		if(lastFound) {
			for(int j = firstPos; j < lastPos; j++)
			{
				param[j - firstPos] = inputArray[j];
			}

			switch(paramNr)
			{
			case 1:
				memcpy(inputParams.iNAT_ip, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 2:
				inputParams.iNAT_tcp_port = atoi(param);
				memset(param, 0, sizeof(param));
				break;

			case 3:
				memcpy(inputParams.iNAT_brdcst_addr, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 4:
				inputParams.iNAT_udp_port = atoi(param);
				memset(param, 0, sizeof(param));
				break;

			case 5:
				memcpy(inputParams.pc_ip, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 6:
#ifdef __linux
				memcpy(inputParams.serialPort, param, sizeof(param));
#else
				inputParams.serialPort = atoi(param);
#endif
				memset(param, 0, sizeof(param));
				break;

			case 7:
				inputParams.log_freq = atoi(param);
				memset(param, 0, sizeof(param));
				break;

			case 8:
				memcpy(inputParams.NTRIP_stream, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 9:
				memcpy(inputParams.NTRIP_server, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 10:
				inputParams.NTRIP_remote_port = atoi(param);
				memset(param, 0, sizeof(param));
				break;

			case 11:
				memcpy(inputParams.NTRIP_user, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			case 12:
				memcpy(inputParams.NTRIP_password, param, sizeof(param));
				memset(param, 0, sizeof(param));
				break;

			default:
				if(paramNr > 0) return 0;
				break;
			}

			if(paramNr >= numOfParams)
			{
				printf(">%s config file: %s \n", p_modName, fileName);
				return 0;
			}

			lastFound = 0;
		}
	}

	if(paramNr < numOfParams)
		return -1;

	return 0;
}

void calc_h_m_s(int *h, int *m, int *s)
{
	while(*s > 59)
	{
		if(*s > 3599)
		{
			*h = *s / 3600;
			*s -= (*h * 3600);
		}
		else
		{
			*m = *s / 60;
			*s -= (*m * 60);
		}
	}
}
