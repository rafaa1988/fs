/*
 * INAT protocol driver node
 *
 *  Created on: 29.06.2017
 *      Authors:
 *
 *      * Maximilian Schier <maximilian.schier@horsepower-hannover.de>
 *      * Schotte
 */

#include <ros/ros.h>
#include <sensor_msgs/TimeReference.h>
#include "Handler.h"
#include "InsComHelper.h"
#include "Welcome.h"
#include <hphlib/misc/UdpMonitor.h>
#include <hphlib/util.h>
#include <telemetry/Runner.h>

static_assert(BYTE_ORDER == LITTLE_ENDIAN, "iXCOM framework only targets little endian");

void static_align(InsComHelper& com, int initial_heading, int initial_heading_std_dev) {
    // 2. Start static alignment

    // Stop any ongoing alignment

    com.issueCommand("Stop alignment", [] (auto& com) {
        return com.createMsgCmdEKF(XCOMEKF_ALIGNCOMPLETE, 0, nullptr);
    });

    // Configure alignment time to be very long such that INS aligns all the way until start of race

    com.issueCommand("Set alignment time", [] (auto& com) {
        uint32_t align_time = 5 * 60; // in seconds
        return com.createMsgPAREKF_ALIGNTIME(&align_time);
    });

    // Start alignment when ready

    com.issueCommand("Start alignment with startup parameters", [&] (auto& com) {
        // Configure external heading aid
        double startup_dparams[20];
        // TODO: Read housing to vehicle frame and calculate housing rad
        startup_dparams[6] =  initial_heading * M_PI / 180.0; // Heading in rad in housing frame
        startup_dparams[7] =  initial_heading_std_dev * M_PI / 180.0; // stddev in rad

        uint32_t startup_iparams[10];
        startup_iparams[0] =  0; // Position mode: Do not use position
        startup_iparams[1] =  0; // Heading mode: Use external aiding was 0
        startup_iparams[2] =  10; // GNSS timeout: Seconds
        startup_iparams[3] =  0; // ZUPT enable ? (was 1)
        startup_iparams[4] =  1; // Realign: Start realign immediately
        startup_iparams[5] =  0; // In motion: Not in motion
        startup_iparams[6] =  0; // Auto restart: Do not restart

        return com.createMsgPAREKF_STARTUPV2(startup_iparams, startup_dparams);
    });

    ROS_INFO("Started static alignment, do not move vehicle");

    // 3. Await static alignment completion or abort if too long

    std::this_thread::sleep_for(std::chrono::seconds(3)); // TODO: Simulating delay to race
}

void run_main(ros::NodeHandle &n) {

    helloRos();

    telemetry::Runner tele_("ins");

    std::string device_ip = getRequiredRosParam<std::string>(n, "device_ip");
    uint16_t device_port = static_cast<uint16_t>(getRequiredRosParam<int>(n, "device_port"));
    std::string sink_ip = getRequiredRosParam<std::string>(n, "sink_ip");
    uint16_t sink_port = static_cast<uint16_t >(getRequiredRosParam<int>(n, "sink_port"));
    int initial_heading = getRequiredRosParam<int>(n, "initial_heading");
    int initial_heading_std_dev = getRequiredRosParam<int>(n, "initial_heading_std_dev");

    int logging_channel = getRequiredRosParam<int>(n, "logging_channel");
    int control_channel = getRequiredRosParam<int>(n, "control_channel");

    Handler handler(n, "iNat", tele_);

    boost::asio::io_service service;

    constexpr int sys_clock = 500; // Hz
    constexpr int log_divider = sys_clock / 50; // 50 Hz
    constexpr int log_divider_10_hz = sys_clock / 10; // 10 Hz
    constexpr int slow_log_divider = sys_clock / 1; // 1 Hz

    // 1. Configure logging channel
    InsComHelper com(device_ip.c_str(), device_port);

    tele_.report("status", "connect");

    com.ensureOnChannel(control_channel);

    tele_.report("status", "init");

    com.issueCommand("Disable UDP broadcast logging", [&] (auto& com) {
        uint32_t disable_params[3] = {
                static_cast<uint32_t>(logging_channel), // logging channel
                0,               // disable
                sink_port    // receiving port
        };

        return com.createMsgPARXCOM_UDPCONFIG(disable_params, const_cast<char*>(sink_ip.c_str()));
    });

    com.ensureOnChannel(logging_channel);

    com.issueCommand("Clear active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_INSSOL /* don't care */, XCOMLOG_TRIGGER_SYNC /* don't care */, XCOMLOG_ACTION_CLEARALL, log_divider);
    });

    com.issueCommand("Add INSSOL to active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_INSSOL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, log_divider);
    });

    com.issueCommand("Add EKFSSTDDEV2 to active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_EKFSTDDEV2, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, log_divider_10_hz);
    });

    com.issueCommand("Add IMUCAL to active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_IMUCAL, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, log_divider);
    });

    com.issueCommand("Add IMUCOMP to active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_IMUCOMP, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, log_divider);
    });

    com.issueCommand("Add SYSTEMP to active channel log list", [&] (auto& com) {
        return com.createMsgCmdLOG(XCOM_MSGID_MSG_SYS_TEMP, XCOMLOG_TRIGGER_SYNC, XCOMLOG_ACTION_ADD, slow_log_divider);
    });

    static_align(com, initial_heading, initial_heading_std_dev);

    ROS_INFO("Switching to R2D, stopping alignment");

    // Stop alignment, must be stopped before vehicle moves

    com.issueCommand("Stop start-position alignment", [] (auto& com) {
        return com.createMsgCmdEKF(XCOMEKF_ALIGNCOMPLETE, 0, nullptr);
    });

    // Switch back to control channel, must free logging channel to enable UDP broadcast logging on logging channel
    com.ensureOnChannel(control_channel);

    // 6. Enable UDP broadcast for logging channel
    com.issueCommand("Enable UDP broadcast logging", [&] (auto& com) {
        uint32_t params[3] = {
                static_cast<uint32_t>(logging_channel), // logging channel
                1,           // enable
                sink_port    // receiving port
        };

        return com.createMsgPARXCOM_UDPCONFIG(params, const_cast<char*>(sink_ip.c_str()));
    });

    // Go go go

    ROS_INFO("Start driving NOW!!! (please)");

    hphlib::UdpMonitor log_dog(hphlib::UdpSocket(sink_port), "INS log broadcast", 100 /* ms */);
    std::array<char, 256 * 256> buf{};
    size_t rx_count;

    ROS_INFO_STREAM("INS driver listening on port " << sink_port);

    while (ros::ok()) {
        ros::spinOnce();

        try {
            rx_count = log_dog.receive(reinterpret_cast<uint8_t *>(buf.data()), buf.size());

            handler.handlePacket(buf.data(), rx_count);

        } catch (const hphlib::UdpMonitor::TimeoutException&) {
            continue;
        }
    }
}

int main(int argc, char **argv) {

    ros::init(argc, argv, "INS driver");
    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }

    return EXIT_SUCCESS;
}
