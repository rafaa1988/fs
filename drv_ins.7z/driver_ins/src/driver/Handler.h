#pragma once

#include <sensor_msgs/TimeReference.h>
#include <sensor_msgs/NavSatFix.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <telemetry/Runner.h>
#include "../insClass.h"

class Handler {
private:

    void stageStatus(uint16_t status);

    useUdpLogData m_udpLog;
    iXComHandler m_uixcomhandler;

    std::string tf_id_;

    nav_msgs::Odometry firstUTMPos;

    ros::Publisher imuRaw_pub;
    ros::Publisher imuCorr_pub;
    ros::Publisher imuComp_pub;
    ros::Publisher imuCal_pub;
//	ros::Publisher insSolOdom_pub = n.advertise<nav_msgs::Odometry>(
//			"iNAT/ins/odom", 1);
//	ros::Publisher insSolPos_pub = n.advertise<geometry_msgs::PoseStamped>(
//			"iNAT/ins/pose", 1);
    ros::Publisher insSolFix_pub;
    ros::Publisher ins_sol_pub_;
    ros::Publisher insSolVel_pub;
    ros::Publisher insPosLLH_pub;
    ros::Publisher insVelBody_pub;
    ros::Publisher insOdo_pub;
    ros::Publisher insPosECEFodom_pub;
    ros::Publisher insPosUTModom_pub;
    ros::Publisher insPosUTMrelativodom_pub;
    ros::Publisher time_reference_pub;

    float pos_std_dev;
    float vel_std_dev;
    float acc_std_dev;
    float rpy_std_dev;
    float omg_std_dev;
    float lla_std_dev;

    boost::optional<t_XCOM_MSG_EKFSTDDEV2> last_std_devs;
    boost::optional<t_XCOM_MSG_GNSSSOL> last_gps_sol;

    telemetry::Runner* tele_;

    sensor_msgs::Imu buildImuMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header);
    nav_msgs::Odometry buildOdometryMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header);
    sensor_msgs::NavSatFix buildFixMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header);

public:

    Handler(ros::NodeHandle& n, const std::string& transformation_frame, telemetry::Runner& tele);

    static ros::Time convertTimestamp(t_XCOM_Header& header);

    void handlePacket(const char* buffer, size_t size);
};