#include "InsComHelper.h"

#include <sstream>

InsComHelper::InsComHelper(const char *device_ip, uint16_t device_port)
    : com_("InsComHelper")
    , active_channel_(-1)
    , device_ip_(device_ip)
    , device_port_(device_port)
{
    // Initially continue
    rx_continue_flag.test_and_set();

    rx_thread = std::thread([this] () {
        com_.parseRxRunData(this->rx_continue_flag);
    });
}

InsComHelper::~InsComHelper() {

    closeActiveChannel();

    // Cooperatively kill rx thread
    rx_continue_flag.clear();

    // Join RX thread which will die shortly
    rx_thread.join();
}

void InsComHelper::ensureOnChannel(int channel) {
    if (active_channel_ == channel) {
        return;
    }

    closeActiveChannel();

    int ret;

    if ((ret = com_.openNConnectSocket(device_ip_.c_str(), device_port_)) != 0) {
        std::stringstream es;
        es << "Failed to open TCP connection to " << device_ip_ << ":" << device_port_;
        throw std::system_error(ret, std::system_category(), es.str());
    }

    issueCommand("Open channel", [channel] (auto& com) {
        return com.createMsgOpenChannel(channel);
    });

    active_channel_ = channel;
}

void InsComHelper::closeActiveChannel() {
    if (active_channel_ >= 0) {
        issueCommand("Close active channel", [this] (auto& com) {
            return com.createMsgCloseChannel(active_channel_);
        });

        active_channel_ = -1;

        com_.closeSocket();
    }
}

void InsComHelper::sendActiveMessage(const char *why) {
    std::array<char, 100> buf{};
    if (com_.sentNConfirmMsg(3'000, buf.data()) != 0) {
        std::stringstream es;
        es << "Failed to issue command for \"" << why << "\": " << buf.data();
        throw std::runtime_error(es.str());
    }
}

