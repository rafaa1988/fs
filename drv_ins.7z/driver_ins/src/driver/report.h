#pragma once

#include <telemetry/Runner.h>

void report(telemetry::Runner& tele, const char* status, )