#include "Handler.h"

#include <cmath>
#include <tf/tf.h>
#include <XComHandler_CSDK_EXT/XCOMtypes.h>
#include <hphlib/util.h>

Handler::Handler(ros::NodeHandle &n, const std::string& transformation_frame, telemetry::Runner& tele)
    : tf_id_(transformation_frame)
//    , imuRaw_pub(n.advertise<sensor_msgs::Imu>("iNAT/imu/Raw", 1000))
//    , imuCorr_pub(n.advertise<sensor_msgs::Imu>("iNAT/imu/Corr", 1))
    , imuComp_pub(n.advertise<sensor_msgs::Imu>("iNAT/imu/Comp", 1))
    , imuCal_pub(n.advertise<sensor_msgs::Imu>("iNAT/imu/Cal", 1))
    , insSolFix_pub(n.advertise<sensor_msgs::NavSatFix>("fix", 1))
    , ins_sol_pub_(n.advertise<sensor_msgs::Imu>("imu", 1))
    , insSolVel_pub(n.advertise<geometry_msgs::Twist>("iNAT/ins/SolVel", 1))
    , insPosLLH_pub(n.advertise<sensor_msgs::NavSatFix>("iNAT/ins/PosLLH", 1))
    , insOdo_pub(n.advertise<nav_msgs::Odometry>("odometry", 1))
//    , insVelBody_pub(n.advertise<geometry_msgs::Twist>("iNAT/ins/VelBody", 1))
//    , insPosECEFodom_pub(n.advertise<nav_msgs::Odometry>("iNAT/ins/PosECEF/odom", 1))
//    , insPosUTModom_pub(n.advertise<nav_msgs::Odometry>("iNAT/ins/PosUTM/odom", 1))
//    , insPosUTMrelativodom_pub(n.advertise<nav_msgs::Odometry>("iNAT/ins/PosUTM/relativodom", 1))
//    , time_reference_pub(n.advertise<sensor_msgs::TimeReference>("iNAT/time_reference", 1))
    , pos_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "pos_std_dev")))
    , vel_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "vel_std_dev")))
    , acc_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "acc_std_dev")))
    , rpy_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "rpy_std_dev")))
    , omg_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "omg_std_dev")))
    , lla_std_dev(static_cast<float>(getRequiredRosParam<double>(n, "lla_std_dev")))
    , tele_(&tele)
{
}

ros::Time Handler::convertTimestamp(t_XCOM_Header& header) {
    ros::Time t;
    t.sec = header.uiGpsTime_sec;
    t.nsec = header.uiGpsTime_usec / 1'000;
    return t;
}

void Handler::handlePacket(const char *buffer, size_t size) {

    for (size_t i = 0; i < size; i++) {

        iXComHandler::iXComReceiveDataReady recvReady =
                m_uixcomhandler.readReceivedXComByte(buffer[i]);

        switch (recvReady) //Here are the data saved receivd by udp
        {
            case (iXComHandler::MSG_IMURAW_Ready): {
                memcpy(&m_udpLog.xcomimuRaw,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_IMURAW),
                       sizeof(t_XCOM_MSG_IMURAW));

                sensor_msgs::Imu imu_raw_data;
                imu_raw_data.header.frame_id = tf_id_;
                imu_raw_data.header.stamp = convertTimestamp(m_udpLog.xcomimuRaw.tHeader);
                imu_raw_data.angular_velocity.x = m_udpLog.xcomimuRaw.fOmg[0];
                imu_raw_data.angular_velocity.y = m_udpLog.xcomimuRaw.fOmg[1];
                imu_raw_data.angular_velocity.z = m_udpLog.xcomimuRaw.fOmg[2];
                imu_raw_data.linear_acceleration.x = m_udpLog.xcomimuRaw.fAcc[0];
                imu_raw_data.linear_acceleration.y = m_udpLog.xcomimuRaw.fAcc[1];
                imu_raw_data.linear_acceleration.z = m_udpLog.xcomimuRaw.fAcc[2];

                imuRaw_pub.publish(imu_raw_data);

            }
                break;
            case (iXComHandler::MSG_IMUCORR_Ready): {
                memcpy(&m_udpLog.xcomimuCorr,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_IMUCORR),
                       sizeof(t_XCOM_MSG_IMUCORR));

//					ROS_INFO("IMU_CORR_received");

                sensor_msgs::Imu imuCorrData;

                imuCorrData.header.frame_id = tf_id_;
                imuCorrData.header.stamp = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                imuCorrData.angular_velocity.x = m_udpLog.xcomimuCorr.fOmg[0];
                imuCorrData.angular_velocity.y = m_udpLog.xcomimuCorr.fOmg[1];
                imuCorrData.angular_velocity.z = m_udpLog.xcomimuCorr.fOmg[2];
                imuCorrData.linear_acceleration.x = m_udpLog.xcomimuCorr.fAcc[0];
                imuCorrData.linear_acceleration.y = m_udpLog.xcomimuCorr.fAcc[1];
                imuCorrData.linear_acceleration.z = m_udpLog.xcomimuCorr.fAcc[2];

                imuCorr_pub.publish(imuCorrData);

            }
                break;
            case (iXComHandler::MSG_IMUCOMP_Ready): {
                memcpy(&m_udpLog.xcomimuComp,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_IMUCOMP),
                       sizeof(t_XCOM_MSG_IMUCOMP));

                sensor_msgs::Imu imuCompData;

                imuCompData.header.frame_id = tf_id_;
                imuCompData.header.stamp = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                imuCompData.angular_velocity.x = m_udpLog.xcomimuComp.fOmg[0];
                imuCompData.angular_velocity.y = m_udpLog.xcomimuComp.fOmg[1];
                imuCompData.angular_velocity.z = m_udpLog.xcomimuComp.fOmg[2];
                imuCompData.linear_acceleration.x = m_udpLog.xcomimuComp.fAcc[0];
                imuCompData.linear_acceleration.y = m_udpLog.xcomimuComp.fAcc[1];
                imuCompData.linear_acceleration.z = m_udpLog.xcomimuComp.fAcc[2];

                imuComp_pub.publish(imuCompData);

            }
                break;
            case (iXComHandler::MSG_IMUCAL_Ready): {
                memcpy(&m_udpLog.xcomimuCal,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_IMUCAL),
                       sizeof(t_XCOM_MSG_IMUCAL));

                sensor_msgs::Imu imuCalData;

                imuCalData.header.frame_id = tf_id_;
                imuCalData.header.stamp = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                imuCalData.angular_velocity.x = m_udpLog.xcomimuCal.dOmgCal[0];
                imuCalData.angular_velocity.y = m_udpLog.xcomimuCal.dOmgCal[1];
                imuCalData.angular_velocity.z = m_udpLog.xcomimuCal.dOmgCal[2];
                imuCalData.linear_acceleration.x = m_udpLog.xcomimuCal.dAccCal[0];
                imuCalData.linear_acceleration.y = m_udpLog.xcomimuCal.dAccCal[1];
                imuCalData.linear_acceleration.z = m_udpLog.xcomimuCal.dAccCal[2];

                imuCal_pub.publish(imuCalData);

            }
                break;
            case (iXComHandler::MSG_INSSOL_Ready): {
                memcpy(&m_udpLog.xcominsSol,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_INSSOL),
                       sizeof(t_XCOM_MSG_INSSOL));

                this->stageStatus(m_udpLog.xcominsSol.tBottom.gStatus);

                std_msgs::Header header;
                header.stamp = ros::Time::now();
                header.frame_id = tf_id_;

                sensor_msgs::Imu insSolImuData = buildImuMsg(m_udpLog.xcominsSol, header);
                nav_msgs::Odometry insOdom = buildOdometryMsg(m_udpLog.xcominsSol, header);
                sensor_msgs::NavSatFix insSolFix = buildFixMsg(m_udpLog.xcominsSol, header);

                ins_sol_pub_.publish(insSolImuData);
                insOdo_pub.publish(insOdom);
                insSolVel_pub.publish(insOdom.twist.twist);
                insSolFix_pub.publish(insSolFix);

            }
                break;
            case (iXComHandler::MSG_INSDCM_Ready): {
                memcpy(&m_udpLog.xcominsDCM,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_INSDCM),
                       sizeof(t_XCOM_MSG_INSDCM));

                //what is this?

            }
                break;
            case (iXComHandler::MSG_INSVELBODY_Ready): {
                memcpy(&m_udpLog.xcominsVelBODY,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_INSVELBODY),
                       sizeof(t_XCOM_MSG_INSVELBODY));


                geometry_msgs::Twist insVelBody;

                insVelBody.linear.x = m_udpLog.xcominsVelBODY.fVx;
                insVelBody.linear.y = m_udpLog.xcominsVelBODY.fVy;
                insVelBody.linear.z = m_udpLog.xcominsVelBODY.fVz;

                insVelBody_pub.publish(insVelBody);

            }
                break;

            case (iXComHandler::MSG_EKFSTDDEV2_Ready):
                memcpy(&m_udpLog.xcomEkfStdDev2,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_EKFSTDDEV2),
                       sizeof(t_XCOM_MSG_EKFSTDDEV2));

                last_std_devs = m_udpLog.xcomEkfStdDev2;

                break;

            case (iXComHandler::MSG_INSPOSLLH_Ready): {
                //printf(">%s Rx Udp Data MSG_INSPOSLLH_Ready\n",m_pcModuleID);
                memcpy(&m_udpLog.xcominsPosLLH,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_INSPOSLLH),
                       sizeof(t_XCOM_MSG_INSPOSLLH));

                sensor_msgs::NavSatFix insPosLLH;

                insPosLLH.header.frame_id = tf_id_;
                insPosLLH.header.stamp = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                insPosLLH.altitude = m_udpLog.xcominsPosLLH.fHeight;
                insPosLLH.latitude = m_udpLog.xcominsPosLLH.dLatitude;
                insPosLLH.longitude = m_udpLog.xcominsPosLLH.dLongitude;

                insPosLLH_pub.publish(insPosLLH);

            }
                break;
            case (iXComHandler::MSG_INSPOSECEF_Ready): {
                //printf(">%s Rx Udp Data MSG_INSPOSLLH_Ready\n",m_pcModuleID);
                memcpy(&m_udpLog.xcominsPosECEF,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_INSPOSECEF),
                       sizeof(t_XCOM_MSG_INSPOSECEF));

                nav_msgs::Odometry insPosECEFodom;

                insPosECEFodom.header.frame_id = tf_id_;
                insPosECEFodom.header.stamp = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                insPosECEFodom.pose.pose.position.x = m_udpLog.xcominsPosECEF.dECEF[0];
                insPosECEFodom.pose.pose.position.y = m_udpLog.xcominsPosECEF.dECEF[1];
                insPosECEFodom.pose.pose.position.z = m_udpLog.xcominsPosECEF.dECEF[2];
//						printf("ECEF: %f, %f, %f \n", m_udpLog.xcominsPosECEF.dECEF[0],m_udpLog.xcominsPosECEF.dECEF[1], m_udpLog.xcominsPosECEF.dECEF[2]);

                insPosECEFodom_pub.publish(insPosECEFodom);

            }
                break;
            case (iXComHandler::MSG_EKFSENSORERR_Ready): {
                memcpy(&m_udpLog.xcomEkfError2,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_EKFSENSORERR2),
                       sizeof(t_XCOM_MSG_EKFSENSORERR2));

                //not realy needed...

            }
                break;
            case (iXComHandler::MSG_GNSSSOL_Ready): {
                memcpy(&m_udpLog.xcomgnssSol,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_GNSSSOL),
                       sizeof(t_XCOM_MSG_GNSSSOL));

                last_gps_sol = m_udpLog.xcomgnssSol;
            }
                break;
            case (iXComHandler::MSG_GNSSTIME_Ready): {
                memcpy(&m_udpLog.xcomgnssTime,
                       (const void *) (m_uixcomhandler.getIXComReceivedData()->MSG_GNSSTIME),
                       sizeof(t_XCOM_MSG_GNSSTIME));

                sensor_msgs::TimeReference time_reference;

                time_reference.header.frame_id = tf_id_;
                ros::Time inatTime = convertTimestamp(m_udpLog.xcomimuCorr.tHeader);
                time_reference.time_ref =  inatTime;
                time_reference.source  = "inat";

            }
                break;
            case (iXComHandler::MSG_SYS_TEMP_Ready):
                std::memcpy(&m_udpLog.xcomTemp, m_uixcomhandler.getIXComReceivedData()->MSG_SYS_TEMP, sizeof(t_XCOM_MSG_SYS_TEMP));

                tele_->stage("cpu-temp", m_udpLog.xcomTemp.fTemp[4]);

                break;
            case (iXComHandler::FRAMENOTCOMPLETE): {
                // Frame is not complete yet, will be completed when more bytes are parsed, therefore this is normal
            }
                break;
            case (iXComHandler::MSG_GNSSHDG_Ready):
            case (iXComHandler::MSG_POSTPROC_Ready): {
                // Values not used
            }
                break;
            default: {
                ROS_WARN_STREAM("Unknown frame type " << recvReady);
            }
                break;
        }
    }

    tele_->report("status", "running");
}

sensor_msgs::Imu Handler::buildImuMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header) {
    sensor_msgs::Imu imu;

    imu.header = header;

    imu.angular_velocity.x = ins_sol.fOmg[0];
    imu.angular_velocity.y = ins_sol.fOmg[1];
    imu.angular_velocity.z = ins_sol.fOmg[2];
    imu.linear_acceleration.x = ins_sol.fAcc[0];
    imu.linear_acceleration.y = ins_sol.fAcc[1];
    imu.linear_acceleration.z = ins_sol.fAcc[2];

    tf::Quaternion q;
    q.setRPY(ins_sol.fRPY[0], ins_sol.fRPY[1], ins_sol.fRPY[2]);
    imu.orientation.w = q.w();
    imu.orientation.x = q.x();
    imu.orientation.y = q.y();
    imu.orientation.z = q.z();

    if (last_std_devs &&
        (*last_std_devs).fMaOmg[0] > 0 &&
        (*last_std_devs).fMaAcc[0] > 0 &&
        (*last_std_devs).fRpy[0] > 0) {
        imu.angular_velocity_covariance = hphlib::buildCovMat3((*last_std_devs).fMaOmg[0],
                                                               (*last_std_devs).fMaOmg[1],
                                                               (*last_std_devs).fMaOmg[2]);
        imu.linear_acceleration_covariance = hphlib::buildCovMat3((*last_std_devs).fMaAcc[0],
                                                                  (*last_std_devs).fMaAcc[1],
                                                                  (*last_std_devs).fMaAcc[2]);
        imu.orientation_covariance = hphlib::buildCovMat3((*last_std_devs).fRpy[0],
                                                          (*last_std_devs).fRpy[1],
                                                          (*last_std_devs).fRpy[2]);
    } else {
        imu.angular_velocity_covariance = hphlib::buildCovMat3(omg_std_dev);
        imu.linear_acceleration_covariance = hphlib::buildCovMat3(acc_std_dev);
        imu.orientation_covariance = hphlib::buildCovMat3(rpy_std_dev);
    }

    return imu;
}

nav_msgs::Odometry Handler::buildOdometryMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header) {
    nav_msgs::Odometry odom;

    odom.header = header;

    odom.child_frame_id = header.frame_id;

    odom.twist.twist.linear.x = ins_sol.fVel[0];
    odom.twist.twist.linear.y = ins_sol.fVel[1];
    odom.twist.twist.linear.z = ins_sol.fVel[2];

    odom.twist.twist.angular.x = ins_sol.fOmg[0];
    odom.twist.twist.angular.y = ins_sol.fOmg[1];
    odom.twist.twist.angular.z = ins_sol.fOmg[2];

    tf::Quaternion q;
    q.setRPY(ins_sol.fRPY[0], ins_sol.fRPY[1], ins_sol.fRPY[2]);
    odom.pose.pose.orientation.w = q.w();
    odom.pose.pose.orientation.x = q.x();
    odom.pose.pose.orientation.y = q.y();
    odom.pose.pose.orientation.z = q.z();

    if (last_std_devs && (*last_std_devs).fVel[0] > 0 && (*last_std_devs).fMaOmg[0] > 0) {
        odom.twist.covariance = hphlib::buildCovMat6((*last_std_devs).fVel[0],
                                                     (*last_std_devs).fVel[1],
                                                     (*last_std_devs).fVel[2],
                                                     (*last_std_devs).fMaOmg[0],
                                                     (*last_std_devs).fMaOmg[1],
                                                     (*last_std_devs).fMaOmg[2]);

        odom.pose.covariance = hphlib::buildCovMat6(0, 0, 0,
                                                    (*last_std_devs).fRpy[0],
                                                    (*last_std_devs).fRpy[1],
                                                    (*last_std_devs).fRpy[2]);
    } else {
        odom.pose.covariance = hphlib::buildCovMat6(0, rpy_std_dev);
        odom.twist.covariance = hphlib::buildCovMat6(vel_std_dev, omg_std_dev);
    }

    return odom;
}

sensor_msgs::NavSatFix Handler::buildFixMsg(t_XCOM_MSG_INSSOL &ins_sol, std_msgs::Header &header) {
    sensor_msgs::NavSatFix fix;

    fix.header = header;

    fix.altitude = ins_sol.fAlt;
    fix.latitude = ins_sol.dPos[1] * 180 / M_PI;
    fix.longitude = ins_sol.dPos[0] * 180 / M_PI;

    if (last_gps_sol && (*last_gps_sol).fStdDevLat > 0) {
        fix.position_covariance_type = fix.COVARIANCE_TYPE_KNOWN;
        fix.position_covariance = hphlib::buildCovMat3((*last_gps_sol).fStdDevLat,
                                                       (*last_gps_sol).fStdDevLon,
                                                       (*last_gps_sol).fStdDevAlt);
    } else {
        fix.position_covariance_type = fix.COVARIANCE_TYPE_APPROXIMATED;
        fix.position_covariance = hphlib::buildCovMat3(lla_std_dev);
    }

    // check if gnss fix (assume we have one if there is no fault)
    if (!static_cast<bool>(ins_sol.tBottom.gStatus & 0x40)) {
        fix.status.status = fix.status.STATUS_FIX;
    }

    return fix;
}


void Handler::stageStatus(uint16_t status) {
    /*if (status & 0x01) {
        tele_.report("hardware-error", "Critical");
    }

    if (status & 0x02) {
        tele_.report("com-error", "Warning");
    }

    if (status & 0x04) {
        tele_.report("nav-error", "Critical");
    }

    if (status & 0x08) {
        tele_.report("calibration-error", "Critical");
    }*/

    // Check accel (0x20) or gyro (0x10) over range
    tele_->stage("range", !static_cast<bool>(status & 0x30));
    tele_->stage("gnss", !static_cast<bool>(status & 0x40));

    /*if (status & 0x80) {
        tele_.report("standby", "Critical");
    }*/
}
