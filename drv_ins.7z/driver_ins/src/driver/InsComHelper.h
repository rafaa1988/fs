#pragma once

#include <insClass.h>
#include <ros/ros.h>
#include <sstream>

/**
 * Helper for managing the state of InsCom objects and error reporting
 */
class InsComHelper {
    insCom com_;
    int active_channel_;
    std::string device_ip_;
    uint16_t device_port_;

    std::thread rx_thread;
    std::atomic_flag rx_continue_flag;

public:
    InsComHelper(const char* device_ip, uint16_t device_port);

    InsComHelper(const InsComHelper& that) = delete;
    InsComHelper(InsComHelper&& that) = delete;
    InsComHelper& operator=(const InsComHelper& that) = delete;
    InsComHelper& operator=(InsComHelper&& that) = delete;

    ~InsComHelper();

    /**
     * Closes the active channel, no effect if already closed
     */
    void closeActiveChannel();

    /**
     * Ensure that the active channel is the given channel
     * @param channel Channel
     */
    void ensureOnChannel(int channel);

    /**
     * Issue a command on the active channel by evaluating the given function create an active message, checking
     * for errors, sending the command and awaiting a positive response
     * @tparam Func Functor type equivalent to std::function<int(insCom)>
     * @param why Reason or effect of this command, used for error reporting
     * @param f Functor
     */
    template <typename Func>
    void issueCommand(const char* why, Func f) {

        ROS_INFO_STREAM("Issuing command: " << why);

        insCom& comref(com_);

        if (f(comref) != 0) {
            std::stringstream es;
            es << "Failed to create command message for \"" << why << "\"";
            throw std::runtime_error(es.str());
        }

        sendActiveMessage(why);
    }

    /**
     * Send away the active message of the underlying insCom object
     * @param why Reason or effect of this command, used for error reporting
     */
    void sendActiveMessage(const char* why);
};