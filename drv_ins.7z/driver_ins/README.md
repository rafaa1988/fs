# Inertial navigation system driver for iNat MC200

## Modifications to manufacturer SDK

1. Instead of printing error and returning arbitrary error code on TCP connection error return errno
2. Use atomic flag to cooperatively cancel from rx thread in insCom::parseRxRunData()
3. Remove copy constructor from INS class that doesn't actually copy