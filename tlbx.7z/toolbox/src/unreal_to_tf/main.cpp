#include <eigen3/Eigen/Eigen>
#include <iostream>
#include <tf_conversions/tf_eigen.h>

using namespace Eigen;

constexpr float DEG_TO_RAD = static_cast<const float>(M_PI / 180);

bool promptBool(const char* what) {
    std::string line;

    for (;;) {
        std::cout << what << "?: " << std::flush;

        if (!std::getline(std::cin, line)) {
            throw std::runtime_error("Unexpected end of input stream");
        }

        std::transform(line.begin(), line.end(), line.begin(), ::tolower);

        if (line == "yes" || line == "y" || line == "true") {
            return true;
        } else if (line == "no" || line == "n" || line == "false") {
            return false;
        }
    }
}

float promptFloat(const char* what) {

    std::string line;

    for (;;) {
        std::cout << what << "?: " << std::flush;

        if (!std::getline(std::cin, line)) {
            throw std::runtime_error("Unexpected end of input stream");
        }

        try {
            return std::stof(line);
        } catch (const std::invalid_argument&) {
            std::cout << "Invalid numeric value\n";
        }
    }
}

int main() {
    Quaterniond q;

    std::cout << "Unreal to TF rotator conversion tool\n";
    std::cout << "------------------------------------\n";
    std::cout << "Enter Unreal Engine local rotator: \n";

    // Unreal Engine rotators in degrees, read values from user
    float x_rot_deg = promptFloat("X"); // roll
    float y_rot_deg = -promptFloat("Y"); // pitch, inverted because left <-> right system
    float z_rot_deg = -promptFloat("Z"); // yaw, inverted because left <-> right system
    bool is_cam     = promptBool("Is cam");

    // Convert to radian for quaternion construction
    float x_rot_rad = x_rot_deg * DEG_TO_RAD;
    float y_rot_rad = y_rot_deg * DEG_TO_RAD;
    float z_rot_rad = z_rot_deg * DEG_TO_RAD;

    // Construct quaternion by applying axis rotations in correct Unreal Engine order
    q = AngleAxisd(z_rot_rad, Vector3d::UnitZ()) * AngleAxisd(y_rot_rad, Vector3d::UnitY()) * AngleAxisd(x_rot_rad, Vector3d::UnitX());

    std::cout << "[DEBUG] Quat before cam: x=" << q.x() << ", y=" << q.y() << ", z=" << q.z() << ", w=" << q.w() << "\n";

    if (is_cam) {
        // Optional: Apply camera rotation
        q *= AngleAxisd(-M_PI / 2, Vector3d::UnitZ()) * AngleAxisd(-M_PI / 2, Vector3d::UnitX());
    }

    q.normalize();

    // Convert Eigen Quaternion to TF quaternion
    tf::Quaternion tf_quat{};
    tf::quaternionEigenToTF(q, tf_quat);

    // Extract rpy values
    double roll, pitch, yaw;
    tf::Matrix3x3(tf_quat).getRPY(roll, pitch, yaw);

    std::cout << "\n ======== TF rotator ======== \n";
    std::cout << "rpy=\"" << roll << " " << pitch << " " << yaw << "\"\n";
}