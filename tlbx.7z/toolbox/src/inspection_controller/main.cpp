#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/Control.h>
#include <hphlib/vehicle/StatusMonitor.h>


ros::Publisher control_pub;

float sine_duration = 5;
float update_frequency = 100;
float inspection_duration = 30;
float target_velocity = 0.5f;

bool first_update = true;
float current_time = 0;

ros::Timer timer;

void timer_callback(const ros::TimerEvent &event) {
    if (first_update) {
        first_update = false;
        return;
    }

    current_time += (event.current_real - event.last_real).toSec();

    hphlib::Control control;
    control.steering_angle = std::sin(current_time * 2 * M_PI / sine_duration) * 30;
    control.target_velocity = target_velocity;

    if (current_time >= inspection_duration) {
        control.finish_mission = true;
    }

    control_pub.publish(control);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "control_switch");
    ros::NodeHandle n("~");

    control_pub = n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "control_topic"), 1);
    sine_duration = getRequiredRosParam<double, float>(n, "sine_duration");
    update_frequency = getRequiredRosParam<double, float>(n, "update_frequency");
    inspection_duration = getRequiredRosParam<double, float>(n, "inspection_duration");
    target_velocity = getRequiredRosParam<double, float>(n, "target_velocity");

    hphlib::vehicle::StatusMonitor vehicle_mon(n);

    // register vehicle status callbacks
    vehicle_mon.set_go_callback([&] () {
        timer = n.createTimer(ros::Duration(1.0f / update_frequency), timer_callback);
    });

    ros::spin();
}
