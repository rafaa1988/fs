#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <cv_bridge/cv_bridge.h>

#include "exportCone.h"

/**
 * Aspect ratio of cone (width / height)
 */
constexpr float CONE_AR = 23.0f / 32.0f;

struct Settings {
    bool single_cone_images;
    bool cones_on_black;
    bool cones_birds_eye;
    bool only_background;
    float max_distance;
};


int main(int argc, char** argv) {
    ros::init(argc, argv, "ConeExport");
    ros::NodeHandle n("~");

    // get Params
    std::string output_folder       = getRequiredRosParam<std::string>(n, "output_folder_path");
    std::string topic_sub_img       = getRequiredRosParam<std::string>(n, "topic_sub_cam_img");
    std::string topic_sub_info      = getRequiredRosParam<std::string>(n, "topic_sub_cam_info");
    std::string topic_sub_cones_map = getRequiredRosParam<std::string>(n, "topic_sub_cones_map");

    Settings s{};
    s.single_cone_images            = getRequiredRosParam<bool>(n, "single_cone_images");
    s.cones_on_black                = getRequiredRosParam<bool>(n, "cones_on_black");
    s.cones_birds_eye               = getRequiredRosParam<bool>(n, "cones_birds_eye");
    s.max_distance                  = getRequiredRosParam<float>(n, "max_distance");

    size_t coneCounter = findLowestAvailableConeNumber(output_folder + "/single/");

    ROS_INFO_STREAM("Starting with cone number " << coneCounter);

    size_t frameCounter = 0;

    hphlib::CloudToCameraTransformer<pcl::PointXYZRGBA> t(
            n, topic_sub_img, topic_sub_info, topic_sub_cones_map,
            [&](auto transform) {

                auto CVObj = cv_bridge::toCvCopy(transform.image, "bgr8");
                std::vector<ConeInfo> conesVec;
                for (size_t i = 0; i < transform.transforms.size(); ++i) {

                    auto point = transform.transforms[i];

                    if (point.distance > s.max_distance) {
                        continue;
                    }
                    //determined by trial and error

                    const float width = 3 * 120 / point.distance;

                    ConeInfo coneInfo{};
                    coneInfo.x = static_cast<int>(point.projectedPoint.x);
                    coneInfo.y = static_cast<int>(point.projectedPoint.y);
                    coneInfo.width = static_cast<int>(width);
                    coneInfo.height = static_cast<int>(width / CONE_AR);
                    coneInfo.color = transform.cloud->points[i].rgba;

                    //export cones

                    if (s.single_cone_images) {
                        exportConesWithConeInfo(CVObj->image, coneInfo,
                                                output_folder,
                                                coneCounter);
                    }
                    conesVec.push_back(coneInfo);

                    coneCounter++;
                }

                if (s.cones_on_black) {
                    ROS_INFO_STREAM(frameCounter);
                    exportConesOnBlack(CVObj->image, conesVec, output_folder, frameCounter);
                }

                /*
                if (s.only_background) {
                    exportOnlyBackground(CVObj->image, conesVec, output_folder, frameCounter);
                }
                */

                frameCounter++;

            }
    );



    ROS_INFO("ConeVisualisation node launched, saving to %s", output_folder.c_str());

    ros::spin();

    return EXIT_SUCCESS;
}