#include "exportCone.h"
#include <ros/ros.h>
#include <opencv2/opencv.hpp>
#include <hphlib/pcl.h>
#include <boost/filesystem.hpp>
#include <regex>

constexpr int IMAGE_WIDTH = 23*3;
constexpr int IMAGE_HEIGHT = 32*3;

/**
 * exports all cones as single jpgs
 * @param CVObjRef
 * @param CInfo
 * @param output_folder
 * @param coneNumber
 */
void exportConesWithConeInfo(cv::Mat &CVObjRef, const struct ConeInfo &CInfo, const std::string& output_folder, size_t coneNumber) {

    //ROS_INFO_STREAM("Cone " << coneNumber << ": " << CInfo.x << ", " << CInfo.y << ", " << CInfo.height << ", " << CInfo.width);

    //discard if cone is out of frame
    if ((CInfo.x-CInfo.width/2) < 0 ||
            (CInfo.x+CInfo.width/2) >= CVObjRef.cols ||
            (CInfo.y-CInfo.height/2) < 0 ||
            (CInfo.y+CInfo.height/2) >= CVObjRef.rows) {
        return;
    }

    std::stringstream file_path;

    file_path << output_folder << "/single/";

    if (!boost::filesystem::exists(file_path.str())) {
        if (!boost::filesystem::create_directories(file_path.str())) {
            ROS_ERROR_STREAM("Failed to create output folder: " << file_path.str());
            return;
        }
    }

    file_path <<  "cone_" << coneNumber << "_";

    cv::Mat croppedImage = CVObjRef(cv::Rect(CInfo.x - CInfo.width/2,
                                             CInfo.y - CInfo.height/2,
                                             CInfo.width,
                                             CInfo.height)).clone();

    assert(croppedImage.rows == CInfo.height);
    assert(croppedImage.cols == CInfo.width);

    if (hphlib::sameRgb(CInfo.color, hphlib::REF_COLOR_RED)) {
        file_path << "red";
    } else if (hphlib::sameRgb(CInfo.color, hphlib::REF_COLOR_BLUE)) {
        file_path << "blue";
    } else if (hphlib::sameRgb(CInfo.color, hphlib::REF_COLOR_YELLOW)) {
        file_path << "yellow";
    } else if (hphlib::sameRgb(CInfo.color, hphlib::REF_COLOR_FINISH)) {
        file_path << "finish";
    } else {
        ROS_ERROR_STREAM("No matching color for cone! Color was " << std::hex << CInfo.color);
        file_path << "unknown";
    }

    file_path << ".jpg";

    cv::Size size(IMAGE_WIDTH, IMAGE_HEIGHT);
    cv::resize(croppedImage, croppedImage, size);

    if (!cv::imwrite(file_path.str(), croppedImage)) {
        ROS_ERROR_STREAM("Failed to write image to " << file_path.str());
        return;
    }
}


/**
 * draws a black image with colored cones as rectangles
 * @param CVObjRef input image (for size)
 * @param CInfo cone positions
 * @param output out directory
 * @param imageNumber for file name
 */
void exportConesOnBlack(cv::Mat &CVObjRef, const std::vector<ConeInfo>& cones, const std::string &output, size_t imageNumber) {

    std::stringstream file_path;
    file_path << output << "/black/";
    if (!boost::filesystem::exists(output.c_str())) {
        boost::filesystem::create_directories(output.c_str());
    }

    file_path << imageNumber << ".jpg";

    //create black image
    cv::Mat image(CVObjRef.rows, CVObjRef.cols, CV_8UC3, cv::Scalar(0, 0, 0));

    for (auto &cone : cones) {

        //discard if cone is out of frame
        if ((cone.x-cone.width/2) < 0 ||
                (cone.x+cone.width/2) >= CVObjRef.cols ||
                (cone.y-cone.height/2) < 0 ||
                (cone.y+cone.height/2) >= CVObjRef.rows) {
            continue;
        }

        //rectangle around cone
        cv::Rect rect(cone.x - cone.width/2,
                 cone.y - cone.height/2,
                 cone.width,
                 cone.height);

        cv::Scalar color(hphlib::rgbBlue(cone.color),
                         hphlib::rgbGreen(cone.color),
                         hphlib::rgbRed(cone.color),
                         hphlib::rgbAlpha(cone.color));

        //draw filled rectangle in color of each cone on black image
        cv::rectangle(image, rect, color, CV_FILLED);
    }

    cv::imwrite(file_path.str(), image);

    ROS_INFO_STREAM("Exported: " << file_path.str() << std::endl);
}

size_t findLowestAvailableConeNumber(const std::string &folder) {

    std::regex re("cone_([0-9]+)_(blue|yellow|red|finish)\\.jpg");
    std::cmatch m;

    size_t result = 0;

    for (const auto& entry : boost::make_iterator_range(boost::filesystem::directory_iterator(folder))) {

        std::string file_name = static_cast<boost::filesystem::path>(entry).filename().string();

        if (std::regex_match(file_name.c_str(), m, re)) {
            size_t no = std::stoull(m[1]);

            result = std::max(result, no + 1);
        }

    }

    return result;
}


#ifdef TEST
/**
 * draws a black image with colored cones as rectangles
 * @param CVObjRef input image (for size)
 * @param CInfo cone positions
 * @param output out directory
 * @param imageNumber for file name
 */
void exportOnlyBackground(cv::Mat &CVObjRef, const std::vector<ConeInfo>& cones, const std::string &output, size_t imageNumber) {

    std::stringstream file_path;
    file_path << output << "/background/";
    if (!boost::filesystem::exists(output.c_str())) {
        boost::filesystem::create_directories(output.c_str());
    }

    file_path << imageNumber << ".jpg";

    //create black image
    cv::Mat image(CVObjRef.rows, CVObjRef.cols, CV_8UC3, cv::Scalar(0, 0, 0));


    for (auto &cone : cones) {

        //discard if cone is out of frame
        if ((cone.x-cone.width/2) < 0 ||
            (cone.x+cone.width/2) >= CVObjRef.cols ||
            (cone.y-cone.height/2) < 0 ||
            (cone.y+cone.height/2) >= CVObjRef.rows) {
            return;
        }

        //rectangle around cone
        cv::Rect rect(cone.x - cone.width/2,
                      cone.y - cone.height/2,
                      cone.width,
                      cone.height);

        cv::Scalar color(hphlib::rgbBlue(cone.color),
                         hphlib::rgbGreen(cone.color),
                         hphlib::rgbRed(cone.color),
                         hphlib::rgbAlpha(cone.color));

        //draw filled rectangle in color of each cone on black image
        cv::rectangle(image, rect, color, CV_FILLED);

    }

    cv::imwrite(file_path.str(), image);

    ROS_INFO_STREAM("Exported: " << file_path.str() << std::endl);
}

#endif