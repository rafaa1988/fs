#pragma once
#include <opencv/cv.h>
#include <cv_bridge/cv_bridge.h>
#include <array>
#include <string>

struct ConeInfo {
    int x;
    int y;
    int width;
    int height;
    uint32_t color;
    std::string text_top;
    std::string text_bottom;
};

void exportConesWithConeInfo(cv::Mat &CVObjRef, const struct ConeInfo &CInfo, const std::string& output_folder, size_t coneNumber);
void exportConesOnBlack(cv::Mat &CVObjRef, const std::vector<ConeInfo>& cones, const std::string &output, size_t imageNumber);
//void exportOnlyBackground(cv::Mat &CVObjRef, const std::vector<ConeInfo>& cones, const std::string &output, size_t imageNumber);

/**
 * Find the lowest available cone number, that is the lowest number for naming cone export files that has no numbers
 * used equal or larger to it
 * @param folder Output folder for single cone images
 * @return Lowest available index
 */
size_t findLowestAvailableConeNumber(const std::string &folder);
