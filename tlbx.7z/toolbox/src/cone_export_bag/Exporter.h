#pragma once

#include <string>

#include <opencv/cv.h>

class Exporter {
public:

    bool create_class_folders_ = true;

    enum class Classification {
        Red, Yellow, Blue, Finish, NoCone
    };

    static Classification fromRgba(uint32_t rgba);

private:
    static void ensureFolder(const std::string& path);

    static size_t findLowestAvailableConeNumber(const std::string &folder);

    std::string root_path_;
    std::string bag_root_path_;
    size_t running_index_;

public:

    enum class OnBagChangeAction {
        Continue, Skip
    };

    explicit Exporter(const std::string& root_path);

    void exportImg(const cv::Mat& img, Classification classification);

    size_t index() const;

    OnBagChangeAction notifyBagChange(const std::string& path);

    void exportImageWithSteeringAndThrottle(cv::Mat &img, float steering_angle, float throttle, std::string topic);
};