#include <boost/program_options.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <tf/transform_listener.h>
#include <tf2_msgs/TFMessage.h>
#include <sensor_msgs/CameraInfo.h>
#include <pcl_ros/point_cloud.h>
#include <hphlib/misc/CloudToCameraTransformer.h>

#include <hphlib/misc/FastPlayback.h>
#include "ExportHandler.h"
#include "../cone_export/exportCone.h"


int main(int argc, char** argv) {

    bool show_help = false;

    ExportHandler::Settings settings;
    settings.export_size = 32;
    settings.max_distance = 15.0f;
    settings.x_std = 0.1f;
    settings.y_std = 0.1f;
    settings.z_std = 0.05f;
    settings.steering = false;
    settings.topdown = false;

    boost::program_options::options_description desc("Options");

    std::string out_path;
    std::vector<std::string> bags;

    desc.add_options()
            ("help,h", boost::program_options::bool_switch(&show_help), "Show help")
            ("out,o", boost::program_options::value<std::string>(&out_path)->required(), "Path to output folder")
            ("bag,b", boost::program_options::value<std::vector<std::string>>(&bags)->required(), "Bag files to read")
            ("xstd", boost::program_options::value<float>(&settings.x_std), "Standard deviation x")
            ("ystd", boost::program_options::value<float>(&settings.y_std), "Standard deviation y")
            ("zstd", boost::program_options::value<float>(&settings.z_std), "Standard deviation z")
            ("size", boost::program_options::value<int>(&settings.export_size), "Export width and height in pixels")
            ("maxdist", boost::program_options::value<float>(&settings.max_distance), "Maximum distance to cone in meters")
            ("steering,s", boost::program_options::bool_switch(&settings.steering), "Export cones on black with steering angle and throttle")
            ("top-down,t", boost::program_options::bool_switch(&settings.topdown), "Export cones from birds eye view");

    // Treat all positional arguments as bag argument
    boost::program_options::positional_options_description positional;
    positional.add("bag", -1);

    boost::program_options::variables_map vm;

    try {
        boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(desc).positional(positional).run(), vm);

        if (show_help) {
            std::cout << "Usage: " << argv[0] << " OPTIONS BAG1 [BAG2 [..]]\n" << desc;
            return EXIT_SUCCESS;
        }

        boost::program_options::notify(vm);
    } catch (const std::exception& e) {
        std::cerr << "Error parsing arguments: " << e.what() << "\n\n"
                  << "Usage: " << argv[0] << " OPTIONS BAG1 [BAG2 [..]]\n" << desc;
        return EXIT_FAILURE;
    }

    settings.exporter = std::make_shared<Exporter>(out_path);

    ros::init(argc, argv, "cone_export_bag");
    std::shared_ptr<ros::NodeHandle> nh = std::make_shared<ros::NodeHandle>("~");

    std::unique_ptr<ExportHandler> left;
    std::unique_ptr<ExportHandler> right;

    if (settings.steering || settings.topdown) {

        std::cout << "Exporting cone images with steering angle and throttle" << std::endl;
        settings.exporter->create_class_folders_ = false;

        left = std::make_unique<ExportHandler>(*nh, "/master/image_raw", "/master/camera_info", "/ref/cones/cones_map/steering",
                           "/ref/cones/cones_map/throttle",  settings);

    } else {

        std::cout << "Starting with cone number " << settings.exporter->index() << std::endl;

        left = std::make_unique<ExportHandler>(*nh, "/master/image_raw", "/master/camera_info", settings);
        right = std::make_unique<ExportHandler>(*nh, "/slave1/image_raw", "/slave1/camera_info", settings);
    }


    hphlib::FastPlayback playback(nh);

    playback.addTopic<tf2_msgs::TFMessage>("/tf_static");
    playback.addTopic<sensor_msgs::Image>("/master/image_raw");
    playback.addTopic<sensor_msgs::Image>("/slave1/image_raw");
    playback.addTopic<sensor_msgs::CameraInfo>("/master/camera_info");
    playback.addTopic<sensor_msgs::CameraInfo>("/slave1/camera_info");
    playback.addTopic<pcl::PointCloud<pcl::PointXYZRGB>>("/ref/cones/cones_map/cones_map");

    if (settings.steering || settings.topdown) {
        playback.addTopic<std_msgs::Float32>("/ref/cones/cones_map/steering");
        playback.addTopic<std_msgs::Float32>("/ref/cones/cones_map/throttle");
    }

    int i = 1;
    for (const auto& bag_path : bags) {

        if (!ros::ok()) {
            ROS_ERROR("ROS is no longer okay");
            return EXIT_FAILURE;
        }

        size_t start = settings.exporter->index();

        if (settings.exporter->notifyBagChange(bag_path) == Exporter::OnBagChangeAction::Skip) {
            ROS_INFO_STREAM("Skipping bag " << bag_path);
            continue;
        }

        ROS_INFO_STREAM("(" << i << "/" << bags.size() << ") " <<  "Reading " << bag_path << "...");
        i++;

        rosbag::Bag bag(bag_path);
        playback.play(bag);

        ROS_INFO_STREAM("Exported " << (settings.exporter->index() - start) << " images");
    }
}