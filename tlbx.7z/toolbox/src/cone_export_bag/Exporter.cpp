#include "Exporter.h"

#include <regex>

#include <boost/filesystem.hpp>
#include <boost/range/iterator_range.hpp>
#include <opencv2/opencv.hpp>

#include <hphlib/pcl.h>

Exporter::Exporter(const std::string& root_path)
    : root_path_(root_path)
{
    ensureFolder(root_path_);

    running_index_ = findLowestAvailableConeNumber(root_path_);
}

size_t Exporter::findLowestAvailableConeNumber(const std::string &folder) {

    std::regex re("([0-9]+)\\.jpg");
    std::cmatch m;

    size_t result = 0;

    for (const auto& entry : boost::make_iterator_range(boost::filesystem::recursive_directory_iterator(folder))) {

        std::string file_name = static_cast<boost::filesystem::path>(entry).filename().string();

        if (std::regex_match(file_name.c_str(), m, re)) {
            size_t no = std::stoull(m[1]);

            result = std::max(result, no + 1);
        }

    }

    return result;
}

void Exporter::ensureFolder(const std::string &path) {
    if (!boost::filesystem::exists(path)) {
        if (!boost::filesystem::create_directories(path)) {
            if (!boost::filesystem::exists(path)) {
                throw std::runtime_error("Failed to create folder " + path);
            }
        }
    }
}

void Exporter::exportImg(const cv::Mat &img, Exporter::Classification classification) {
    std::string folder = bag_root_path_ + "/";

    switch (classification) {
        case Classification::Red:
            folder += "red";
            break;
        case Classification::Blue:
            folder += "blue";
            break;
        case Classification::Yellow:
            folder += "yellow";
            break;
        case Classification::Finish:
            folder += "finish";
            break;
        case Classification::NoCone:
            folder += "nocone";
            break;
    }

    std::stringstream path_stream;
    path_stream << folder << "/" << running_index_++ << ".jpg";

    cv::imwrite(path_stream.str(), img);
}


void Exporter::exportImageWithSteeringAndThrottle(cv::Mat &img, float steering_angle, float throttle, std::string topic) {
    std::replace(topic.begin(), topic.end(), '/', '_');
    std::string folder = bag_root_path_ + topic + "/";
    ensureFolder(folder);

    std::stringstream path_stream;
    path_stream << folder << running_index_++ << ".png";

    // append angle to csv file
    std::ofstream steering_outfile;
    steering_outfile.open(folder + "../labels.csv", std::ios_base::app);
    steering_outfile << path_stream.str() << ";" << steering_angle << ";" << throttle << ";" << topic << std::endl;

    cv::imwrite(path_stream.str(), img);
}

Exporter::Classification Exporter::fromRgba(uint32_t rgba) {
    if (hphlib::sameRgb(rgba, hphlib::REF_COLOR_RED)) {
        return Classification::Red;
    } else if (hphlib::sameRgb(rgba, hphlib::REF_COLOR_YELLOW)) {
        return Classification::Yellow;
    } else if (hphlib::sameRgb(rgba, hphlib::REF_COLOR_BLUE)) {
        return Classification::Blue;
    } else if (hphlib::sameRgb(rgba, hphlib::REF_COLOR_FINISH)) {
        return Classification::Finish;
    } else {
        throw std::runtime_error("Invalid color constant");
    }
}

size_t Exporter::index() const {
    return running_index_;
}

Exporter::OnBagChangeAction Exporter::notifyBagChange(const std::string &path) {


    // Create folders for subimages
    boost::filesystem::path root(root_path_);

    boost::filesystem::path bag_path(path);

    auto export_path = root / bag_path.filename();

    if (boost::filesystem::exists(export_path)) {
        return OnBagChangeAction::Skip;
    }

    bag_root_path_ = export_path.string();

    if (create_class_folders_) {
        auto classes = {"red", "blue", "yellow", "finish", "nocone"};

        for (const auto &clazz : classes) {
            auto folder_path = export_path / clazz;

            ensureFolder(folder_path.string());
        }
    }

    return OnBagChangeAction::Continue;
}
