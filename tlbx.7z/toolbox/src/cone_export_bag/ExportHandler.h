#pragma once

#include <random>

#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <image_geometry/pinhole_camera_model.h>
#include <pcl_ros/point_cloud.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <tf/transform_listener.h>
#include <hphlib/SteeringAngle.h>
#include <hphlib/Throttle.h>
#include <std_msgs/Float32.h>

#include "Exporter.h"
#include "UsageMap.h"

class ExportHandler {
public:

    struct Settings {
        float x_std;
        float y_std;
        float z_std;
        float max_distance;
        std::shared_ptr<Exporter> exporter;
        int export_size;
        bool steering;
        bool topdown;
    };

private:

    using SYNC = message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::CameraInfo, pcl::PointCloud<pcl::PointXYZRGB>>;

    message_filters::Subscriber<sensor_msgs::Image> img_sub_;
    message_filters::Subscriber<sensor_msgs::CameraInfo> info_sub_;
    message_filters::Subscriber<pcl::PointCloud<pcl::PointXYZRGB>> cloud_sub_;
    message_filters::Synchronizer<SYNC> synchronizer_;

    bool exportBinary_ = false;
    bool exportTopdown_ = false;

    cv::Mat binaryImg;
    cv::Mat topdownImg;

    ros::Subscriber steering_sub_;
    ros::Subscriber throttle_sub_;

    float lastReceivedSteeringAngle;
    float lastReceivedThrottle;

    tf::TransformListener tf_listener_;

    std::mt19937 engine_;
    std::normal_distribution<float> x_dist_;
    std::normal_distribution<float> y_dist_;
    std::normal_distribution<float> z_dist_;

    float max_distance_;

    int export_size_;

    std::shared_ptr<Exporter> exporter_;

    UsageMap map_;

public:

    ExportHandler(ros::NodeHandle &n, const std::string &img_topic, const std::string &info_topic,
                  const std::string &steering_topic, const std::string &throttle_topic, const Settings &s);

    ExportHandler(ros::NodeHandle& n, const std::string& img_topic, const std::string& info_topic, const Settings& s);

    // Binding this, don't move or copy
    ExportHandler(const ExportHandler& that) = delete;
    ExportHandler& operator=(const ExportHandler& that) = delete;

    void callback(const sensor_msgs::Image::ConstPtr& img, const sensor_msgs::CameraInfo::ConstPtr& info, const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr& cloud);

    /**
     * Export cone sub images from the given synchronized messages
     * @param img Image message
     * @param info CameraInfo message
     * @param cloud Reference cones message
     */
    void doConeSubimageExport(const sensor_msgs::Image::ConstPtr &img, const sensor_msgs::CameraInfo::ConstPtr &info,
                              const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &cloud);

    void exportConeSubimage(const cv::Mat &img, const tf::Stamped<tf::Point> &point,
                            image_geometry::PinholeCameraModel &model,
                            Exporter::Classification classification);

    void steeringCallback(const std_msgs::Float32::ConstPtr &steering);

    void throttleCallback(const std_msgs::Float32::ConstPtr &throttle);

    void drawRectOnBinaryImg(const cv::Point &pt, float distance, Exporter::Classification classification);

    void drawPointOnTopdownImg(cv::Point3d point3d, float distance, Exporter::Classification classification, int resolution);
};