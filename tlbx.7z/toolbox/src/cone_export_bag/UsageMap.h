#pragma once

#include <random>
#include <set>

class UsageMap {
private:
    std::set<std::pair<int, int>> free_tiles_;
    float tile_size_;
    int max_x_;
    int min_x_;
    int max_y_;
    int min_y_;

    std::mt19937 engine_;

public:
    UsageMap(float min_x, float max_x, float min_y, float max_y, float tile_size);

    void clear();

    std::vector<std::pair<float, float>> getFreeTileCenters(size_t count);

    void remove(float x, float y, float r);
};