#include "ExportHandler.h"

#include <cv_bridge/cv_bridge.h>
#include <image_geometry/pinhole_camera_model.h>
#include <pcl_ros/transforms.h>
#include <hphlib/pcl.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <std_msgs/Float32.h>
#include <validation/shared/shared.h>

ExportHandler::ExportHandler(ros::NodeHandle &n, const std::string &img_topic, const std::string &info_topic,
                             const std::string &steering_topic, const std::string &throttle_topic, const Settings& s)
        : img_sub_(n, img_topic, 2)
        , info_sub_(n, info_topic, 2)
        , cloud_sub_(n, "/ref/cones/cones_map/cones_map", 2)
        , synchronizer_(SYNC(10), img_sub_, info_sub_, cloud_sub_)
        , exportBinary_(s.steering)
        , exportTopdown_(s.topdown)
        , steering_sub_(n.subscribe<std_msgs::Float32>(steering_topic, 1, &ExportHandler::steeringCallback, this))
        , throttle_sub_(n.subscribe<std_msgs::Float32>(throttle_topic, 1, &ExportHandler::throttleCallback, this))
        , x_dist_(0, s.x_std)
        , y_dist_(0, s.y_std)
        , z_dist_(0, s.z_std)
        , max_distance_(s.max_distance)
        , export_size_(s.export_size)
        , exporter_(s.exporter)
        , map_(1.0f, 15.0f, -10.0f, 10.0f, 0.5f)
{
    synchronizer_.registerCallback(&ExportHandler::callback, this);
}

ExportHandler::ExportHandler(ros::NodeHandle &n, const std::string &img_topic, const std::string &info_topic, const Settings& s)
    : ExportHandler(n, img_topic, info_topic, "", "", s) {}

void ExportHandler::steeringCallback(const std_msgs::Float32::ConstPtr &steering) {
    lastReceivedSteeringAngle = steering->data;
}

void ExportHandler::throttleCallback(const std_msgs::Float32::ConstPtr &throttle) {
    lastReceivedThrottle = throttle->data;
}

void ExportHandler::callback(const sensor_msgs::Image::ConstPtr &img, const sensor_msgs::CameraInfo::ConstPtr &info,
                             const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &cloud) {

    // By default export sub images
    if (!exportBinary_ && !exportTopdown_) {
        doConeSubimageExport(img, info, cloud);
        return;
    }

    auto copy = *cloud;

    // Apply random noise to cloud data to simulate lidar inaccuracies, also build tile map
    map_.clear();
    for (auto& pt : copy) {
        map_.remove(pt.x, pt.y, 1.5f);

        pt.x += x_dist_(engine_);
        pt.y += y_dist_(engine_);
        pt.z += z_dist_(engine_);
    }

    // Transform noisy data to camera frame
    pcl::PointCloud<pcl::PointXYZRGB> transformed_cloud;

    if (!pcl_ros::transformPointCloud(info->header.frame_id, copy, transformed_cloud, tf_listener_)) {
        return;
    }

    image_geometry::PinholeCameraModel cam_model;
    cam_model.fromCameraInfo(info);

    auto CVObj = cv_bridge::toCvShare(img, "bgr8");

    if (exportBinary_) {
        //create black image
        binaryImg = cv::Mat(CVObj->image.rows, CVObj->image.cols, CV_8UC3, cv::Scalar(0,0,0));
    }

    if (exportTopdown_) {
        //TODO: parameter
        const int resolution = 10;

        double extraConeProbability = 0.00;
        double undetectedProbability = 0.00;

        std::random_device rd;
        std::mt19937 mt(rd());
        std::uniform_real_distribution<double> dist(0.0, 1.0);

        for (;undetectedProbability < 0.1; undetectedProbability += 0.02) {
            topdownImg = cv::Mat(static_cast<int>(2 * resolution * max_distance_), static_cast<int>(resolution * max_distance_), CV_8UC3, cv::Scalar(0, 0, 0));

            for (const auto& pt : copy) {
                if (dist(mt) > undetectedProbability) {
                    float distance = std::sqrt((pt.x * pt.x) + (pt.y * pt.y) + (pt.z * pt.z));
                    drawPointOnTopdownImg(cv::Point3d(pt.x, pt.y, pt.z), distance, Exporter::fromRgba(pt.rgba), resolution);

                    if (dist(mt) < extraConeProbability) {
                        float x = static_cast<float>(dist(mt) * max_distance_);
                        float y = static_cast<float>((dist(mt) * 2 * max_distance_) - (max_distance_));
                        distance = std::sqrt(x*x + y*y);
                        drawPointOnTopdownImg(cv::Point3d(x, y, 0), distance, Exporter::fromRgba(pt.rgba), resolution);
                    }
                }
            }

            exporter_->exportImageWithSteeringAndThrottle(topdownImg, lastReceivedSteeringAngle, lastReceivedThrottle,
                                                          "TD_un" + img_sub_.getTopic());
        }

        undetectedProbability = 0;
        for (;extraConeProbability < 0.1; extraConeProbability += 0.02) {
            topdownImg = cv::Mat(static_cast<int>(2 * resolution * max_distance_), static_cast<int>(resolution * max_distance_), CV_8UC3, cv::Scalar(0, 0, 0));

            for (const auto& pt : copy) {
                if (dist(mt) > undetectedProbability) {
                    float distance = std::sqrt((pt.x * pt.x) + (pt.y * pt.y) + (pt.z * pt.z));
                    drawPointOnTopdownImg(cv::Point3d(pt.x, pt.y, pt.z), distance, Exporter::fromRgba(pt.rgba), resolution);

                    if (dist(mt) < extraConeProbability) {
                        float x = static_cast<float>(dist(mt) * max_distance_);
                        float y = static_cast<float>((dist(mt) * 2 * max_distance_) - (max_distance_));
                        distance = std::sqrt(x*x + y*y);
                        drawPointOnTopdownImg(cv::Point3d(x, y, 0), distance, Exporter::fromRgba(pt.rgba), resolution);
                    }
                }
            }

            exporter_->exportImageWithSteeringAndThrottle(topdownImg, lastReceivedSteeringAngle, lastReceivedThrottle,
                                                          "TD_ex" + img_sub_.getTopic());
        }


    }

    for (const auto& point : transformed_cloud) {
        cv::Point3d pt3d = cv::Point3d(point.x, point.y, point.z);

        cv::Point projectedPoint = cam_model.project3dToPixel(pt3d);
        float distance = std::sqrt((point.x * point.x) + (point.y * point.y) + (point.z * point.z));

        if (exportBinary_) {
            drawRectOnBinaryImg(projectedPoint, distance, Exporter::fromRgba(point.rgba));
        }
    }

    if (exportBinary_) {
        exporter_->exportImageWithSteeringAndThrottle(binaryImg, lastReceivedSteeringAngle, lastReceivedThrottle,
                                                      img_sub_.getTopic());
    }
}

void ExportHandler::drawRectOnBinaryImg(const cv::Point& pt, float distance, Exporter::Classification classification) {

    // Discard if maximum distance to camera exceeded
    if (distance > max_distance_) {
        return;
    }

    int size = static_cast<int>(4 * 120 / distance);

    // Discard if cone is out of frame
    if ((pt.x - size) < 0 ||
        (pt.x + size) >= binaryImg.cols ||
        (pt.y - size) < 0 ||
        (pt.y + size) >= binaryImg.rows) {
        return;
    }

    if (classification == Exporter::Classification::Blue) {
        cv::rectangle(binaryImg, cv::Rect(pt.x - size / 2, pt.y - size / 2, size, size), cv::Scalar(255, 0, 0), CV_FILLED);
    } else if (classification == Exporter::Classification::Yellow) {
        cv::rectangle(binaryImg, cv::Rect(pt.x - size / 2, pt.y - size / 2, size, size), cv::Scalar(0, 255, 255), CV_FILLED);
    } else if (classification == Exporter::Classification::Red) {
        cv::rectangle(binaryImg, cv::Rect(pt.x - size / 2, pt.y - size / 2, size, size), cv::Scalar(0, 0, 255), CV_FILLED);
    } else if (classification == Exporter::Classification::Finish) {
        cv::rectangle(binaryImg, cv::Rect(pt.x - size / 2, pt.y - size / 2, size, size), cv::Scalar(0, 255, 0), CV_FILLED);
    }
}

void ExportHandler::drawPointOnTopdownImg(cv::Point3d pt, float distance, Exporter::Classification classification, int resolution) {

    bool excludeBlue    = false;
    bool excludeYellow  = false;
    bool excludeRed     = false;
    bool excludeFinish  = false;

    int radius = static_cast<int>(resolution * 0.5);

    // Discard if maximum distance to camera exceeded
    if (distance > max_distance_) {
        return;
    }

    pt.y += max_distance_;
    pt *= resolution;

    cv::Point pixelCoords = cv::Point(static_cast<int>(std::round(pt.x)), static_cast<int>(std::round(pt.y)));

    if (classification == Exporter::Classification::Blue && !excludeBlue) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(255, 0, 0), CV_FILLED);
    } else if (classification == Exporter::Classification::Yellow && !excludeYellow) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 255, 255), CV_FILLED);
    } else if (classification == Exporter::Classification::Red && !excludeRed) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 0, 255), CV_FILLED);
    } else if (classification == Exporter::Classification::Finish && !excludeFinish) {
        cv::circle(topdownImg, pixelCoords, radius, cv::Vec3b(0, 255, 0), CV_FILLED);
    }

    // draw car (approx. 1.2m wide and 2.4m long)
    cv::Point carStart(0, static_cast<int>(resolution * max_distance_) - static_cast<int>(resolution * 0.6));
    cv::Point carEnd(static_cast<int>(resolution * 0.6), static_cast<int>(resolution * max_distance_) + static_cast<int>(resolution * 0.6));
    cv::rectangle(topdownImg, carStart, carEnd, cv::Scalar(255, 255, 255), CV_FILLED);

}

void ExportHandler::exportConeSubimage(const cv::Mat &img, const tf::Stamped<tf::Point> &point,
                                       image_geometry::PinholeCameraModel &model,
                                       Exporter::Classification classification) {
    auto rect = hphlib::spanRectangle(point, hphlib::CLOUD_TO_CAMERA_DEFAULT_BOX_SIZE, model, tf_listener_);

    auto subimg = validation::extractSubImage(img, rect);

    // Discard if cone is out of frame
    if (subimg.empty()) {
        return;
    }

    exporter_->exportImg(subimg, classification);
}

void ExportHandler::doConeSubimageExport(const sensor_msgs::Image::ConstPtr &img,
                                         const sensor_msgs::CameraInfo::ConstPtr &info,
                                         const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &cloud) {

    try {
        auto copy = *cloud;

        // Apply random noise to cloud data to simulate lidar inaccuracies, also build tile map
        map_.clear();
        for (auto &pt : copy) {
            map_.remove(pt.x, pt.y, 1.5f);

            pt.x += x_dist_(engine_);
            pt.y += y_dist_(engine_);
            pt.z += z_dist_(engine_);
        }

        // Initialize camera model
        image_geometry::PinholeCameraModel cam_model;
        cam_model.fromCameraInfo(info);

        // Bridge from ROS to OpenCV
        auto CVObj = cv_bridge::toCvShare(img, "bgr8");

        pcl::PointXYZRGB origin{};

        // Export the reference cones
        for (const auto &point : copy) {
            if (hphlib::distanceSquared<pcl::PointXYZRGB>(point, origin) > max_distance_ * max_distance_) {
                continue;
            }

            tf::Stamped<tf::Point> stamped = {
                    {point.x, point.y, point.z},
                    pcl_conversions::fromPCL(copy.header.stamp),
                    copy.header.frame_id
            };

            exportConeSubimage(CVObj->image, stamped, cam_model, Exporter::fromRgba(point.rgba));
        }

        // ----- Generate none matches -----

        // Request free tiles from tile occupancy map (no cones on these tiles)
        auto free = map_.getFreeTileCenters(5);

        for (const auto &pt : free) {

            // Tiles are 2D and were created in point cloud space. Add zeroed X component and created stamped point in
            // appropriate frame
            tf::Stamped<tf::Point> stamped = {
                    {pt.first, pt.second, 0.0f},
                    pcl_conversions::fromPCL(copy.header.stamp),
                    copy.header.frame_id
            };

            // Export as no cone
            exportConeSubimage(CVObj->image, stamped, cam_model, Exporter::Classification::NoCone);
        }
    } catch (const tf2::LookupException& e) {
        ROS_WARN_STREAM("Error in TF2 lookup, dropping this frame: " << e.what());
    }
}
