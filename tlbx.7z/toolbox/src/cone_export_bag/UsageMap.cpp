#include <cmath>
#include <algorithm>
#include "UsageMap.h"

UsageMap::UsageMap(float min_x, float max_x, float min_y, float max_y, float tile_size)
    : tile_size_(tile_size)
{
    min_x_ = static_cast<int>(min_x / tile_size);
    max_x_ = static_cast<int>(max_x / tile_size);
    min_y_ = static_cast<int>(min_y / tile_size);
    max_y_ = static_cast<int>(max_y / tile_size);
}

void UsageMap::clear() {
    for (int x = min_x_; x <= max_x_; ++x) {
        for (int y = min_y_; y <= max_y_; ++y) {
            free_tiles_.insert(std::make_pair(x, y));
        }
    }
}

void UsageMap::remove(const float x, const float y, const float r) {
    int x_low = static_cast<int>(std::round((x - r) / tile_size_));
    int x_high = static_cast<int>(std::round((x + r) / tile_size_));

    int y_low = static_cast<int>(std::round((y - r) / tile_size_));
    int y_high = static_cast<int>(std::round((y + r) / tile_size_));

    for (int ix = x_low; ix <= x_high; ++ix) {
        for (int iy = y_low; iy <= y_high; ++iy) {
            free_tiles_.erase(std::make_pair(ix, iy));
        }
    }
}

std::vector<std::pair<float, float>> UsageMap::getFreeTileCenters(size_t count) {
    std::vector<std::pair<int, int>> copy;

    std::copy(free_tiles_.begin(), free_tiles_.end(), std::back_inserter(copy));

    std::shuffle(copy.begin(), copy.end(), engine_);

    std::vector<std::pair<float, float>> result;

    for (size_t i = 0; i < std::min(copy.size(), count); ++i) {
        result.push_back(std::make_pair(copy[i].first * tile_size_, copy[i].second * tile_size_));
    }

    return result;
}
