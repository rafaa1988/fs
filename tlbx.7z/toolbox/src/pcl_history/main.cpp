#include <ros/ros.h>
#include <hphlib/util.h>
#include "HistoryListener.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "pcl_history");

    ros::NodeHandle n("~");

    std::string topic_in  = getRequiredRosParam<std::string>(n, "in");
    std::string topic_out = getRequiredRosParam<std::string>(n, "out");
    int         size      = getRequiredRosParam<int>(n, "size");
    std::string mode      = getRequiredRosParam<std::string>(n, "mode");
    auto fixed_frame      = getOptionalRosParam<std::string>(n, "fixed");

    if (mode == "xyz") {
        HistoryListener<pcl::PointXYZ> hl(n, topic_in, topic_out, static_cast<size_t>(size), fixed_frame);
        ros::spin();
    } else if (mode == "xyzrgb") {
        HistoryListener<pcl::PointXYZRGB> hl(n, topic_in, topic_out, static_cast<size_t>(size), fixed_frame);
        ros::spin();
    } else if (mode == "xyzrgba") {
        HistoryListener<pcl::PointXYZRGBA> hl(n, topic_in, topic_out, static_cast<size_t>(size), fixed_frame);
        ros::spin();
    } else {
        throw std::runtime_error("Unsupported mode: " + mode);
    }
}