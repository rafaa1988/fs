# PCL history visualization

Visualize the history of a pointcloud in a fixed tf frame.
All received pointclouds are fist converted to the fixed tf frame, then the last *n* pointclouds are all published as 
one pointcloud in the fixed frame whenever a new pointcloud is received.
This is useful for example to visualize the lidar data of a moving vehicle on the global frame. 

## Parameters
Name  | Meaning
------|---
in    | Topic name of input topic
out   | Topic name of output topic
size  | Size of history in messages
mode  | PCL mode, either "xyz", "xyzrgb" or "xyzrgba"
fixed | Fixed frame name to convert history to, i.e. "0" or "world"
