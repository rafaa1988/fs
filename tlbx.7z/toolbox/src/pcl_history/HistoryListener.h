#pragma once

#include <hphlib/optional.h>
#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include <deque>

template <typename Point>
class HistoryListener {
private:
    ros::Subscriber sub_;
    ros::Publisher  pub_;

    size_t size_;

    std::string frame_;

    std::deque<pcl::PointCloud<Point>> history_;

    tf::TransformListener tf_listener_;

    void callback(const typename pcl::PointCloud<Point>::ConstPtr& msg) {

        // Transform to fixed frame
        history_.emplace_back();
        history_.back().header.stamp = msg->header.stamp;
        history_.back().header.frame_id = frame_;

        if (!pcl_ros::transformPointCloud(frame_, *msg, history_.back(), tf_listener_)) {
            return;
        }

        // Pop from history if too large
        if (history_.size() > size_) {
            history_.pop_front();
        }

        pcl::PointCloud<Point> result;
        result.header = history_.back().header;

        for (const auto& entry : history_) {
            result.insert(result.end(), entry.begin(), entry.end());
        }

        pub_.publish(result);
    }

public:
    HistoryListener(ros::NodeHandle& n, const std::string& in_topic, const std::string& out_topic, size_t size,
                    hphlib::optional<std::string> fixed_frame)
        : sub_(n.subscribe<pcl::PointCloud<Point>>(in_topic, 1, &HistoryListener::callback, this))
        , pub_(n.advertise<pcl::PointCloud<Point>>(out_topic, 1))
        , size_(size)
        , frame_(fixed_frame ? *fixed_frame : "0")
    {
    }

    // Binding this, do not copy or move
    HistoryListener(const HistoryListener& that) = delete;
    HistoryListener& operator=(const HistoryListener& that) = delete;
};