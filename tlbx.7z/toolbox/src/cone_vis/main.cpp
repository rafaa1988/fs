#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/imgcodecs/imgcodecs.hpp>

#include "drawFunc.h"

/**
 * Aspect ratio of cone (width / height)
 */
constexpr float CONE_AR = 23.0f / 32.0f;

int main(int argc, char** argv) {
    ros::init(argc, argv, "ConeVisualisation");
    ros::NodeHandle n("~");

    // get Params
    std::string topic_pub_img       = getRequiredRosParam<std::string>(n, "topic_img_pub");
    std::string topic_sub_img       = getRequiredRosParam<std::string>(n, "topic_img_sub");
    std::string topic_sub_info      = getRequiredRosParam<std::string>(n, "topic_info_sub");
    std::string topic_sub_transform = getRequiredRosParam<std::string>(n, "topic_transform_sub");

    Mode mode = parseMode(getRequiredRosParam<std::string>(n, "mode"));

    bool use_pcl_color = false;
    bool debug_export = false;

    n.getParam("usePclColor", use_pcl_color);
    n.getParam("debug_export", debug_export);

    hphlib::CloudToCameraTransformer<pcl::PointXYZRGBA> t(n, topic_sub_img, topic_sub_info, topic_sub_transform,
       [&, imgPub = n.advertise<sensor_msgs::Image>(topic_pub_img, 1)] (auto transform) {

           auto CVObj = cv_bridge::toCvCopy(transform.image, "bgr8");

           for (size_t index = 0; index < transform.transforms.size(); ++index) {
               const auto& point(transform.transforms[index]);

               ConeInfo coneInfo{};
               coneInfo.x = static_cast<int>(point.projectedPoint.x);
               coneInfo.y = static_cast<int>(point.projectedPoint.y);
               coneInfo.box = point.projectedBox;

               if (use_pcl_color) {
                   coneInfo.color = { (*transform.cloud)[index].b, (*transform.cloud)[index].g, (*transform.cloud)[index].r };
               } else {
                   coneInfo.color = {255, 255, 255};
               }

               drawConeInfo(CVObj->image, coneInfo, mode);
           }

           if (debug_export) {
               // Get namespace in path compatible way
               std::string ns(n.getNamespace());

               for (char& c : ns) {
                   if (c == '/') {
                       c = '_';
                   }
               }

               std::stringstream name;
               name << "/tmp/" << ns << "_" << transform.image->header.seq << ".png";
               cv::imwrite(name.str(), CVObj->image);
           }

           auto msg = CVObj->toImageMsg();

           msg->header = transform.image->header;

           imgPub.publish(msg);
       }, mode != Mode::Point
    );

    ROS_INFO("ConeVisualisation node launched, publish on %s", topic_pub_img.c_str());

    ros::spin();

    return EXIT_SUCCESS;
}
