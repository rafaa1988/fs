#include "drawFunc.h"

Mode parseMode(const std::string& s) {
    if (s == "rect") {
        return Mode::Rect;
    } else if (s == "cross") {
        return Mode::Cross;
    } else if (s == "point") {
        return Mode::Point;
    } else {
        throw std::runtime_error("Unsupported drawing mode: " + s);
    }
}

void drawConeInfo(cv::Mat &CVObjRef, struct ConeInfo &CInfo, Mode mode) {

    cv::Scalar color = cv::Scalar(CInfo.color[0], CInfo.color[1], CInfo.color[2]);

    if (mode == Mode::Rect) {
        cv::rectangle(CVObjRef, CInfo.box.tl(), CInfo.box.br(), color, 2);
    } else if (mode == Mode::Point) {
        cv::Point2i center { CInfo.x, CInfo.y };

        cv::rectangle(CVObjRef, center, center, color, 5);
    } else if (mode == Mode::Cross) {
        cv::Point2d p3 {CInfo.box.x,                       CInfo.box.y + CInfo.box.height / 2};
        cv::Point2d p4 {CInfo.box.x + CInfo.box.width,     CInfo.box.y + CInfo.box.height / 2};
        cv::Point2d p5 {CInfo.box.x + CInfo.box.width / 2, CInfo.box.y                       };
        cv::Point2d p6 {CInfo.box.x + CInfo.box.width / 2, CInfo.box.y + CInfo.box.height    };

        cv::line(CVObjRef, p3, p4, color, 2);
        cv::line(CVObjRef, p5, p6, color, 2);
    }
}

