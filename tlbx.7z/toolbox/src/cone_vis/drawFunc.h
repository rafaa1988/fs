#pragma once
#include <opencv/cv.h>
#include <cv_bridge/cv_bridge.h>
#include <array>
#include <string>

struct ConeInfo {
    int x;
    int y;
    std::array<int, 3> color;
    cv::Rect2d box;
};

enum class Mode {
    Point,
    Rect,
    Cross
};

Mode parseMode(const std::string& s);

void drawConeInfo(cv::Mat &CVObjRef, struct ConeInfo &CInfo, Mode mode);