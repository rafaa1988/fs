#include <ros/ros.h>

#include <chrono>
#include <hphlib/Control.h>
#include <hphlib/util.h>
#include <thread>

int main(int argc, char** argv) {
    ros::init(argc, argv, "test_switches");

    ros::NodeHandle n("~");

    ros::Publisher pub(n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "topic"), 1));

    ROS_WARN("Switch test node is running, do not run on production vehicle");

    ros::SteadyTimerCallback cb = [&n, &pub] (const auto& ev) {
        (void) ev;

        bool asms;

        if (n.getParam("/test/asms", asms)) {
            hphlib::Control control;
            control.header.stamp = ros::Time::now();

            if (asms) {
                control.test_arm = true;
            } else {
                control.test_reset = true;
            }

            // Spam the control message a bit to overshout other controllers,
            // this is poor design :/
            for (int i = 0; i < 20; ++i) {
                pub.publish(control);
                ros::spinOnce();
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }

            n.deleteParam("/test/asms");
        }
    };

    auto timer = n.createSteadyTimer(ros::WallDuration(0.1), cb);

    ros::spin();
}
