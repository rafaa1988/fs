#include <hphlib/Control.h>
#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <std_msgs/Float32.h>
#include <hphlib/util.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "joy_steering");

    ros::NodeHandle n("~");

    std::string topic_joy      = getRequiredRosParam<std::string>(n, "topic_joy");
    int axis_steering          = getRequiredRosParam<int>(n, "axis_steering");
    int axis_cruise            = getRequiredRosParam<int>(n, "axis_cruise");
    bool axis_cruise_invert    = getRequiredRosParam<bool>(n, "axis_cruise_invert");
    bool axis_cruise_remap    = getRequiredRosParam<bool>(n, "axis_cruise_remap");
    int button_cruise          = getRequiredRosParam<int>(n, "button_cruise");
    int button_arm             = getRequiredRosParam<int>(n, "button_arm");
    int button_reset           = getRequiredRosParam<int>(n, "button_reset");
    int button_finish          = getRequiredRosParam<int>(n, "button_finish");
    float angle_max            = getRequiredRosParam<float>(n, "angle_max");
    float cruise_speed         = getRequiredRosParam<float>(n, "cruise_kmh") / 3.6f;
    std::string topic          = getRequiredRosParam<std::string>(n, "topic");

    ros::Publisher pub = n.advertise<hphlib::Control>(topic, 1);

    boost::function<void(const sensor_msgs::Joy::ConstPtr&)> cb = [&] (const sensor_msgs::Joy::ConstPtr& msg) {

        hphlib::Control control;
        control.header.stamp = ros::Time::now();

        control.test_reset = msg->buttons.at(static_cast<unsigned long>(button_reset));
        control.test_arm   = msg->buttons.at(static_cast<unsigned long>(button_arm));
        control.finish_mission = msg->buttons.at(static_cast<unsigned long>(button_finish));

        // Read raw steering angle from controller
        float steering_raw = msg->axes.at(static_cast<unsigned long>(axis_steering));

        // Clamp steering axis ot expected range
        steering_raw = hphlib::clamp(steering_raw, -1.0f, 1.0f);

        // Always invert steering axis for XBOX 360 controller
        steering_raw *= -1.0f;

        // Multiply with angle max and publish
        control.steering_angle = steering_raw * angle_max;

        // If cruise control enabled
        if (msg->buttons.at(static_cast<unsigned long>(button_cruise))) {
            // Read cruise control velocity
            float velocity_raw = msg->axes.at(static_cast<unsigned long>(axis_cruise));

            // Clamp velocity axis to expected range
            velocity_raw = hphlib::clamp(velocity_raw, -1.0f, 1.0f);

            // Remap axis to fit [0.0, 1.0] range from [-1.0, 1.0] range
            if (axis_cruise_remap) {
                velocity_raw = velocity_raw * 0.5f + 0.5f;
            }

            // Axis now 0.0 for fully pressed, 1.0 for idle, invert
            if (axis_cruise_invert) {
                velocity_raw = 1.0f - velocity_raw;
            }

            // ensure the speed is always positive
            velocity_raw = hphlib::clamp(velocity_raw, 0.0f, 1.0f);

            // Multiply with speed limiter
            control.target_velocity = velocity_raw * cruise_speed;
        } else {
            // If cruise control not enabled, stop
            control.target_velocity = 0.0f;
        }

        pub.publish(control);
    };

    ros::Subscriber sub = n.subscribe<sensor_msgs::Joy>(topic_joy, 1, cb);

    ros::spin();
}
