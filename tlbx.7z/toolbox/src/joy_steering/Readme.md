# Joystick control interface driver

This node interfaces with a ROS joy node to publish steering and velocity control messages to the RTCU driver topics.

By default steering angle is mapped to the *left thumb stick* and the *right trigger* controls the velocity of the vehicle,
which will only move if the *A button* is simultaneously pressed to release controllers.

## Parameters
Name           | Meaning
---------------|---
topic_joy      | ROS topic where the `std_msgs::Joy` message containing joystick input is published
axis_steering  | Steering axis index
axis_cruise    | Cruise axis index
button_cruise  | Cruise control button index, unlocks cruise control axis
angle_max      | Maximum steering angle in degrees
cruise_kmh     | Maximum cruise speed in km/h
topic_steering | ROS topic where steering control message is published for RTCU driver
topic_velocity | ROS topic where velocity control message is published for RTCU driver 