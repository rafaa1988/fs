#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/SteeringAngle.h>
#include <hphlib/Throttle.h>
#include <std_msgs/Float32.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "float_to_custom_msg");

    ros::NodeHandle n("~");

    std::string topic_float_steering  = getRequiredRosParam<std::string>(n, "topic_float_steering");
    std::string topic_float_throttle  = getRequiredRosParam<std::string>(n, "topic_float_throttle");
    std::string topic_output_steering  = getRequiredRosParam<std::string>(n, "topic_output_steering");
    std::string topic_output_throttle  = getRequiredRosParam<std::string>(n, "topic_output_throttle");

    ros::Publisher steering_pub(n.advertise<hphlib::SteeringAngle>(topic_output_steering, 1));
    ros::Publisher throttle_pub(n.advertise<hphlib::SteeringAngle>(topic_output_throttle, 1));

    boost::function<void(const std_msgs::Float32::ConstPtr& steering)> handlerSteering = [&] (const std_msgs::Float32::ConstPtr& steering) {

        // Do no work if not needed
        if (steering_pub.getNumSubscribers() == 0) {
            return;
        }

        hphlib::SteeringAngle out_msg;
        out_msg.header.stamp = ros::Time::now();
        out_msg.angle = steering->data;

        steering_pub.publish(out_msg);
    };

    boost::function<void(const std_msgs::Float32::ConstPtr& throttle)> handlerThrottle = [&] (const std_msgs::Float32::ConstPtr& throttle) {

        // Do no work if not needed
        if (throttle_pub.getNumSubscribers() == 0) {
            return;
        }

        hphlib::SteeringAngle out_msg;
        out_msg.header.stamp = ros::Time::now();
        out_msg.angle = throttle->data;

        throttle_pub.publish(out_msg);
    };

    ros::Subscriber sub_steering = n.subscribe<std_msgs::Float32>(topic_float_steering, 1, handlerSteering);
    ros::Subscriber sub_throttle = n.subscribe<std_msgs::Float32>(topic_float_steering, 1, handlerThrottle);

    ros::spin();
}