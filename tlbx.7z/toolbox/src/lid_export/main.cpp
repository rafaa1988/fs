#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <sensor_msgs/LaserScan.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <hphlib/util.h>

typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::LaserScan, sensor_msgs::LaserScan,
        sensor_msgs::LaserScan, sensor_msgs::LaserScan> MySyncPolicy;

void callback(const sensor_msgs::LaserScanConstPtr& l0, const sensor_msgs::LaserScanConstPtr& l1,
              const sensor_msgs::LaserScanConstPtr& l2, const sensor_msgs::LaserScanConstPtr& l3) {
    auto size = l0->ranges.size();

    if (l1->ranges.size() != size || l2->ranges.size() != size || l3->ranges.size() != size) {
        ROS_WARN("Mismatch in laser scan width, skipping this frame");
        return;
    }

    std::vector<float> measurements;
    measurements.reserve(size * 4);

    const sensor_msgs::LaserScan* layers[] = { &*l0, &*l1, &*l2, &*l3 };

    for (const auto& l : layers) {
        for (const auto& p : l->ranges) {
            float v = (p - l->range_min) / (l->range_max - l->range_min);

            measurements.push_back(v);
        }
    }

    ROS_INFO("Received");
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "Lidar export");
    ros::NodeHandle n("~");

    std::string prefix(getRequiredRosParam<std::string>(n, "prefix"));

    message_filters::Subscriber<sensor_msgs::LaserScan> layer0(n, prefix + "0", 1);
    message_filters::Subscriber<sensor_msgs::LaserScan> layer1(n, prefix + "1", 1);
    message_filters::Subscriber<sensor_msgs::LaserScan> layer2(n, prefix + "2", 1);
    message_filters::Subscriber<sensor_msgs::LaserScan> layer3(n, prefix + "3", 1);

    message_filters::Synchronizer<MySyncPolicy> sync(MySyncPolicy(10), layer0, layer1, layer2, layer3);

    sync.registerCallback(boost::bind(&callback, _1, _2, _3, _4));

    ROS_INFO_STREAM("Exporting from " << prefix << "[0-3]...");

    ros::spin();

    return EXIT_SUCCESS;
}