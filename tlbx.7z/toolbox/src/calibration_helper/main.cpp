#include <chrono>
#include <hphlib/pcl.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <thread>
#include <hphlib/util.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "calibration_helper");

    ros::NodeHandle n("~");

    std::string global_frame = getRequiredRosParam<std::string>(n, "global");
    std::string left_frame   = getRequiredRosParam<std::string>(n, "left");
    std::string right_frame  = getRequiredRosParam<std::string>(n, "right");

    ros::Publisher pub = n.advertise<pcl::PointCloud<pcl::PointXYZ>>("ref", 1);

    tf::TransformListener tf;

    // Reference grid of object position relative to the origin of the left sensor on its local translation but not
    // rotation
    std::vector<pcl::PointXYZ> relative_left_grid = {
            { 1.0f, 1.0f, 0.0f},
            { 3.0f, 1.0f, 0.0f},
            { 5.0f, 1.0f, 0.0f},
            { 5.0f, 2.0f, 0.0f},
            { 5.0f, 3.0f, 0.0f},
            { 5.0f, 4.0f, 0.0f},
            { 5.0f, 5.0f, 0.0f},
            { 7.0f, 1.0f, 0.0f},
            {10.0f, 1.0f, 0.0f},
            {10.0f, 2.0f, 0.0f},
            {10.0f, 3.0f, 0.0f},
            {10.0f, 4.0f, 0.0f},
            {10.0f, 5.0f, 0.0f},
    };

    // Create local grid for right calibration by mirroring left grid
    std::vector<pcl::PointXYZ> relative_right_grid;

    std::transform(relative_left_grid.begin(), relative_left_grid.end(), std::back_inserter(relative_right_grid),
                   [] (const auto& pt) -> pcl::PointXYZ {
                       return {pt.x, -pt.y, pt.z};
                   });

    // Point cloud storing the origin of the left sensor in the sensor's local frame
    pcl::PointCloud<pcl::PointXYZ> local_left_origin;
    local_left_origin.push_back({0.0f, 0.0f, 0.0f});
    local_left_origin.header.frame_id = left_frame;

    // Point cloud storing the origin of the right sensor in the sensor's local frame
    pcl::PointCloud<pcl::PointXYZ> local_right_origin;
    local_right_origin.push_back({0.0f, 0.0f, 0.0f});
    local_right_origin.header.frame_id = right_frame;

    // Temporary cloud, stores the position of the current sensor mount point in the global frame
    pcl::PointCloud<pcl::PointXYZ> temp_cloud;

    auto next_clock = std::chrono::steady_clock::now();

    while (ros::ok()) {

        pcl::PointCloud<pcl::PointXYZ> global_grid;
        global_grid.header.frame_id = global_frame;
        global_grid.header.stamp = pcl_conversions::toPCL(ros::Time::now());

        if (pcl_ros::transformPointCloud(global_frame, local_left_origin, temp_cloud, tf)) {
            for (const auto& pt : relative_left_grid) {
                global_grid.push_back(temp_cloud[0] + pt);
            }
        }

        if (pcl_ros::transformPointCloud(global_frame, local_right_origin, temp_cloud, tf)) {
            for (const auto& pt : relative_right_grid) {
                global_grid.push_back(temp_cloud[0] + pt);
            }
        }

        pub.publish(global_grid);

        // Sleep 80 ms which is equivalent to 12.5 Hz, this topic is synchronized with cameras
        next_clock += std::chrono::milliseconds(80);
        std::this_thread::sleep_until(next_clock);

        ros::spinOnce();
    }
}
