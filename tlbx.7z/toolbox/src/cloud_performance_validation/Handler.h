#pragma once

#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <pcl_ros/point_cloud.h>
#include <tf/transform_listener.h>

class Handler {
private:

    using Cloud    = pcl::PointCloud<pcl::PointXYZRGB>;
    using CloudPtr = typename Cloud::ConstPtr;

    using SYNC = message_filters::sync_policies::ApproximateTime<Cloud, Cloud>;

    tf::TransformListener tf_listener_;

    message_filters::Subscriber<Cloud> reference_sub_;
    message_filters::Subscriber<Cloud> testee_sub_;

    bool must_match_rgb_;

    std::vector<std::pair<double, double>> precision_recall_history_;

    // TODO: Software can reach better results by dropping frames if using Approx Sync Policy
    message_filters::Synchronizer<SYNC> synchronizer_;

public:

    explicit Handler(ros::NodeHandle& n);

    void callback(const CloudPtr& reference, const CloudPtr& testee);
};