#include "Handler.h"

#include <hphlib/pcl.h>
#include <hphlib/util.h>
#include <pcl_ros/transforms.h>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/plot.hpp>

constexpr float MAX_DISTANCE_SQUARED = 1.0f;

Handler::Handler(ros::NodeHandle &n)
    : reference_sub_(n, getRequiredRosParam<std::string>(n, "reference"), 2)
    , testee_sub_(n, getRequiredRosParam<std::string>(n, "testee"), 2)
    , must_match_rgb_(getRequiredRosParam<bool>(n, "same_rgb"))
    , synchronizer_(SYNC(10), reference_sub_, testee_sub_)
{
    synchronizer_.registerCallback(&Handler::callback, this);
}

void Handler::callback(const Handler::CloudPtr &reference, const Handler::CloudPtr &testee) {
    // Transform reference onto testee tf frame to compare coordinates directly
    Cloud reference_copy;

    if (!pcl_ros::transformPointCloud(testee->header.frame_id, *reference, reference_copy, tf_listener_)) {
        return;
    }

    Cloud testee_copy(*testee);

    size_t correctly_detected = 0;

    for (auto ref_it = reference_copy.begin(); ref_it != reference_copy.end(); ref_it++) {
        for (auto testee_it = testee_copy.begin(); testee_it != testee_copy.end(); testee_it++) {

            auto& ref_pt(*ref_it);
            auto& testee_pt(*testee_it);

            // RGB is ok if the RGB does not have to match or the RGB actually matches
            bool rgb_ok = !must_match_rgb_ || hphlib::sameRgb(ref_pt.rgba, testee_pt.rgba);

            if (hphlib::distanceSquared(ref_pt, testee_pt) < MAX_DISTANCE_SQUARED && rgb_ok) {
                std::swap(ref_pt, reference_copy.back());
                reference_copy.points.pop_back();
                std::swap(testee_pt, testee_copy.back());
                testee_copy.points.pop_back();

                ref_it--;
                testee_it--;

                correctly_detected++;
            }
        }
    }

    size_t not_detected = reference_copy.size();
    size_t fake_detected = testee_copy.size();

    double precision = static_cast<double>(correctly_detected) / (correctly_detected + fake_detected);
    double recall    = static_cast<double>(correctly_detected) / (correctly_detected + not_detected);

    precision_recall_history_.push_back(std::make_pair(precision, recall));

    cv::Mat precision_plot_data(static_cast<int>(precision_recall_history_.size()), 1, CV_64F);
    cv::Mat recall_plot_data(static_cast<int>(precision_recall_history_.size()), 1, CV_64F);

    for (int i = 0; i < precision_plot_data.rows; ++i) {
        precision_plot_data.at<double>(i) = precision_recall_history_[i].first;
        recall_plot_data.at<double>(i) = precision_recall_history_[i].second;
    }

    cv::Mat precision_plot_result;
    cv::Mat recall_plot_result;

    cv::Ptr<cv::plot::Plot2d> precision_plot = cv::plot::Plot2d::create(precision_plot_data);
    cv::Ptr<cv::plot::Plot2d> recall_plot = cv::plot::Plot2d::create(recall_plot_data);

    precision_plot->setMinY(0.0);
    recall_plot->setMinY(0.0);
    precision_plot->setMaxY(1.0f);
    recall_plot->setMaxY(1.0f);
    precision_plot->setShowText(false);
    recall_plot->setShowText(false);
    precision_plot->setInvertOrientation(true);
    recall_plot->setInvertOrientation(true);
    precision_plot->render(precision_plot_result);
    recall_plot->render(recall_plot_result);
    cv::putText(precision_plot_result, "Precision", cv::Point(20, 20), cv::FONT_HERSHEY_COMPLEX, 0.8, cv::Scalar(255, 255, 255));
    cv::putText(recall_plot_result,    "Recall",    cv::Point(20, 20), cv::FONT_HERSHEY_COMPLEX, 0.8, cv::Scalar(255, 255, 255));

    cv::Mat window(cv::Size(precision_plot_result.cols, precision_plot_result.rows * 2), precision_plot_result.type(), cv::Scalar::all(0));
    cv::Mat roi = window(cv::Rect(0,0, precision_plot_result.cols, precision_plot_result.rows));
    precision_plot_result.copyTo(roi);
    roi = window(cv::Rect(0, precision_plot_result.rows, recall_plot_result.cols ,recall_plot_result.rows));
    recall_plot_result.copyTo(roi);

    cv::imshow("Precision / Recall", window);

    ROS_INFO_STREAM("Precision: " << std::setw(20) << precision << ", Recall: " << std::setw(20) << recall);
}

