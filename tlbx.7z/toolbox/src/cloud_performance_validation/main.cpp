#include "Handler.h"
#include <opencv2/highgui.hpp>

int main(int argc, char** argv) {

    ros::init(argc, argv, "cloud_performance_validation");
    ros::NodeHandle n("~");

    Handler h(n);

    while (ros::ok()) {
        ros::spinOnce();
        cv::waitKey(50);
    }
}