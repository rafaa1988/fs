#include <ros/ros.h>
#include <message_filters/synchronizer.h>
#include <message_filters/subscriber.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_conversions/pcl_conversions.h>
#include <hphlib/util.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <telemetry/Runner.h>

using PCL = pcl::PointCloud<pcl::PointXYZ>;
using PCLPCL_SYNC = message_filters::sync_policies::ApproximateTime<PCL, PCL>;
using PCLIMG_SYNC = message_filters::sync_policies::ApproximateTime<PCL, sensor_msgs::Image>;
std::unique_ptr<telemetry::Runner> tele;

void pclPclCallback(const PCL::ConstPtr& m1, const PCL::ConstPtr& m2) {
    ros::Duration diff = pcl_conversions::fromPCL(m1->header.stamp) - pcl_conversions::fromPCL(m2->header.stamp);

    tele->report("dt", diff.toSec());
}

void pclImgCallback(const PCL::ConstPtr& m1, const sensor_msgs::Image::ConstPtr& m2) {
    ros::Duration diff = pcl_conversions::fromPCL(m1->header.stamp) - m2->header.stamp;

    tele->report("dt", diff.toSec());
}

void run_main(ros::NodeHandle& n) {

    std::string tele_topic   = getRequiredRosParam<std::string>(n, "tele");
    std::string first_topic  = getRequiredRosParam<std::string>(n, "first_topic");
    std::string second_topic = getRequiredRosParam<std::string>(n, "second_topic");
    std::string mode         = getRequiredRosParam<std::string>(n, "mode");

    tele = std::make_unique<telemetry::Runner>(tele_topic);

    if (mode == "pclpcl") {
        message_filters::Subscriber<PCL> sub1(n, first_topic, 3);
        message_filters::Subscriber<PCL> sub2(n, second_topic, 3);

        message_filters::Synchronizer<PCLPCL_SYNC> sync(PCLPCL_SYNC(10), sub1, sub2);

        sync.registerCallback(&pclPclCallback);

        ros::spin();
    } else if (mode == "pclimg") {
        message_filters::Subscriber<PCL> sub1(n, first_topic, 3);
        message_filters::Subscriber<sensor_msgs::Image> sub2(n, second_topic, 3);

        message_filters::Synchronizer<PCLIMG_SYNC> sync(PCLIMG_SYNC(10), sub1, sub2);

        sync.registerCallback(&pclImgCallback);

        ros::spin();
    } else {
        std::stringstream estream;
        estream << "Unsupported mode: " << mode;
        ROS_ERROR_STREAM(estream.str());
        throw std::runtime_error(estream.str());
    }
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "sync_check");

    ros::NodeHandle n("~");

    try {
        run_main(n);
    } catch (const std::exception& e) {
        ROS_ERROR_STREAM("Uncaught exception: " << e.what());
        throw;
    }

    return EXIT_SUCCESS;
}