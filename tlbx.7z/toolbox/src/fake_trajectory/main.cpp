#include <ros/ros.h>

#include <eigen3/Eigen/Eigen>

#include <tf/transform_datatypes.h>
#include <nav_msgs/Path.h>

#include <hphlib/util.h>
#include <hphlib/Control.h>
#include <visualization_msgs/Marker.h>

float path_step;
int path_length;

visualization_msgs::Marker marker_direction;
ros::Publisher pub;
ros::Publisher marker_pub;

geometry_msgs::PoseStamped poseFromEigen(Eigen::Vector2f vec) {
    geometry_msgs::PoseStamped pose;

    pose.pose.position.x = vec.x();
    pose.pose.position.y = vec.y();

    return pose;
}

void controlCallback(const hphlib::Control &control) {
    nav_msgs::Path path;

    path.header.stamp = ros::Time::now();
    path.header.frame_id = "base_link";

    float current_angle = 0;
    Eigen::Vector2f pos = Eigen::Vector2f::Zero();

    path.poses.push_back(poseFromEigen(pos));
    for(int i = 0; i < path_length; i++) {
        current_angle -= control.steering_angle / 180 * M_PI;
        pos.x() += cosf(current_angle) * control.target_velocity;
        pos.y() += sinf(current_angle) * control.target_velocity;
        path.poses.push_back(poseFromEigen(pos));
    }

    pub.publish(path);

    marker_direction.pose.orientation = tf::createQuaternionMsgFromYaw(control.steering_angle / 180 * M_PI);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "joy_steering");

    ros::NodeHandle n("~");

    path_step = getRequiredRosParam<float>(n, "path_increment");
    path_length = getRequiredRosParam<int>(n, "path_length");

    pub = n.advertise<nav_msgs::Path>(getRequiredRosParam<std::string>(n, "out_topic"), 1);
    ros::Subscriber sub = n.subscribe(getRequiredRosParam<std::string>(n, "in_topic"), 1, &controlCallback);
    marker_pub = n.advertise<visualization_msgs::Marker>(getRequiredRosParam<std::string>(n, "marker_topic"), 1);

    marker_direction.header.frame_id = "/base_link";
    marker_direction.header.stamp = ros::Time::now();
    marker_direction.ns = "direction";
    marker_direction.type = visualization_msgs::Marker::ARROW;
    marker_direction.pose.position.x = 0.0;
    marker_direction.pose.position.y = 0.0;
    marker_direction.pose.position.z = 0.0;
    marker_direction.scale.x = 2;
    marker_direction.scale.y = 0.2;
    marker_direction.scale.z = 0.03;
    marker_direction.color.r = 1.0f;
    marker_direction.color.g = 0.0f;
    marker_direction.color.b = 0.0f;
    marker_direction.color.a = 0.8;

    ros::spin();

    return 0;
}
