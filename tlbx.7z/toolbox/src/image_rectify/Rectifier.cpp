#include "Rectifier.h"

#include <image_geometry/pinhole_camera_model.h>
#include <cv_bridge/cv_bridge.h>

Rectifier::Rectifier(ros::NodeHandle& n, const std::string &topic_img, const std::string &topic_info,
                     std::function<void(Rectifier::Result)> callback)
    : cam_sub_(n, topic_img, 1)
    , info_sub_(n, topic_info, 1)
    , sync_(10, cam_sub_, info_sub_)
    , user_callback_(std::move(callback))
{
    sync_.registerCallback(&Rectifier::callback, this);
}

void Rectifier::callback(const sensor_msgs::Image::ConstPtr &img, const sensor_msgs::CameraInfo::ConstPtr &info) {

    Result r{};

    // TODO: Currently crashes with non 0 ROI offset since ROI is added to image (which seems non-sensical)
    // TODO: Setting to 0 may however also influence result, check once camera publishes fully correct ROI and Size
    sensor_msgs::CameraInfo info_copy = *info;
    info_copy.roi.x_offset = info_copy.roi.y_offset = 0;

    // Only initialize camera model once, apparently expensive to calculate rectification mappings
    if (!model_) {
        model_ = std::make_shared<image_geometry::PinholeCameraModel>();
        model_->fromCameraInfo(info_copy);
    }

    r.camera_model = model_;
    r.original_image = img;
    r.original_info = info;

    auto share = cv_bridge::toCvShare(img, "bgr8");

    model_->rectifyImage(share->image, r.rectified);

    user_callback_(std::move(r));
}
