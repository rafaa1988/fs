#include <ros/ros.h>
#include <hphlib/util.h>
#include <message_filters/subscriber.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <image_geometry/pinhole_camera_model.h>
#include <cv_bridge/cv_bridge.h>
#include "Rectifier.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "image_rectify");

    ros::NodeHandle n("~");

    std::string topic_cam  = getRequiredRosParam<std::string>(n, "cam");
    std::string topic_info = getRequiredRosParam<std::string>(n, "info");
    std::string topic_out  = getRequiredRosParam<std::string>(n, "out");

    ros::Publisher pub(n.advertise<sensor_msgs::Image>(topic_out, 1));

    Rectifier rect(n, topic_cam, topic_info, [&] (Rectifier::Result r) {
        cv_bridge::CvImage img(r.original_image->header, "bgr8", r.rectified);

        pub.publish(img.toImageMsg());
    });

    ros::spin();
}