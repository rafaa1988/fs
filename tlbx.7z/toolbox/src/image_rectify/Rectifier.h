#pragma once

#include <opencv-3.3.1-dev/opencv2/core/mat.hpp>
#include <message_filters/subscriber.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <image_geometry/pinhole_camera_model.h>

class Rectifier {
public:
    class Result {
        friend class Rectifier;

    public:
        cv::Mat rectified;
        sensor_msgs::Image::ConstPtr original_image;
        sensor_msgs::CameraInfo::ConstPtr original_info;
        std::shared_ptr<const image_geometry::PinholeCameraModel> camera_model;
    };

private:
    message_filters::Subscriber<sensor_msgs::Image> cam_sub_;
    message_filters::Subscriber<sensor_msgs::CameraInfo> info_sub_;

    using SYNC = message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::CameraInfo>;

    message_filters::Synchronizer<SYNC> sync_;

    std::function<void(Result)> user_callback_;

    std::shared_ptr<image_geometry::PinholeCameraModel> model_;

    void callback(const sensor_msgs::Image::ConstPtr& img, const sensor_msgs::CameraInfo::ConstPtr& info);

public:
    Rectifier(ros::NodeHandle& n, const std::string& topic_img, const std::string& topic_info,
              std::function<void(Result)> callback);

    // Binding this, do not copy or move
    Rectifier(const Rectifier& that) = delete;
    Rectifier& operator=(const Rectifier& that) = delete;
};