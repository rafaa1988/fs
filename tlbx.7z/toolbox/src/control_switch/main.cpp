#include <ros/ros.h>
#include <hphlib/util.h>
#include <hphlib/Control.h>
#include <hphlib/vehicle/StatusMonitor.h>
#include <hphlib/misc/Watchdog.h>


ros::Publisher control_pub;

bool global_received = false;

void localControlCallback(hphlib::Control control) {
    if (!global_received) {
        control_pub.publish(control);
    }
}

void globalControlCallback(hphlib::Control control) {
    global_received = true;
    control_pub.publish(control);
}


int main(int argc, char** argv) {
    ros::init(argc, argv, "control_switch");
    ros::NodeHandle n("~");

    ros::Subscriber local_control_sub = n.subscribe(getRequiredRosParam<std::string>(n, "local_control_topic"), 1, &localControlCallback);
    ros::Subscriber global_control_sub = n.subscribe(getRequiredRosParam<std::string>(n, "global_control_topic"), 1, &globalControlCallback);
    control_pub = n.advertise<hphlib::Control>(getRequiredRosParam<std::string>(n, "control_topic"), 1);

    hphlib::vehicle::StatusMonitor vehicle_mon(n);

    hphlib::Watchdog wdog(n, "/control/wd");

    // register vehicle status callbacks
    vehicle_mon.set_ready_callback([&] () {
        global_received = false;
    });

    wdog.enable();

    ros::spin();
}
