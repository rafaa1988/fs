#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <hphlib/util.h>
#include <cv_bridge/cv_bridge.h>


int main(int argc, char** argv) {
    ros::init(argc, argv, "image_rescale");

    ros::NodeHandle n("~");

    std::string sub_topic = getRequiredRosParam<std::string>(n, "in");
    std::string pub_topic = getRequiredRosParam<std::string>(n, "out");
    float factor          = getRequiredRosParam<float>(n, "factor");

    ros::Publisher pub    = n.advertise<sensor_msgs::Image>(pub_topic, 1);

    boost::function<void(const sensor_msgs::Image::ConstPtr& msg)> handler = [&] (const sensor_msgs::Image::ConstPtr& msg) {

        // Do no work if not needed
        if (pub.getNumSubscribers() == 0) {
            return;
        }

        auto cv_copy = cv_bridge::toCvCopy(msg, "bgr8");

        cv::Mat result;

        cv::Size out_size(
                static_cast<int>(msg->width * factor),
                static_cast<int>(msg->height * factor)
        );

        cv::resize(cv_copy->image, cv_copy->image, out_size);

        auto out_msg = cv_copy->toImageMsg();
        out_msg->header.frame_id = msg->header.frame_id;
        out_msg->header.stamp    = msg->header.stamp;

        pub.publish(out_msg);
    };

    ros::Subscriber sub = n.subscribe<sensor_msgs::Image>(sub_topic, 1, handler);

    ros::spin();
}