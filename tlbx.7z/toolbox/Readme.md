# Toolbox package
Contains optional data visualization and debugging tools. ROS nodes contained in this package are optional and should therefore not be launched or required by the vehicle master package.
