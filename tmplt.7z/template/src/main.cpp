#include <ros/ros.h>
#include <telemetry/Runner.h>
#include <hphlib/vehicle/StatusMonitor.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "template");

    ros::NodeHandle n("~");

    hphlib::vehicle::StatusMonitor mon(n);

    mon.set_go_callback([&] () {
        ROS_WARN_STREAM("GO, mission is " << mon.mission_on_ready());
    });

    mon.set_off_callback([] () {
        ROS_WARN_STREAM("Off");
    });

    mon.set_ready_callback([&] () {
        ROS_WARN_STREAM("Ready, mission is " << mon.mission_on_ready());
    });

    ros::SteadyTimerCallback cb = [&] (const auto& ev) {
        (void) ev;
        ROS_INFO_STREAM("State: " << mon.state());
    };

    auto timer = n.createSteadyTimer(ros::WallDuration(1.0), cb);

    ros::spin();

    return EXIT_SUCCESS;
}