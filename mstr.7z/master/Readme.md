# Master package
This is a meta-package used to launch all ROS nodes of the vehicle.
This package should therefore only contain launch files and no source.