# Horsepower Hannover Library package
This package contains classes and functions that are useful to a multitude of nodes.

## Documentation

This library has full doxygen annotations, to generate run `doxygen` from the library root (folder
of this readme). Output is generated in `doxygen/html/`.

## Library subfolders

Package | Description
------- | -----------
`async` | Helpers for asynchronous IO using `boost::asio`
`io` | Synchronous IO wrappers for protocols like CAN, SPI, UDP.