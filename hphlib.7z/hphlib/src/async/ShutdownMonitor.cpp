#include <ros/ros.h>
#include "../../include/hphlib/async/ShutdownMonitor.h"

using hphlib::ShutdownMonitor;

ShutdownMonitor::ShutdownMonitor(boost::asio::io_service &service)
    : service_(service)
    , timer_(service)
    , next_tick_(std::chrono::steady_clock::now())
{
    schedule_next_tick();
}

void ShutdownMonitor::schedule_next_tick() {

    using namespace std::chrono_literals;

    next_tick_ += 500ms;

    timer_.expires_at(next_tick_);

    timer_.async_wait([this] (const boost::system::error_code&) {
        ros::spinOnce();

        if (ros::ok()) {
            // Ignore recusrion warning
            this->schedule_next_tick();
        } else {
            service_.stop();
        }
    });
}
