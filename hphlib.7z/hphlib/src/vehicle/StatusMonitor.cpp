#include <hphlib/vehicle/StatusMonitor.h>
#include <ros/node_handle.h>

std::string hphlib::vehicle::decodeAmi(uint8_t ami) {
    switch (ami) {
        case hphlib::Status::AMI_ACCEL:
            return "acceleration";
        case hphlib::Status::AMI_BRAKETEST:
            return "braketest";
        case hphlib::Status::AMI_INSPECTION:
            return "inspection";
        case hphlib::Status::AMI_SKIDPAD:
            return "skidpad";
        case hphlib::Status::AMI_TRACKDRIVE:
            return "trackdrive";
        default:
            std::stringstream stream;
            stream << "<invalid: " << static_cast<int>(ami) << ">";
            return stream.str();
    }
}

hphlib::vehicle::StatusMonitor::StatusMonitor(ros::NodeHandle &n)
    : status_sub_(n.subscribe<hphlib::Status>(STATUS_TOPIC, 1, &StatusMonitor::status_callback, this))
    , last_mission_(0)
    , last_asms_(false)
{
}

void hphlib::vehicle::StatusMonitor::status_callback(const hphlib::Status::ConstPtr& msg) {

    // Check mission has changed
    if (last_mission_ != msg->mission) {
        last_mission_ = msg->mission;

        // If last mission is a valid mission
        if (last_mission_ == hphlib::Status::AMI_ACCEL || last_mission_ == hphlib::Status::AMI_SKIDPAD ||
            last_mission_ == hphlib::Status::AMI_TRACKDRIVE || last_mission_ == hphlib::Status::AMI_BRAKETEST ||
            last_mission_ == hphlib::Status::AMI_INSPECTION) {
            if (mission_change_callback_) {
                mission_change_callback_(last_mission_);
            }
        }
    }

    // Call ASMS callbacks if ASMS changes
    if (last_asms_ != msg->asms_on) {
        if (msg->asms_on && asms_on_callback_) {
            asms_on_callback_();
        }

        if (!msg->asms_on && asms_off_callback_) {
            asms_off_callback_();
        }

        last_asms_ = msg->asms_on;
    }

    if (msg->state != last_state_) {
        if (state_change_callback_) {
            state_change_callback_(msg->state);
        }
    }

    // Trigger all callbacks if state changed or first state observed
    if (msg->state == STATE_DRIVING && last_state_ != STATE_DRIVING) {
        if (go_callback_) {
            go_callback_();
        }
    } else if (msg->state == STATE_READY && last_state_ != STATE_READY) {
        mission_on_ready_ = msg->mission;

        if (ready_callback_) {
            ready_callback_();
        }
    } else if (msg->state == STATE_OFF && last_state_ != STATE_OFF) {
        if (off_callback_) {
            off_callback_();
        }
    }

    last_state_ = msg->state;
}

void hphlib::vehicle::StatusMonitor::set_go_callback(std::function<void()> cb) {
    go_callback_ = std::move(cb);
}

void hphlib::vehicle::StatusMonitor::set_ready_callback(std::function<void()> cb) {
    ready_callback_ = std::move(cb);
}

void hphlib::vehicle::StatusMonitor::set_off_callback(std::function<void()> cb) {
    off_callback_ = std::move(cb);
}

uint8_t hphlib::vehicle::StatusMonitor::mission_on_ready() const {

    if (!mission_on_ready_) {
        throw std::logic_error("Vehicle did not become ready, cannot query mission");
    }

    return *mission_on_ready_;
}

const std::string &hphlib::vehicle::StatusMonitor::state() const {
    return last_state_;
}

void hphlib::vehicle::StatusMonitor::set_state_change_callback(std::function<void(const std::string &)> cb) {
    state_change_callback_ = std::move(cb);
}

void hphlib::vehicle::StatusMonitor::set_asms_on_callback(std::function<void()> cb) {
    asms_on_callback_ = std::move(cb);
}

void hphlib::vehicle::StatusMonitor::set_asms_off_callback(std::function<void()> cb) {
    asms_off_callback_ = std::move(cb);
}

void hphlib::vehicle::StatusMonitor::set_mission_change_callback(std::function<void(uint8_t)> cb) {
    mission_change_callback_ = std::move(cb);
}
