#include <hphlib/util.h>

uint16_t getRequiredRosParamPort(const ros::NodeHandle& n, const std::string& name) {
    int int_port = getRequiredRosParam<int>(n, name);

    if (int_port < 1 || int_port > std::numeric_limits<uint16_t>::max()) {
        ROS_ERROR_STREAM(int_port << " is not a legal value for the port parameter \"" << name << "\"");
        throw std::runtime_error("Illegal value for port parameter");
    }

    return static_cast<uint16_t>(int_port);
}

bool hphlib::isBlockingException(const std::system_error& e) {
    return e.code().category() == std::system_category()
            && (e.code().value() == EAGAIN || e.code().value() == EWOULDBLOCK);
}