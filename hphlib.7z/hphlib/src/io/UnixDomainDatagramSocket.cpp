#include <hphlib/io/UnixDomainDatagramSocket.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/un.h>
#include <cstring>
#include <system_error>
#include <sstream>
#include <iostream>

hphlib::UnixDomainDatagramSocket::UnixDomainDatagramSocket() noexcept
    : Socket()
{
}

hphlib::UnixDomainDatagramSocket::UnixDomainDatagramSocket(const Endpoint& endpoint)
    : Socket(AF_UNIX, SOCK_DGRAM, 0)
{
    if (!endpoint.isUnnamed()) {
        // Always reuse UDS addresses
        int reuse = 1;

        if (setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, (const char*) &reuse, sizeof reuse) < 0) {
            throw std::system_error(errno, std::system_category(), "Failed to set SO_REUSEADDR");
        }

        if (::bind(*this, endpoint.addr(), endpoint.len()) != 0) {
            throw std::system_error(errno, std::system_category(), "Failed to bind Unix domain socket");
        }
    }
}

void hphlib::UnixDomainDatagramSocket::sendTo(const uint8_t *buffer, size_t buffer_length,
                                              const hphlib::UnixDomainDatagramSocket::Endpoint &remote) {
    ssize_t sendBytes = ::sendto(fd_, buffer, buffer_length, 0, remote.addr(), remote.len());

    if (sendBytes == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to send on Unix domain socket");
    }
}

size_t hphlib::UnixDomainDatagramSocket::receive(uint8_t *buffer, size_t buffer_length,
                                                 hphlib::UnixDomainDatagramSocket::Endpoint *sender_out) {
    Endpoint e;
    e.used_len_ = sizeof(e.addr_);

    ssize_t rx_count = ::recvfrom(fd_, buffer, buffer_length, 0, (sockaddr*)&e.addr_, &e.used_len_);

    // Violation of man page:
    // When the address of an unnamed socket is returned, its length is sizeof(sa_family_t),
    // and sun_path should not be inspected.
    //
    // Actually on some systems length was found to be zero in that case, so always set it to the correct size.
    if (e.used_len_ == 0) {
        e.used_len_ = sizeof(e.addr_.sun_family);
    }

    if (rx_count < 0) {
        throw std::system_error(errno, std::system_category(), "Failed to receive on Unix domain socket");
    }

    if (sender_out != nullptr) {
        *sender_out = e;
    }

    return static_cast<size_t>(rx_count);
}

hphlib::UnixDomainDatagramSocket::Endpoint::Endpoint() noexcept
    : used_len_(0)
{
}

socklen_t hphlib::UnixDomainDatagramSocket::Endpoint::len() const {
    return used_len_;
}

hphlib::UnixDomainDatagramSocket::Endpoint hphlib::UnixDomainDatagramSocket::Endpoint::unnamed() {
    Endpoint e;
    e.addr_.sun_family = AF_UNIX;
    e.used_len_ = sizeof(e.addr_.sun_family);

    return e;
}

hphlib::UnixDomainDatagramSocket::Endpoint hphlib::UnixDomainDatagramSocket::Endpoint::abstract(const char *name) {

    if (name == nullptr) {
        throw std::logic_error("name == nullptr");
    }

    Endpoint e;

    size_t len = std::strlen(name);

    if (len > sizeof(e.addr_.sun_path) - 1) {
        throw std::logic_error("Name too long for abstract unix domain endpoint");
    }

    e.addr_.sun_family = AF_UNIX;
    e.addr_.sun_path[0] = '\0';

    std::strcpy(e.addr_.sun_path + 1, name);

    e.used_len_ = sizeof(e.addr_.sun_family) + 1 + len;

    return e;
}

bool hphlib::UnixDomainDatagramSocket::Endpoint::isUnnamed() const {
    assertInitialized();

    return used_len_ == sizeof(addr_.sun_family);
}

void hphlib::UnixDomainDatagramSocket::Endpoint::assertInitialized() const {
    if (used_len_ == 0) {
        throw std::logic_error("Endpoint not initialized");
    }
}

const sockaddr *hphlib::UnixDomainDatagramSocket::Endpoint::addr() const {
    assertInitialized();

    return reinterpret_cast<const sockaddr *>(&addr_);
}

bool hphlib::UnixDomainDatagramSocket::Endpoint::isAbstract() const {
    return !isUnnamed() && addr_.sun_path[0] == '\0';
}

bool hphlib::UnixDomainDatagramSocket::Endpoint::isPathname() const {
    return !isUnnamed() && !isAbstract();
}

std::string hphlib::UnixDomainDatagramSocket::Endpoint::abstractName() const {
    if (!isAbstract()) {
        throw std::logic_error("Endpoint not abstract");
    }

    size_t len = used_len_ - 1 - sizeof(addr_.sun_family);

    return {addr_.sun_path + 1, addr_.sun_path + 1 + len};
}
