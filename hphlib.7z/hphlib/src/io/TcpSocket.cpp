#include <hphlib/io/TcpSocket.h>

#include <netinet/tcp.h>

using hphlib::TcpSocket;

hphlib::TcpSocket::TcpSocket(FileDescriptor fd)
    : Socket(std::move(fd))
{}

hphlib::TcpSocket::TcpSocket(uint16_t bound_port)
    : Socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
{
    if (bound_port != DYNAMIC_PORT) {
        sockaddr_in addr{};
        addr.sin_family      = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port        = htons(bound_port);

        if (bind(fd_, reinterpret_cast<const sockaddr *>(&addr), sizeof addr) != 0) {
            std::stringstream es;
            es << "Failed to bind TCP socket to port " << bound_port;
            throw std::system_error(errno, std::system_category(), es.str());
        }
    }
}

TcpSocket hphlib::TcpSocket::accept(Endpoint* remote) {

    sockaddr_in addr{};
    socklen_t len = sizeof(addr);

    int fd = ::accept(fd_, reinterpret_cast<sockaddr *>(&addr), &len);

    if (fd == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to accept on TCP socket");
    }

    TcpSocket sock{FileDescriptor(fd)};

    if (remote != nullptr) {
        *remote = Endpoint{addr};
    }

    return sock;
}

void hphlib::TcpSocket::connect(const TcpSocket::Endpoint &remote) {
    if (::connect(fd_, remote.addr(), remote.len()) != 0) {
        throw std::system_error(errno, std::system_category(), "Failed to connect TCP socket");
    }
}

void hphlib::TcpSocket::listen(int backlog) {
    if (::listen(fd_, backlog) != 0) {
        throw std::system_error(errno, std::system_category(), "Failed to set TCP socket to listen");
    }
}

void hphlib::TcpSocket::setNagleEnabled(bool enabled) {
    // Nagle enabled <-> No delay disabled
    int no_delay_enable = enabled ? 0 : 1;

    if (setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &no_delay_enable, sizeof no_delay_enable) != 0) {
        throw std::system_error(errno, std::system_category(), "Failed to set Nagle mode");
    }
}

size_t hphlib::TcpSocket::receiveSome(uint8_t *buffer, size_t size) {
    ssize_t rx_count = recv(fd_, buffer, size, 0);

    if (rx_count < 0) {
        throw std::system_error(errno, std::system_category(), "Failed to receive TCP bytes");
    }

    return static_cast<size_t>(rx_count);
}

void hphlib::TcpSocket::receiveExact(uint8_t *buffer, size_t size) {
    while (size > 0) {
        size_t last = receiveSome(buffer, size);

        if (last == 0) {
            throw std::runtime_error("Remote host closed TCP connection before receiving all bytes");
        }

        buffer += last;
        size   -= last;
    }
}

void hphlib::TcpSocket::send(const uint8_t *buffer, size_t size) {

    ssize_t tx_count = ::send(fd_, buffer, size, 0);

    if (tx_count < 0 || static_cast<size_t>(tx_count) != size) {
        throw std::system_error(errno, std::system_category(), "Failed to send TCP bytes");
    }
}
