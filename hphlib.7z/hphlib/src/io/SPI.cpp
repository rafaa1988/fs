#include <hphlib/io/SPI.h>
#include <hphlib/io/Ipv4Endpoint.h>

#include <sstream>

#include <fcntl.h>
#include <sys/ioctl.h>

using hphlib::SPI;

SPI::SPI(const char* device, Mode mode, uint8_t bits_per_word, uint32_t speed)
    : fd_(FileDescriptor(open(device, O_RDWR)))
    , bits_per_word_(bits_per_word)
    , speed_(speed)
{
    
    if (fd_ < 0) {
        std::stringstream estream;
        estream << "Failed to open device " << device;
        throw std::system_error(std::error_code(errno, std::system_category()), estream.str());
    }
    
    // Set SPI mode
    if (ioctl(fd_, SPI_IOC_WR_MODE, &mode) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to set SPI clock mode");
    }
    
    // Read back SPI mode
    Mode mode_check;
    if (ioctl(fd_, SPI_IOC_RD_MODE, &mode_check) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to read SPI clock mode");
    }
    
    if (mode_check != mode) {
        throw std::runtime_error("SPI device did not apply correct mode, read back incorrect");
    }
    
    // Set bits per word
    if (ioctl(fd_, SPI_IOC_WR_BITS_PER_WORD, &bits_per_word_) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to set SPI bits per word");
    }
    
    // Read back bits per word
    uint8_t bits_per_word_check;
    if (ioctl(fd_, SPI_IOC_RD_BITS_PER_WORD, &bits_per_word_check) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to read SPI bits per word");
    }
    
    if (bits_per_word_check != bits_per_word_) {
        throw std::runtime_error("SPI device did not apply correct word size, read back incorrect");
    }
    
    // Set clock speed
    if (ioctl(fd_, SPI_IOC_WR_MAX_SPEED_HZ, &speed_) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to set SPI frequency");
    }
    
    // Read back clock speed
    uint32_t speed_check;
    if (ioctl(fd_, SPI_IOC_RD_MAX_SPEED_HZ, &speed_check) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to read SPI bits per word");
    }
    
    if (speed_check != speed_) {
        throw std::runtime_error("SPI device did not apply correct clock speed, read back incorrect");
    }
}

void SPI::fullDuplexTransfer(uint8_t* buffer, uint32_t length) {

    // Transfer control instructions for kernel controller driver
    spi_ioc_transfer ctl{};
    
    // Send from buffer, for some reason the kernel uses uint64s for
    // addresses instead of pointers, convert. Also note, that for
    // 32-bit and 64-bit the control structure layout is identical.
    ctl.tx_buf        = reinterpret_cast<__u64>(buffer);
    // Receive into buffer
    ctl.rx_buf        = reinterpret_cast<__u64>(buffer);
    // Length of buffer is buffer length
    ctl.len           = length;
    // Speed of device already known from initialisation
    ctl.speed_hz      = speed_;
    // Bits per word also already known
    ctl.bits_per_word = bits_per_word_;
    
    // Don't deselect device before transfer
    ctl.cs_change     = 0;
    
    // Delay for deselecting device before transfer, don't deselect
    ctl.delay_usecs   = 0;
    
    // Perform 1 IOC transfer as described starting at ctl.
    // Could also perform multiple transfers right after another through this call
    // if ctl was an array and by increasing SPI_IO_MESSAGE(n).
    if (ioctl(fd_, SPI_IOC_MESSAGE(1), &ctl) < 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to perform SPI full duplex transfer");
    }
}
