#include "../../include/hphlib/io/FileDescriptor.h"
#include <algorithm>
#include <unistd.h>

using hphlib::FileDescriptor;

constexpr int FD_INVALID = -1;

FileDescriptor::FileDescriptor() noexcept
    : fd_(FD_INVALID)
{
}

hphlib::FileDescriptor::FileDescriptor(int native) noexcept
    : fd_(native)
{
}

FileDescriptor::FileDescriptor(FileDescriptor &&that) noexcept
    : FileDescriptor()
{
    this->swap(that);
}

FileDescriptor::~FileDescriptor() {
    close();
}

FileDescriptor::operator bool() const noexcept {
    return fd_ != FD_INVALID;
}

FileDescriptor::operator int() const noexcept {
    return fd_;
}

FileDescriptor &FileDescriptor::operator=(FileDescriptor &&that) noexcept {
    this->swap(that);

    return *this;
}

void hphlib::FileDescriptor::swap(FileDescriptor &that) noexcept {
    std::swap(this->fd_, that.fd_);
}

void hphlib::FileDescriptor::close() {
    if (fd_ != FD_INVALID) {
        ::close(fd_);
        fd_ = FD_INVALID;
    }
}