#include <hphlib/io/Socket.h>

#include <fcntl.h>
#include <sys/socket.h>
#include <system_error>

using hphlib::Socket;

/**
 * Convert miliseconds to a timeval structure
 * @param milis Miliseconds
 * @return Timeval
 */
timeval milisToTimeval(int milis) {
    timeval tv{};

    tv.tv_sec = milis / 1000;
    tv.tv_usec = (milis - (tv.tv_sec * 1000)) * 1000;

    return tv;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

hphlib::Socket::Socket(hphlib::FileDescriptor fd)
    : fd_(std::move(fd))
{
}

hphlib::Socket::Socket(int domain, int type, int protocol)
    : fd_(socket(domain, type, protocol))
{
    if (fd_ == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to allocate socket");
    }
}


int hphlib::Socket::getFileStatusFlags() const {
    int flags = fcntl(fd_, F_GETFL, nullptr);

    if (flags == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to get socket file status flags");
    }

    return flags;
}

void hphlib::Socket::setFileStatusFlags(int flags) {
    if (fcntl(fd_, F_SETFL, flags) == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to set socket file status flags");
    }
}

bool hphlib::Socket::isBlocking() const {
    return !(getFileStatusFlags() & O_NONBLOCK);
}

void hphlib::Socket::setBlocking(bool block) {
    int flags = getFileStatusFlags();

    if (block) {
        flags &= ~O_NONBLOCK;
    } else {
        flags |= O_NONBLOCK;
    }

    setFileStatusFlags(flags);
}

void hphlib::Socket::setReceiveBufferSize(size_t bytes) {
    if (setsockopt(fd_, SOL_SOCKET, SO_RCVBUF, &bytes, sizeof bytes) == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to set socket receive buffer size");
    }
}

size_t hphlib::Socket::getReceiveBufferSize() const {
    size_t size;
    socklen_t opt_len = sizeof(size);

    if (getsockopt(fd_, SOL_SOCKET, SO_RCVBUF, &size, &opt_len) == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to get socket receive buffer size");
    }

    // Value doubled by kernel for bookkeeping, see man-page socket(7)
    return size / 2;
}

void hphlib::Socket::setReceiveTimeoutMs(int millis) {
    timeval tv(milisToTimeval(millis));

    if (setsockopt(fd_, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv) != 0) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to set socket receive timeout");
    }
}

hphlib::Socket::operator int() {
    return fd_;
}

hphlib::Socket::operator bool() {
    return fd_;
}
