#include <hphlib/io/UdpSocket.h>

#include <sstream>
#include <system_error>

using hphlib::UdpSocket;

UdpSocket::UdpSocket() noexcept {}

hphlib::UdpSocket::UdpSocket(uint16_t port, bool reuse)
    : Socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
{
    if (fd_ == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to allocate UDP/IPv4 socket");
    }

    if (port != 0) {
        sockaddr_in localAddress{};
        localAddress.sin_family = AF_INET;  // Binding as IPv4
        localAddress.sin_port = htons(port);
        localAddress.sin_addr.s_addr = htons(INADDR_ANY);

        if (reuse) {
            int r = 1;
            if (setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, (const char*)&r, sizeof(r)) < 0)
                throw std::system_error(errno, std::system_category(), "Failed to set SO_REUSEADDR");

            if (setsockopt(fd_, SOL_SOCKET, SO_REUSEPORT, (const char*)&r, sizeof(r)) < 0)
                throw std::system_error(errno, std::system_category(), "Failed to set SO_REUSEPORT");
        }

        if (bind(fd_, (sockaddr*) &localAddress, sizeof localAddress) != 0) {
            std::stringstream stream;
            stream << "Failed to bind to port " << port;
            throw std::system_error(std::error_code(errno, std::system_category()), stream.str());
        }
    }
}

hphlib::UdpSocket::UdpSocket(uint16_t port) : UdpSocket(port, false) {}

void UdpSocket::sendTo(const uint8_t *buffer, size_t buffer_length, const UdpSocket::Endpoint &remote) {
    ssize_t sendBytes = sendto(fd_, buffer, buffer_length, 0, remote.addr(), remote.len());

    if (sendBytes == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to send on UDP socket");
    }

    // TODO What if sendBytes != bufferLength?
}

size_t UdpSocket::receive(uint8_t *buffer, size_t buffer_length, Endpoint* sender_out) {
    ssize_t written_bytes = this->receiveNoThrow(buffer, buffer_length, sender_out);

    if (written_bytes == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to receive on UDP socket");
    }

    // No error, safe to assume this is a non-negative number now
    return static_cast<size_t>(written_bytes);
}

ssize_t UdpSocket::receiveNoThrow(uint8_t *buffer, size_t buffer_length, Endpoint* sender_out) {
    sockaddr_in remote_address{};
    socklen_t address_length = sizeof remote_address;

    ssize_t rx_count = recvfrom(fd_, buffer, buffer_length, 0, (sockaddr*)&remote_address, &address_length);

    if (sender_out != nullptr) {
        *sender_out = Endpoint(remote_address);
    }

    return rx_count;
}
