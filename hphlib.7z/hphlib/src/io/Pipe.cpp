#include <hphlib/io/Pipe.h>
#include <unistd.h>
#include <system_error>

hphlib::Pipe::Pipe(const hphlib::PipeTypeAnonymous& p) {
    (void) p;

    int pipefd[2];

    if (::pipe(pipefd) != 0) {
        throw std::system_error(errno, std::system_category(), "Failed to create pipe");
    }

    reader_ = FileDescriptor(pipefd[0]);
    writer_ = FileDescriptor(pipefd[1]);
}

hphlib::FileDescriptor& hphlib::Pipe::reader() {
    return reader_;
}

hphlib::FileDescriptor& hphlib::Pipe::writer() {
    return writer_;
}