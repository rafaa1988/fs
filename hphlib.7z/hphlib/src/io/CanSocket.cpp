#include "../../include/hphlib/io/CanSocket.h"
#include <cstring>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <stdexcept>
#include <iostream>
#include <sstream>

using hphlib::CanSocket;

CanSocket::CanSocket(const char* if_name)
    : Socket(PF_CAN, SOCK_RAW, CAN_RAW)
{
    ifreq ifr{};

    if (std::strlen(if_name) + 1 /* trailing zero */ >= sizeof ifr.ifr_name) {
        std::stringstream estream;
        estream << "Interface name \"" << if_name << "\" too long, maximum length with trailing zero is " << sizeof ifr.ifr_name;
        throw std::length_error(estream.str());
    }

    // Copy interface name to interface request as C string with zero terminator
    std::strcpy(ifr.ifr_name, if_name);

    if (ioctl(fd_, SIOCGIFINDEX, &ifr) != 0) {
        std::stringstream estream;
        estream << "Failed to get interface index for name \"" << if_name << "\"";
        throw std::system_error(std::error_code(errno, std::system_category()), estream.str());
    }

    sockaddr_can addr{};
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(fd_, reinterpret_cast<const sockaddr *>(&addr), sizeof ifr) != 0) {
        std::stringstream estream;
        estream << "Failed to bind CAN socket to \"" << if_name << "\" (" << addr.can_ifindex << ")";
        throw std::system_error(std::error_code(errno, std::system_category()), estream.str());
    }
}

void CanSocket::sendBuffer(canid_t target, const __u8 *buffer, const __u8 length) {
    can_frame frame{};

    if (length > 8) {
        std::stringstream estream;
        estream << "CAN payload too large, maximum 8 bytes, was " << length;
        throw std::length_error(estream.str());
    }

    frame.can_id = target;
    frame.can_dlc = length;

    memcpy(frame.data, buffer, length);

    ssize_t bytes_sent = write(fd_, &frame, sizeof frame);

    if (bytes_sent == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to send CAN frame");
    }
}

void CanSocket::receiveBuffer(canid_t *sender_out, __u8 *length_out, __u8 *buffer_out) {
    can_frame frame{};

    ssize_t bytes_read = read(fd_, &frame, sizeof frame);

    if (bytes_read == -1) {
        throw std::system_error(std::error_code(errno, std::system_category()), "Failed to receive CAN frame");
    }

    if (sender_out != nullptr) {
        *sender_out = frame.can_id;
    }

    if (length_out != nullptr) {
        *length_out = frame.can_dlc;
    }

    std::memcpy(buffer_out, frame.data, frame.can_dlc);
}
