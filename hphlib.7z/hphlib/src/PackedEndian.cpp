// Dummy src file because IDE has trouble with include folder if not included from src o.O

#include <hphlib/PackedEndian.h>
#include <hphlib/util.h>
#include <hphlib/pcl.h>
#include <hphlib/misc/CloudToCameraTransformer.h>
#include <hphlib/misc/SlidingWindow.h>