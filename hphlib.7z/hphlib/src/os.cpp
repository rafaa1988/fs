#include <hphlib/io/Pipe.h>
#include <hphlib/os.h>
#include <cstdlib>
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pwd.h>
#include <iosfwd>
#include <sstream>
#include <climits>
#include <array>

pid_t hphlib::os::execute(const char* image, char* const* args, ExecuteMode mode) {
    // Create pipe for interprocess communication to determine whether child could run execv successfully
    hphlib::Pipe pipe(hphlib::PipeAnonymous);

    // Everything set up for the fork, go go go
    pid_t pid = ::fork();

    if (pid == -1) {
        // Error while forking
        throw std::system_error(errno, std::system_category(), "Failed to fork");
    } else if (pid == 0) {
        // Child process, usually don't want to call anything but exec* family function if spawning here
        // and especially in multi-threaded program must only call signal safe functions

        // Close our reading side of the pipe, signal safe
        pipe.reader().close();

        // Set our writing side to close on exec, just overwrite all flag bits and ignore errors which should not occur
        // and we can't handle well anyways
        ::fcntl(pipe.writer(), F_SETFD, FD_CLOEXEC);

        // Try to execute command
        if (mode == ExecuteMode::Path) {
            ::execv(image, args);
        } else {
            ::execvp(image, args);
        }

        // Process image not swapped, error occured, write errno to pipe
        int error = errno;

        // Ignore result of write, on error can't handle anyways
        ssize_t ignored = ::write(pipe.writer(), &error, sizeof error);
        (void) ignored;

        // Close writer flushing pipe and exit fast to keep signal safety
        pipe.writer().close();
        ::_exit(error);
    } else {
        // Parent, no fork error

        // Close our writing side of the pipe
        pipe.writer().close();

        // Do blocking read to get result of child's exec operation
        int error;

        ssize_t read_bytes = ::read(pipe.reader(), &error, sizeof error);

        if (read_bytes == 0) {
            // Success, all writers closed without writing data
            return pid;
        } else {

            std::stringstream estream;
            estream << "Failed to execute process image " << image << " in child process";

            throw std::system_error(error, std::system_category(), estream.str());
        }
    }
}

const char* hphlib::os::getHomeDir() {
    const char* home_dir;

    if ((home_dir = getenv("HOME")) == nullptr) {
        passwd* p = getpwuid(getuid());

        if (p == nullptr) {
            throw std::system_error(errno, std::system_category(), "Failed to query password database for user id, please set $HOME");
        }

        home_dir = p->pw_dir;
    }

    if (home_dir == nullptr) {
        throw std::runtime_error("Failed to get home directory, please set $HOME");
    }

    return home_dir;
}

std::string hphlib::os::getCurrentProcessExecutablePath() {
    std::array<char, PATH_MAX> buffer{};

    ssize_t count = readlink("/proc/self/exe", buffer.data(), buffer.size());

    if (count < 0) {
        throw std::system_error(errno, std::system_category(), "Failed to read self exe");
    }

    return std::string(buffer.data(), static_cast<unsigned long>(count));
}

void hphlib::os::signal(pid_t pid, int sig) {
    if (::kill(pid, sig) != 0) {
        std::stringstream estream;
        estream << "Failed to signal process " << pid << " with signal " << sig;
        throw std::system_error(errno, std::system_category(), estream.str());
    }
}

hphlib::optional<int> hphlib::os::checkTerminated(pid_t pid) {
    int status;

    pid_t res = ::waitpid(pid, &status, WNOHANG);

    if (res == -1) {
        std::stringstream estream;
        estream << "Failed to wait on child with PID " << pid;
        throw std::system_error(errno, std::system_category(), estream.str());
    } else if (res == 0) {
        return {};
    } else {
        return status;
    }
}

int hphlib::os::waitTerminated(pid_t pid) {

    int status;

    pid_t res = ::waitpid(pid, &status, 0);

    if (res == -1) {
        std::stringstream estream;
        estream << "Failed to wait on child with PID " << pid;
        throw std::system_error(errno, std::system_category(), estream.str());
    }

    return status;
}