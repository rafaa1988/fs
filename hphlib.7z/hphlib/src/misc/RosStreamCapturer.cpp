#include <hphlib/misc/RosStreamCapturer.h>

using hphlib::RosStreamCapturer;

RosStreamCapturer::RosStreamCapturer()
    : stdout_pipe_(hphlib::PipeAnonymous)
    , stdout_filebuf_(stdout_pipe_.reader(), std::ios::in)
    , stdout_stream_(&stdout_filebuf_)
    , stderr_pipe_(hphlib::PipeAnonymous)
    , stderr_filebuf_(stderr_pipe_.reader(), std::ios::in)
    , stderr_stream_(&stderr_filebuf_)
{
}

RosStreamCapturer::~RosStreamCapturer() {
    stdout_thread_.join();
    stderr_thread_.join();
}

void RosStreamCapturer::checked_dup2(int from_fd, int to_fd) {
    if (::dup2(from_fd, to_fd) == -1) {
        throw std::system_error(errno, std::system_category(), "Failed to dup2() file descriptors");
    }
}

hphlib::FileDescriptor RosStreamCapturer::checked_dup(int fd) {
    hphlib::FileDescriptor dup_fd(::dup(fd));

    if (!dup_fd) {
        throw std::system_error(errno, std::system_category(), "Failed to dup() file descriptor");
    }

    return dup_fd;
}
