#include <hphlib/misc/PollService.h>
#include <ros/poll_manager.h>
#include <sys/epoll.h>

hphlib::PollService::PollService(Socket& socket, std::function<void()> callback)
    : sock_fd_(socket)
    , cb_(std::move(callback))
{

    auto manager_ptr = ros::PollManager::instance();

    if (!manager_ptr) {
        throw std::runtime_error("Failed to get ros::PollManager instance");
    }

    auto& poll_set = manager_ptr->getPollSet();

    // Create the update function for this socket
    ros::PollSet::SocketUpdateFunc fn = [this] (int sock_ev) {
        (void) sock_ev;
        
        this->cb_();
    };

    if (!poll_set.addSocket(sock_fd_, fn)) {
        throw std::runtime_error("Failed to add socket to PollSet");
    }

    if (!poll_set.addEvents(sock_fd_, EPOLLIN)) {
        throw std::runtime_error("Failed to add EPOLLIN event to PollSet");
    }
}

hphlib::PollService::~PollService() {
    auto manager_ptr = ros::PollManager::instance();

    // If poll manager is gone, just return
    if (!manager_ptr) return;

    // Delete our socket from the poll set, ignore return value since we cannot recover errors anyways
    manager_ptr->getPollSet().delSocket(sock_fd_);
}
