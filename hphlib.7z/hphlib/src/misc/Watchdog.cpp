#include <hphlib/misc/Watchdog.h>
#include <hphlib/Woof.h>
#include <ros/node_handle.h>

using hphlib::Watchdog;

Watchdog::Watchdog(ros::NodeHandle &n, const std::string& topic, const std::string &woof)
    : woof_(woof)
    , pub_(n.advertise<hphlib::Woof>(topic, 1))
    , timer_(n.createSteadyTimer(ros::WallDuration(0.1), &Watchdog::callback, this))
    , enabled_(false)
{
}

void hphlib::Watchdog::callback(const ros::SteadyTimerEvent &ev) {
    (void) ev;

    if (enabled_) {
        hphlib::Woof msg;
        msg.header.stamp = ros::Time::now();
        msg.howl = woof_;

        pub_.publish(msg);
    }
}

void hphlib::Watchdog::enable() {
    enabled_ = true;
}

void hphlib::Watchdog::disable() {
    enabled_ = false;
}
