#include <resource_retriever/retriever.h>

#include <hphlib/misc/map/MapLoader.h>

boost::optional<hphlib::Map> hphlib::MapLoader::load(std::string map_name) {
    resource_retriever::Retriever r;
    resource_retriever::MemoryResource resource;

    boost::optional<hphlib::Map> map;

    try {
        std::string path = "package://master/maps/" + map_name;
        resource = r.get(path);

        // we need to 0 terminate the string. stupid resource loader...
        auto *s = static_cast<uint8_t *>(malloc((resource.size + 1) * sizeof(uint8_t)));
        if (!s)
            return map;

        memcpy(s, resource.data.get(), resource.size);
        s[resource.size] = '\0';

        nlohmann::json j = nlohmann::json::parse(s);
        map = j;
    }
    catch (resource_retriever::Exception& e) {
        ROS_ERROR("Failed to retrieve file: %s", e.what());
    }
    return map;
}
