#include "hphlib/misc/UdpMonitor.h"
#include <hphlib/util.h>
#include <ros/ros.h>

using hphlib::UdpMonitor;

UdpMonitor::UdpMonitor(hphlib::UdpSocket sock, const std::string &name, int timeout_ms)
    : sock_(std::move(sock))
    , name_(name)
    , initial_frame_(true)
    , log_next_frame_(true)
{
    sock_.setReceiveTimeoutMs(timeout_ms);
}

size_t UdpMonitor::receive(uint8_t *buffer, size_t buffer_length, hphlib::UdpSocket::Endpoint *sender_out) {
    try {
        size_t rx_count = sock_.receive(buffer, buffer_length, sender_out);

        if (log_next_frame_) {
            if (initial_frame_) {
                ROS_INFO_STREAM("Got initial datagram for \"" << name_ << "\"");
            } else {
                ROS_INFO_STREAM("Got a datagram again for \"" << name_ << "\"");
            }

            log_next_frame_ = false;
        }

        initial_frame_ = false;

        return rx_count;
    } catch (const std::system_error& e) {
        if (hphlib::isBlockingException(e)) {
            if (!log_next_frame_) {
                log_next_frame_ = true;
                ROS_WARN_STREAM("Timeout receiving datagram for \"" << name_ << "\"");
            }
            throw TimeoutException{};
        } else {
            throw;
        }
    }
}
