#include <hphlib/misc/CloudToCameraTransformer.h>

cv::Rect2d hphlib::spanRectangle(const tf::Stamped<tf::Point>& point, float size,
                         const image_geometry::PinholeCameraModel& model,
                         tf::TransformListener& tf_listener) {
    // Box is created by spanning a plane from the position of the target with a fixed physical size
    // The forward vector from the camera to the target is taken and by taking the cross product with
    // the global up vector the right vector is found.

    const auto& info(model.cameraInfo());

    // Find camera vector in point cloud transformation frame
    tf::Stamped<tf::Point> tf_camera_origin;

    tf_listener.transformPoint(
            point.frame_id_,                                                // Target frame is point frame
            {{0.0f, 0.0f, 0.0f}, info.header.stamp, info.header.frame_id},  // Transform camera origin
            tf_camera_origin
    );

    // Vector always facing upwards on the PCL plane
    Eigen::Vector3f up     = { 0.0f, 0.0f, 1.0f };

    // Camera position in PCL space
    Eigen::Vector3f camera = {
            static_cast<float>(tf_camera_origin.x()),
            static_cast<float>(tf_camera_origin.y()),
            static_cast<float>(tf_camera_origin.z())
    };

    // Point cloud used to calculate box in camera image
    pcl::PointCloud<pcl::PointXYZ> box_cloud;
    box_cloud.header.stamp = pcl_conversions::toPCL(point.stamp_);
    box_cloud.header.frame_id = point.frame_id_;

    // Vector containing the 4 corners of the box in 3d PCL space
    std::vector<Eigen::Vector3f> corners;

    // Target position in PCL space
    Eigen::Vector3f target = {
            static_cast<float>(point.x()),
            static_cast<float>(point.y()),
            static_cast<float>(point.z())
    };

    // Forward vector from camera to target
    Eigen::Vector3f forward = target - camera;

    // Span right plane from cross product of forward and up vector
    Eigen::Vector3f right = forward.cross(up).normalized();

    corners.clear();
    corners.emplace_back(target + right *  size + up * -size);
    corners.emplace_back(target + right * -size + up * -size);
    corners.emplace_back(target + right *  size + up *  size);
    corners.emplace_back(target + right * -size + up *  size);

    // Convert eigen vectors of corners back to PCL cloud
    for (const auto &c : corners) {
        box_cloud.points.emplace_back(c[0], c[1], c[2]);
    }

    // Transform all 3D corners from PCL to camera frame
    pcl_ros::transformPointCloud(info.header.frame_id, box_cloud, box_cloud, tf_listener);

    // Initialize 2D box corners with minimum values
    cv::Point top_left = {std::numeric_limits<int>::max(), std::numeric_limits<int>::max()};
    cv::Point bottom_right = {std::numeric_limits<int>::min(), std::numeric_limits<int>::min()};

    // Convert 3D corners to 2D unrectified coordinates and find maximum values to span box
    for (const auto &box_pt : box_cloud) {
        cv::Point corner_pt = model.project3dToPixel({box_pt.x, box_pt.y, box_pt.z});
        corner_pt = model.unrectifyPoint(corner_pt);

        top_left.x = std::min(top_left.x, corner_pt.x);
        top_left.y = std::min(top_left.y, corner_pt.y);
        bottom_right.x = std::max(bottom_right.x, corner_pt.x);
        bottom_right.y = std::max(bottom_right.y, corner_pt.y);
    }

    // Want to return a square, average width and height
    cv::Rect rect {top_left, bottom_right};

    auto rect_size = (rect.width + rect.height) / 2;

    cv::Point center(rect.x + rect.width / 2, rect.y + rect.height / 2);

    return {
            static_cast<double>(center.x - rect_size / 2),
            static_cast<double>(center.y - rect_size / 2),
            static_cast<double>(rect_size),
            static_cast<double>(rect_size)
    };
}