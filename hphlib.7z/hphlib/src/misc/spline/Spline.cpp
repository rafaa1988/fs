#include <iostream>

#include <hphlib/eigen.h>
#include <hphlib/misc/spline/Spline.h>

using namespace Eigen;

void hphlib::Spline::fit(float alpha, float beta, float gamma, float h, float p, float h_spline, const Eigen::VectorXf &knots) {
    float scale_factor = 1.0f / h;
    long n = knots.rows();

    this->h = h;
    this->h_spline = h_spline;
    this->h_factor = h / h_spline;

    MatrixXf A(8, 8);
    A << 1,0,0,0,0,0,0,0,
         1,1,1,1,1,1,1,1,
         0,1,0,0,0,0,0,0,
         0,1,2,3,4,5,6,7,
         0,0,2,0,0,0,0,0,
         0,0,2,6,12,20,30,42,
         0,0,0,6,0,0,0,0,
         0,0,0,6,24,60,120,210;
    MatrixXf Ainv = A.inverse();

    // D1 is that part of the D1 matrix that corresponds to the minimum acceleration spline.
    // D1_1 is that part of the D1 matrix that corresponds to the minimum velocity spline.
    // D1_3 is that part of the D1 matrix that corresponds to the minimum jerk spline.
    Matrix3f D1, D1_1, D1_3;
    D1 << 25.45454545f, 0, -25.45454545f,
          -2.424242424f, 4.848484848f, -2.424242424f,
          .9090909091e-1f, 0, -.9090909091e-1f;
    D1_1 << .6317016317f, 0, -.6317016317f,
            -.5361305361e-1f, 0.1072261072f, -.5361305361e-1f,
            .1942501943e-2f, 0, -.1942501943e-2f;
    D1_3 << 1120, 0, -1120,
            -200, 400, -200,
            6.666666667f, 0, -6.666666667f;
    // The total D1 matrix is a weighted and scaled sum of D1, D1_1, and D1_3.
    D1 = (beta * std::pow(scale_factor, 3) * D1) + (alpha * scale_factor * D1_1) + (gamma * std::pow(scale_factor, 5) * D1_3);

    // D1t is called D1-tilde in the paper.
    Matrix3f D1t, D1t_1, D1t_3;
    D1t << 25.45454545f, -25.45454545f, 0,
           2.424242424f, -2.424242424f, 0,
           .9090909091e-1f, -.9090909091e-1f, 0;
    D1t_1 << .6317016317f, -.6317016317f, 0,
             .5361305361e-1f, -.5361305361e-1f, 0,
             .1942501943e-2f, -.1942501943e-2, 0;
    D1t_3 << 1120, -1120, 0,
             200, -200, 0,
             6.666666667f, -6.666666667f, 0;
    D1t = (beta * std::pow(scale_factor, 3) * D1t) + (alpha * scale_factor * D1t_1) + (gamma * std::pow(scale_factor, 5) * D1t_3);

    // D1tt is called D1-double-tilde in the paper.
    Matrix3f D1tt, D1tt_1, D1tt_3;
    D1tt << 0, 25.45454545f, -25.45454545f,
            0, -2.424242424f, 2.424242424f,
            0, .9090909091e-1f, -.9090909091e-1f;
    D1tt_1 << 0, .6317016317f, -.6317016317f,
              0, -.5361305361e-1f, .5361305361e-1f,
              0, .1942501943e-2f, -.1942501943e-2f;
    D1tt_3 << 0, 1120, -1120,
              0, -200, 200,
              0, 6.666666667f, -6.666666667f;
    D1tt = (beta * std::pow(scale_factor, 3) * D1tt) + (alpha * scale_factor * D1tt_1) + (gamma * std::pow(scale_factor, 5) * D1tt_3);

    Matrix3f D2, D2_1, D2_3;
    D2 << 9.870129870f, .7835497835f, .2164502165e-1f,
          -.7835497835f, -.4329004329e-2f, .3607503608e-2f,
          .2164502165e-1f, -.3607503608e-2f, -.4329004329e-3f;
    D2_1 << .3230103230e-1f, -.7825507826e-2f, -.8325008325e-3f,
            .7825507826e-2f, .2719502720e-2f, .2025752026e-3f,
            -.8325008325e-3f, -.2025752026e-3f, -.1387501388e-4f;
    D2_3 << 525.7142857f, 82.85714286f, 2.476190476f,
            -82.85714286f, -11.42857143f, -.2380952381f,
            2.476190476f, .2380952381f, -.1587301587e-1f;
    D2 = (beta * std::pow(scale_factor, 3) * D2) + (alpha * scale_factor * D2_1) + (gamma * std::pow(scale_factor, 5) * D2_3);

    Matrix3f D2tt, D2tt_1, D2tt_3;
    D2tt << 9.870129870f, .7835497835f, .2164502165e-1f,
            -.7835497835f, -.4329004329e-2f, .3607503608e-2f,
            .2164502165e-1f, -.3607503608e-2f, -.4329004329e-3f;
    D2tt_1 << .3230103230e-1f, -.7825507826e-2f, -.8325008325e-3f,
              .7825507826e-2f, .2719502720e-2f, .2025752026e-3f,
              -.8325008325e-3f, -.2025752026e-3f, -.1387501388e-4f;
    D2tt_3 << 525.7142857f, 82.85714286f, 2.476190476f,
              -82.85714286f, -11.42857143f, -.2380952381f,
              2.476190476f, .2380952381f, -.1587301587e-1f;
    D2tt = (beta * std::pow(scale_factor, 3) * D2tt) + (alpha * scale_factor * D2tt_1) + (gamma * std::pow(scale_factor, 5) * D2tt_3);

    Matrix3f D3, D3_1, D3_3;
    D3 << 31.16883117f, 0.f, .1385281385f,
          0.f, .8658008658f, 0.f,
          .1385281385f, 0.f, .2308802309e-2f;
    D3_1 << 1.198801199f, 0.f, .5550005550e-2f,
            0.f, .1620601621e-1f, 0.f,
            .5550005550e-2f, 0.f, .4440004440e-4f;
    D3_3 << 1188.571429f, 0.f, 8.380952381f,
            0.f, 57.14285714f, 0.f,
            8.380952381f, 0.f, .2539682540f;
    D3 = (beta * std::pow(scale_factor, 3) * D3) + (alpha * scale_factor * D3_1) + (gamma * std::pow(scale_factor, 5) * D3_3);

    Matrix3f D3t, D3t_1, D3t_3;
    D3t << 15.58441558f, 1.640692641f, .6926406926e-1f,
           1.640692641f, .4329004329f, .2020202020e-1f,
          .6926406926e-1f, .2020202020e-1f, .1154401154e-2f;;
    D3t_1 << .5994005994f, .6143856144e-1f, .2775002775e-2f,
             .6143856144e-1f, .8103008103e-2f, .4107004107e-3f,
             .2775002775e-2f, .4107004107e-3f, .2220002220e-4f;
    D3t_3 << 594.2857143f, 117.1428571f, 4.190476190f,
             117.1428571f, 28.57142857f, 1.095238095f,
             4.190476190f, 1.095238095f, .1269841270f;
    D3t = (beta * std::pow(scale_factor, 3) * D3t) + (alpha * scale_factor * D3t_1) + (gamma * std::pow(scale_factor, 5) * D3t_3);

    Matrix3f D3tt, D3tt_1, D3tt_3;
    D3tt << 15.58441558f, -1.640692641f, .6926406926e-1f,
            -1.640692641f, .4329004329f, -.2020202020e-1f,
            .6926406926e-1f, -.2020202020e-1f, .1154401154e-2f;
    D3tt_1 << .5994005994f, -.6143856144e-1f, .2775002775e-2f,
              -.6143856144e-1f, .8103008103e-2f, -.4107004107e-3f,
              .2775002775e-2f, -.4107004107e-3f, .2220002220e-4f;
    D3tt_3 << 594.2857143f, -117.1428571f, 4.190476190f,
              -117.1428571f, 28.57142857f, -1.095238095f,
              4.190476190f, -1.095238095f, .1269841270f;
    D3tt = (beta * std::pow(scale_factor, 3) * D3tt) + (alpha * scale_factor * D3tt_1) + (gamma * std::pow(scale_factor, 5) * D3tt_3);

    Matrix3f D4, D4_1, D4_3;
    D4 << 9.870129870f, -.7835497835f, .2164502165e-1f,
          .7835497835f, -.4329004329e-2f, -.3607503608e-2f,
          .2164502165e-1f, .3607503608e-2f, -.4329004329e-3f;
    D4_1 << .3230103230e-1f, .7825507826e-2f, -.8325008325e-3f,
            -.7825507826e-2f, .2719502720e-2f, -.2025752026e-3f,
            -.8325008325e-3f, .2025752026e-3f, -.1387501388e-4f;
    D4_3 << 525.7142857f, -82.85714286f, 2.476190476f,
            82.85714286f, -11.42857143f, .2380952381f,
            2.476190476f, -.2380952381f, -.1587301587e-1f;
    D4 = (beta * std::pow(scale_factor, 3) * D4) + (alpha * scale_factor * D4_1) + (gamma * std::pow(scale_factor, 5) * D4_3);

    Matrix3f D4t, D4t_1, D4t_3;
    D4t << 9.870129870f, -.7835497835f, .2164502165e-1f,
          .7835497835f, -.4329004329e-2f, 0.f,
          .2164502165e-1f, .3607503608e-2f, -.4329004329e-3f;
    D4t_1 << .3230103230e-1f, .7825507826e-2f, -.8325008325e-3f,
             -.7825507826e-2f, .2719502720e-2f, 0.f,
             -.8325008325e-3f, .2025752026e-3f, -.1387501388e-4f;
    D4t_3 << 525.7142857f, -82.85714286f, 2.476190476f,
             82.85714286f, -11.42857143f, 0.f,
             2.476190476f, -.2380952381f, -.1587301587e-1f;
    D4t = (beta * std::pow(scale_factor, 3) * D4t) + (alpha * scale_factor * D4t_1) + (gamma * std::pow(scale_factor, 5) * D4t_3);

    RowVector3f E1, E1_1, E1_3;
    E1 << -50.90909091f, 101.8181818f, -50.90909091f;
    E1_1 << -3.263403263f, 6.526806527f, -3.263403263f;
    E1_3 << -2240.f, 4480.f, -2240.f;
    E1 = (beta * std::pow(scale_factor, 3) * E1) + (alpha * scale_factor * E1_1) + (gamma * std::pow(scale_factor, 5) * E1_3);

    RowVector3f E1t, E1t_1, E1t_3;
    E1t << 50.90909091f, -50.90909091f, 0.f;
    E1t_1 << 3.263403263f, -3.263403263f, 0.f;
    E1t_3 << 2240.f, -2240.f, 0.f;
    E1t = (beta * std::pow(scale_factor, 3) * E1t) + (alpha * scale_factor * E1t_1) + (gamma * std::pow(scale_factor, 5) * E1t_3);

    RowVector3f E1tt, E1tt_1, E1tt_3;
    E1tt << 0.f, -50.90909091f, 50.90909091f;
    E1tt_1 << 0.f, -3.263403263f, 3.263403263f;
    E1tt_3 << 0.f, -2240.f, 2240.f;
    E1tt = (beta * std::pow(scale_factor, 3) * E1tt) + (alpha * scale_factor * E1tt_1) + (gamma * std::pow(scale_factor, 5) * E1tt_3);

    RowVector3f E2, E2_1, E2_3;
    E2 << -25.45454545f, -2.424242424f, -.9090909091e-1f;
    E2_1 << -.6317016317f, -.5361305361e-1f, -.1942501943e-2f;
    E2_3 << -1120.f, -200.f, -6.666666667f;
    E2 = (beta * std::pow(scale_factor, 3) * E2) + (alpha * scale_factor * E2_1) + (gamma * std::pow(scale_factor, 5) * E2_3);

    RowVector3f E2tt, E2tt_1, E2tt_3;
    E2tt << -25.45454545f, -2.424242424f, -.9090909091e-1f;
    E2tt_1 << -.6317016317f, -.5361305361e-1f, -.1942501943e-2f;
    E2tt_3 << -1120.f, -200.f, -6.666666667f;
    E2tt = (beta * std::pow(scale_factor, 3) * E2tt) + (alpha * scale_factor * E2tt_1) + (gamma * std::pow(scale_factor, 5) * E2tt_3);

    RowVector3f E3, E3_1, E3_3;
    E3 << 0.f, 4.848484848f, 0.f;
    E3_1 << 0.f, .1072261072f, 0.f;
    E3_3 << 0.f, 400.f, 0.f;
    E3 = (beta * std::pow(scale_factor, 3) * E3) + (alpha * scale_factor * E3_1) + (gamma * std::pow(scale_factor, 5) * E3_3);

    RowVector3f E3t, E3t_1, E3t_3;
    E3t << 25.45454545f, 2.424242424f, .9090909091e-1f;
    E3t_1 << .6317016317f, .5361305361e-1f, .1942501943e-2f;
    E3t_3 << 1120.f, 200.f, 6.666666667f;
    E3t = (beta * std::pow(scale_factor, 3) * E3t) + (alpha * scale_factor * E3t_1) + (gamma * std::pow(scale_factor, 5) * E3t_3);

    RowVector3f E3tt, E3tt_1, E3tt_3;
    E3tt << -25.45454545f, 2.424242424f, -.9090909091e-1f;
    E3tt_1 << -.6317016317f, .5361305361e-1f, -.1942501943e-2f;
    E3tt_3 << -1120.f, 200.f, -6.666666667f;
    E3tt = (beta * std::pow(scale_factor, 3) * E3tt) + (alpha * scale_factor * E3tt_1) + (gamma * std::pow(scale_factor, 5) * E3tt_3);

    RowVector3f E4, E4_1, E4_3;
    E4 << 25.45454545f, -2.424242424f, .9090909091e-1f;
    E4_1 << .6317016317f, -.5361305361e-1f, .1942501943e-2f;
    E4_3 << 1120.f, -200.f, 6.666666667f;
    E4 = (beta * std::pow(scale_factor, 3) * E4) + (alpha * scale_factor * E4_1) + (gamma * std::pow(scale_factor, 5) * E4_3);

    RowVector3f E4t, E4t_1, E4t_3;
    E4t << 25.45454545f, -2.424242424f, .9090909091e-1f;
    E4t_1 << .6317016317f, -.5361305361e-1f, .1942501943e-2f;
    E4t_3 << 1120.f, -200.f, 6.666666667f;
    E4t = (beta * std::pow(scale_factor, 3) * E4t) + (alpha * scale_factor * E4t_1) + (gamma * std::pow(scale_factor, 5) * E4t_3);

    long nm1 = n - 1;
    long nm2 = nm1 - 1;
    long nm3 = nm2 - 1;

    // Put all the submatrices together to get a total D matrix.
    MatrixXf D = MatrixXf::Zero(3 * n, 3 * n);
    for (int i = 1; i <= n; i++) {
        if (i == n)
            D.block<3,3>(3 * i - 3, 3 * i - 6) = D2tt;
        else if(i > 1)
            D.block<3,3>(3 * i - 3, 3 * i - 6) = D2;

        if (i == 1)
            D.block<3,3>(0, 0) = D3t;
        else if(i == n)
            D.block<3,3>(3 * i - 3, 3 * i - 3) = D3tt;
        else
            D.block<3,3>(3 * i - 3, 3 * i - 3) = D3;

        if (i == 1)
            D.block<3,3>(0, 3) = D4t;
        else if(i < n)
            D.block<3,3>(3 * i - 3, 3 * i) = D4;
    }

    // Put all the submatrices together to get a total C matrix.
    MatrixXf C = MatrixXf::Zero(3 * n, n);
    C.block<3,3>(0, 0) = D1t;
    for (int i = 2; i <= nm1; i++) {
        C.block<3,3>(3 * i - 3, i - 2) = D1;
    }
    C.block<3,3>(3 * n - 3, nm3) = D1tt;
    C = -C;

    // Put all the submatrices together to get a total E matrix.
    MatrixXf E = MatrixXf::Zero(n,3 * n);
    E.block<1,3>(0, 0) = E3t;
    E.block<1,3>(0, 3) = E4t;
    E.block<1,3>(1, 0) = E2;
    E.block<1,3>(1, 3) = E3;
    E.block<1,3>(1, 6) = E4;
    for (int i = 3; i <= nm2; i++) {
        E.block<1,3>(i - 1, 3 * i - 6) = E2;
        E.block<1,3>(i - 1, 3 * i - 3) = E3;
        E.block<1,3>(i - 1, 3 * i) = E4;
    }
    E.block<1,3>(nm2, 3 * n - 9) = E2;
    E.block<1,3>(nm2, 3 * n - 6) = E3;
    E.block<1,3>(nm2, 3 * n - 3) = E4;
    E.block<1,3>(nm1, 3 * n - 6) = E2tt;
    E.block<1,3>(nm1, 3 * n - 3) = E3tt;

    // Put all the submatrices together to get a total F matrix.
    MatrixXf F = MatrixXf::Zero(n,n);
    F.block<1,3>(0, 0) = E1t;
    F.block<1,3>(1, 0) = E1;
    for (int i = 3; i <= nm2; i++) {
        F.block<1,3>(i-1, i-2) = E1;
    }
    F.block<1,3>(nm2, nm3) = E1;
    F.block<1,3>(nm1, nm3) = E1tt;
    F = -F;

    // Create the P matrix.
    MatrixXf P = MatrixXf::Zero(n, n);
    for (int i = 0; i < n; i++) {
        P(i, i) = -2 * p;
    }

    // Create the G matrix.
    VectorXf G = 2 * p * knots;

    // Do temp calculations. Otherwise Eigen is painfully slow
    MatrixXf Dinv = D.inverse();
    MatrixXf DinvC = Dinv * C;
    MatrixXf t1 = E * DinvC;
    MatrixXf t2 = t1 - F;
    MatrixXf t3 = t2 - P;
    MatrixXf t3inv = t3.inverse();

    // Solve for the optimal spline values and derivatives at the knot times.
    VectorXf Y = t3inv * G;
    VectorXf Yr = DinvC * Y;

    // Parse the spline derivatives from the Y array.
    VectorXf ypknots(n);
    VectorXf yppknots(n);
    VectorXf ypppknots(n);
    for (int i = 0; i < n; i++) {
        ypknots(i) = Yr(3 * i);
        yppknots(i) = Yr(3 * i + 1);
        ypppknots(i) = Yr(3 * i + 2);
    }

    // Initialize arrays.
    auto out_length = static_cast<int>(nm1 * (h / h_spline + 1));
    _y = VectorXf(out_length);
    _yp = VectorXf(out_length);
    _ypp = VectorXf(out_length);
    _yppp = VectorXf(out_length);
    _t = VectorXf(out_length);

    // Generate the spline values and derivatives every h_spline seconds.
    int idx = 0;
    for (int i = 0; i < nm1; i++) {
        VectorXf b(8);
        b << Y(i), Y(i+1), ypknots(i), ypknots(i+1), yppknots(i), yppknots(i+1), ypppknots(i), ypppknots(i+1);
        VectorXf coeff = Ainv * b;
        for (int j = 0; j < h / h_spline; j++)
        {
            float t = j * (h_spline / h);
            float t2 = t * t, t3 = t2 * t, t4 = t3 * t, t5 = t4 * t, t6 = t5 * t, t7 = t6 * t;
            RowVectorXf basis(8);

            basis << 1, t, t2, t3, t4, t5, t6, t7;
            _y(idx) = basis * coeff;

            basis << 0, 1, 2 * t, 3 * t2, 4 * t3, 5 * t4, 6 * t5, 7 * t6;
            _yp(idx) = basis * coeff;

            basis << 0, 0, 2, 6*t, 12*t2, 20*t3, 30*t4, 42*t5;
            _ypp(idx) = basis * coeff;

            basis << 0, 0, 0, 6, 24*t, 60*t2, 120*t3, 210*t4;
            _yppp(idx) = basis * coeff;

            _t(idx) = i + t;
            idx++;
        }
    }

    slice(0, idx);

    // Scale the spline derivatives as required.
    _yp = _yp / h;
    _ypp = _ypp / h / h;
    _yppp = _yppp / h / h / h;
}

void hphlib::Spline::slice(size_t start, size_t end) {
    end = std::min(end, static_cast<size_t>(_y.rows()));

    // resize the value vectors
    _y = VectorXf(_y.segment(start, end - start));
    _yp = VectorXf(_yp.segment(start, end - start));
    _ypp = VectorXf(_ypp.segment(start, end - start));
    _yppp = VectorXf(_yppp.segment(start, end - start));

    // adjust the times in the times array
    float start_time = _t[start];
    _t = VectorXf(_t.segment(start, end - start));
    offsetTime(start_time);
}

void hphlib::Spline::shift(long offset) {
    _y = shiftMatrix(_y, offset);
    _yp = shiftMatrix(_yp, offset);
    _ypp = shiftMatrix(_ypp, offset);
    _yppp = shiftMatrix(_yppp, offset);
}

void hphlib::Spline::offsetTime(float t) {
    _t = _t + t * VectorXf::Ones(_t.rows());
}