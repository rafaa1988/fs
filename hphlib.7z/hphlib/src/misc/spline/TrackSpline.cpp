#include <hphlib/eigen.h>
#include <hphlib/util.h>
#include <hphlib/misc/spline/TrackSpline.h>

using namespace Eigen;
using namespace hphlib;

void TrackSpline::fit(float alpha, float beta, float gamma, float h, float p, float h_spline, const VectorXf &x, const VectorXf &y) {
    _x.fit(alpha, beta, gamma, h, p, h_spline, x);
    _y.fit(alpha, beta, gamma, h, p, h_spline, y);
}



void TrackSpline::fit(float alpha, float beta, float gamma, float h, float p, float h_spline, bool circular, const std::vector<Eigen::Vector2f> &track) {
    std::vector<Vector2f> normalized_path;
    if (!track.empty()) {
        // walk along the path and divide it in equidistance parts
        int start_idx = 0;
        int end_idx = static_cast<int>(track.size()) - 1;
        if (circular) {
            // start round 20% or 20 knots before the start and continue for additional 20% or 20 knots
            // done to have a continous merge of start and end
            start_idx = -std::min(20, static_cast<int>(track.size() * .2f));
            end_idx = static_cast<int>(track.size() - start_idx);
        }

        Vector2f current = track[circular_mod(start_idx, track.size())];
        Vector2f next;
        normalized_path.push_back(current);
        for (int i = start_idx + 1; i <= end_idx; i++) {
            next = track[circular_mod(i, track.size())];
            Vector2f direction = (next - current).normalized();

            // add all possible parts between next and current
            while ((next - current).squaredNorm() > h * h) {
                current += direction * h;
                normalized_path.push_back(current);
            }
            // we still have some part of (next - current) left but not enough to fulfill h
            Vector2f overnext = track[circular_mod(i + 1, track.size())];
            while ((overnext - next).squaredNorm() < h * h) {
                // skip parts that are shorter than the desired knot distance
                i++;
                overnext = track[circular_mod(i + 1, track.size())];
            }
            // we don't want this in a not circular track as this is the start
            if (!circular && i >= end_idx)
                break;
            // use pythagoras to get the length of the next path we need to add to maintain the distance `h` across the hypotenuse
            float b = std::sqrt(h * h - (next - current).squaredNorm());
            Vector2f next_direction = (overnext - next).normalized();
            current = next + (next_direction * b);
            normalized_path.push_back(current);
        }
    }

    std::cout << "normalized path length: " << normalized_path.size() << std::endl;

    VectorXf x(normalized_path.size());
    VectorXf y(normalized_path.size());

    for (size_t i = 0; i < normalized_path.size(); i++) {
        x(i) = normalized_path[i].x();
        y(i) = normalized_path[i].y();
    }

    std::cout << "starting fit" << std::endl;

    fit(alpha, beta, gamma, h, p, h_spline, x, y);

    std::cout << "track spline fitted" << std::endl;

    if (circular) {
        // join the spline together at the start
        // find closest knot to the expected start of the track in the first half
        size_t closest_start_idx = 0;
        size_t closest_end_idx = 0;
        float dist_sq = std::numeric_limits<float>::max();

        for (size_t i = 0; i < size() / 2; i++) {
            float dist = (track[0] - this->p(i)).squaredNorm();
            if (dist < dist_sq) {
                closest_start_idx = i;
                dist_sq = dist;
            }
        }
        // look in the second half for the end
        dist_sq = std::numeric_limits<float>::max();
        for (size_t i = size() - 1; i > size() / 2; i--) {
            float dist = (track[0] - this->p(i)).squaredNorm();
            if (dist < dist_sq) {
                closest_end_idx = i;
                dist_sq = dist;
            }
        }

        // now slice the splines to join up
        _x.slice(closest_start_idx, closest_end_idx);
        _y.slice(closest_start_idx, closest_end_idx);
    }
}
void TrackSpline::fit(float alpha, float beta, float gamma, float h, float p, float h_spline, bool circular, const nav_msgs::Path &path) {
    std::vector<Vector2f> track;
    track.reserve(path.poses.size());

    std::transform(path.poses.begin(), path.poses.end(), std::back_inserter(track),
                   [](auto &pose) -> Vector2f { return Vector2f(pose.pose.position.x, pose.pose.position.y); });

    fit(alpha, beta, gamma, h, p, h_spline, circular, track);
}

void TrackSpline::calculateOrientationAndCurvature() {
    _theta = VectorXf(size());
    _theta_angle = MatrixXf(size(), 2);
    _kappa = VectorXf(size());
    for (size_t i = 0; i < size(); i++) {
        _theta(i) = std::atan2(_y.yp(i), _x.yp(i));
        _theta_angle.block<1,2>(i, 0) = Eigen::RowVector2f(-std::sin(_theta(i)), std::cos(_theta(i)));
        _kappa(i) = (_x.yp(i) * _y.ypp(i) - _x.ypp(i) * _y.yp(i)) / (std::pow(_x.yp(i) * _x.yp(i) + _y.yp(i) * _y.yp(i), 1.5f));
    }
}

void TrackSpline::slice(size_t start, size_t end) {
    end = std::min(end, size());

    _x.slice(start, end);
    _y.slice(start, end);

    if (static_cast<size_t>(_theta.rows()) >= end)
        _theta = _theta.segment(start, end - start);
    if (static_cast<size_t>(_theta_angle.rows()) >= end)
        _theta_angle = _theta_angle.block(start, end - start, end - start, 2);
    if (static_cast<size_t>(_kappa.rows()) >= end)
        _kappa = _kappa.segment(start, end - start);
}

void TrackSpline::shift(long offset) {
    _x.shift(offset);
    _y.shift(offset);

    shiftMatrix(_theta, offset);
    shiftMatrix(_theta_angle, offset);
    shiftMatrix(_kappa, offset);
}

void TrackSpline::offsetTime(float t) {
    _x.offsetTime(t);
    _y.offsetTime(t);
}