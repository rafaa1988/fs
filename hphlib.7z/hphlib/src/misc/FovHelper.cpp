#include <cmath>
#include <utility>
#include <geometry_msgs/PolygonStamped.h>

#include <hphlib/misc/FovHelper.h>


FovHelper::FovHelper(ros::NodeHandle& n, std::string pub_topic, std::string frame_id, float near, float far, float max_angle)
    : frame_id(std::move(frame_id))
    , near_observation_distance(near)
    , far_observation_distance(far)
    , max_observation_angle(static_cast<float>(max_angle * M_PI / 180))
    , fov_pub_(n.advertise<geometry_msgs::PolygonStamped>(pub_topic, 1))
{
}

void FovHelper::publish() {
    geometry_msgs::PolygonStamped poly;

    // far points
    for (float theta = -max_observation_angle; theta < max_observation_angle; theta += max_observation_angle / 50 * M_PI) {
        geometry_msgs::Point32 p;
        p.x = cosf(theta) * far_observation_distance;
        p.y = sinf(theta) * far_observation_distance;
        poly.polygon.points.push_back(p);
    }

    //near points
    for (float theta = max_observation_angle; theta > -max_observation_angle; theta -= max_observation_angle / 50 * M_PI) {
        geometry_msgs::Point32 p;
        p.x = cosf(theta) * near_observation_distance;
        p.y = sinf(theta) * near_observation_distance;
        poly.polygon.points.push_back(p);
    }

    poly.header.stamp = ros::Time::now();
    poly.header.frame_id = frame_id;

    fov_pub_.publish(poly);
}

bool FovHelper::angleDistInFov(float angle, float dist) {
    return dist > near_observation_distance &&
           dist < far_observation_distance &&
           angle > -max_observation_angle &&
           angle < max_observation_angle;
}

bool FovHelper::pointInFov(Eigen::Vector2f point) {
    return angleDistInFov(point.norm(), atan2f(point.y(), point.x()));
}