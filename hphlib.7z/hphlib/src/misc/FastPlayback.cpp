#include <hphlib/misc/FastPlayback.h>

#include <rosbag/view.h>
#include <ros/callback_queue.h>

using hphlib::FastPlayback;

FastPlayback::FastPlayback(std::shared_ptr<ros::NodeHandle> node)
        : node_(std::move(node))
{
}

void FastPlayback::play(const rosbag::Bag &bag) {
    ros::CallbackQueue q;

    std::vector<std::string> topics;

    for (const auto& entry : handlers_) {
        topics.push_back(entry.first);
    }

    rosbag::View view(bag, rosbag::TopicQuery(topics));

    for (const rosbag::MessageInstance& m : view) {

        handlers_[m.getTopic()](m);

        ros::spinOnce();
    }
}
