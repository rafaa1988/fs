#pragma once

#include <hphlib/optional.h>
#include <functional>
#include <hphlib/Status.h>
#include <ros/subscriber.h>


namespace hphlib {
    namespace vehicle {

        /**
         * Get a human readable representation of the given AMI
         * @param ami Autonomous mission
         * @return Readable string
         */
        std::string decodeAmi(uint8_t ami);

        /**
         * Monitor the state machine state of the vehicle and execute callbacks on state change. Integrates with
         * the ROS event loop.
         */
        class StatusMonitor final {
        private:
            std::function<void()> go_callback_;
            std::function<void()> ready_callback_;
            std::function<void()> off_callback_;
            std::function<void(const std::string&)> state_change_callback_;
            std::function<void(uint8_t)> mission_change_callback_;
            std::function<void()> asms_on_callback_;
            std::function<void()> asms_off_callback_;
            ros::Subscriber status_sub_;

            hphlib::optional<uint8_t> mission_on_ready_;
            std::string last_state_;
            uint8_t last_mission_;
            bool last_asms_;

            void status_callback(const hphlib::Status::ConstPtr& msg);

        public:

            static constexpr const char* STATUS_TOPIC = "/vehicle/status";
            static constexpr const char* STATE_DRIVING = "driving";
            static constexpr const char* STATE_READY = "ready";
            static constexpr const char* STATE_OFF = "off";
            static constexpr const char* STATE_FINISHED = "finished";
            static constexpr const char* STATE_EMERGENCY = "emergency";

            /**
             * Initialize new status monitor with the given node handle
             */
            explicit StatusMonitor(ros::NodeHandle &n);

            /**
             * Get the mission that was selected when the vehicle entered ready state
             * @return Selected mission
             * @throws std::logic_error If vehicle did not enter ready state once
             */
            uint8_t mission_on_ready() const;

            /**
             * Get the current state, may be empty if no state observed
             * @return Current state
             */
            const std::string& state() const;

            void set_asms_on_callback(std::function<void()> cb);
            void set_asms_off_callback(std::function<void()> cb);

            /**
             * Set the go callback. This callback is edge-triggered when the vehicle enters driving state
             * @param cb Callback
             */
            void set_go_callback(std::function<void()> cb);

            /**
             * Set the ready callback. This callback is edge-triggered when the vehicle enters ready state
             * @param cb Callback
             */
            void set_ready_callback(std::function<void()> cb);

            /**
             * Set the off callback. This callback is edge-triggered when the vehicle enters off state.
             * NOTE: Since the initial state of this monitor is 'unknown', this callback will be called on off if it
             * is the first state seen.
             * @param cb Callback
             */
            void set_off_callback(std::function<void()> cb);

            /**
             * Set a callback that is called whenever the vehicle state is changed. Takes new state as argument.
             * This callback is also called on the first state observed. Since the callback is executed before
             * changing the stored state, the previous state may be accessed in the callback by inspecting state()
             * of this monitor.
             * @param cb Callback
             */
            void set_state_change_callback(std::function<void(const std::string&)> cb);

            /**
             * Set a callback that is called whenever the mission changes. Takes new mission as argument. Is only
             * invoked if the selected mission is a valid mission, that is one present in the constants of this class.
             * @param cb Callback
             */
            void set_mission_change_callback(std::function<void(uint8_t)> cb);
        };
    }
}