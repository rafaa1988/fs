#pragma once

#include <string>
#include "optional.h"

namespace hphlib {

    namespace os {

        /**
         * Operation mode for execute
         */
        enum class ExecuteMode {
            /**
             * Search for process image in path environment, i.e. 'echo'
             */
                    SearchExecutable,
            /**
             * Process image is absolute or relative path, i.e. '/bin/echo'
             */
                    Path
        };

        /**
         * Wrapper for execv that safely executes a new process image in a forked process and determines whether the
         * launch for successful through pipe communication
         * @param image Process image to execute, interpretation depends on execute mode
         * @param args nullptr terminated argument list wherer the first argument is also path
         * @param mode Execution mode
         * @return PID of launched process
         * @throws std::system_error On error
         */
        pid_t execute(const char *image, char *const *args, ExecuteMode mode = ExecuteMode::Path);

        /**
         * Signal process
         * @param pid PID of process
         * @param sig Signal ID
         */
        void signal(pid_t pid, int sig);

        /**
         * Check whether child was terminated, if so return exit code
         * @param pid PID of child process
         * @return Exit status of child or nothing if not terminated
         */
        hphlib::optional<int> checkTerminated(pid_t pid);

        /**
         * Wait for child to be terminated and return exit code
         * @param pid PID of child process
         */
        int waitTerminated(pid_t pid);

        /**
         * Get the home directory of the current user
         * @return Path to home directory
         * @throws std::system_error If password database cannot be queried
         * @throws std::runtime_error If home directory is not set
         */
        const char *getHomeDir();

        /**
         * Get the path of the current process executable file
         * @return Path
         * @throws std::system_error If the self process entry cannot be read
         */
        std::string getCurrentProcessExecutablePath();

    }
}