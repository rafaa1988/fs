#pragma once

#include <boost/optional.hpp>

namespace hphlib {
    template <typename T>
    using optional = boost::optional<T>;
}