#pragma once

#include "Socket.h"
#include "Ipv4Endpoint.h"

namespace hphlib {
    /**
     * @brief TCP/IPv4 socket abstraction and error handling
     *
     * @author Maximilian Schier
     */
    class TcpSocket final : public Socket {
    private:
        /**
         * Wrap existing socket
         * @param fd file descriptor for socket
         */
        TcpSocket(FileDescriptor fd);
    public:
        using Endpoint = Ipv4Endpoint<SOCK_STREAM>;

        static constexpr uint16_t DYNAMIC_PORT = 0;

        /**
         * Create an unusable TCP socket
         */
        TcpSocket() noexcept = default;

        /**
         * Allocate a new TCP socket and optionally bind to a specific port.
         * Note: Do not bind to a specific port, because you want to operate a TCP server, an Acceptor socket is
         * required for this task. The only use case for using a static port here is the remote host filters based
         * on origin port.
         * @param bound_port Port this socket should be bound to on the local host. Use DYNAMIC_PORT to let the
         * operating system assign any port on first connection.
         * @throws std::system_error on error
         */
        explicit TcpSocket(uint16_t bound_port);

        TcpSocket(TcpSocket&& that) noexcept = default;
        TcpSocket& operator=(TcpSocket&& that) noexcept = default;

        /**
         * Accept an incoming connection if this is a passive acceptor socket
         * @param remote Optional pointer to remote structure to be filled with remote endpoint, may be nullptr
         * @return Socket handling new connection
         */
        TcpSocket accept(Endpoint* remote = nullptr);

        /**
         * Connect this socket with the given remote endpoint.
         * @param remote Remote endpoint
         * @throws std::system_error on error
         */
        void connect(const Endpoint& remote);

        /**
         * Mark this socket as a passive acceptor socket that will serve incoming connections
         * @param backlog Backlog size
         */
        void listen(int backlog);

        /**
         * Receive bytes, fully filling the specified buffer with the specified amount of bytes. Note that this function
         * may call kernel receive functions multiple times, in total exceeding any configured receive timeout which
         * applies to individual receives.
         * @param buffer Buffer to copy received bytes to
         * @param size Exact amount of bytes to receive
         * @throws std::system_error on sytem related error
         * @throws std::runtime_error if the remote host closed the connection before receiving all bytes
         */
        void receiveExact(uint8_t *buffer, size_t size);

        /**
         * Receive some bytes into the specified buffer, but at most the specified amount. This function may return
         * 0 bytes received if the remote hosed closed its writer side of the connection.
         * @param buffer Buffer to copy received bytes to
         * @param size Maximum amount of bytes to receive
         * @return Number of bytes received
         * @throws std::system_error on error
         */
        size_t receiveSome(uint8_t* buffer, size_t size);

        /**
         * Send the specified buffer
         * @param buffer Buffer to send
         * @param size Size of buffer in bytes
         * @throws std::system_error on error
         */
        void send(const uint8_t* buffer, size_t size);

        /**
         * Set whether Nagle's algorithm should be enabled on this socket. This algorithm delays sending packets until
         * a "sufficient" amount of output bytes were buffered. It is highly encouraged to explicitly disable this
         * algorithm for communication with devices and always send full frames. This algorithm is enabled on Linux by
         * default
         * @param enabled True to enable, false to disable
         * @throws std::system_error on error
         */
        void setNagleEnabled(bool enabled);
    };
}