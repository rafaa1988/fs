#pragma once

namespace hphlib {

    /**
     * @brief Wrapper to manage native file descriptors
     *
     * @author Maximilian Schier
     */
    class FileDescriptor final {
    private:
        int fd_;

    public:
        /**
         * Instantiate an uninitialized file descriptor
         */
        FileDescriptor() noexcept;

        /**
         * Wrap an existing native file descriptor
         * @param native
         */
        explicit FileDescriptor(int native) noexcept;

        FileDescriptor(const FileDescriptor &that) = delete;
        FileDescriptor &operator=(const FileDescriptor &that) = delete;

        FileDescriptor(FileDescriptor &&that) noexcept;
        FileDescriptor &operator=(FileDescriptor &&that) noexcept;

        /**
         * Close the native file descriptor if allocated
         */
        ~FileDescriptor();

        /**
         * Whether this file descriptor is initialized
         * @return True if so, otherwise false
         */
        explicit operator bool() const noexcept;

        /**
         * Return the native file descriptor
         * @return Native file descriptor
         */
        operator int() const noexcept;

        /**
         * Swap this file descriptor with another one
         * @param that Other
         */
        void swap(FileDescriptor& that) noexcept;

        /**
         * Closes this file descriptor if it is still open.
         *
         * Signal-safety: Async signal safe
         */
        void close();
    };
}

// Prevent closing managed file descriptor manually through implicit cast by providing unimplemented methods
void close(hphlib::FileDescriptor&& fd);
void close(const hphlib::FileDescriptor& fd);