#pragma once

#include <netdb.h>
#include <netinet/in.h>
#include <sstream>

namespace hphlib {
    /**
     * @brief Remote endpoint for the IPv4 protocol
     *
     * Handles resolving of remote ip addresses and host names and manages the lifetime of the structures returned by
     * the kernel. Usually this class isn't used directly, but through the instance defined by the used socket, like
     * UdpSocket::Endpoint.
     *
     * @tparam SockType Socket type to resolve for
     *
     * @author Maximilian Schier
     */
    template <int SockType>
    class Ipv4Endpoint final {

        union {
            addrinfo* resolved;
            sockaddr_in assigned;
        } val_;

        bool was_resolved_;

    public:

        /**
         * Instantiate an unresolved remote address that cannot be used
         */
        Ipv4Endpoint() noexcept
            : was_resolved_(true)
        {
            val_.resolved = nullptr;
        }

        /**
         * Initialize a new endpoint by directly wrapping the given sockaddr structure
         * @param set_addr Socket address, for example obtained by receiving from a UDP port
         */
        explicit Ipv4Endpoint(sockaddr_in set_addr) noexcept
            : was_resolved_(false)
        {
            val_.assigned = set_addr;
        }

        /**
         * Resolve a remote endpoint
         * @param host Hostname
         * @param port Port
         * @throws std::runtime_error on resolver error
         */
        Ipv4Endpoint(const char* host, uint16_t port)
            : was_resolved_(true)
        {
            val_.resolved = nullptr;

            addrinfo hints{};
            hints.ai_family   = AF_INET;    // Must take IPv4 here since socket is created with IPv4
            hints.ai_socktype = SockType;

            std::stringstream port_stream;
            port_stream << port;

            // Store linked list of address infos in result for given host and port
            int s = getaddrinfo(host, port_stream.str().c_str(), &hints, &val_.resolved);

            if (s != 0 || val_.resolved == nullptr) {
                std::stringstream stream;
                stream << "Failed to get address information for " << host << ":" << port << ": " << gai_strerror(s);
                throw std::runtime_error(stream.str());
            }
        }

        Ipv4Endpoint(const Ipv4Endpoint& that) = delete;
        Ipv4Endpoint& operator=(const Ipv4Endpoint& that) = delete;

        Ipv4Endpoint(Ipv4Endpoint&& that) noexcept
            : Ipv4Endpoint()
        {
            this->swap(that);
        }

        Ipv4Endpoint& operator=(Ipv4Endpoint&& that) noexcept {
            this->swap(that);
            return *this;
        }

        /**
         * Get the length of the first address stored
         * @return Length in bytes
         * @throws std::system_error If endpoint has not been resolved or set
         */
        socklen_t len() const {
            if (was_resolved_) {
                if (val_.resolved == nullptr) {
                    throw std::logic_error("This endpoint has not been resolved or set");
                }

                return val_.resolved->ai_addrlen;
            } else {
                return sizeof(val_.assigned);
            }
        }

        /**
         * Get a non-owning pointer to the first address stored. Valid while this object is not modified
         * @return Point to first address structure
         * @throws std::system_error If endpoint has not been resolved or set
         */
        const sockaddr* addr() const {
            if (was_resolved_) {
                if (val_.resolved == nullptr) {
                    throw std::logic_error("This endpoint has not been resolved or set");
                }

                return val_.resolved->ai_addr;
            } else {
                return reinterpret_cast<const sockaddr *>(&val_.assigned);
            }
        }

        /**
         * Return whether this endpoint is usable, that is either was successfully resolved or explicitly set from
         * kernel sockaddr
         * @return True if usable
         */
        operator bool() const noexcept {
            return !was_resolved_ || val_.resolved != nullptr;
        }

        /**
         * Swap this remote endpoint object with another one
         * @param that Other endpoint object
         */
        void swap(Ipv4Endpoint& that) noexcept {
            if (this->was_resolved_ && that.was_resolved_) {
                std::swap(this->val_.resolved, that.val_.resolved);
            } else if (this->was_resolved_ && !that.was_resolved_) {
                addrinfo* tmp = this->val_.resolved;
                this->val_.assigned = that.val_.assigned;
                that.val_.resolved = tmp;
            } else if (!this->was_resolved_ && that.was_resolved_) {
                addrinfo* tmp = that.val_.resolved;
                that.val_.assigned = this->val_.assigned;
                this->val_.resolved = tmp;
            } else {
                std::swap(this->val_.assigned, that.val_.assigned);
            }

            std::swap(this->was_resolved_, that.was_resolved_);
        }

        ~Ipv4Endpoint() {
            if (was_resolved_ && this->val_.resolved != nullptr) {
                freeaddrinfo(this->val_.resolved);

                this->val_.resolved = nullptr;
            }
        }
    };
}