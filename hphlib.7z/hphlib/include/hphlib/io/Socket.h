#pragma once

#include <cstddef>
#include "FileDescriptor.h"

namespace hphlib {

    /**
     * @brief Socket wrapper and common socket operations
     *
     * Wraps a managed file descriptor and implements socket based file descriptor operations.
     * A socket is usually obtained by calling allocate() directly, or by using an extending class
     * such as UdpSocket
     *
     * @author Maximilian Schier
     */
    class Socket {
    protected:
        FileDescriptor fd_;

        /**
         * Get the file status flag word of this socket
         * @return Flag word
         * @throws std::system_error on error
         */
        int getFileStatusFlags() const;

        /**
         * Set the file status flag word of this socket
         * @param flags New flag word
         * @throws std::system_error on error
         */
        void setFileStatusFlags(int flags);

    public:

        /**
         * Create an unusable socket
         */
        Socket() = default;

        /**
         * Create a socket by wrapping an existing managed file descriptor
         * @param fd Managed file descriptor
         */
        explicit Socket(FileDescriptor fd);

        /**
         * Allocate a new socket of the given domain, type and protocol
         * @param domain Domain, i.e. AF_INET for IPv4 domain
         * @param type Type, i.e. SOCK_STREAM for stream type
         * @param protocol Protocol, i.e. 0 for default (usually TCP with above parameters)
         * @throws std::system_error on error
         */
        Socket(int domain, int type, int protocol);

        Socket(Socket&& that) = default;
        Socket& operator=(Socket&& that) = default;
        
        virtual ~Socket() = default;

        /**
         * Return whether this socket is currently wrapping a file descriptor that appears to be valid
         * @return True if so
         */
        explicit operator bool();

        /**
         * Get the underlying native file descriptor of this socket
         * @return Native file descriptor
         */
        operator int();

        /**
         * Return the currently set receive buffer size in bytes without additional kernel bookkeeping
         * @return Size in bytes
         * @throws std::system_error on error while querying
         */
        size_t getReceiveBufferSize() const;

        /**
         * Return whether this socket is blocking
         * @return True if blocking, otherwise false
         * @throws std::system_error on error while querying
         */
        bool isBlocking() const;

        /**
         * Set the blocing status of this socket
         * @param block True to block, false to use non-blcking io
         * @throws std::system_error on error
         */
        void setBlocking(bool block);

        /**
         * Set the socket-subsystem allocated receive buffer size for this socket to the given size without bookkeeping
         * overhead (internally kernel increases size)
         * @param size Size in bytes for native receive buffer
         * @throws std::system_error When receive buffer size cannot be set
         */
        void setReceiveBufferSize(size_t bytes);

        /**
         * Set the receive timeout to the given period
         * @param millis Milliseconds until receive fails or 0 for no timeout errors
         * @throws std::system_error When timeout cannot be set; usually because the socket was not allocated
         */
        void setReceiveTimeoutMs(int millis);
    };

}