#pragma once
#include <string>
#include <linux/can.h>
#include "Socket.h"

namespace hphlib {

    /**
     * @brief Access CAN bus through SocketCAN
     *
     * CanSocket uses the SocketCAN driver, which provides access to CAN networks
     * through the standard BSD socket system of Linux to provide userland access
     * to CAN. This class expects the userland device file of socket can to be fully
     * configured to the correct baud rate, for example through 'ip link set'
     *
     * @author Maximilian Schier
     */
    class CanSocket final : public Socket {
    public:
        /**
         * Create an unusable socket
         */
        CanSocket() noexcept = default;

        /**
         * Instantiate a new CAN socket for the given interface.
         * Note that SocketCAN allows interface sharing, multiple
         * subscribers to the interface will receive all messages through their
         * own buffer and can all send data.
         * @param interface_name Name of interface as seen in ifconfig, i.e. 'can0'
         * @throws std::length_error If interface name is excessively long
         */
        explicit CanSocket(const char* interface_name);

        CanSocket(CanSocket&& that) noexcept = default;
        CanSocket& operator=(CanSocket&& that) noexcept = default;

        /**
         * Receive a CAN frame on the interface
         * @param sender_out Pointer to canid_t where sender address will be stored, may be nullptr
         * @param length_out Pointer to u8 where data length will be stored, may be nullptr
         * @param buffer_out Pointer to u8 buffer where data is stored, must be at least 8 bytes in size
         * @throws std::system_error On system transmission error
         */
        void receiveBuffer(canid_t *sender_out, __u8 *length_out, __u8 *buffer_out);

        /**
         * Send a buffer to the specified target
         * @param target Target address
         * @param buffer Pointer to start of buffer
         * @param length Length of buffer, must not exceed 8
         * @throws std::system_error On system transmission error
         * @throws std::length_error On excessively large buffers
         */
        void sendBuffer(canid_t target, const __u8 *buffer, __u8 length);

        /**
         * Send a C-compatible data structure to the specified target
         * @tparam T POD data type, like int, float, a POD struct, etc.
         * @param target Target address
         * @param data Data to be sent
         * @throws See sendBuffer()
         */
        template<typename T>
        void sendPod(canid_t target, const T &data) {
            static_assert(std::is_pod<T>::value, "T must be POD type");

            static_assert(sizeof data <= 8, "sizeof(T) <= 8");

            sendBuffer(target, reinterpret_cast<const __u8 *>(&data), sizeof data);
        }
    };
}