#pragma once

#include <cstdint>
#include <linux/spi/spidev.h>
#include "FileDescriptor.h"

namespace hphlib {

    /**
     * @brief Userland SPI device file handle
     *
     * SPI provides userland access to a Serial Peripheral Interface device.
     * While linux SPI device files are compatible with the standard file API
     * transferring data through read() and write(), this class allows full
     * duplex transfer with the device (simultaneous reading and writing).
     * Since userland protocol drivers have rather high latency and jitter,
     * this class should only be employed for testing and low performance
     * use cases.
     *
     * @author Maximilian Schier
     */
    class SPI final {
        FileDescriptor fd_;
        uint8_t bits_per_word_;
        uint32_t speed_;

    public:

        /**
         * SPI bus mode
         */
        enum class Mode : uint8_t {
            /**
             * SPI mode 0, CPOL = 0, clock idle low, CPHA = 0, rising edge phase
             */
                    M0 = SPI_MODE_0,
            /**
             * SPI mode 1, CPOL = 0, clock idle low, CPHA = 1, falling edge phase
             */
                    M1 = SPI_MODE_1,
            /**
             * SPI mode 2, CPOL = 1, clock idle high, CPHA = 0, falling edge phase
             */
                    M2 = SPI_MODE_2,
            /**
             * SPI mode 3, CPOL = 1, clock idle high, CPHA = 1, rising edge phase
             */
                    M3 = SPI_MODE_3
        };

        /**
         * Instantiate unusable SPI device handle
         */
        SPI() noexcept = default;

        /**
         * Instantiate a new SPI handle for the given device file and configuration
         * @param device Path to device file
         * @param mode SPI mode
         * @param bits_per_word Bits to send per word, usually 8
         * @param speed Bus clock in Hz
         */
        SPI(const char *device, Mode mode, uint8_t bits_per_word, uint32_t speed);

        SPI(SPI&& that) noexcept = default;
        SPI& operator=(SPI&& that) noexcept = default;

        /**
         * Perform a full duplex transfer by pulling down slave select, sending specified
         * amount of bytes from the given buffer and simultaneously receiving the same amount
         * of bytes, overwriting the buffer, then pulling up slave select.
         * @param buffer Pointer to buffer containing data to send, will be overwritten with received bytes
         * @param length Length of buffer
         * @throws std::system_error On transfer error
         */
        void fullDuplexTransfer(uint8_t *buffer, uint32_t length);
    };
}