#pragma once

#include <hphlib/io/FileDescriptor.h>

namespace hphlib {

    struct PipeTypeAnonymous final {};

    constexpr PipeTypeAnonymous PipeAnonymous = {};

    class Pipe final {
    private:
        FileDescriptor reader_;
        FileDescriptor writer_;

    public:
        /**
         * Default constructor for unusable pipe
         */
        Pipe() = default;

        /**
         * Create a new anonymous pipe
         * @param p hphlib::PipeAnonymous or any other hphlib::PipeTypeAnonymous
         */
        explicit Pipe(const PipeTypeAnonymous& p);

        Pipe(Pipe&& that) = default;
        Pipe& operator=(Pipe&& that) = default;

        /**
         * Return the reader file descriptor of this pipe
         * @return Reader file descriptor
         */
        FileDescriptor& reader();

        /**
         * Return the writer file descriptor of this pipe
         * @return Writer file descriptor
         */
        FileDescriptor& writer();
    };
}