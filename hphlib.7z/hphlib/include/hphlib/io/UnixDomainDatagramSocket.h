#pragma once

#include "Socket.h"
#include <cstdint>
#include <string>
#include <sys/socket.h>
#include <sys/un.h>

namespace hphlib {
    class UnixDomainDatagramSocket final : public Socket {
    public:

        class Endpoint final {
            friend class UnixDomainDatagramSocket;

            sockaddr_un addr_;
            socklen_t used_len_;

        public:
            /**
             * Create unsuable endpoint
             */
            Endpoint() noexcept;

            /**
             * Create abstract endpoint
             * @return Endpoint
             */
            static Endpoint abstract(const char* name);

            /**
             * Create unnamed endpoint
             * @return Endpoint
             */
            static Endpoint unnamed();

            void assertInitialized() const;

            /**
             * Return the abstract name of this endpoint without trailing zero byte in address structure
             * @return Abstract name
             * @throws std::logic_error If endpoint is not abstract
             */
            std::string abstractName() const;

            bool isAbstract() const;

            bool isPathname() const;

            bool isUnnamed() const;

            const sockaddr* addr() const;

            socklen_t len() const;
        };

        /**
         * Create unusable socket
         */
        UnixDomainDatagramSocket() noexcept;

        /**
         * Create a new socket bound to the specified endpoint
         * @param endpoint Local endpoint
         */
        explicit UnixDomainDatagramSocket(const Endpoint& endpoint);

        UnixDomainDatagramSocket(UnixDomainDatagramSocket&& that) = default;
        UnixDomainDatagramSocket& operator=(UnixDomainDatagramSocket&& that) = default;

        /**
         * Receive a datagram from any host and write to the buffer of given length.  Note that each call to receive
         * returns one datagram, meaning that a too small supplied buffer will cause all excess bytes of the datagram to
         * be dropped.
         * @param buffer Start of buffer
         * @param buffer_length Length of buffer in bytes
         * @param sender_out Optional pointer to Endpoint where sending endpoint will be stored
         * @return Number of bytes written to buffer
         * @throws std::system_error If no packet could be received
         */
        size_t receive(uint8_t *buffer, size_t buffer_length, Endpoint* sender_out = nullptr);

        /**
         * Send a packet to the specified remote.
         * @param buffer Start of buffer for packet data
         * @param buffer_length Length of buffer in bytes
         * @param remote Remote address
         * @throws std::system_error If the packet cannot be send
         * @throws std::logic_error If this remote address was not initialized
         */
        void sendTo(const uint8_t *buffer, size_t buffer_length, const Endpoint &remote);
    };
}