#pragma once

#include <netdb.h>
#include <cstddef>
#include <cstdint>
#include <string>
#include <stdexcept>
#include "Socket.h"
#include "Ipv4Endpoint.h"

namespace hphlib {

    /**
     * @brief UDP/IPv4 socket abstraction and error handling
     *
     * Managed wrapper for synchronous UDP socket handling.
     *
     * @author Maximilian Schier
     */
    class UdpSocket final : public Socket {
    public:

        using Endpoint = Ipv4Endpoint<SOCK_DGRAM>;

        /**
         * Returned by receive() on receive error
         */
        static constexpr ssize_t BAD_RECEIVE = -1;

        /**
         * Specifies that no timeout errors should occur, meaning that a socket will block until success or interrupt
         */
        static constexpr int NO_TIMEOUT = 0;

        /**
         * Specifies that the operating system may choose a port to bind this socket to.
         */
        static constexpr uint16_t DYNAMIC_PORT = 0;

        /**
         * Instantiate an unallocated socket. This socket cannot be used for any operation until it has been allocated.
         */
        UdpSocket() noexcept;

        /**
         * Allocate a new UDP/IPv4 socket binding to the specified port on all interfaces. If port is DYNAMIC_PORT,
         * the socket isn't bound yet and will be bound by the operating system on first IO to any free port.
         * @param port Port to bind to
         */
        explicit UdpSocket(uint16_t port);

        /**
         * Allocate a new UDP/IPv4 socket binding to the specified port on all interfaces. If port is DYNAMIC_PORT,
         * the socket isn't bound yet and will be bound by the operating system on first IO to any free port.
         * @param port Port to bind to
         * @param reuse Set port to reuse address and port
         */
        explicit UdpSocket(uint16_t port, bool reuse);

        UdpSocket(UdpSocket&& that) noexcept = default;
        UdpSocket& operator=(UdpSocket&& that) noexcept = default;

        /**
         * Receive a datagram from any host and write to the buffer of given length.  Note that each call to receive
         * returns one datagram, meaning that a too small supplied buffer will cause all excess bytes of the datagram to
         * be dropped.
         * Caution: Calling this function is legal even if the socket is not bound to any port
         * @param buffer Start of buffer
         * @param buffer_length Length of buffer in bytes
         * @param sender_out Optional pointer to Endpoint where sending endpoint will be stored
         * @return Number of bytes written to buffer
         * @throws std::system_error If no packet could be received
         */
        size_t receive(uint8_t *buffer, size_t buffer_length, Endpoint* sender_out = nullptr);

        /**
         * Receive a datagram from any host and write to the buffer of given length.  Note that each call to receive
         * returns one datagram, meaning that a too small supplied buffer will cause all excess bytes of the datagram to
         * be dropped.
         * Caution: Calling this function is legal even if the socket is not bound to any port
         * @param buffer Start of buffer
         * @param buffer_length Length of buffer in bytes
         * @param sender_out Optional pointer to Endpoint where sending endpoint will be stored
         * @return Number of bytes written to buffer or BAD_RECEIVE on error. The cause of the error can be determined
         * by examining the POSIX errno immediately after this call.
         */
        ssize_t receiveNoThrow(uint8_t *buffer, size_t buffer_length, Endpoint* sender_out = nullptr)
            __attribute__((warn_unused_result));

        /**
         * Send a packet to the specified remote. This function blocks until the packet is send
         * @param buffer Start of buffer for packet data
         * @param buffer_length Length of buffer in bytes
         * @param remote Remote address
         * @throws std::system_error If the packet cannot be send
         * @throws std::logic_error If this remote address was not resolved
         */
        void sendTo(const uint8_t *buffer, size_t buffer_length, const Endpoint &remote);
    };
}