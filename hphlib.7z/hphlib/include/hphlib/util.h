#pragma once

#include <boost/optional.hpp>
#include <hphlib/optional.h>
#include <ros/ros.h>
#include <string>

constexpr double DEG_TO_RAD = M_PI / 180.0;
constexpr double RAD_TO_DEG = 180.0 / M_PI;

namespace hphlib {
    template<typename T, typename Compare>
    constexpr const T& clamp(const T &v, const T &lo, const T &hi, Compare comp) {
        return assert(!comp(hi, lo)),
                comp(v, lo) ? lo : comp(hi, v) ? hi : v;
    }

    template<typename T>
    constexpr const T& clamp(const T &v, const T &lo, const T &hi) {
        return clamp(v, lo, hi, std::less<>());
    }
}

/**
 * Get an optional ROS parameter wrapped in an optional
 * @tparam T Parameter type
 * @param n Node handle
 * @param name Parameter name
 * @return Optional containing either the value of the parameter or empty
 */
template <typename T>
hphlib::optional<T> getOptionalRosParam(const ros::NodeHandle& n, const std::string& name) {
    T out;

    if (n.getParam(name, out)) {
        return { std::move(out) };
    } else {
        return {};
    }
}

/**
 * Get a required ROS parameter or throw if the operation fails
 * @tparam TIn Parameter type
 * @tparam TOut Optional return type if not identical to T, for example to return float, but ROS can only read double
 * @param n Node handle
 * @param name Parameter name
 * @return Value on success
 * @throws std::runtime_error If the parameter could not be read
 */
template <typename TIn, typename TOut = TIn>
TOut getRequiredRosParam(const ros::NodeHandle& n, const std::string& name) {

    TIn out;

    if (!n.getParam(name, out)) {
        ROS_ERROR(
                "%s: Parameter %s required but does not exist or has wrong type",
                n.getNamespace().c_str(),
                name.c_str()
        );
        throw std::runtime_error("Failed to get a required parameter, see log for details");
    }

    return static_cast<TOut>(out);
}

uint16_t getRequiredRosParamPort(const ros::NodeHandle& n, const std::string& name);

namespace hphlib {
    /**
     * Return whether the given system error was caused by a blocking resource error
     * @param e System error
     * @return True if so
     */
    bool isBlockingException(const std::system_error &e);


    constexpr boost::array<double, 9> buildCovMat3(float std1, float std2, float std3) {
        return {
            std1 * std1, 0, 0,
            0, std2 * std2, 0,
            0, 0, std3 * std3
        };
    }

    constexpr boost::array<double, 9> buildCovMat3(float std) {
        return buildCovMat3(std, std, std);
    }

    constexpr boost::array<double, 36> buildCovMat6(float std1, float std2, float std3,
                                                    float std4, float std5, float std6) {
        return {
            std1 * std1, 0, 0, 0, 0, 0,
            0, std2 * std2, 0, 0, 0, 0,
            0, 0, std3 * std3, 0, 0, 0,
            0, 0, 0, std4 * std4, 0, 0,
            0, 0, 0, 0, std5 * std5, 0,
            0, 0, 0, 0, 0, std6 * std6
        };
    }

    constexpr boost::array<double, 36> buildCovMat6(float std) {
        return buildCovMat6(std, std, std, std, std, std);
    }

    constexpr boost::array<double, 36> buildCovMat6(float std1, float std2) {
        return buildCovMat6(std1, std1, std1, std2, std2, std2);
    }

    /**
     * Circular modulo operation that returns a positive number as the python operator % would
     * E.g. 3 % 10 = 3
     * E.g. -3 % 10 = 7
     * @param numer
     * @param denom
     * @return
     */
    constexpr size_t circular_mod(int numer, size_t denom) {
        return (denom + (numer % static_cast<int>(denom))) % denom;
    }
}