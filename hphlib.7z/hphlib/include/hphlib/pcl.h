#pragma once

#include <cstdint>
#include <pcl_ros/point_cloud.h>

namespace hphlib {

    /**
     * ARGB color for lidar points that are classified as dirty
     */
    constexpr uint32_t LIDAR_COLOR_DIRT    = 0xff8b4513;

    /**
     * ARGB color for lidar points that are classified as ground
     */
    constexpr uint32_t LIDAR_COLOR_GROUND  = 0xff000000;

    /**
     * ARGB color for lidar points that are classified as clutter
     */
    constexpr uint32_t LIDAR_COLOR_CLUTTER = 0xffffff00;

    /**
     * ARGB color for lidar points that are not specifically classified
     */
    constexpr uint32_t LIDAR_COLOR_NEUTRAL = 0xffffffff;

    /**
     * ARGB color for reference points of red cones
     */
    constexpr uint32_t REF_COLOR_RED = 0xffff0000;

    /**
     * ARGB color for reference points of (red) finish line cones
     */
    constexpr uint32_t REF_COLOR_FINISH = 0xff00ff00;

    /**
     * ARGB color for reference points of yellow cones
     */
    constexpr uint32_t REF_COLOR_YELLOW = 0xffffff00;

    /**
     * ARGB color for reference points of blue cones
     */
    constexpr uint32_t REF_COLOR_BLUE = 0xff0000ff;

    constexpr uint32_t REF_COLORS[] = {
        REF_COLOR_RED,
        REF_COLOR_FINISH,
        REF_COLOR_YELLOW,
        REF_COLOR_BLUE
    };

    /**
     * Compare the RGB components of the given ARGB colors
     * @param a First color
     * @param b Second color
     * @return True if RGB components identical, otherwise false
     */
    constexpr bool sameRgb(uint32_t a, uint32_t b) {
        // Ignore alpha byte and compare
        return (a & 0x00ffffff) == (b & 0x00ffffff);
    }

    constexpr uint8_t rgbRed(uint32_t color) {
        return static_cast<uint8_t>(color >> 16);
    }

    constexpr uint8_t rgbBlue(uint32_t color) {
        return static_cast<uint8_t>(color);
    }

    constexpr uint8_t rgbGreen(uint32_t color) {
        return static_cast<uint8_t>(color >> 8);
    }

    constexpr uint8_t rgbAlpha(uint32_t color) {
        return static_cast<uint8_t>(color >> 24);
    }

    /**
     * Calculate squared distance of two three dimensional points
     * @tparam P Point type, must have x, y and z members
     * @param pt1 First point
     * @param pt2 Second point
     * @return Squared distance of points
     */
    template<typename P>
    constexpr auto distanceSquared(const P& pt1, const P& pt2) {
        return (pt1.x - pt2.x) * (pt1.x - pt2.x) + (pt1.y - pt2.y) * (pt1.y - pt2.y) + (pt1.z - pt2.z) * (pt1.z - pt2.z);
    }

    template<typename P>
    constexpr auto distanceSquaredFromOrigin(const P& pt) {
        return (pt.x * pt.x) + (pt.y * pt.y) + (pt.z * pt.z);
    }
}

// --- Operators for working with pcl points

template <typename N>
typename std::enable_if<std::is_arithmetic<N>::value, pcl::PointXYZ>::type
operator*(const pcl::PointXYZ& p, const N f) {
    return { p.x * f, p.y * f, p.z * f };
}

template <typename N>
typename std::enable_if<std::is_arithmetic<N>::value, pcl::PointXYZ>::type
operator/(const pcl::PointXYZ& p, const N f) {
    return { p.x / f, p.y / f, p.z / f };
}

inline float L2_Norm_SQR(const pcl::PointXYZ& p1, const pcl::PointXYZ& p2) {
    return p1.x * p2.x + p1.y * p2.y + p1.z * p2.z;
}

inline float L2_Norm(const pcl::PointXYZ& p1, const pcl::PointXYZ& p2) {
    return std::sqrt(L2_Norm_SQR(p1, p2));
}

inline float L2_Norm_SQR(const pcl::PointXYZ& p) {
    return L2_Norm_SQR(p, p);
}

inline float L2_Norm(const pcl::PointXYZ& p) {
    return L2_Norm(p, p);
}

inline pcl::PointXYZ operator+(const pcl::PointXYZ& p1, const pcl::PointXYZ& p2) {
    return { p1.x + p2.x, p1.y + p2.y, p1.z + p2.z };
}

inline pcl::PointXYZ pointStripColor(const pcl::PointXYZRGBA& pt) {
    return { pt.x, pt.y, pt.z };
}

inline pcl::PointXYZRGBA pointWithColor(const pcl::PointXYZ& pt, uint32_t rgba) {
    pcl::PointXYZRGBA pt2{};
    pt2.x = pt.x;
    pt2.y = pt.y;
    pt2.z = pt.z;
    pt2.rgba = rgba;

    return pt2;
}