#pragma once

#include <map>
#include <string>
#include <ros/ros.h>
#include <rosbag/bag.h>

namespace hphlib {
    /**
     * Fast rosbag playback, busy loops the roscore by publishing a message from a rosbag, then spinning the node once.
     * This allows playing rosbags at the maximum speed while still being able to use features such as message filters
     * that only work on live data and cannot be applied directly to rosbags. Since the node is spun after each message, the
     * rosbag cannot outrun the listeners, since spinning immediately returns, as soon as the listeners are ready the next
     * message is published.
     *
     * CAUTION: The node using this class must be single threaded. The roscore must not publish messages from other sources
     * on the added topics.
     */
    class FastPlayback final {

        std::map<std::string, std::function<void(const rosbag::MessageInstance&)>> handlers_;
        std::shared_ptr <ros::NodeHandle> node_;

    public:
        explicit FastPlayback(std::shared_ptr <ros::NodeHandle> node);

        template<typename T>
        void addTopic(const std::string &name) {
            handlers_[name] = [n = name, pub = node_->advertise<T>(name, 1)](const rosbag::MessageInstance &m) {

                auto ptr = m.instantiate<T>();

                if (ptr == nullptr) {
                    std::stringstream estream;
                    estream << "Playback error: Topic \"" << n << "\" has mismatching type with registered handler";
                    throw std::runtime_error(estream.str());
                }

                pub.publish(ptr);
            };
        }

        void play(const rosbag::Bag &bag);
    };
}