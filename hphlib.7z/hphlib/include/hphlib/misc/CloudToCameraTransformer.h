#pragma once

#include <image_geometry/pinhole_camera_model.h>
#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <tf/transform_listener.h>

namespace hphlib {

    /**
     * Span a rectangle facing the camera for the given point, then construct the smallest image corners that
     * enclose that rectangle, returning a two dimensional rectangle in pixel coordinates enclosing a square of the
     * physical width and height in the point cloud. Used to generate sub images from point cloud data of comparable
     * physical dimensions.
     * @throws tf2::LookupException On tf lookup errors
     */
    cv::Rect2d spanRectangle(const tf::Stamped<tf::Point>& point, float size,
                             const image_geometry::PinholeCameraModel& model,
                             tf::TransformListener& tf_listener);

    constexpr float CLOUD_TO_CAMERA_DEFAULT_BOX_SIZE = 0.4f;

    /**
     * @brief Transform point clouds to camera images
     */
    template <typename P>
    class CloudToCameraTransformer final {
    public:

        using CloudType = pcl::PointCloud<P>;

        struct TransformPoint {
            cv::Point2d projectedPoint;
            cv::Rect2d  projectedBox;
            float distance;
        };

        struct Transform {
            sensor_msgs::Image::ConstPtr image;
            sensor_msgs::CameraInfo::ConstPtr camera_info;
            image_geometry::PinholeCameraModel camera_model;
            typename CloudType::ConstPtr cloud;
            std::vector<TransformPoint> transforms;
        };

    private:

        using SYNC = message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::CameraInfo, CloudType>;

        tf::TransformListener tf_listener_;
        message_filters::Subscriber<sensor_msgs::Image> img_sub_;
        message_filters::Subscriber<sensor_msgs::CameraInfo> info_sub_;
        message_filters::Subscriber<CloudType> pcl_sub_;
        message_filters::Synchronizer<SYNC> synchronizer_;
        std::function<void(Transform)> user_callback_;
        bool do_box_;

        void callback(const sensor_msgs::Image::ConstPtr& img, const sensor_msgs::CameraInfo::ConstPtr& info, const typename CloudType::ConstPtr& pcl) {

            Transform result{};
            result.image       = img;
            result.camera_info = info;
            result.cloud       = pcl;

            result.camera_model.fromCameraInfo(info);

            CloudType transformed_cloud;

            if (!pcl_ros::transformPointCloud(info->header.frame_id, *pcl, transformed_cloud, tf_listener_)) {
                return;
            }

            for (const auto& point : transformed_cloud) {
                cv::Point3d pt3d = cv::Point3d(point.x, point.y, point.z);

                TransformPoint tp{};
                tp.projectedPoint = result.camera_model.project3dToPixel(pt3d);
                tp.projectedPoint = result.camera_model.unrectifyPoint(tp.projectedPoint);
                tp.distance       = std::sqrt((point.x * point.x) + (point.y * point.y) + (point.z * point.z));

                result.transforms.push_back(tp);
            }

            if (do_box_) {

                for (size_t i = 0; i < pcl->size(); ++i) {

                    const auto& point(pcl->points[i]);

                    tf::Stamped<tf::Point> stamped_pt {
                            {point.x, point.y, point.z},
                            pcl_conversions::fromPCL(pcl->header.stamp),
                            pcl->header.frame_id
                    };

                    result.transforms[i].projectedBox = spanRectangle(
                            stamped_pt,
                            CLOUD_TO_CAMERA_DEFAULT_BOX_SIZE,
                            result.camera_model,
                            tf_listener_
                    );
                }
            }

            user_callback_(std::move(result));
        }

    public:
        CloudToCameraTransformer(ros::NodeHandle& n, const std::string& img_topic, const std::string& info_topic,
                                 const std::string& pcl_topic, std::function<void(Transform)> user_callback, bool do_box = false)
            : img_sub_(n, img_topic, 2)
            , info_sub_(n, info_topic, 2)
            , pcl_sub_(n, pcl_topic, 2)
            , synchronizer_(SYNC(10), img_sub_, info_sub_, pcl_sub_)
            , user_callback_(user_callback)
            , do_box_(do_box)
        {
            synchronizer_.registerCallback(&CloudToCameraTransformer::callback, this);
        }

        // Binding this, don't copy or move
        CloudToCameraTransformer(const CloudToCameraTransformer& that) = delete;
        CloudToCameraTransformer& operator=(const CloudToCameraTransformer& that) = delete;
    };
}
