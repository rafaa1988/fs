#pragma once

#include <ext/stdio_filebuf.h>
#include <hphlib/io/Pipe.h>
#include <ros/ros.h>
#include <thread>
#include <unistd.h>

namespace hphlib {
    /**
     * Capture STDOUT and STDERR of a given functor and forward to ROS logger
     *
     * @author Maximilian Schier
     */
    class RosStreamCapturer final {
    private:
        hphlib::Pipe stdout_pipe_;
        std::thread stdout_thread_;
        __gnu_cxx::stdio_filebuf<char> stdout_filebuf_;
        std::istream stdout_stream_;

        hphlib::Pipe stderr_pipe_;
        std::thread stderr_thread_;
        __gnu_cxx::stdio_filebuf<char> stderr_filebuf_;
        std::istream stderr_stream_;

        static hphlib::FileDescriptor checked_dup(int fd);

        static void checked_dup2(int from_fd, int to_fd);

    public:
        RosStreamCapturer();

        /**
         * Capture STDOUT and STDERR of the given functor and output to ROS console through separate threads. Threads will
         * be joined upon destruction of this unit
         * @tparam Fn Type of functor
         * @param functor Functor
         */
        template<typename Fn>
        void capture(Fn &&functor) {

            // Ensure capture wasn't called before, since pipe writers are closed after duplicating to STD* streams,
            // can just check if pipe writers still valid
            if (!stdout_pipe_.writer()) {
                throw std::logic_error("capture() may not be called more than once on RosStreamCapturer");
            }

            // Create copy of original STDOUT and STDERR
            hphlib::FileDescriptor old_stdout(checked_dup(STDOUT_FILENO));
            hphlib::FileDescriptor old_stderr(checked_dup(STDERR_FILENO));

            // Change STDOUT and STDERR to be pipe writers
            checked_dup2(stdout_pipe_.writer(), STDOUT_FILENO);
            checked_dup2(stderr_pipe_.writer(), STDERR_FILENO);

            // Close original pipe writers, otherwise would have two FDs to write to pipe
            stdout_pipe_.writer().close();
            stderr_pipe_.writer().close();

            // Execute whatever output should be captured
            functor();

            // Restore original STDOUT and STDERR
            checked_dup2(old_stdout, STDOUT_FILENO);
            checked_dup2(old_stderr, STDERR_FILENO);

            // Launch threads to forward streams to ROS
            stdout_thread_ = std::thread([this]() {
                std::string line;

                while (std::getline(this->stdout_stream_, line)) {
                    ROS_INFO_STREAM(line);
                }
            });

            stderr_thread_ = std::thread([this]() {
                std::string line;

                while (std::getline(this->stderr_stream_, line)) {
                    ROS_WARN_STREAM(line);
                }
            });
        }

        ~RosStreamCapturer();
    };
}