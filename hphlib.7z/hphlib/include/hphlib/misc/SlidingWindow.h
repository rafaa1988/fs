#pragma once

#include <chrono>
#include <vector>

namespace hphlib {

    /**
     * @brief Track values for given time period
     * Sliding window keeps track of stored objects and removes them when updated if time period of storage is exceeded.
     * Window does not guarantee order of insertion is maintained
     *
     * @tparam T Type of object to be stored in window
     * @author Maximilian Schier
     */
    template<typename T>
    class SlidingWindow final {
    private:
        std::vector<T> values_;
        std::vector<std::chrono::steady_clock::time_point> times_;
        std::chrono::seconds window_size_;

    public:
        /**
         * Initialize new window that keeps track of objects for the specified window size
         * @param window_size Duration to keep objects
         */
        explicit SlidingWindow(std::chrono::seconds window_size)
                : window_size_(window_size) {
        }

        /**
         * Get the number of elements stored in the window
         * @return Number of elements
         */
        const auto size() const {
            return values_.size();
        }

        /**
         * Return const iterator begin for values stored in window
         * @return Iterator
         */
        const auto begin() const {
            return values_.begin();
        }

        /**
         * Return const iterator end for values stored in window
         * @return
         */
        const auto end() const {
            return values_.end();
        }

        /**
         * Remove outdated objects from the window
         */
        void update() {

            // TODO: Could be optimized if vector remained sorted

            auto now = std::chrono::steady_clock::now();

            for (size_t i = 0; i < values_.size(); ++i) {
                if (times_[i] + window_size_ < now) {
                    // Pop and swap
                    std::swap(times_[i], times_.back());
                    std::swap(values_[i], values_.back());
                    times_.pop_back();
                    values_.pop_back();
                }
            }
        }

        /**
         * Add a value to the window and remove outdated objects from the window
         * @param val Value to add
         */
        void update(T val) {
            values_.push_back(std::move(val));
            times_.push_back(std::chrono::steady_clock::now());

            update();
        }
    };

}