#pragma once

#include <nav_msgs/Path.h>
#include "Spline.h"

namespace hphlib {
    class TrackSpline {
    private:
        Spline _x;
        Spline _y;

        Eigen::VectorXf _theta;
        Eigen::MatrixXf _theta_angle;
        Eigen::VectorXf _kappa;

    public:
        void fit(float alpha, float beta, float gamma, float h, float p, float h_spline, const Eigen::VectorXf &x,
                 const Eigen::VectorXf &y);

        void fit(float alpha, float beta, float gamma, float h, float p, float h_spline, bool circular,
                 const std::vector<Eigen::Vector2f> &track);

        void fit(float alpha, float beta, float gamma, float h, float p, float h_spline, bool circular,
                 const nav_msgs::Path &track);

        void calculateOrientationAndCurvature();

        inline Eigen::Vector2f p(float t) { return {_x(t), _y(t)}; }

        inline Eigen::Vector2f p(size_t i) { return {_x(i), _y(i)}; }

        inline Eigen::Vector2f operator()(float t) { return p(t); }

        inline Eigen::Vector2f operator()(size_t i) { return p(i); }

        inline Spline &x() { return _x; };

        inline Spline &y() { return _y; };

        inline Eigen::VectorXf &theta() { return _theta; };

        inline Eigen::MatrixXf &thetaAngle() { return _theta_angle; };

        inline Eigen::VectorXf &kappa() { return _kappa; };

        inline size_t size() { return _x.size(); }

        void slice(size_t start, size_t end);

        void shift(long offset);

        void offsetTime(float t);
    };
}