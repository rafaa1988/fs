#pragma once

#include <eigen3/Eigen/Eigen>

namespace hphlib {

    /**
     * A custom spline fittign class thta fits the data point with an 8th order polynomial that can be
     * optimized for velocity, acceleration or jerk minimization.
     * The algebraic spline minimizes a combination
     * of knot error and smoothness (as measured by the integral of the square
     * of the first three derivatives of the spline)
     * Closely follows the Matlab implementation found here: http://academic.csuohio.edu/simond/splines/
     */
    class Spline {
    private:
        Eigen::VectorXf _t;
        Eigen::VectorXf _y;
        Eigen::VectorXf _yp;
        Eigen::VectorXf _ypp;
        Eigen::VectorXf _yppp;

        float h;
        float h_spline;
        float h_factor;

        inline float lerp(float t, Eigen::VectorXf &y) {
            auto t1 = static_cast<long>(std::floor(t * (h_factor + 1)));
            auto t2 = static_cast<long>(std::ceil(t * (h_factor + 1)));
            float p = 1.0f - std::fmod(t, 1.0f / (h_factor)) * h_factor;
            return y(t1) * p + y(t2) * (1 - p);
        }

    public:
        /**
         * Fit the spline to the given data points
         * @param alpha Weight on first derivative
         * @param beta Weight on second deriative
         * @param gamma Weight on third derivative
         * @param h Knot distance
         * @param p Interior knot weight
         * @param knots Knot values
         * @param h_spline Spacing between output points in resulting spline
         */
        void fit(float alpha, float beta, float gamma, float h, float p, float h_spline, const Eigen::VectorXf &knots);

        inline Eigen::VectorXf &t() { return _t; }

        inline Eigen::VectorXf &y() { return _y; }

        inline Eigen::VectorXf &yp() { return _yp; }

        inline Eigen::VectorXf &ypp() { return _ypp; }

        inline Eigen::VectorXf &yppp() { return _yppp; }

        inline float y(float t) { return lerp(t, _y); }

        inline float yp(float t) { return lerp(t, _yp); }

        inline float ypp(float t) { return lerp(t, _ypp); }

        inline float yppp(float t) { return lerp(t, _yppp); }

        inline float y(size_t i) { return _y(i); }

        inline float yp(size_t i) { return _yp(i); }

        inline float ypp(size_t i) { return _ypp(i); }

        inline float yppp(size_t i) { return _yppp(i); }

        void slice(size_t start, size_t end);

        void shift(long offset);

        void offsetTime(float t);

        inline float operator()(float t) { return y(t); }

        inline float operator()(size_t i) { return y(i); }

        inline size_t size() { return _y.rows(); }
    };

}