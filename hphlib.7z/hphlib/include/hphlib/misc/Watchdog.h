#pragma once

#include <ros/publisher.h>
#include <ros/steady_timer.h>
#include <string>

namespace hphlib {
    class Watchdog final {
    private:
        std::string woof_;
        ros::Publisher pub_;
        ros::SteadyTimer timer_;
        bool enabled_;

        void callback(const ros::SteadyTimerEvent& ev);

    public:
        /**
         * Construct new watchdog that will not howl until told to howl, then repeatedly howl until told to shut the f up.
         * Obviously this watchdog must stay alive while the node is alive, but who would be so cruel to kill a dog?
         * @param n Node handle to howl on
         * @param woof Very special howl
         */
        explicit Watchdog(ros::NodeHandle& n, const std::string& topic = "wd", const std::string& woof = "a-woooooh");

        /**
         * Enable this watchdog
         */
        void enable();

        /**
         * Disable this watchdog
         */
        void disable();
    };
}