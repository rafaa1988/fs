#pragma once

#include <hphlib/io/UdpSocket.h>

namespace hphlib {

    class UdpMonitor final {
    private:
        hphlib::UdpSocket sock_;
        std::string name_;
        bool initial_frame_;
        bool log_next_frame_;

    public:

        class TimeoutException : public std::exception {};

        UdpMonitor(hphlib::UdpSocket sock, const std::string &name, int timeout_ms);

        /**
         * Receive a datagram and perform logging on the connection status
         * @param buffer Buffer to write to
         * @param buffer_length Length of buffer in bytes
         * @param sender_out Optional sender endpoint to write to
         * @return Number of bytes received
         * @throws TimeoutException on timeout
         */
        size_t receive(uint8_t *buffer, size_t buffer_length, hphlib::UdpSocket::Endpoint *sender_out = nullptr);
    };
}