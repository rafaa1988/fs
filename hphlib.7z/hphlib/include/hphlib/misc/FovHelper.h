#pragma once

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <eigen3/Eigen/Eigen>

class FovHelper {
private:
    std::string frame_id;
    float near_observation_distance;
    float far_observation_distance;
    float max_observation_angle;

    ros::Publisher fov_pub_;

public:
    FovHelper(ros::NodeHandle& n, std::string pub_topic, std::string frame_id, float near, float far, float max_angle);

    void publish();

    bool angleDistInFov(float angle, float dist);
    bool pointInFov(Eigen::Vector2f point);
};