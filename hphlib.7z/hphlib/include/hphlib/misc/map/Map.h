#pragma once

#include <string>
#include <algorithm>
#include <eigen3/Eigen/Eigen>
#include <nlohmann/json.hpp>

#include <hphlib/pcl.h>

#include "JsonDefinitions.h"

namespace hphlib {
    struct MapSection {
        std::vector<Eigen::Vector2f> vertices;
        std::vector<int> ids;
    };

    struct Map {
        std::vector<pcl::PointXYZRGBA> cones;
        std::vector<Eigen::Vector2f> drive_line;
        std::vector<MapSection> sections;

        inline pcl::PointCloud<pcl::PointXYZRGBA> coneCloud() {
            pcl::PointCloud<pcl::PointXYZRGBA> cloud;

            for (auto &cone: cones) {
                cloud.push_back(cone);
            }

            return cloud;
        }
    };
    // json helper for MapSection
    inline void to_json(nlohmann::json& j, const MapSection& map_section) {
        j = nlohmann::json{
                {"vertices", map_section.vertices},
                {"ids", map_section.ids}
        };
    }

    inline void from_json(const nlohmann::json& j, MapSection& map_section) {
        map_section.vertices = j.at("vertices").get<std::vector<Eigen::Vector2f>>();
        map_section.ids = j.at("ids").get<std::vector<int>>();
    }

    // json helper for Map
    inline void to_json(nlohmann::json& j, const Map& map) {
        j = nlohmann::json{
                {"cones", map.cones},
                {"drive_line", map.drive_line},
                {"sections", map.sections}
        };
    }

    inline void from_json(const nlohmann::json& j, Map& map) {
        map.cones = j.at("cones").get<std::vector<pcl::PointXYZRGBA>>();
        map.drive_line = j.at("drive_line").get<std::vector<Eigen::Vector2f>>();
        map.sections = j.at("sections").get<std::vector<MapSection>>();
    }
}