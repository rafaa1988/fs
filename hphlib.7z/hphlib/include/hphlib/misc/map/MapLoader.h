#pragma once

#include <hphlib/misc/map/Map.h>

namespace hphlib {
    class MapLoader {
    public:
    	static boost::optional<Map> load(std::string map_name);
    };
}