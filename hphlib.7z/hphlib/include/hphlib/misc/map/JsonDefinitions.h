#pragma once

#include <nlohmann/json.hpp>

// declaration of json serializer for not owned types
inline const char* color_to_name(uint32_t color) {
    switch(color) {
        case hphlib::REF_COLOR_BLUE:
            return "blue";
        case hphlib::REF_COLOR_YELLOW:
            return "yellow";
        case hphlib::REF_COLOR_FINISH:
            return "finish";
        case hphlib::REF_COLOR_RED:
            return "red";
        default:
            return "";
    }
}

inline uint32_t name_to_color(const std::string &name) {
    if (name == "blue")
        return hphlib::REF_COLOR_BLUE;
    else if (name == "yellow")
        return hphlib::REF_COLOR_YELLOW;
    else if (name == "finish")
        return hphlib::REF_COLOR_FINISH;
    else
        return hphlib::REF_COLOR_RED;
}

namespace nlohmann {
    template <>
    struct adl_serializer<pcl::PointXYZRGBA> {
        static void to_json(json& j, const pcl::PointXYZRGBA& p) {
            j = json{
                    {"x", p.x},
                    {"y", p.y},
                    {"type", color_to_name(p.rgba)},
            };
        }

        static void from_json(const json& j, pcl::PointXYZRGBA& p) {
            p.x = j.at("x");
            p.y = j.at("y");
            p.rgba = name_to_color(j.at("type"));
        }
    };


    template <>
    struct adl_serializer<Eigen::Vector2f> {
        static void to_json(json& j, const Eigen::Vector2f& v) {
            j = json::array({v.x(), v.y()});
        }

        static void from_json(const json& j, Eigen::Vector2f& v) {
            v.x() = j.at(0);
            v.y() = j.at(1);
        }
    };
}