#pragma once

#include <hphlib/optional.h>

namespace hphlib {
    /**
     * Basic digital low pass filter
     * @tparam T Type used for calculations
     * @author Maximilian Schier
     */
    template <typename T>
    class TLowPassFilter final {
    private:
        T rc_;
        bool is_first_;
        T last_;

    public:
        /**
         * Construct new low pass filter with given cut-off frequency
         * @param cutoff_hz Cut-off frequency in Hz
         */
        explicit TLowPassFilter(T cutoff_hz)
            : rc_(1 / (cutoff_hz * 2 * M_PI))
            , is_first_(true)
            , last_{} // Ignore incorrect -Werror=maybe-uninitialized
        {
        }

        /**
         * Feed a new value to the filter
         * @param val Current value
         * @param dt Time in seconds since last feed, value ignored for first feed, which just returns the input value
         * @return Value after filtering
         */
        T feed(T val, T dt) {
            // If first sample just return sample
            if (is_first_) {
                last_ = val;
                is_first_ = false;
                return val;
            }

            T alpha(dt / (rc_ + dt));

            last_ = last_ + (alpha * (val - last_));

            return last_;
        }
    };

    using LowPassFilter = TLowPassFilter<float>;
}