#pragma once

#include <functional>
#include <hphlib/io/Socket.h>

namespace hphlib {
    /**
     * Execute callback when socket becomes ready to read. 
     *
     * Usage example:
     *
     * @code
     * std::arrray<uint8_t, 64> buffer;
     * UdpSocket sock(1234);
     * PollService p(sock, [&] () {
     *     sock.receive(buffer.data(), buffer.size());
     * });
     *
     * ros::spin();
     * @endcode
     *
     * @author Maximilian Schier
     */
    class PollService final {
    private:
        int sock_fd_;
        std::function<void()> cb_;

    public:
        /**
         * Create new poll service. The poll service does not hold the specified socket, therefore it is the caller's
         * responsibility to ensure the socket remains alive.
         * @param sock Socket to be monitored for input events
         * @param callback Callback to be called repeatedly on input ready
         * @throws std::logic_error If socket is blocking
         * @throws std::runtime_error If failed to register with ROS poll manager
         */
        PollService(Socket& sock, std::function<void()> callback);
        ~PollService();

        // Cannot copy or move PollService, capturing this
        PollService(const PollService& that) = delete;
        PollService& operator=(const PollService& that) = delete;
    };
}
