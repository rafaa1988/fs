#pragma once

#include <cstdint>
#include <endian.h>
#include <limits>
#include <type_traits>
#include <cstring>

namespace hphlib {

    // Make sure system byte order is well defined
    static_assert(BYTE_ORDER == BIG_ENDIAN || BYTE_ORDER == LITTLE_ENDIAN, "System byte order must be either LE or BE");

    /**
     * Whether the target system has big endian byte order (true) or little endian byte order (false)
     */
    constexpr bool SYSTEM_IS_BE = BYTE_ORDER == BIG_ENDIAN;

    /**
     * Swap the byte order of the input number by performing a GCC built-in swap of correct size
     * @tparam T Type of number, must be arithmetic type of size 2, 4 or 8
     * @param val Input value
     * @return Value with byte order swapped
     */
    template <typename T>
    inline T endian_swap(T val) {
        static_assert(std::is_arithmetic<T>(), "T must be built-in arithmetic");
        static_assert(sizeof val == 2 || sizeof val == 4 || sizeof val == 8, "T must have size 2, 4 or 8");

        if (sizeof val == 2) {
            uint16_t t;
            std::memcpy(&t, &val, sizeof val);
            t = __builtin_bswap16(t);
            std::memcpy(&val, &t, sizeof val);
        } else if (sizeof val == 4) {
            uint32_t t;
            std::memcpy(&t, &val, sizeof val);
            t = __builtin_bswap32(t);
            std::memcpy(&val, &t, sizeof val);
        } else {
            uint64_t t;
            std::memcpy(&t, &val, sizeof val);
            t = __builtin_bswap64(t);
            std::memcpy(&val, &t, sizeof val);
        }

        return val;
    }

    /**
     * Convert native byte order to big endian
     * @tparam T Type of number, must be arithmetic type of size 2, 4 or 8
     * @param val Input value
     * @return Value with byte order converted
     */
    template <typename T>
    inline T native_to_big(T val) {
        if (SYSTEM_IS_BE) {
            return val;
        } else {
            return endian_swap(val);
        }
    }

    /**
     * Convert big endian to native byte order
     * @tparam T Type of number, must be arithmetic type of size 2, 4 or 8
     * @param val Input value
     * @return Value with byte order converted
     */
    template <typename T>
    inline T big_to_native(T val) {
        if (SYSTEM_IS_BE) {
            return val;
        } else {
            return endian_swap(val);
        }
    }

    /**
     * Convert native byte order to little endian
     * @tparam T Type of number, must be arithmetic type of size 2, 4 or 8
     * @param val Input value
     * @return Value with byte order converted
     */
    template <typename T>
    inline T native_to_little(T val) {
        if (!SYSTEM_IS_BE) {
            return val;
        } else {
            return endian_swap(val);
        }
    }

    /**
     * Convert little endian to native byte order
     * @tparam T Type of number, must be arithmetic type of size 2, 4 or 8
     * @param val Input value
     * @return Value with byte order converted
     */
    template <typename T>
    inline T little_to_native(T val) {
        if (!SYSTEM_IS_BE) {
            return val;
        } else {
            return endian_swap(val);
        }
    }

    /**
     * Wraps a packed value of specified byte order. This structure should be similar in use compared to
     * boost/endian/arithmetic, but can be used in packed structures which boost endians could not at the time of
     * writing. Additionally this struct works with floating point types where boost endians did not at the time of
     * writing.
     *
     * @tparam T Wrapped value type
     * @tparam BigEndian If true wrapped value is always stored as big endian in memory, if false as little endian
     *
     * @author Maximilian Schier
     */
    template <typename T, bool BigEndian>
    struct __attribute__((packed)) PackedEndian {
        T val;

        /**
         * Set the wrapped value to a new value
         * @param new_value New value in native byte order
         * @return Self
         */
        inline PackedEndian& operator=(T new_value) {
            if (BigEndian) {
                val = native_to_big(new_value);
            } else {
                val = native_to_little(new_value);
            }

            return *this;
        }

        /**
         * Get the wrapped value in native byte order
         * @return Value in native byte order
         */
        inline operator T() const {
            if (BigEndian) {
                return big_to_native(val);
            } else {
                return little_to_native(val);
            }
        }

        T native() const {
            return *this;
        }
    };
}

// Ensure system has standard conformant floating point numbers
static_assert(std::numeric_limits<float>::is_iec559,  "Float must be IEC 559/IEEE 754 conformant");
static_assert(std::numeric_limits<double>::is_iec559, "Double must be IEC 559/IEEE 754 conformant");


// Define convenience types for the template with all commonly used types.

using big_uint64_t = hphlib::PackedEndian<uint64_t, true>;
using big_uint32_t = hphlib::PackedEndian<uint32_t, true>;
using big_uint16_t = hphlib::PackedEndian<uint16_t, true>;
using big_int64_t  = hphlib::PackedEndian<int64_t, true>;
using big_int32_t  = hphlib::PackedEndian<int32_t, true>;
using big_int16_t  = hphlib::PackedEndian<int16_t, true>;

using little_uint64_t = hphlib::PackedEndian<uint64_t, false>;
using little_uint32_t = hphlib::PackedEndian<uint32_t, false>;
using little_uint16_t = hphlib::PackedEndian<uint16_t, false>;
using little_int64_t  = hphlib::PackedEndian<int64_t, false>;
using little_int32_t  = hphlib::PackedEndian<int32_t, false>;
using little_int16_t  = hphlib::PackedEndian<int16_t, false>;

using big_f64_t = hphlib::PackedEndian<double, true>;
using big_f32_t = hphlib::PackedEndian<float, true>;

using little_f64_t = hphlib::PackedEndian<double, false>;
using little_f32_t = hphlib::PackedEndian<float, false>;