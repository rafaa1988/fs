#pragma once

#include <boost/asio/io_service.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/future.hpp>
#include <atomic>
#include <condition_variable>
#include <mutex>

namespace hphlib {
    class ParallelizedProcessingService final {
    private:
        size_t no_threads_;
        boost::asio::io_service io_service_;
        boost::thread_group thread_group_;
        boost::asio::io_service::work work_;

    public:
        explicit ParallelizedProcessingService(size_t no_threads)
            : no_threads_(no_threads)
            , work_(io_service_)
        {
            for (size_t i = 0; i < no_threads; ++i) {
                thread_group_.create_thread([this] () { this->io_service_.run(); });
            }
        }

        // Binding this, don't copy or move
        ParallelizedProcessingService(const ParallelizedProcessingService& that) = delete;
        ParallelizedProcessingService(ParallelizedProcessingService&& that) = delete;
        ParallelizedProcessingService& operator=(const ParallelizedProcessingService& that) = delete;
        ParallelizedProcessingService& operator=(ParallelizedProcessingService&& that) = delete;

        ~ParallelizedProcessingService() {
            io_service_.stop();
            thread_group_.join_all();
        }

        template <typename InputIt, typename OutputIt, typename Fn>
        void parallel_transform(InputIt ibegin, InputIt iend, OutputIt obegin, const Fn& processor) {

            // Don't do any overhead if this is a single threaded processor
            if (no_threads_ < 2) {
                std::transform(ibegin, iend, obegin, processor);
                return;
            }

            // Decay the type returned by the transformer, this is our output type that we use for the tasks and futures
            using R = typename std::decay<decltype(processor(*ibegin))>::type;

            // Determine the actual amount of items to process
            size_t count = std::distance(ibegin, iend);

            // Keep tasks and futures in vector
            std::vector<boost::packaged_task<R>> tasks;
            std::vector<boost::shared_future<R>> futures;

            // Important: Do not resize vectors later or all references will be broken, therefore ensure enough space
            tasks.reserve(count);
            futures.reserve(count);

            std::for_each(ibegin, iend, [&] (const auto& in) {
                tasks.emplace_back([&] () {
                    return processor(in);
                });

                futures.emplace_back(tasks.back().get_future());

                io_service_.post([&t = tasks.back()] () {
                    t();
                });
            });

            boost::wait_for_all(futures.begin(), futures.end());

            std::transform(futures.begin(), futures.end(), obegin, [] (const boost::shared_future<R>& future) {
                return future.get();
            });
        }

    };
}