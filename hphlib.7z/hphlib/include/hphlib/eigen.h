#pragma once

#include <eigen3/Eigen/Eigen>

#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>

namespace Eigen {
    template <typename M>
    inline M rotateMatrix(const M &in, long offset) {
        if (!offset || !in.rows() || !in.cols())
            return in;

        M out(in.rows(), in.cols());

        if (offset > 0)
            offset = offset % in.rows();
        else
            offset = in.rows() - (-offset % in.rows());

        int rest = in.rows() - offset;
        out.topRows(offset) = in.bottomRows(offset);
        out.bottomRows(rest) = in.topRows(rest);
        return out;
    }

    template <typename M>
    inline M shiftMatrix(const M &in, long offset) {
        if (!offset || !in.rows() || !in.cols())
            return in;

        M out = M::Zero(in.rows(), in.cols());

        if (offset > 0) {
            offset = offset % in.rows();
            int rest = in.rows() - offset;
            out.bottomRows(rest) = in.topRows(rest);
        } else {
            offset = in.rows() - (-offset % in.rows());
            out.topRows(offset) = in.bottomRows(offset);
        }

        return out;
    }

    inline void extractValues(const MatrixXf &in, std::initializer_list<Eigen::VectorXf*> out_list )
    {
        if (static_cast<size_t>(in.cols()) != out_list.size()) {
            throw std::runtime_error("Matrix column count does not match number of output variables");
        }

        for (int i = 0; i < in.rows(); i++) {
            size_t j = 0;
            for (auto vp: out_list) {
                (*vp)(i) = in(i, j++);
            }
        }
    }

    template<class V>
    inline void extractValues(const std::vector<V> &in, std::initializer_list<Eigen::VectorXf*> out_list )
    {
        if (in.empty())
            return;

        if (static_cast<size_t>(in[0].size()) != out_list.size()) {
            throw std::runtime_error("Matrix column count does not match number of output variables");
        }

        for (size_t i = 0; i < in.size(); i++) {
            size_t j = 0;
            for (auto vp: out_list) {
                (*vp)(i) = in[i](j++);
            }
        }
    }

    inline void linearFit(const ArrayXf &x, const ArrayXf &y, float &m, float &b) {
        // do a linear regression as described here:
        // https://web.archive.org/web/20150715022401/http://faculty.cs.niu.edu/~hutchins/csci230/best-fit.htm
        long count = x.count();
        float x_sum = x.sum();
        float y_sum = y.sum();
        float x_sum2 = (x * x).sum();
        float xy_sum = (x * y).sum();
        float x_mean = x_sum / count;
        float y_mean = y_sum / count;

        m = (xy_sum - x_sum * y_mean) / (x_sum2 - x_sum * x_mean);
        b = y_mean - m * x_mean;
    }


    inline void linearFit(const std::vector<Vector2f> v, float &m, float &b) {
        ArrayXf x(v.size());
        ArrayXf y(v.size());

        for (size_t i = 0; i < v.size(); i++) {
            x(i) = v[i].x();
            y(i) = v[i].y();
        }

        linearFit(x, y, m, b);
    }


    inline nav_msgs::Path vectorListToPath(std::vector<Vector2f> vector) {
        nav_msgs::Path path;

        for (auto &v: vector) {
            geometry_msgs::PoseStamped p;
            p.pose.position.x = v.x();
            p.pose.position.y = v.y();
            path.poses.push_back(p);
        }

        return path;
    }
}