#pragma once

#include <boost/asio/steady_timer.hpp>

namespace hphlib {

    /**
     * @brief Shutdown boost::asio::io_service on ROS shutdown
     *
     * Register a service unit on a boost IO service to periodically check the ROS status and stop all async operations
     * of the IO service on ROS shutdown. This monitor will also spin ROS. Note that the spinning frequency is quite
     * low, therefore this node should NOT be used with subscribers that require prompt message delivery.
     *
     * Usage example:
     *
     * @code
     * boost::asio::io_service service;
     *
     * ShutdownMonitor monitor(service);
     *
     * // ... Synchronous initialization of other service units, i.e.:
     * boost::asio::ip::udp::socket(service);
     * // ... Init socket and receive async
     *
     * service.run(); // Run until ROS shuts down
     *
     * // If synchronous device shutdown desired:
     * service.reset();
     * // ... Shutdown now
     * @endcode
     *
     * @author Maximilian Schier
     */
    class ShutdownMonitor {
    private:
        // Handle to the service, used to stop the service on ROS shutdown
        boost::asio::io_service &service_;

        // Steady timer used to perform periodic ROS spins at
        boost::asio::steady_timer timer_;

        // Timepoint when next scheduling should occur
        std::chrono::steady_clock::time_point next_tick_;

        /**
         * Schedule the next tick and recurse until ROS is shutdown
         */
        void schedule_next_tick();

    public:
        /**
         * Instantiate a new monitor stopping the given service
         * @param service Service to stop on ROS shutdown
         */
        explicit ShutdownMonitor(boost::asio::io_service &service);
    };
}